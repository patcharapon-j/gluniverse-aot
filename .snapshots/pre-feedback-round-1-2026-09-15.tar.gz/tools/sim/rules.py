"""Rule values for the Wings of Freedom Phase 1 simulator, read from data/ YAML when the module loads.

Nothing here restates a table. Every number, row, and list comes from the YAML file named beside it
(ADR-0012). Where a value is written only in a YAML prose field, it is parsed from that field with a
pattern that raises if the wording changes, so a later YAML fix either flows through or stops the run.
Procedures (the order of steps, what a test means) live in engine.py; the values they use live here.
"""
import itertools
import os
import re

import yaml

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
DATA = os.path.join(ROOT, "data")


def load(rel):
    with open(os.path.join(DATA, rel)) as fh:
        return yaml.safe_load(fh)


def covers(results, total):
    lo, hi = results.get("min"), results.get("max")
    return (lo is None or total >= lo) and (hi is None or total <= hi)


def walk(node):
    if isinstance(node, dict):
        yield node
        for v in node.values():
            yield from walk(v)
    elif isinstance(node, list):
        for v in node:
            yield from walk(v)


def parse(pattern, text, what):
    m = re.search(pattern, " ".join(text.split()))
    if not m:
        raise ValueError(f"cannot read {what} from its YAML text: {text[:160]!r}")
    return m


def pos_name(pid):
    return pid.replace("-", " ").title()


WORDS = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9,
         "ten": 10, "twelve": 12}


def count_of(word, what):
    """A count written as a digit or a word ("three"); raises on anything else."""
    w = str(word).strip().lower()
    if w.isdigit():
        return int(w)
    if w in WORDS:
        return WORDS[w]
    raise ValueError(f"cannot read a count for {what} from {word!r}")


def thousands(text, what):
    return int(parse(r"([\d,]+)", text, what).group(1).replace(",", ""))


FRACTIONS = {"half": 2, "third": 3, "quarter": 4, "fifth": 5, "sixth": 6}


def fraction_of(text, what):
    """A share written as words ("a third", "two thirds", "one half") or a percentage ("33%"), as a number from 0
    to 1; raises on anything else."""
    t = " ".join(str(text).strip().lower().split())
    m = re.fullmatch(r"([\d.]+)%", t)
    if m:
        return float(m.group(1)) / 100
    m = re.fullmatch(r"(a|an|one|two|three|four|five) (half|halves|thirds?|quarters?|fifths?|sixths?)", t)
    if m:
        num = 1 if m.group(1) in ("a", "an") else count_of(m.group(1), what)
        word = "half" if m.group(2) == "halves" else m.group(2).rstrip("s")
        return num / FRACTIONS[word]
    raise ValueError(f"cannot read a share for {what} from {text!r}")


def tolerance_of(value, what):
    """A target's tolerance as ADR-0014 (as amended in decision batch 5, OQ-127) and the tuning files write it:
    "exactly N" (a median, read exactly), "A% to B%" or "A to B" (both edges inside), "at most X", "at least X"
    (the edge inside), or "under X" (the edge outside). A bare whole number is "exactly". Raises on anything else.
    A band may be followed by a comma and the reading it names (decision batch 5, 5-19: "at most 0.05, deaths
    through the end of the Titan Engagement; ..."): the band is read before the first comma, and the reading is
    returned as written for the caller to check (targets.py).
    Returns dict(kind "exact" or "band", value, lo, hi, lo_in, hi_in, text, reading)."""
    if isinstance(value, int):
        return dict(kind="exact", value=value, lo=None, hi=None, lo_in=True, hi_in=True, text=f"exactly {value}",
                    reading=None)
    band, _, reading = " ".join(str(value).split()).partition(",")
    out = _band_of(band.strip(), value, what)
    out["reading"] = reading.strip() or None
    return out


def _band_of(t, value, what):
    m = re.fullmatch(r"(?:the median kill round is )?exactly (\d+)", t)
    if m:
        return dict(kind="exact", value=int(m.group(1)), lo=None, hi=None, lo_in=True, hi_in=True, text=t)
    m = re.fullmatch(r"([\d.]+)(%?) to ([\d.]+)(%?)", t)
    if m:
        return dict(kind="band", value=None, lo=float(m.group(1)), hi=float(m.group(3)), lo_in=True, hi_in=True, text=t)
    m = re.fullmatch(r"(at most|at least|under) ([\d.]+)(%?)", t)
    if m:
        x = float(m.group(2))
        if m.group(1) == "at least":
            return dict(kind="band", value=None, lo=x, hi=None, lo_in=True, hi_in=True, text=t)
        return dict(kind="band", value=None, lo=None, hi=x, lo_in=True, hi_in=m.group(1) == "at most", text=t)
    raise ValueError(f"cannot read a tolerance for {what} from {value!r}")


class Rules:
    def __init__(self):
        self._dice()
        self._mind()
        self._harm()
        self._gear()
        self._engagement()
        self._titans()
        self._character()
        self._treatment()
        self._read()
        self._scars()
        self._carrying_and_horses()
        self._round_and_setup()
        self._case_dimensions()

    # ------------------------------------------------------------------ Chapter 1
    def _dice(self):
        dp = load("core/dice-pool.yaml")
        faces = {tuple(d["success_faces"]) for d in dp["die_types"]}
        if len(faces) != 1 or len(next(iter(faces))) != 1:
            raise ValueError("dice-pool.yaml: the simulator expects one success face shared by every die type")
        self.success_face = next(iter(faces))[0]
        comp = {c["id"]: c for c in dp["components"]}
        self.min_base_dice = comp["penalty"]["min_base_dice_after"]
        bd = load("core/bonus-dice-sources.yaml")
        self.bonus_cap = min(comp["bonus"]["max"], bd["cap_per_roll"])
        src = {s["id"]: s for s in bd["sources"]}
        self.grounded_bonus = src["grounded-titan"]["dice_per_unit"]
        self.help_max = src["help"]["max_units"]

    # ------------------------------------------------------------------ Chapter 3, mind
    def _mind(self):
        sr = load("mind/stress-responses.yaml")
        self.sr_rows = []
        for row in sr["table"]["rows"]:
            r = dict(id=row["id"], results=row["results"], lasting=row["duration"] == "lasting", pen={},
                     push_stress=0, lose=0, zero=False, spend_turns=0, stress=0)
            for e in row["effects"]:
                t = e["type"]
                if t == "penalty":
                    for en in e["entries"]:
                        r["pen"][en] = r["pen"].get(en, 0) + e["dice"]
                elif t == "push-stress":
                    r["push_stress"] += e["amount"]
                elif t == "lose-successes":
                    r["lose"] += e["amount"]
                elif t == "zero-successes":
                    r["zero"] = True
                elif t == "spend-next-turn":
                    r["spend_turns"] += e.get("turns", 1)
                elif t == "stress-gain":
                    r["stress"] += e["amount"]
                else:
                    raise ValueError(f"stress-responses.yaml: effect type {t} is not modelled")
            self.sr_rows.append(r)
        self.sr_by_id = {r["id"]: r for r in self.sr_rows}

        fr = load("mind/fear-rolls.yaml")
        self.fear_triggers = [t["id"] for t in fr["triggers"]]
        self.fear_rows = []
        for row in fr["table"]["rows"]:
            r = dict(id=row["id"], results=row["results"], stress=0, next_pen=0, spend_action=False,
                     spend_turns=0, no_react=False, scar=False)
            for e in row["effects"]:
                t = e["type"]
                if t == "stress-gain":
                    r["stress"] += e["amount"]
                elif t == "next-roll-penalty":
                    r["next_pen"] += e["dice"]
                elif t == "spend-next-action":
                    r["spend_action"] = True
                elif t == "spend-next-turn":
                    r["spend_turns"] += e.get("turns", 1)
                elif t == "no-reactions":
                    r["no_react"] = True
                elif t == "gain-scar":
                    r["scar"] = True
                else:
                    raise ValueError(f"fear-rolls.yaml: effect type {t} is not modelled")
            self.fear_rows.append(r)

        gr = load("mind/grief.yaml")
        self.grief_max = gr["maximum"]
        # grief.yaml, amount: the deaths of one day passing give each soldier 1 Grief in total (healing.yaml, each_day)
        parse(r"So do the deaths of one day passing", next(a["limit"] for a in gr["gaining"]["amount"] if "limit" in a),
              "Grief for the deaths of one day")
        parse(r"every other living soldier in the Squad", gr["gaining"]["who"]["other_death"],
              "who gains Grief for a death outside a Titan Engagement")

    def sr_index(self, total):
        for i, r in enumerate(self.sr_rows):
            if covers(r["results"], total):
                return i
        raise ValueError(total)

    def fear_row(self, total):
        for r in self.fear_rows:
            if covers(r["results"], total):
                return r
        raise ValueError(total)

    # ------------------------------------------------------------------ Chapter 3, harm
    def _harm(self):
        ci = load("harm/critical-injuries.yaml")
        self.ci_per_held = ci["worsening"]["per_held_injury"]
        self.ci_location_rows = [(r["results"], r["injury_location"]) for r in ci["injury_location_table"]["rows"]]
        self.ci_tables = {}
        for loc, t in ci["tables"].items():
            rows = []
            for r in t["rows"]:
                row = dict(id=r["id"], results=r["results"], instant_death=bool(r.get("instant_death", False)),
                           down=r.get("down") == "until_treated", lethal=bool(r.get("lethal", False)),
                           limit=r.get("time_limit"), dr_pen=r.get("death_roll_penalty") or 0, pen={}, pen_perm={},
                           stress=0, perm=bool(r.get("permanent_effects")), repeat=r.get("repeat_row"), loc=loc,
                           heal_days=r.get("healing_days"))
                for perm, e in [(False, e) for e in (r.get("effects") or [])] + \
                               [(True, e) for e in (r.get("permanent_effects") or [])]:
                    if e["type"] == "penalty":
                        for en in e["entries"]:
                            row["pen"][en] = row["pen"].get(en, 0) + e["dice"]
                            if perm:     # healing.yaml, healing_time, heals: permanent effects stay after it heals
                                row["pen_perm"][en] = row["pen_perm"].get(en, 0) + e["dice"]
                    elif e["type"] == "stress-gain":
                        row["stress"] += e["amount"]
                    else:
                        raise ValueError(f"critical-injuries.yaml: effect type {e['type']} is not modelled")
                if not row["instant_death"] and row["heal_days"] is None:
                    raise ValueError(f"critical-injuries.yaml: {row['id']} has no healing_days")
                rows.append(row)
            self.ci_tables[loc] = dict(rows=rows, cap=t["non_lethal_cap"], by_id={r["id"]: r for r in rows})

        dr = load("harm/death-rolls.yaml")
        self.death_attribute = dr["death_roll"]["attribute"]
        self.death_needs = dr["death_roll"]["needs"]
        self.death_outcomes = [(o["successes"], o["id"]) for o in dr["outcomes"]]
        self.limit_slows = {tl["id"]: tl.get("slows_to") for tl in dr["time_limits"]}
        self.limit_ids = [tl["id"] for tl in dr["time_limits"]]
        if self.limit_slows.get("day") != "stabilized":
            raise ValueError("death-rolls.yaml: a day limit no longer slows to stabilized")

        # healing.yaml: the interim day (decision batch 5, 5-2, OQ-120) and each day's steps, in order
        hl = load("harm/healing.yaml")
        parse(r"one day passes at the start of each session, before the interim issue", hl["day_passes"]["interim"],
              "the interim day")
        parse(r"each_day runs as written, and Stress and Grief do not change", hl["day_passes"]["interim"],
              "the interim day's Stress and Grief")
        steps = [" ".join(x.split()) for x in hl["each_day"]]
        keys = ("Hold a care window", "with a day limit runs out and causes a Death Roll",
                "gets back all Health lost to damage", "healing time drops by 1 day. One that reaches 0 heals")
        if len(steps) != len(keys) or any(k not in s for k, s in zip(keys, steps)):
            raise ValueError(f"healing.yaml each_day changed; engine.Fight.day_passes follows the old steps: {steps}")
        self.lethal_heal_floor = int(parse(r"It stays at (\d+) day until it is stabilized",
                                           hl["healing_time"]["lethal_injuries"], "a lethal injury's healing time").group(1))

    def death_outcome(self, successes):
        for res, oid in self.death_outcomes:
            if covers(res, successes):
                return oid
        raise ValueError(successes)

    # ------------------------------------------------------------------ Chapter 4
    def _gear(self):
        fl = load("gear/falls.yaml")
        self.fall_bands = [b["id"] for b in fl["height"]["bands"]]
        self.fall_adds = {b["id"]: b["adds"] for b in fl["height"]["bands"]}
        self.fall_damage_rows = [(r["results"], r["damage"]) for r in fl["damage_table"]["rows"]]
        self._fall_height_text = " ".join(fl["height"]["steps"])

        od = load("gear/odm-gear.yaml")
        self.full_gas = od["gas"]["full_gas_rating"]
        self.gas_dice = od["gas_roll"]["dice"]

        fr = load("gear/field-repair.yaml")
        self.field_repair_attribute = fr["attribute"]
        self.field_repair_needs = fr["needs"]

        si = load("gear/standard-issue.yaml")
        self.funding = si["funding"]["until_funding_rules"]
        row = next(r for r in si["by_funding"] if r["funding"] == self.funding)
        self.issue = dict(row)
        self.issue["blade_set_rating"] = si["every_row"]["blade_set_rating"]
        ss = load("gear/squad-supply.yaml")
        self.supply = next(r for r in ss["stock"]["by_funding"] if r["funding"] == self.funding)

    def gas_roll_dice(self, pc, pushed_odm):
        if not pc:
            return self.gas_dice["squadmate"]
        return self.gas_dice["after_pushed_odm_roll"] if pushed_odm else self.gas_dice["standard"]

    def fall_damage(self, total):
        for res, dmg in self.fall_damage_rows:
            if covers(res, total):
                return dmg
        raise ValueError(total)

    # ------------------------------------------------------------------ Chapter 5
    def _engagement(self):
        ar = load("engagement/anchor-ratings.yaml")
        self.positions = list(ar["positions"])
        self.ratings = {}
        for r in ar["ratings"]:
            steps = {}
            for st in r["steps"]:
                kinds = {k for k, key in (("foot", "on_foot"), ("mounted", "mounted"), ("odm", "odm")) if st.get(key)}
                steps[frozenset(st["between"])] = dict(kinds=kinds, fly=st.get("fly_roll"))
            self.ratings[r["id"]] = dict(name=r["name"], steps=steps)
        g = ar["grounded_titan"]
        m = parse(r"joining two of ([a-z-]+), ([a-z-]+), and ([a-z-]+)", g["on_foot_steps"], "grounded on-foot Positions")
        self.grounded_close = set(m.groups())
        m = parse(r"step between ([a-z-]+) and ([a-z-]+) that a move on foot or an ODM move", g["open_rating"],
                  "the grounded Open step")
        self.grounded_extra_pair = frozenset(m.groups())
        self.grounded_extra_rating = next(rid for rid, r in self.ratings.items()
                                          if re.search(rf"\bAt the {r['name']} rating", g["open_rating"]))
        m = parse(r"holds ([a-z-]+) relative to it then holds ([a-z-]+) instead", g["ends"], "grounding's end")
        self.grounded_end_move = (m.group(1), m.group(2))
        self.fall_raise_ratings = {rid for rid, r in self.ratings.items() if r["name"] in self._fall_height_text}
        self.fall_high = set()
        for pid in self.positions:
            for part in re.findall(r"([A-Z][A-Za-z ]+?) or ([A-Z][A-Za-z ]+?) is (low|high)", self._fall_height_text):
                if pos_name(pid) in part[:2] and part[2] == "high":
                    self.fall_high.add(pid)
        if not self.fall_high:
            raise ValueError("falls.yaml: no Position reads as a high fall")
        # falls.yaml, height, steps: the fall's reference Titan is the Focus Titan the soldier holds the closest
        # Position to (decision batch 5, 5-5, OQ-123). With one Focus Titan it is always that Titan.
        m = parse(r"find the fall's reference Titan: the Focus Titan relative to which the soldier held the closest "
                  r"Position when they fell, in the order ([A-Z][a-z]+ [A-Z][a-z]+), ([A-Z][a-z]+ [A-Z][a-z]+), "
                  r"([A-Z][a-z]+ [A-Z][a-z]+), ([A-Z][a-z]+)\.", self._fall_height_text, "the fall's reference Titan")
        self.fall_reference_order = [next(p for p in self.positions if pos_name(p) == g) for g in m.groups()]
        pos = load("engagement/positions.yaml")
        m = parse(r"holds ([a-z-]+) relative to that Titan once the fall", pos["falls_land"]["from_on_body_or_blind_spot"],
                  "where a fall lands")
        self.fall_lands = m.group(1)
        m = parse(r"only the step from ([a-z-]+) to ([a-z-]+), on foot", pos["moves"]["down_soldier"]["allowed"],
                  "the Down soldier's move")
        self.down_step = (m.group(1), m.group(2))

        at = load("engagement/attention.yaml")
        self.tests = {t["id"]: t for t in at["tests"]}
        m = parse(r"in the order ([a-z-]+), ([a-z-]+), ([a-z-]+), ([a-z-]+)\.", self.tests["nearest"]["meaning"],
                  "the nearest order")
        self.nearest_rank = {p: i for i, p in enumerate(m.groups())}
        self.ladders = {l["id"]: list(l["rungs"]) for l in at["ladders"]}
        self.flags = [f["id"] for f in at["flags"]]
        ba = at["break_attention"]
        self.ba_needs = dict(ba["needs"])
        self.decoys = {d["id"]: d for d in ba["decoys"]}
        m = parse(r"holds ([a-z-]+) or ([a-z-]+) relative to the Titan", self.decoys["feint"]["requirement"], "the Feint's Positions")
        self.feint_positions = set(m.groups())
        m = parse(r"holds ([a-z-]+) or ([a-z-]+) relative to the Titan", self.decoys["thrown-cloak"]["requirement"], "the cloak's Positions")
        self.cloak_positions = set(m.groups())
        # attention.yaml, draw_attention, requirements: not from Distant (decision batch 5, 5-8, OQ-113)
        m = parse(r"holds a Position other than ([a-z-]+) relative to that Titan", " ".join(at["draw_attention"]["requirements"]),
                  "Draw Attention's Position requirement")
        self.draw_barred_positions = {m.group(1)}

        th = load("engagement/titan-harm.yaml")
        self.part_kinds = {k["id"]: k for k in th["body_part_kinds"]}
        self.grounding_kinds = {k["id"] for k in th["body_part_kinds"] if "grounded" in k["when_broken"]}
        self.flare_blocking_kinds = {k["id"] for k in th["body_part_kinds"] if "Flare" in k["when_broken"]}
        self.part_states = list(th["states"]["order"])
        self.broken = len(self.part_states) - 1
        self.body_strike_needs = th["body_part_strikes"]["needs"]
        m = parse(r"struck from ([a-z-]+), ([a-z-]+), or ([a-z-]+)", " ".join(th["grounded"]["effects"]), "grounded reach")
        self.grounded_reach = set(m.groups())

        gb = load("engagement/grab.yaml")
        esc = {e["id"]: e for e in gb["escapes"]}
        self.break_free_needs = esc["break-free"]["needs"]
        self.break_free_lifted_penalty = esc["break-free"]["lifted_penalty"]
        self.pry_loose_needs = esc["pry-loose"]["needs"]
        self.pry_loose_lifted_penalty = esc["pry-loose"]["lifted_penalty"]
        arm = esc["strike-the-holding-arm"]
        self.grab_reach_before = set(arm["reach_before_lift"])
        self.grab_reach_after = set(arm["reach_after_lift"])
        self.grab_strike_penalty = arm["strike_penalty"]
        self.grip_toughness = gb["grab_lands"]["grip_toughness"]
        # grab.yaml, grab_lands, steps, in order: the hold before the crush (decision batch 5, 5-6, OQ-124)
        self.grab_steps = [s["id"] for s in gb["grab_lands"]["steps"]]
        parse(r"already Grabbed", next(s["text"] for s in gb["grab_lands"]["steps"] if s["id"] == "crush"),
              "the crush on a soldier already Grabbed")
        m = parse(r"holding arm is the first ([a-z]+) in the Titan's stat block",
                  next(s["text"] for s in gb["grab_lands"]["steps"] if s["id"] == "hold"), "the holding arm's kind")
        self.grab_kind = m.group(1)

        sc = load("engagement/size-classes.yaml")
        self.size_classes = {c["id"]: c for c in sc["classes"]}

        rd = load("engagement/round.yaml")
        m = parse(r"cards numbered (\d+) to (\d+)", rd["initiative_cards"]["set"], "the initiative cards")
        self.cards = (int(m.group(1)), int(m.group(2)))

        st = load("engagement/squad-tactics.yaml")
        self.tactics = {t["id"]: t for t in st["tactics"]}
        m = parse(r"gains (\d+) more success", self.tactics["hamstring-line"]["effect"], "Hamstring Line's successes")
        self.hamstring_extra = int(m.group(1))

        es = load("engagement/engagement-setup.yaml")
        self.setup = es

        self.engagement_tuning = load("engagement/tuning.yaml")

    # ------------------------------------------------------------------ Chapter 6
    def _titans(self):
        idx = load("titans/index.yaml")
        self.titan_index = idx
        for l in idx["ladders"]:
            self.ladders[l["id"]] = list(l["rungs"])
        self.titan_blocks = {}
        for tid in list(idx["standard_titans"].values()) + [a["id"] for a in idx["abnormals"]]:
            self.titan_blocks[tid] = load(f"titans/{tid}.yaml")
        ref = self.engagement_tuning["simulation_reference_titan"]
        self.titan_blocks[ref["id"]] = ref
        self.titan_tuning = load("titans/tuning.yaml")

    def titan_ids(self):
        idx = self.titan_index
        return list(idx["standard_titans"].values()) + [a["id"] for a in idx["abnormals"]]

    # ------------------------------------------------------------------ Chapters 2 and 5 builds
    def _character(self):
        sq = load("character/squadmates.yaml")
        self.templates = {t["id"]: t for t in sq["templates"]}
        self.attribute_ids = list(next(iter(self.templates.values()))["attributes"].keys())
        self.talent_names = {}
        # A dice Talent's condition on an entry it names (talents.yaml, condition): the gear item the roll must use
        # for the Talent's dice to add, as Horsemanship's dodge only with the horse (decision batch 5, 5-3, OQ-121).
        self.talent_gear = {}
        for d in walk(load("character/talents.yaml")):
            if "id" in d and "names" in d and d.get("type") == "dice":
                self.talent_names[d["id"]] = list(d["names"])
                for entry, text in (d.get("condition") or {}).items():
                    if entry not in d["names"]:
                        raise ValueError(f"talents.yaml {d['id']}: condition on {entry}, which it does not name")
                    m = re.fullmatch(r"while mounted, with the (horse) as the ([a-z-]+)'s gear item", " ".join(str(text).split()))
                    if not m or m.group(2) != entry:
                        raise ValueError(f"talents.yaml {d['id']}: condition {text!r} is not one the simulator reads")
                    self.talent_gear.setdefault(d["id"], {})[entry] = m.group(1)
        self.entry_attribute = {}
        for d in walk(load("character/action-catalog.yaml")):
            if "id" in d and "attribute" in d and isinstance(d["attribute"], str):
                self.entry_attribute.setdefault(d["id"], d["attribute"])
        b = self.engagement_tuning["builds"]
        self.talent_dice_on = list(b["talent_dice_on"])
        self.builds = {}
        for bid in ("rookie", "veteran", "levi_grade"):
            spec = b[bid]
            attrs = {}
            for a in self.attribute_ids:
                attrs[a] = spec["attributes"].get(a, spec["attributes"].get("every_other_attribute"))
            items = spec["item_ratings"]
            def rating(key):
                return items.get(key, items.get("every_other_item", items.get("every_item")))
            self.builds[bid] = dict(attributes=attrs, health=spec["health"], resolve_total=spec["resolve"],
                                    scars=spec["scars"], min_stress=spec["minimum_stress"],
                                    stress=spec["stress_when_a_fight_begins"], odm=rating("odm_gear"),
                                    horse=rating("horse"), blade=rating("blade_set"),
                                    talent=spec["talent_level"])

    # ------------------------------------------------------------------ Chapter 3, treatment and engagement end
    def _treatment(self):
        ti = load("harm/treat-injury.yaml")
        self.treat_entry = ti["entry"]
        self.treat_attribute = ti["attribute"]
        self.treat_needs = ti["needs"]
        self.treat_self_penalty = int(parse(r"penalty of (\d+) base dice", ti["patients"]["self"],
                                            "the self-treatment penalty").group(1))
        self.care_help_max = int(parse(r"At most (\d+) soldiers Help one roll", ti["care_windows"]["help"],
                                       "the care window's Help limit").group(1))
        cat = {d["id"]: d for d in walk(load("character/action-catalog.yaml")) if "id" in d and "kind" in d}
        if cat[self.treat_entry].get("without_gear") != "attribute_alone":
            raise ValueError("action-catalog.yaml: treat-injury without a medical kit is no longer attribute_alone")
        self.catalog = cat
        bd = {s["id"]: s for s in load("core/bonus-dice-sources.yaml")["sources"]}
        self.medical_supply_dice = bd["medical-supplies"]["dice_per_unit"]
        ss = load("gear/squad-supply.yaml")
        uses = {u["id"]: u for u in ss["medical_uses"]}
        self.care_bonus_units = int(parse(r"(\d+) medical unit", uses["care-bonus"]["spends"], "the care bonus").group(1))
        # The steps a Titan Engagement's end resolves, in order (engagement-end.yaml, steps). engine.finish
        # runs these ids in this order and stops if the list changes.
        self.end_steps = [s["id"] for s in load("harm/engagement-end.yaml")["steps"]]
        sc = load("core/stress-changes.yaml")
        red = {r["id"]: r for r in sc["reductions"]}
        gains = {g["id"]: g for g in sc["gains"]}
        self.relief_end = red["engagement-ends"]["amount"]
        self.relief_nape = red["nape-kill"]["amount"]
        self.cover_stress = gains["cover"]["amount"]
        self.min_stress_per_scar = sc["minimum"]["per_scar"]
        fr = load("gear/field-repair.yaml")
        self.care_field_repair = "one Field Repair roll" in " ".join(fr["outside_titan_engagement"]["rolls"].split())
        gr = load("mind/grief.yaml")
        amt = gr["gaining"]["amount"]
        self.grief_per_engagement = amt[0]["grief"]
        self.grief_numb = next(a["grief"] for a in amt if "Numb" in a["who"])
        dr = load("harm/death-rolls.yaml")
        m = parse(r"a (turn) or (engagement) limit that the soldier survived becomes (day)",
                  dr["outside_titan_engagement_restart"], "the limit after an outside Death Roll")
        self.limit_after_outside_roll = m.group(3)

    # ------------------------------------------------------------------ Chapter 5, Read and Call It
    def _read(self):
        rd = load("engagement/read.yaml")
        self.read_entry = rd["read"]["entry"]
        self.read_attribute = self.catalog[self.read_entry]["attribute"]
        self.read_needs = rd["read"]["needs"]
        src = parse(r"bonus-dice-sources\.yaml, ([a-z-]+)\)", rd["read"]["from_distant"], "the Read's Distant bonus").group(1)
        bd = {s["id"]: s for s in load("core/bonus-dice-sources.yaml")["sources"]}
        self.read_distant_dice = bd[src]["dice_per_unit"]
        self.read_facts = {f["id"]: list(f["for"]) for f in rd["facts"]}
        ci = rd["call_it"]
        self.call_it_successes = int(parse(r"(\d+) of the Read's successes", ci["successes_needed"], "Call It's successes").group(1))
        self.call_it_sharp = int(parse(r"With Sharp Call, (\d+)", ci["successes_needed"], "Sharp Call's successes").group(1))
        src = parse(r"bonus-dice-sources\.yaml, ([a-z-]+)\)", ci["effect"], "Call It's bonus").group(1)
        self.call_it_dice = bd[src]["dice_per_unit"]

    # ------------------------------------------------------------------ Chapter 3, Scars
    SCAR_IDS = {"the-closing-hand", "survivors-guilt", "unsteady-hands", "cannot-look-away", "numb", "reckless-blade",
                "nerves-on-edge", "fear-of-falling", "blood-on-the-blade", "carrying-their-weight", "second-guessing",
                "old-nightmare"}

    def _scars(self):
        sc = load("mind/scars.yaml")
        self.scar_max = sc["gaining"]["maximum"]
        rows = {}
        for r in sc["table"]["rows"]:
            row = dict(id=r["id"], results=list(r["results"]), pen={}, cond_pen={}, stress=0, fear_total=0,
                       fear_triggers=[], squadmate_rerolls=bool(r.get("squadmate_rerolls")))
            for e in r["effects"]:
                if e["type"] == "penalty":
                    target = row["cond_pen"] if e.get("applies_to") else row["pen"]
                    for en in e["entries"]:
                        target[en] = target.get(en, 0) + e["dice"]
                elif e["type"] == "stress-gain":
                    row["stress"] += e["amount"]
                elif e["type"] == "fear-roll-total":
                    row["fear_total"] += e["amount"]
                    m = parse(r"for the ([a-z-]+)(?: or ([a-z-]+))? trigger", r["trigger"], f"{r['id']}'s triggers")
                    row["fear_triggers"] = [x for x in m.groups() if x]
                elif e["type"] != "other":
                    raise ValueError(f"scars.yaml: effect type {e['type']} is not modelled")
            rows[r["id"]] = row
        if set(rows) != self.SCAR_IDS:
            raise ValueError(f"scars.yaml: the Scar rows changed; engine.py applies each row's trigger by id: {sorted(rows)}")
        self.scar_rows = rows
        self.scar_by_result = {res: rid for rid, r in rows.items() for res in r["results"]}

    # ------------------------------------------------------------------ Chapter 4, carrying and horses
    def _carrying_and_horses(self):
        ca = load("gear/carrying.yaml")
        self.carry_limit_add = int(parse(r"strength \+ (\d+)", ca["limit"]["formula"], "the carrying limit").group(1))
        items = {}
        for row in ca["items_counted"]:
            w = row["what"]
            key = ("spare" if "spare gas canister" in w else "blade_spare" if "Blade Set not in the handles" in w
                   else "medical_kit" if "medical kit" in w else "tool_kit" if "tool kit" in w
                   else "comrade" if "comrade" in w else None)
            if key:
                items[key] = row["items"]
        if set(items) != {"spare", "blade_spare", "medical_kit", "tool_kit", "comrade"}:
            raise ValueError(f"carrying.yaml: items_counted rows changed: {items}")
        self.carry_items = items
        self.overloaded_spends_action = "also spends their action" in " ".join(ca["overloaded"]["effect"].split())
        si = load("gear/standard-issue.yaml")
        self.specialty_items = {r["specialty"]: (r["item"], r["rating"]) for r in si["by_specialty"]["rows"]}
        self.issue_rows = {r["funding"]: r for r in si["by_funding"]}
        self.interim = si["interim_issue"]

    # ------------------------------------------------------------------ Chapter 5, round, Wings, swaps, setup
    def _round_and_setup(self):
        rd = load("engagement/round.yaml")
        self.round_steps = [s["id"] for s in rd["round_steps"]]
        for need in ("wings", "deal", "swap", "play", "end"):
            if need not in self.round_steps:
                raise ValueError(f"round.yaml: round step {need} is gone")
        sq = load("character/squadmates.yaml")
        self.wing_max = sq["wing"]["max_squadmates_per_wing"]
        self.squadmate_pushes = next(r for r in sq["rules_applicability"] if r["rule"] == "Push")["applies"]
        self.squadmate_covers = next(r for r in sq["rules_applicability"]
                                     if r["rule"].startswith("Cover (as the Covering"))["applies"]
        m = parse(r"since the previous wings step, a soldier died, left the Titan Engagement, became Down, or became "
                  r"Grabbed, or a Focus Titan entered or died", rd["wings"]["when"], "when Wings may change")
        self.tracker_moments = rd["gm_tracker"]["per_round_order"]
        es = self.setup

        def weights(table, key):
            out = {}
            for row in es[table]["rows"]:
                out[row[key]] = out.get(row[key], 0) + len(row["results"]) / 6
            return out
        self.setup_anchor = weights("anchor_rating", "anchor_rating")
        self.setup_size = weights("size_class", "size_class")
        self.setup_medium_abnormal = weights("medium_abnormal", "titan")
        self.setup_background = [(len(r["results"]) / 6, list(r["clocks"])) for r in es["background_titans"]["rows"]]
        for rid in self.setup_anchor:
            if rid not in self.ratings:
                raise ValueError(f"engagement-setup.yaml names Anchor Rating {rid}, which anchor-ratings.yaml lacks")

        # the retreat clock and the retreat (decision batch 5, 5-1 and 5-10; OQ-119, OQ-126)
        self.retreat_clock = int(es["retreat_clock"])
        bt = load("engagement/background-titans.yaml")
        ticks = {t["id"]: " ".join(t["text"].split()) for t in bt["ticks"]["rows"]}
        parse(r"after every Background Titan's clock has filled and every full clock has resolved \(full_clock\), fill "
              r"1 segment of the retreat clock", ticks["retreat-clock"], "when the retreat clock fills")
        parse(r"A flare never fills the retreat clock", ticks["flare"], "the flare and the retreat clock")
        # decision batch 6, 6-1 (OQ-134): a retreat stops the Background Titans' clocks and the retreat clock only;
        # engine.Fight.end_steps fills the Regeneration clock every round, retreat or not
        parse(r"During a retreat no Background Titan's clock fills and the retreat clock does not fill\. A Focus Titan's "
              r"Regeneration clock still fills at the regeneration end step", bt["ticks"]["stopped"],
              "which clocks a retreat stops")
        parse(r"A retreat does not stop it", load("engagement/titan-harm.yaml")["regeneration"]["tick"],
              "the Regeneration clock during a retreat")
        parse(r"or when the retreat clock is full", bt["retreat"]["starts"], "the retreat clock starting a retreat")
        eff = {e["id"]: " ".join(e["text"].split()) for e in bt["retreat"]["effects"]}
        for need in ("no-entries", "moves", "order", "no-return", "actions"):
            if need not in eff:
                raise ValueError(f"background-titans.yaml retreat effects: {need} is gone")
        parse(r"their move comes before their action", eff["order"], "the retreat's order")
        # decision batch 5b, 5-15: engine.Fight.can_nape and nape_strike refuse a Nape strike during a retreat
        parse(r"no Nape strike is made during a retreat, on a soldier's own turn or through Hook and Cut", eff["actions"],
              "no Nape strike in a retreat")
        parse(r"A stay-with-a-comrade move \(option 4\) comes after the action taken for that comrade", eff["order"],
              "the retreat's option 4 exception")
        parse(r"A move on a turn whose action is lift-comrade comes after the lift", eff["order"], "the retreat's lift exception")
        m = parse(r"one of these actions for that comrade: (treat-injury); or, for a Grabbed comrade, (break-free) on their "
                  r"behalf with Pry Loose, a (body-part-strike) against the holding arm, or (break-attention) against the "
                  r"holding Titan", eff["moves"], "the actions option 4 follows")
        self.retreat_stay_actions = set(m.groups())
        parse(r"Toward distant: one step along a shortest chain of steps their move can make", eff["moves"], "retreat option 1")
        parse(r"A soldier who can make none of these may let go", eff["moves"], "the retreat's letting go")
        fl = load("engagement/engagement-flow.yaml")["ending"]
        parse(r"A Titan Engagement always ends", fl["always_ends"], "the retreat clock ending every Titan Engagement")
        parse(r"every soldier who still holds a Position in it dies, left to the Titans", fl["left_behind"], "left behind")
        pos = load("engagement/positions.yaml")
        parse(r"holds distant relative to every Focus Titan, and is not Down, Grabbed, or carried", pos["leaving"]["who"],
              "who can leave")
        parse(r"except during a retreat", pos["leaving"]["returning"], "no return during a retreat")
        parse(r"holds on-body or blind-spot relative to a Focus Titan and is not Grabbed or carried",
              pos["moves"]["letting_go"]["who"], "who can let go")
        ee = load("harm/engagement-end.yaml")
        parse(r"two soldiers who have both left the Titan Engagement count as holding the same Position. A soldier who has "
              r"left never counts as holding the same Position as, or one step from, a soldier who still holds a Position",
              ee["soldiers_who_left"]["same_position"], "the Position test for soldiers who left")
        parse(r"reads their last Positions", ee["positions_read"], "the end steps' last Positions")

    # ------------------------------------------------------------------ case dimensions stated in the tuning files
    def _case_dimensions(self):
        t5 = self.engagement_tuning
        t6 = self.titan_tuning
        # "No kill" is the share of fights that end with the Focus Titan alive, under the retreat clock (decision batch
        # 5, 5-10); no column or band names a round horizon any more.
        if "no_kill" not in t5["prepared_squad_kill"]["columns"] or "no_kill" not in t6["targets"]["large"]["at_the_reference_start"]:
            raise ValueError("tuning files: the no_kill column or the Large band is gone")
        for k in list(t5["prepared_squad_kill"]["columns"]) + list(t6["targets"]["large"]["at_the_reference_start"]):
            if re.search(r"no_kill_in_\d+_rounds", k):
                raise ValueError(f"tuning files: {k} names a round horizon, which decision batch 5 removed")
        # Every target's tolerance (ADR-0014, as amended in decision batch 5, 5-11, OQ-127), from the tuning files,
        # cross-checked against data/titans/tuning.yaml (adr_0014_targets_quoted, bands).
        tol5 = {"prepared_squad_kill": t5["prepared_squad_kill"]["tolerance"], "solo_nape": t5["solo_nape"]["tolerance"],
                "grab": t5["grab"]["tolerance"], "gas": t5["gas"]["tolerance"]}
        self.tolerances = {
            "median_kill_round": tolerance_of(tol5["prepared_squad_kill"]["median_kill_round"], "prepared_squad_kill"),
            "rookie_fresh_cut": tolerance_of(tol5["solo_nape"]["rookie_fresh_cut"], "solo_nape, rookie_fresh_cut"),
            "levi_grade": tolerance_of(tol5["solo_nape"]["levi_grade"], "solo_nape, levi_grade"),
            "grab_alone": tolerance_of(tol5["grab"]["alone"], "grab, alone"),
            "grab_every_cell": tolerance_of(tol5["grab"]["every_cell"], "grab, every_cell"),
            "gas_standard": tolerance_of(tol5["gas"]["median_rounds"], "gas, median_rounds"),
            "gas_pushed": tolerance_of(tol5["gas"]["median_rounds_pushing_every_round"], "gas, pushing every round"),
        }
        cell_keys = [k for k in tol5["grab"] if re.fullmatch(r"stress_\d+_grief_\d+", k)]
        if len(cell_keys) != 1:
            raise ValueError(f"tuning.yaml grab.tolerance: expected one named cell, got {cell_keys}")
        m = re.fullmatch(r"stress_(\d+)_grief_(\d+)", cell_keys[0])
        self.grab_named_cell = (int(m.group(1)), int(m.group(2)))
        self.tolerances["grab_named_cell"] = tolerance_of(tol5["grab"][cell_keys[0]], f"grab, {cell_keys[0]}")
        bands6 = t6["targets"]["adr_0014_targets_quoted"]["bands"]
        for key6, key5 in (("rookie_fresh_cut", "rookie_fresh_cut"), ("levi_grade", "levi_grade")):
            if tolerance_of(bands6["lone_strike"][key6], key6) != self.tolerances[key5]:
                raise ValueError(f"the tuning files disagree on the {key6} tolerance")
        for key6, key5 in (("alone", "grab_alone"), ("every_cell", "grab_every_cell"), (cell_keys[0], "grab_named_cell")):
            if tolerance_of(bands6["grab"][key6], key6) != self.tolerances[key5]:
                raise ValueError(f"the tuning files disagree on the Grab {key6} tolerance")
        if tolerance_of(bands6["prepared_squad"], "prepared_squad")["value"] != self.tolerances["median_kill_round"]["value"]:
            raise ValueError("the tuning files disagree on the prepared-Squad median")
        m = parse(r"past a band's edge by at most (\w+) standard errors is re-run on a second seed and judged on the figure "
                  r"pooled over both runs", bands6["second_seed"], "the second-seed rule for targets")
        self.target_standard_errors = count_of(m.group(1), "the second-seed rule's standard errors")
        parse(r"Each range or limit in targets is its own band, read exactly, and a median is read exactly", bands6["per_table"],
              "the per-table bands' reading")
        self.fights_per_case = thousands(t5["prepared_squad_kill"]["fights_per_case"], "fights per case")
        # simulator review round 3, Minor 7: the safety cap and the baseline and template roles, read from their text
        model = t5["prepared_squad_kill"]["model"]
        self.safety_cap = int(parse(r"max_rounds is a safety cap of (\d+) rounds", model["retreat"],
                                    "the safety cap").group(1))
        files_cap = int(parse(r"a safety cap of (\d+) that no fight should reach", " ".join(str(f) for f in
                              t5["probes"]["files"]) if isinstance(t5["probes"]["files"], list) else
                              str(t5["probes"]["files"]), "the probes' safety cap").group(1))
        if files_cap != self.safety_cap:
            raise ValueError("data/engagement/tuning.yaml: the probes and the retreat model name different safety caps")
        m = parse(r"starting at distant: (\w+) cutters and (\w+) strikers", model["squad"], "the baseline roles")
        self.baseline_roles = (["cutter"] * count_of(m.group(1), "cutters")
                               + ["striker"] * count_of(m.group(2), "strikers"))
        m = parse(r"uses the (\w+) and (\w+) templates as strikers and the (\w+) and (\w+) as cutters", model["squad"],
                  "the template roles")
        self.template_roles = [(m.group(1).lower(), "striker"), (m.group(2).lower(), "striker"),
                               (m.group(3).lower(), "cutter"), (m.group(4).lower(), "cutter")]
        # Chapter 5's rows that change one Titan value: prepared_squad_kill, medium_severity and
        # alternatives_rejected. Each row's values are read from its case text, so a relabelled row runs its new
        # values or stops the run.
        tiers = list(self.size_classes["medium"]["severity"])
        self.ch5_value_rows = []
        for row in t5["prepared_squad_kill"]["medium_severity"]:
            vals = [int(x) for x in parse(r"^Severity (\d+), (\d+), (\d+)$", row["case"], "a medium_severity row").groups()]
            if len(vals) != len(tiers):
                raise ValueError(f"size-classes.yaml severity tiers {tiers} and the row {row['case']!r} disagree")
            self.ch5_value_rows.append(("medium_severity", row["case"], {"sev": dict(zip(tiers, vals))},
                                        "sev" + "".join(map(str, vals))))
        ref_size = self.engagement_tuning["simulation_reference_titan"]["size_class"]
        for row in t5["prepared_squad_kill"]["alternatives_rejected"]:
            m = parse(r"^([A-Z][a-z]+), ([A-Z][A-Za-z ]+?) (\d+)(?: \([^)]*\))?$", row["case"], "an alternatives_rejected row")
            size = m.group(1).lower()
            if size not in self.size_classes:
                raise ValueError(f"alternatives_rejected row {row['case']!r}: {size} is not a Size Class")
            stem = m.group(2).lower().replace(" ", "_")
            fields = [k for k, v in self.size_classes[size].items() if k.startswith(stem) and isinstance(v, int)]
            if len(fields) != 1:
                raise ValueError(f"alternatives_rejected row {row['case']!r}: {m.group(2)} names no one Size Class value")
            over = {"titan": {fields[0]: int(m.group(3))}}
            short = {"regeneration_clock": "regen", "nape_depth": "nd"}.get(fields[0], fields[0])
            key = short + m.group(3)
            if size != ref_size:
                over["size_class"] = size
                key = f"{size}_{key}"
            self.ch5_value_rows.append(("alternatives_rejected", row["case"], over, key))
        ab = t6["targets"]["abnormals"]
        self.bar_fights = ab["sampling"]["fights_per_row"]
        self.bar_standard_errors = ab["sampling"]["standard_errors"]
        self.bar_median_min = int(parse(r"median kill round is (\d+) or later", " ".join(ab["not_trivial"]),
                                        "the bar's median floor").group(1))
        self.bar_median_max = int(parse(r"median kill round is (\d+) or sooner", " ".join(ab["winnable"]),
                                        "the bar's median ceiling").group(1))
        # the fresh lone cut
        sn = t5["solo_nape"]
        self.solo_stresses = [int(parse(r"start_stress_(\d+)$", c, "a fresh-cut column").group(1)) for c in sn["columns"]]
        self.solo_attempts = count_of(parse(r"up to (\w+) times until it succeeds", sn["model"], "Break Attention attempts").group(1),
                                      "Break Attention attempts")
        self.solo_trials = thousands(parse(r"([\d,]+) trials per cell", sn["model"], "fresh-cut trials").group(0), "fresh-cut trials")
        self.solo_band = tuple(float(x) for x in parse(r"between ([\d.]+)% and ([\d.]+)%", sn["target"], "the lone band").groups())
        if (self.tolerances["rookie_fresh_cut"]["lo"], self.tolerances["rookie_fresh_cut"]["hi"]) != self.solo_band:
            raise ValueError("tuning.yaml solo_nape: the target's band and its tolerance disagree")
        self.lone_trials = thousands(parse(r"([\d,]+) lone fights per row", sn["lone_fight"]["probe"], "lone trials").group(0), "lone trials")
        # the Grab
        g = t5["grab"]
        self.grab_cells = []
        for c in g["comrades_close"]["cells"]:
            m = parse(r"^stress_(\d+)_grief_(\d+)$", c, "a Grab cell")
            self.grab_cells.append((int(m.group(1)), int(m.group(2))))
        self.grab_alone_trials = thousands(parse(r"([\d,]+) per row", g["lone"]["trials"], "alone Grab trials").group(0), "alone Grab trials")
        self.grab_templates_trials = thousands(parse(r"\(([\d,]+) for templates_alone\)", g["lone"]["trials"], "template Grab trials").group(1), "template Grab trials")
        self.grab_cell_trials = thousands(g["comrades_close"]["trials"], "Grab cell trials")
        hr = g["health_reports"]
        m = parse(r"(\w+) at Health (\d) to (\d), and (\w+) at Health (\d)", hr["model"], "the Health reports' earlier injuries")
        self.health_earlier = {}
        for h in range(int(m.group(2)), int(m.group(3)) + 1):
            self.health_earlier[h] = count_of(m.group(1), "earlier injuries")
        self.health_earlier[int(m.group(5))] = count_of(m.group(4), "earlier injuries")
        m = parse(r"one comrade at Stress (\d) with Grief (\d)", hr["model"], "the Health reports' comrade")
        self.health_comrade = (int(m.group(1)), int(m.group(2)))
        self.health_rows = {int(parse(r"^health_(\d+)$", k, "a Health row").group(1)): v
                            for k, v in hr["with_earlier_injuries"].items()}
        self.health_fresh = {int(parse(r"^health_(\d+)$", k, "a Health row").group(1)): v
                             for k, v in hr["fresh_victim_lone"].items()}
        if set(self.health_rows) != set(self.health_earlier):
            raise ValueError("tuning.yaml grab.health_reports: the rows and the earlier-injury text disagree")
        self.grab_templates_alone = []
        for row in g["lone"]["templates_alone"]:
            tid = parse(r"^(\w+) \(", row["case"], "a template Grab row").group(1).lower()
            if tid not in self.templates:
                raise ValueError(f"tuning.yaml grab.templates_alone names {tid}, not a template")
            self.grab_templates_alone.append((tid, row["death"]))
        m = parse(r"Rescuers: Rookies with Strength (\d)", g["model"], "the rescuer's Strength")
        self.rescuer_strength = int(m.group(1))
        # the Jam test
        jt = t5["jam_test"]
        self.jam_rounds = count_of(parse(r"for (\w+) rounds", jt["model"], "the Jam test's rounds").group(1), "Jam rounds")
        self.jam_trials = thousands(parse(r"([\d,]+) fights per cell", jt["model"], "Jam trials").group(0), "Jam trials")
        self.jam_columns = []
        for c in jt["columns"]:
            m = parse(r"^help_(\d+)(_covered)?$", c, "a Jam column")
            self.jam_columns.append((c, int(m.group(1)), bool(m.group(2))))
        self.jam_tiers = [k for k in jt["tiers"] if k in jt]
        jam_target = next(x for x in t6["targets"]["every_standard_table"] if "Jam test" in x)
        m = parse(r"stays under ([a-z0-9. %]+?), for (\w+) and for (\w+) Titans", jam_target, "the Jam limit")
        self.jam_limit = m.group(1)
        self.jam_limit_value = fraction_of(m.group(1), "the Jam limit")
        self.jam_titan_counts = [count_of(m.group(2), "the Jam test's Titans"), count_of(m.group(3), "the Jam test's Titans")]
        # data/titans/tuning.yaml, simulator_cases: the mixed pairs of the Jam test
        mixed = next((x for x in t6["simulator_cases"] if "in the Jam test" in x), "")
        parse(r"Two Focus Titans of different Size Classes in the Jam test, and a standard Titan with the Abnormal", mixed,
              "the Jam test's mixed pairs")
        std = self.titan_index["standard_titans"]
        by_size = list(std.items())
        self.jam_mixed_pairs = [(a, b) for (sa, a), (sb, b) in itertools.combinations(by_size, 2) if sa != sb]
        self.jam_mixed_pairs += [(t, ab["id"]) for t in std.values() for ab in self.titan_index["abnormals"]]
        # gas
        gas = t5["gas"]
        self.gas_trials = thousands(parse(r"([\d,]+) canisters per case", gas["figures"], "gas trials").group(0), "gas trials")
        self.gas_target = [(int(a), float(b)) for a, b in re.findall(r"median (\d+), mean ([\d.]+)", gas["target"])]
        if len(self.gas_target) != 2:
            raise ValueError("tuning.yaml gas.target: expected two medians with means")
        if [self.tolerances["gas_standard"]["value"], self.tolerances["gas_pushed"]["value"]] != [m_ for m_, _ in self.gas_target]:
            raise ValueError("tuning.yaml gas: the target's medians and its tolerance disagree")
        # the dodges reported beside the targets
        rb = t5["reported_beside_targets"]
        self.dodge_reports = {}
        for key, tid in (("rookie_dodge", None), ("flier_template_dodge", "flier")):
            pairs = [(int(s), float(p)) for s, p in re.findall(r"Severity (\d) ([\d.]+)%", rb[key])]
            st = int(parse(r"Stress (\d)", rb[key], f"{key}'s Stress").group(1))
            self.dodge_reports[key] = dict(template=tid, stress=st, figures=pairs,
                                           responses="without Stress Responses" not in rb[key])


R = Rules()

# The four Position ids of data/engagement/anchor-ratings.yaml (positions), named for the procedures in
# engine.py and policy.py. A renamed or added Position stops the run here.
D, IR, OB, BS = "distant", "in-reach", "on-body", "blind-spot"
if set(R.positions) != {D, IR, OB, BS}:
    raise ValueError(f"anchor-ratings.yaml positions changed: {R.positions}")
# data/gear/odm-gear.yaml, strikes: a Nape strike, and a Body Part strike made from these Positions, need
# working ODM Gear unless the Titan is grounded.
m = parse(r"made from ([A-Z][a-z]+ [A-Z][a-z]+) or ([A-Z][a-z]+ [A-Z][a-z]+), need",
          load("gear/odm-gear.yaml")["strikes"]["rule"], "where strikes need ODM Gear")
ODM_STRIKE_POSITIONS = {p for p in R.positions if pos_name(p) in m.groups()}
m = parse(r"gains a ([a-z]+) Critical Injury with cannot_be_lethal true",
          next(s["text"] for s in load("engagement/grab.yaml")["grab_lands"]["steps"] if s["id"] == "crush"),
          "the Grab's crush")
GRAB_CRUSH_LOCATION = m.group(1)
