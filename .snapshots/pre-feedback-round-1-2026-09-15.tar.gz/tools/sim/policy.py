"""Every choice a player or Squadmate makes in the simulator, in one place.

These are the baseline and sensitivity policies Chapters 5 and 6 state (data/engagement/tuning.yaml,
prepared_squad_kill, model; solo_nape; lone_fight; grab; jam_test; data/titans/tuning.yaml, probes,
baseline_policy), ported from the committed probes and applied through engine.py's rules, and the policies
this simulator adds for the rules the probes left out. A choice the chapters leave open is marked POLICY
CHOICE with the reason. The rules engine never chooses; it calls these functions and checks what they return.

Squad (build_squad):
- 4 Rookie player characters at their fight-start Stress, starting at Distant: two cutters and two strikers,
  listed cutters first unless sheet_order says otherwise (the order chooses nothing under decision batch
  4). The template row uses the Slayer and Flier templates as strikers and the Brawler and Hunter as cutters.
  Helper Squadmates are the ADR-0014 Rookie build at fight-start Stress 1 (a reference choice: squadmates.yaml
  builds a Squadmate from a template), in the role the case names. A reader is the Tactician template (the
  simulator case names a Tactician) at Stress 1. health, kit, and pry_loose change every soldier's Health, give
  every soldier a medical kit, or give the player characters Pry Loose.
Baseline turns (take_turn):
- cutter: Distant or Blind Spot to In Reach; strike the more damaged unbroken leg, then arms, Helped by up to
  2 comrades (cut_order eyes first moves to On Body for the eyes). With Hook and Cut held, first take Break
  Attention with ODM Gear when a striker at Blind Spot with an unspent action holds Attention or has 2 Bonus
  Dice from others' Openings and grounding.
- striker: to Blind Spot (changing a canister when dry), then a Nape strike spending every Opening it did
  not create and Help up to the cap: eager strikes whenever it can; wait needs 2 such Bonus Dice or round 3.
  A striker with Jammed ODM Gear against a standing Titan becomes a cutter.
- helper: to In Reach, and Helps.
- dodge "harm": dodge every behavior with a Grab, a Critical Injury, or a knock-loose that would make the
  soldier fall; "lethal": only a Grab and a Critical Injury that can be lethal. dodge_help and dodge_cover
  add Help and Covering on the dodge (the full-fight Jam test).
- on a Grab: every soldier but a striker ready to cut with 2 Bonus Dice goes for the holding arm, without
  Help, Pushing toward the arm's next state; with escapes, Help on Break Free and a Break Attention rescue
  when the hand cannot be struck; with Pry Loose, a comrade at On Body pries instead when the arm needs more
  successes than Break Free. The Grabbed soldier always tries Break Free.
- decoyer, screen, screen2, rider, draw_attention: as in the Chapter 5 and 6 probes (see below). A cutter who
  would take Draw Attention from Distant, which the rule bars (attention.yaml, draw_attention), takes its turn
  without it and is counted in draws_barred.
- reader: stays at Distant and Reads every turn it has not already Called It on the Titan's Next Behavior;
  picks the attention-ladder fact first on an Abnormal whose ladder is hidden, then next-behavior and Call It.
- treat_in_fight: a cutter or helper whose Position holds a comrade who is Down or holds an untreated lethal
  turn-limit Critical Injury takes Treat Injury on them before its own action.
- carry: a cutter or helper whose Position holds a Down comrade lifts them, carries them to Distant, and sets
  them down there.
- Squad Tactics when held: Hook and Cut after any Break Attention success, by a ready comrade (strikers
  first); Hamstring Line on the first Helped leg strike; Clear the Hand by the first rescuer at In Reach once
  the victim is lifted; Fall Back at the wings step for soldiers at On Body or Blind Spot with no working
  ODM Gear against a standing Titan.
- Wings (wings): at each wings step the rules allow, each living Squadmate in sheet order goes on the Wing of
  the next living player character without one, taking those not Down or Grabbed first and otherwise sheet
  order, one Squadmate a Wing. Swaps (swaps): every cutter whose card comes after a striker's is paired with
  that striker; the engine makes each pair within one step whose soldiers are in no earlier swap, so the cut
  lands before the Nape strike.
- The end of a Titan Engagement: aftermath patients are taken Down patients first, then by the largest Death
  Roll penalty; each gets the soldier within one step, alive, not Down, and not yet treating, with the largest
  Treat Injury pool, and treats themself only when no comrade qualifies and they are not Down. In the care
  window every living soldier not Down makes one Treat Injury roll: the tasks, in order untreated lethal
  injuries, untreated Down rows, other untreated injuries, and reviving a Down soldier, go to the largest pools
  first; spare soldiers Help each lethal patient's roll up to the Help limit, with a medical unit on it, and a
  player character Covers a roll that Pushes. Then each soldier not Down makes one Field Repair on their own
  worn ODM Gear, or else the first comrade's.
- Promotion (promote, in the sequences): each player whose character died or retired chooses the living
  Squadmate in sheet order with the fewest untreated Critical Injuries; the contest's D6 settles a Squadmate
  two players choose (squadmates.yaml, promotion, contested).
- A Down soldier crawls from In Reach to Distant.
The retreat (retreat_turn; background-titans.yaml, retreat), the probes' policy (tools/probes/chapter-05/fight.py),
with each forced move before the action: a soldier at a Grabbed comrade's Position pries (with Pry Loose, as the
rescue does), strikes the holding arm, or with the escapes takes Break Attention, and stays (option 4); from
elsewhere they step toward the hand and then act. A soldier carrying a comrade heads out. Otherwise the nearest
Down comrade (fewest steps, then card): at the same Position, Treat Injury on a turn-limit lethal injury in the
treat_in_fight rows and stay, or lift them and head out; from elsewhere a step toward them and a lift on arrival.
Otherwise head out: a step toward Distant (In Reach first), leaving at Distant, and letting go from On Body or
Blind Spot when no step can be made. No Nape strike, Hook and Cut, Read, or Draw Attention is taken in a retreat.
Lone (lone_turn), Grab cell rescuers, and the Jam test holder are documented at their functions.
"""
from dice import make_build, make_template
from rules import R, D, IR, OB, BS

TACTIC_IDS = {"hook": "hook-and-cut", "hamstring": "hamstring-line", "clear": "clear-the-hand",
              "fallback": "fall-back"}
LEG = "leg"
ARM = R.grab_kind
EYES = next(iter(R.flare_blocking_kinds))
READER_TEMPLATE = "tactician"


# ---------------------------------------------------------------------- the Squad
def build_squad(f):
    cfg = dict(f.cfg)
    tactics = [TACTIC_IDS.get(x, x) for x in cfg.get("tactics", [])]
    for tid in tactics:
        if tid not in R.tactics:
            raise ValueError(tid)
    cfg["tactics"] = tactics
    f.cfg = cfg
    st = cfg.get("stress")
    everyone = bool(cfg.get("mounted_start"))
    over = {}
    if cfg.get("health"):
        over["health"] = cfg["health"]
    if cfg.get("kit"):
        over["kit"] = cfg["kit"]
    if cfg.get("template"):
        specs = list(R.template_roles)     # data/engagement/tuning.yaml, prepared_squad_kill, model, squad
        pcs = [(make_template(tid, tid, stress=1 if st is None else st, **over), role) for tid, role in specs]
    else:
        roles = cfg.get("roles") or list(R.baseline_roles)     # prepared_squad_kill, model, squad
        rt = ("pry-loose",) if cfg.get("pry_loose") else ()
        pcs = [(make_build(cfg.get("build", "rookie"), f"pc{i}", stress=st, rule_talents=rt, **over), role)
               for i, role in enumerate(roles)]
    order = cfg.get("sheet_order")
    if order:
        first = "cutter" if order == "cutters_first" else "striker"
        pcs = [x for x in pcs if x[1] == first] + [x for x in pcs if x[1] != first]
    for s, role in pcs:
        f.add(s, role, mounted=everyone)
    for i in range(cfg.get("squadmates", 0)):
        role = cfg.get("squadmate_role", "helper")
        s = make_build("rookie", f"sm{i}", pc=False, stress=st, **over)
        f.add(s, role, mounted=everyone or role in ("rider", "screen2"))
    for i in range(cfg.get("readers", 0)):
        s = make_template(READER_TEMPLATE, f"reader{i}", pc=False, stress=1 if st is None else st, **over)
        f.add(s, "reader", mounted=everyone)


# ---------------------------------------------------------------------- shared choices
def helpers(f, roller, n):
    """Help: a comrade within one Position step, not Down or Grabbed, with an unspent action, who is not a
    decoyer or a rider, and whose card has come up, or who is a helper Squadmate, or a striker who began the
    round at Distant; those whose card has come up first."""
    n = min(n, R.help_max)
    if n <= 0:
        return []
    out = []
    for h in f.present():
        if (h is roller or h.down or h.grabbed or h.cur_action or h.carried_by is not None
                or (f.bound(h) and not h.cur_move)     # under a retreat the forced move comes first
                or h.role in ("decoyer", "rider", "lone", "victim", "reader")):
            continue
        if f.steps_apart(h.pos, roller.pos) > 1:
            continue
        if not (h.card_passed or h.role == "helper" or (h.role == "striker" and h.start_pos == D)):
            continue
        out.append(h)
    out.sort(key=lambda h: not h.card_passed)
    out = out[:n]
    for h in out:
        h.cur_action = True
    return out


def dodge_helpers(f, s):
    """Chapter 1, section 1.8: a comrade can Help a Reaction with an unspent action this round. POLICY CHOICE
    (dodge_help): every comrade within one step who is not Down, Grabbed, or carried and has an unspent action
    Helps, those whose card has come up first, up to the Help cap; no Help without dodge_help (the baseline)."""
    if not f.cfg.get("dodge_help"):
        return []
    out = [h for h in f.present() if h is not s and not h.down and not h.grabbed and h.carried_by is None
           and not h.cur_action and not (f.bound(h) and not h.cur_move) and h.role not in ("lone", "victim")
           and f.steps_apart(h.pos, s.pos) <= 1]
    out.sort(key=lambda h: not h.card_passed)
    out = out[:R.help_max]
    for h in out:
        h.cur_action = True
    return out


def dodge_coverer(f, s):
    """stress-changes.yaml, cover: a player character comrade, not Down (nor Grabbed, which forbids it), at the
    same Position or one step away. POLICY CHOICE (dodge_cover): the lowest-Stress such comrade Covers every
    dodge Push; no Covering without dodge_cover (the baseline)."""
    if not f.cfg.get("dodge_cover") or not s.can_push():
        return None
    out = [c for c in f.present() if c is not s and (c.pc or R.squadmate_covers) and not c.down and not c.grabbed
           and f.steps_apart(c.pos, s.pos) <= 1]
    return min(out, key=lambda c: c.stress) if out else None


def wants_dodge(f, s, effects):
    policy = f.cfg.get("dodge", "harm")
    for eff in effects:
        if eff["type"] == "grab":
            return True
        if eff["type"] == "critical-injury" and (policy == "harm" or not eff["cannot_be_lethal"]):
            return True
        if (policy == "harm" and eff["type"] == "knock-loose" and not s.mounted
                and (s.airborne or s.pos in R.fall_high)):
            return True
    return False


def wants_break_free(f, s):
    return True


def down_turn(f, s):
    f.crawl(s)


def wings_step(f):
    t = f.t
    if f.holds_tactic("fall-back"):
        stranded = [s for s in f.present() if not s.down and not s.grabbed and s.pos in (OB, BS)
                    and not s.odm_working() and not t.grounded()]
        if stranded:
            f.use_tactic("fall-back")
            for s in stranded:
                s.pos = IR
                if s.carrying is not None:
                    s.carrying.pos = IR
                f.stats["fall_backs"] += 1


def assign_wings(f):
    """Returns (Squadmate, player character) pairs."""
    pcs = [s for s in f.sold if s.pc and not s.dead]
    pcs.sort(key=lambda s: (s.down or s.grabbed))
    out, free = [], list(pcs)
    for sm in [s for s in f.sold if not s.pc and not s.dead]:
        if not free:
            break
        out.append((sm, free.pop(0)))
    return out


def promotion_choice(free):
    """squadmates.yaml, promotion, who_chooses: the player whose character died or retired chooses. POLICY CHOICE:
    the living Squadmate with the fewest untreated Critical Injuries, then sheet order. Returns them in order of
    preference."""
    return sorted(free, key=lambda s: len(s.untreated()))


def swaps(f):
    out = []
    for c in [s for s in f.present() if s.role == "cutter"]:
        for k in [s for s in f.present() if s.role == "striker"]:
            if f.card.get(c.name, 0) > f.card.get(k.name, 99):
                out.append((c, k))
    return out


def read_picks(f, s, succ):
    """Returns (facts, call_it). POLICY CHOICE: on an Abnormal whose ladder is hidden, the ladder first; then the
    Next Behavior and Call It when the successes pay for it; a Next Behavior already Called is not Read again."""
    t = f.t
    need = R.call_it_sharp if "sharp-call" in s.rule_talents else R.call_it_successes
    picks, left = [], succ
    kind = "abnormal" if t.abnormal else "standard"
    if not t.ladder_revealed and kind in R.read_facts["attention-ladder"] and left >= 1:
        picks.append("attention-ladder")
        left -= 1
    already = t.called is not None and t.called["serial"] == t.nb_serial
    if left >= need and not already:
        return picks + ["next-behavior"], True
    if left >= 1 and not t.nb_revealed:
        picks.append("next-behavior")
    return picks, False


def aftermath_treaters(f, patients):
    """treat-injury.yaml, aftermath_rolls: (patient, treater or None) pairs."""
    def pool(tr, p):
        kit = tr.kit is not None and tr.kit > 0
        return (tr.a(R.treat_attribute) + (tr.talents.get(R.treat_entry, 0) + tr.kit if kit else 0) + tr.stress
                - (R.treat_self_penalty if tr is p else 0))
    order = sorted(patients, key=lambda p: (not p.down, -max(c["row"]["dr_pen"] for c in f.aftermath_cis(p))))
    used, out = set(), []
    for p in order:
        cands = [tr for tr in f.sold if not tr.dead and not tr.down and tr is not p and tr.name not in used
                 and f.apart(tr, p) <= 1]
        if not cands and not p.down and p.name not in used:
            cands = [p]
        if not cands:
            out.append((p, None))
            continue
        tr = max(cands, key=lambda x: pool(x, p))
        used.add(tr.name)
        out.append((p, tr))
    return out


def aftermath_ci(f, p):
    return max(f.aftermath_cis(p), key=lambda c: c["row"]["dr_pen"])


def care_window(f, alive):
    """treat-injury.yaml, care_windows, engagement-end, and field-repair.yaml: every living soldier not Down makes
    one Treat Injury roll and one Field Repair roll. Tasks, in order: untreated lethal Critical Injuries, untreated
    Down rows, other untreated Critical Injuries, then reviving a Down soldier at 0 Health."""
    rollers = [s for s in alive if not s.down]
    tasks = []
    for p in alive:
        for c in p.untreated():
            rank = 0 if c["row"]["lethal"] else (1 if c["row"]["down"] else 2)
            tasks.append((rank, p, "treat", c))
    for p in alive:
        if p.down and p.current_health() == 0 and p.health_lost > 0 and not p.untreated():
            tasks.append((3, p, "revive", None))
    tasks.sort(key=lambda x: x[0])
    for s in rollers:               # squad-supply.yaml, restock-kit: a worn kit first
        if s.kit_max is not None and s.kit < s.kit_max and f.supply["medical"] > 0:
            f.supply["medical"] -= 1
            s.kit = s.kit_max
    free = sorted(rollers, key=lambda s: -(s.a(R.treat_attribute) + ((s.talents.get(R.treat_entry, 0) + s.kit)
                                                                     if s.kit else 0)))
    plan = []
    for rank, p, use, c in tasks:
        if not free:
            break
        r = free.pop(0)
        plan.append([rank, p, use, c, r, []])
    for step in plan:
        while free and len(step[5]) < R.care_help_max and step[0] == 0:
            step[5].append(free.pop(0))
    for rank, p, use, c, r, hs in plan:
        if use == "treat" and c["treated"]:
            continue
        cover = next((x for x in alive if x.pc and not x.down and x is not r), None) if r.can_push() else None
        f.care_roll(r, p, use, c, helpers=hs, cover=cover, units=R.care_bonus_units if rank == 0 else 0)
    if R.care_field_repair:
        worn = [s for s in alive if s.odm < s.odm_max]
        for s in [s for s in alive if not s.down]:
            target = s if s in worn else (worn[0] if worn else None)
            if target is None:
                break
            f.care_repair(s, target)
            if target.odm >= target.odm_max and target in worn:
                worn.remove(target)


def after_decoy(f, s):
    """Hook and Cut (squad-tactics.yaml): a ready comrade cuts at once, strikers first; never in a retreat, whose cut
    would be a Nape strike (decision batch 5b, 5-15), so the Tactic is not spent."""
    t = f.t
    if not f.holds_tactic("hook-and-cut") or t.dead or f.retreat:
        return
    ready = [c for c in f.present() if c is not s and f.can_nape(c)]
    if not ready:
        return
    ready.sort(key=lambda c: c.role != "striker")
    f.use_tactic("hook-and-cut")
    f.nape_strike(ready[0])


def on_nape(f, s, res):
    if s.role == "lone":
        L = f.lone
        L.update(struck=True, kill=res.succ >= f.t.nd, round=f.rnd, stress_at_strike=s.stress,
                 cards_before=f.stats["resolved"], cis_before=f.stats["cis"])
        if f.cfg.get("stop_at_first_nape", True):
            f.stop = True
            L["end"] = "struck"


def round_dealt(f):
    lone = [s for s in f.alive() if s.role == "lone"]
    if lone:
        sc = f.card[lone[0].name]
        passed = sum(1 for c in f.tcards if c < sc)
        line = f.cfg.get("line", "waiting")
        f.lone["t_first"] = passed == f.t.tempo if line in ("waiting", "one_card_hold") else passed >= 1


def after_event(f):
    if f.cfg.get("cell") and f.lone.get("grabbed") and f.t.grab is None:
        f.stop = True


def end_of_round(f):
    lone = [s for s in f.alive() if s.role == "lone"]
    if not lone:
        return
    if not f.stop and f.t.holder != "decoy" and not any_decoy_left(f, lone[0]):
        lone_end(f, "no_decoy_usable", lone[0])
    elif not f.stop and f.retreat:
        # the retreat clock filled: the lone fight's measurement (a usable strike) ends, since no Nape strike is made
        # in a retreat (decision batch 5b, 5-15)
        lone_end(f, "retreat", lone[0])
    else:
        count_gap(f, lone[0])


# ---------------------------------------------------------------------- a soldier's turn
def take_turn(f, s):
    t = f.t
    cfg = f.cfg
    role = s.role
    if role == "lone":
        return lone_turn(f, s)
    if role in ("rider", "victim"):
        return
    if role == "reader":
        if not t.dead and t.holder != "decoy" and not s.cur_action:
            already = t.called is not None and t.called["serial"] == t.nb_serial
            if not already or not t.ladder_revealed:
                f.read(s)
        return
    if cfg.get("treat_in_fight") and role in ("cutter", "helper") and not s.cur_action and not t.dead:
        pat = next((p for p in f.present() if p is not s and p.pos == s.pos and not p.grabbed and
                    (p.down or any(c["row"]["lethal"] and c["limit"] == "turn" for c in p.untreated()))), None)
        if pat is not None:
            lethal = [c for c in pat.untreated() if c["row"]["lethal"] and c["limit"] == "turn"]
            downs = [c for c in pat.untreated() if c["row"]["down"]]
            if lethal or downs or pat.untreated():
                f.treat(s, pat, "treat", (lethal or downs or pat.untreated())[0])
            elif pat.health_lost > 0:
                f.treat(s, pat, "revive")
    if cfg.get("carry") and role in ("cutter", "helper") and not t.dead:
        if s.carrying is not None:
            if s.pos == D:
                f.set_down(s)
            else:
                f.try_step(s, IR if s.pos in (OB, BS) else D, ("foot", "odm"))
                if s.pos == D:
                    f.set_down(s)
                return
        elif not s.cur_action and not t.grab:
            c = next((p for p in f.present() if p is not s and p.pos == s.pos and p.down and not p.grabbed
                      and p.carried_by is None and p.pos != D), None)
            if c is not None and f.lift(s, c):
                f.try_step(s, IR if s.pos in (OB, BS) else D, ("foot", "odm"))
                return
    if (cfg.get("draw_attention") and role == "cutter" and not t.grab and not t.dead and not s.cur_action
            and (t.ladder_revealed or not cfg.get("draw_after_read"))):
        h = t.holder
        if h not in (None, "decoy") and h is not s and h.role == "striker":
            if s.pos in R.draw_barred_positions:
                # attention.yaml, draw_attention: not from Distant (decision batch 5, OQ-113); the turn goes on without it
                f.stats["draws_barred"] += 1
            else:
                f.draw_attention(s)
    if role == "screen2" and not t.grab and not t.dead:
        if f.horse_usable(s):
            return screen_horse(f, s)
        if cfg.get("screen_feints", True) and s.cloak_thrown:
            return screen_feint(f, s)
    if role == "striker" and s.odm == 0 and not t.grounded():
        s.role = role = "cutter"
    if t.grab and t.grab["victim"] is not s:
        return rescue(f, s)
    if role == "decoyer":
        if not s.cur_action and f.decoy_legal(s, "riderless-horse"):
            f.break_attention(s, "riderless-horse")
    elif role == "screen":
        if f.horse_usable(s) and s.pos == D:
            if not s.cur_action and f.decoy_legal(s, "riderless-horse"):
                f.break_attention(s, "riderless-horse")
        elif not s.cloak_thrown:
            if s.pos == D:
                f.try_step(s, IR)
            elif s.pos == IR:
                f.try_step(s, BS)
            if s.pos in (OB, BS) and not s.cur_action and s.odm_working() and f.decoy_legal(s, "thrown-cloak"):
                f.break_attention(s, "thrown-cloak", "odm")
        elif s.pos == D:
            f.try_step(s, IR)
    elif role == "screen2":
        h = t.holder
        hpos = h.pos if h not in (None, "decoy") else None
        if not s.cloak_thrown:
            target = hpos if hpos in (OB, BS) else BS
            if s.pos == D:
                f.try_step(s, IR)
            elif s.pos != target:
                f.try_step(s, target)
            if s.pos in (OB, BS) and not s.cur_action and s.odm_working() and f.decoy_legal(s, "thrown-cloak"):
                f.break_attention(s, "thrown-cloak", "odm")
        elif s.pos == D:
            f.try_step(s, IR)
    elif role == "cutter":
        cutter_turn(f, s)
    elif role == "striker":
        striker_turn(f, s)
    elif role == "helper":
        if s.pos == D:
            f.try_step(s, IR)


def screen_horse(f, s):
    t = f.t
    h = t.holder
    hpos = h.pos if h not in (None, "decoy") else None
    if s.mounted and hpos in (D, IR) and s.pos != hpos:
        f.try_step(s, hpos, ("mounted",))
    if not s.cur_action and f.decoy_legal(s, "riderless-horse"):
        f.break_attention(s, "riderless-horse")


def screen_feint(f, s):
    if s.pos == D:
        f.try_step(s, IR)
    elif s.pos == BS:
        f.try_step(s, IR)
    if s.pos in R.feint_positions and not s.cur_action and f.decoy_legal(s, "feint"):
        gears = f.feint_gears(s)
        if "odm" in gears:
            f.break_attention(s, "feint", "odm")
        elif None in gears and f.cfg.get("onfoot_feint"):
            f.break_attention(s, "feint", None)


def pick_part(f, s):
    t = f.t
    for kind in f.cfg.get("cut_order") or (LEG, ARM):
        opts = [p for p in t.part_ids if t.kind[p] == kind and t.state[p] < R.broken]
        if opts:
            return max(opts, key=lambda p: (t.state[p], t.count[p]))
    return None


def cutter_turn(f, s):
    t = f.t
    part = pick_part(f, s)
    eyes_first = part is not None and t.kind[part] == EYES
    if eyes_first:
        # cut_order eyes first: the eyes are struck from on-body or blind-spot (titan-harm.yaml, body_part_kinds)
        if s.pos in (D, BS):
            f.try_step(s, IR)
        if s.pos == IR and not f.can_strike_part(s, part):
            f.try_step(s, OB)
    elif s.pos in (D, BS) or (s.pos == OB and f.cfg.get("cut_order")):
        f.try_step(s, IR)
    if (f.holds_tactic("hook-and-cut") and s.pos in (IR, OB) and not s.cur_action and s.odm_working()
            and not t.grab and not t.dead and t.holder != "decoy"):
        ready = [c for c in f.present() if c is not s and not c.down and not c.grabbed and c.pos == BS
                 and not c.cur_action and c.handles and (c.odm_working() or t.grounded())]
        if any(t.holder is c or f.nape_bonus_without_help(c) >= 2 for c in ready):
            # POLICY CHOICE: a flare while the Squad Supply holds one (need 2), else a Feint (need 3); the
            # probe named no decoy and never ran out.
            d = "flare" if f.decoy_legal(s, "flare") else ("feint" if f.decoy_legal(s, "feint") else None)
            if d:
                f.break_attention(s, d, "odm")
    if s.pos in (IR, OB) and not s.cur_action and s.handles:
        part = pick_part(f, s)
        if part and f.can_strike_part(s, part):
            hs = helpers(f, s, 2)
            ham = bool(hs) and t.kind[part] == LEG and f.holds_tactic("hamstring-line")
            if ham:
                f.use_tactic("hamstring-line")
            f.body_strike(s, part, hs, ham)


def striker_turn(f, s):
    t = f.t
    if s.pos != BS and f.route_step(s, BS, assume_odm=True) is None:
        # POLICY CHOICE: on an Anchor Rating with no chain of steps to Blind Spot (Open, while the Titan stands)
        # the striker cuts as a cutter until grounding opens one. On Wooded a chain always exists.
        return cutter_turn(f, s)
    if s.pos != BS:
        nxt = f.route_step(s, BS) or BS
        if s.pos == D:
            f.try_step(s, IR)
        elif s.gas == 0 and s.spares > 0 and not t.grounded() and not s.cur_action:
            f.change_canister(s)
            f.try_step(s, f.route_step(s, BS) or BS)
        else:
            f.try_step(s, nxt)
    if f.can_nape(s):
        if f.cfg.get("policy", "eager") == "eager" or f.nape_bonus_without_help(s) >= 2 or f.rnd >= 3:
            f.nape_strike(s)
    elif s.pos == BS and s.gas == 0 and s.spares > 0 and not s.cur_action and not t.grounded():
        f.change_canister(s)


def rescue(f, s):
    t = f.t
    g = t.grab
    if s.role == "striker" and f.can_nape(s) and f.nape_bonus_without_help(s) >= 2:
        f.nape_strike(s)
        return
    narrow = g["lifted"] and not g["clear"]
    if narrow and s.pos == IR and f.holds_tactic("clear-the-hand") and not s.cur_action and s.handles:
        f.use_tactic("clear-the-hand")
        g["clear"] = True
        narrow = False
    arm = g["arm"]
    to_free = (R.broken - t.state[arm]) * t.tough(arm) - t.count[arm]
    if "pry-loose" in s.rule_talents and (f.cfg.get("pry") == "prefer" or to_free > R.pry_loose_needs or not s.handles):
        # POLICY CHOICE: Pry Loose (grab.yaml, escapes, pry-loose, needs) when the arm needs more successes than that or cannot be
        # struck; pry "prefer" (the Pry Loose rows) pries whenever the rescuer can reach On Body
        if s.pos == D:
            f.try_step(s, IR)
        if s.pos in (IR, BS):
            f.try_step(s, OB)
        if f.pry_loose(s):
            return
        if s.cur_action:
            return
    reach = set(R.grab_reach_after if g["lifted"] else R.grab_reach_before)
    if g["clear"]:
        reach.add(IR)
    if s.pos not in reach:
        if s.pos == D:
            f.try_step(s, IR)
        if s.pos not in reach and s.pos == IR:
            f.try_step(s, OB)
    if not s.cur_action and f.can_strike_part(s, arm):
        push = None
        if f.cfg.get("rescue_push") == "free":
            # the Grab cells' rescuer (tuning.yaml, grab, model): Push toward the successes that free the victim
            push = to_free
        f.body_strike(s, arm, (), push_to=push)
    elif f.cfg.get("escapes") and not s.cur_action and not s.down and not t.dead and t.holder != "decoy":
        # POLICY CHOICE: the probe rolled with ODM Gear, or the horse from Distant, naming no decoy. The
        # simulator names the cloak, then a flare, then a Feint with ODM Gear, or the riderless horse at Distant.
        if s.odm_working():
            for d in ("thrown-cloak", "flare", "feint"):
                if f.decoy_legal(s, d):
                    f.break_attention(s, d, "odm")
                    return
        if s.pos == D and f.decoy_legal(s, "riderless-horse"):
            f.break_attention(s, "riderless-horse")


# ---------------------------------------------------------------------- the retreat (decision batch 5, 5-1 and 5-10)
def retreat_toward(f, s, target):
    """Retreat options 1 and 3 (background-titans.yaml, retreat, moves): one step that lowers the number of Position
    steps to target, tried In Reach, On Body, Blind Spot, Distant (the probe's order)."""
    if s.cur_move:
        return False
    d = f.steps_apart(s.pos, target)
    for to in (IR, OB, BS, D):
        if to != s.pos and f.step_kinds(s.pos, to) and f.steps_apart(to, target) < d and f.retreat_step(s, to):
            return True
    return False


def retreat_out(f, s):
    """Options 1 and 2: a step toward Distant, or leaving from Distant. A soldier at On Body or Blind Spot who can make
    no step lets go (positions.yaml, moves, letting_go) and falls."""
    if s.cur_move:
        return
    if s.pos == D:
        f.leave(s)
    elif not retreat_toward(f, s, D) and s.pos in (OB, BS):
        f.let_go(s)


def retreat_act(f, s, g):
    """The action taken for a Grabbed comrade in a retreat: Pry Loose (as rescue chooses it), a strike on the holding
    arm, or with the escapes Break Attention with ODM Gear. Returns True when an action was taken."""
    t = f.t
    if s.cur_action or t.dead or t.grab is not g:
        return False
    arm = g["arm"]
    to_free = (R.broken - t.state[arm]) * t.tough(arm) - t.count[arm]
    if ("pry-loose" in s.rule_talents and s.pos == OB
            and (f.cfg.get("pry") == "prefer" or to_free > R.pry_loose_needs or not s.handles)):
        f.pry_loose(s)
        if s.cur_action:
            return True
    if f.can_strike_part(s, arm):
        f.body_strike(s, arm, (), push_to=to_free if f.cfg.get("rescue_push") == "free" else None)
        return True
    if f.cfg.get("escapes") and t.holder != "decoy" and s.odm_working():
        for d in ("thrown-cloak", "flare", "feint"):
            if f.decoy_legal(s, d):
                f.break_attention(s, d, "odm")
                return True
    return False


def retreat_turn(f, s):
    """A standing soldier's turn under the retreat (background-titans.yaml, retreat): the forced move, then the action,
    except option 4 (the action for the comrade, then the stay) and the lift (then the move that carries them out)."""
    t = f.t
    g = t.grab
    if g is not None and g["victim"] is not s and not g["victim"].dead:
        v = g["victim"]
        if s.pos == v.pos:
            if retreat_act(f, s, g):
                f.stay(s, v)
                return
        elif retreat_toward(f, s, v.pos):
            retreat_act(f, s, g)
            return
    if s.carrying is not None:
        retreat_out(f, s)
        return
    fallen = [c for c in f.present() if c is not s and c.down and not c.grabbed and c.carried_by is None]
    if fallen:
        c = min(fallen, key=lambda c: (f.steps_apart(s.pos, c.pos), f.card.get(c.name, 99)))
        if c.pos == s.pos:
            if not s.cur_action:
                lethal = [x for x in c.untreated() if x["row"]["lethal"] and x["limit"] == "turn"]
                if f.cfg.get("treat_in_fight") and lethal:
                    f.treat(s, c, "treat", lethal[0])
                    f.stay(s, c)
                    return
                if f.lift(s, c):
                    retreat_out(f, s)
                    return
        elif retreat_toward(f, s, c.pos):
            if c.pos == s.pos and not s.cur_action:
                f.lift(s, c)
            return
    retreat_out(f, s)


# ---------------------------------------------------------------------- the lone soldier
def repairable(f, s):
    return f.cfg.get("repair", True) and s.odm == 0 and (s.gas > 0 or s.spares > 0)


def feint_usable(f, s):
    """lone.py's check of the Feint at In Reach or On Body, with the grounded way on foot added: working ODM
    Gear, a sound horse under the soldier, not mounted against a grounded Titan, a dry harness with a spare,
    or a Jammed harness Field Repair can restore."""
    if not f.cfg.get("feint", True):
        return False
    if s.odm_working() or (s.mounted and s.horse > 0 and not s.horse_gone):
        return True
    if not s.mounted and f.t.grounded():
        return True
    if s.odm > 0 and s.gas == 0 and s.spares > 0:
        return True
    return repairable(f, s)


def lone_choice(f, s):
    if f.horse_usable(s):
        return "riderless-horse"
    if f.flares > 0 and not f.t.eyes_broken():
        return "flare"
    if feint_usable(f, s):
        return "feint"
    return None


def any_decoy_left(f, s):
    return f.horse_usable(s) or (f.flares > 0 and not f.t.eyes_broken()) or feint_usable(f, s)


def lone_stage(f, s):
    """The Position the lone soldier Breaks Attention from: one that has a step to Blind Spot this soldier can
    make now (In Reach on Wooded; On Body against a grounded Titan at Open)."""
    for p in (IR, OB):
        kinds = f.step_kinds(p, BS)
        if ("odm" in kinds and s.odm_working()) or ("foot" in kinds):
            return p
    return None


def route_gap(f, s):
    """ADR-0010's promise checked in play, at every lone turn and every lone ending: a gap is a state in which a
    Nape strike is legal now or after one step the soldier can make, while no decoy is legal at the soldier's
    Position or at any Position one such step away. A decoy already holding is not a gap."""
    t = f.t
    if t.dead or s.dead or s.down or s.grabbed or t.holder == "decoy":
        return False
    reach = [(s.pos, s.mounted)]
    for p in R.positions:
        if p == s.pos:
            continue
        kinds = f.step_kinds(s.pos, p)
        if "foot" in kinds or ("odm" in kinds and s.odm_working()):
            reach.append((p, False))
        if "mounted" in kinds and s.mounted:
            reach.append((p, True))
    if not any(p == BS and not m and s.handles and (s.odm_working() or t.grounded()) for p, m in reach):
        return False
    saved = (s.pos, s.mounted, s.cur_action)
    try:
        s.cur_action = False
        for p, m in reach:
            s.pos, s.mounted = p, m
            if any(f.decoy_legal(s, d) for d in ("feint", "flare", "thrown-cloak", "riderless-horse")):
                return False
    finally:
        s.pos, s.mounted, s.cur_action = saved
    return True


def count_gap(f, s):
    if route_gap(f, s):
        f.lone["gap_checks_failed"] = f.lone.get("gap_checks_failed", 0) + 1
        f.lone["gap_grounded"] = f.lone.get("gap_grounded", False) or f.t.grounded()
    f.lone["gap_checks"] = f.lone.get("gap_checks", 0) + 1


def lone_ba(f, s, d):
    if d and f.decoy_legal(s, d):
        f.break_attention(s, d)
        return True
    return False


def lone_end(f, why, s=None):
    if s is not None:
        count_gap(f, s)
    f.lone["end"] = why
    f.stop = True


def lone_no_route(f, s, tf):
    """lone_turn when no Position has a step to Blind Spot this soldier can make: no Break Attention. Pull back
    from On Body; on a round in which the line would move in, go to In Reach on foot and cut the grounding leg;
    otherwise wait at Distant."""
    t = f.t
    if s.pos == OB:
        f.try_step(s, IR, ("foot", "odm"))
    elif s.pos == D and tf and not s.cur_move and not s.cur_action:
        f.try_step(s, IR, ("foot", "odm"))
    elif s.pos == IR and not tf and not s.cur_move:
        f.try_step(s, D, ("mounted", "foot") if s.mounted else ("foot",))
    if s.pos == IR and tf and not s.cur_action and s.handles and not t.dead and not t.grounded():
        leg = next((p for p in t.part_ids if t.kind[p] in R.grounding_kinds and f.can_strike_part(s, p)), None)
        if leg is not None:
            f.body_strike(s, leg, push_to=t.tough(leg) - t.count[leg])
            f.lone["leg_cuts"] = f.lone.get("leg_cuts", 0) + 1


def lone_turn(f, s):
    """The lone fight (tuning.yaml, solo_nape, lone_fight), lone.py's policy: Field Repair a Jammed harness
    first; if a decoy holds, step to Blind Spot and cut; change a dry canister; otherwise wait at Distant
    until a round in which every card of the Titan has come up (the waiting line; the hurried line once one
    has), then move in and Break Attention with the horse, a flare, then the Feint, pulling back to Distant on
    a round in which the soldier's card comes first. At Blind Spot with no decoy holding, a flare or the cloak.
    A lone fight ends at the first Nape strike or when no decoy is usable.

    POLICY CHOICE (Opus review 2, Minor 5): Break Attention is never taken while no Position has a step to Blind
    Spot this soldier can make (lone_stage None: a standing Titan on Open, or ODM Gear that cannot be used where
    only an ODM step reaches Blind Spot), since a decoy then buys no strike. Instead the soldier pulls back from
    On Body to In Reach, even while a decoy holds, and on a round in which every card of the Titan has come up
    (the line's timing) cuts the grounding leg from In Reach, on foot, which opens a route; on other rounds they
    wait at Distant. remount: a soldier at Distant beside their own horse mounts it."""
    t = f.t
    L = f.lone
    count_gap(f, s)
    decoy = t.holder == "decoy"
    if repairable(f, s) and not s.cur_action and not decoy:
        f.field_repair(s)
    if decoy:
        if not f.can_nape(s) and s.pos != BS:
            f.try_step(s, BS)
        if f.can_nape(s):
            f.nape_strike(s, help_nape=False)
            return
    if s.gas == 0 and s.spares > 0 and not s.cur_action and not decoy:
        f.change_canister(s)
    tf = L.get("t_first", False)
    stage = lone_stage(f, s)
    if f.cfg.get("remount") and s.pos == D and f.can_mount(s) and not s.cur_move:
        f.mount(s)
    ride = ("mounted", "foot") if s.mounted else ("foot",)
    if stage is None and s.pos != BS:
        return lone_no_route(f, s, tf)
    if s.pos == D:
        if tf and not s.cur_move and not s.cur_action and not decoy:
            d = lone_choice(f, s)
            if d is None:
                return lone_end(f, "no_decoy_usable", s)
            f.try_step(s, IR, ride)
            if stage != OB:
                lone_ba(f, s, d)
    elif s.pos == IR:
        if stage == OB:
            f.try_step(s, OB, ("foot", "odm"))
            if s.pos == OB and tf and not s.cur_action and not decoy:
                lone_ba(f, s, lone_choice(f, s))
        elif tf and not s.cur_action and not decoy:
            d = lone_choice(f, s)
            if d is None:
                return lone_end(f, "no_decoy_usable", s)
            lone_ba(f, s, d)
        elif not tf and not s.cur_move and not decoy:
            f.try_step(s, D, ride)
            if f.cfg.get("remount") and s.pos == D:
                f.mount(s, within_move=True)
    elif s.pos == OB:
        if stage == OB and tf and not s.cur_action and not decoy:
            d = lone_choice(f, s)
            if d is None:
                return lone_end(f, "no_decoy_usable", s)
            lone_ba(f, s, d)
    elif s.pos == BS:
        if tf and not s.cur_action and not decoy:
            d = "flare" if f.decoy_legal(s, "flare") else ("thrown-cloak" if f.decoy_legal(s, "thrown-cloak") else None)
            if d is None:
                return lone_end(f, "no_decoy_usable", s)
            f.break_attention(s, d)
