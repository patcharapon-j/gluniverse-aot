"""Dice, soldiers, and the harm procedures of Chapters 1, 3, and 4, with every table read through rules.R.

- Pool (dice-pool.yaml): attribute + one dice Talent + Bonus Dice (capped) - penalties (base dice at least
  the minimum, applied after the cap) + Gear Dice (one item's current rating) + Stress Dice (current Stress).
- Push: only if no Stress Die shows 1 and the soldier may Push (a player character, not Down). +1 Stress and
  one new Stress Die (Covered: the Coverer takes the Stress, no die is added); push-stress results add
  their Stress either way. Base and Stress Dice not showing a success are re-rolled; Gear Dice never are.
- Finishing: at most one Stress Response (a Stress Die showing 1 after any Push), which may change the
  successes; Gear Dice showing 1 on a Pushed roll are wear.
- Critical Injuries (treated or not), Health boxes, Down, falls, Fear Rolls with their Scar totals, gaining a
  Scar on the D66 table (scars.yaml), and Death Rolls, as their YAML rows give them.
"""
from rules import R, covers

SF = R.success_face

# Round-time counter (data/engagement/round.yaml, round_time): every dice pool rolled, attribute rolls and
# Death Rolls. engine.Fight reads the difference over a fight.
COUNT = {"pools": 0}

# Scar rows whose trigger is a roll for these entries (scars.yaml, reckless-blade).
RECKLESS_ENTRIES = ("nape-strike", "body-part-strike")


class Roll:
    __slots__ = ("succ", "pushed", "gear_ones", "spend_turns", "covered")

    def __init__(self, succ, pushed, gear_ones, spend_turns, covered=None):
        self.succ, self.pushed, self.gear_ones, self.spend_turns = succ, pushed, gear_ones, spend_turns
        self.covered = covered


class Soldier:
    def __init__(self, name, attributes, health, resolve_base, talents, stress, min_stress=0, scars=0,
                 odm=None, horse=None, blade=None, spares=None, blades=None, pc=True, grief=0, kit=None,
                 rule_talents=(), specialty=None, talent_gear=None):
        self.name = name
        self.attr = dict(attributes)
        self.health = health
        self.resolve_base = resolve_base
        self.scars = scars
        self.scar_rows = set()     # rows of the Scar table held; a build's Scars name none (see the report)
        self.grief = grief
        self.talents = dict(talents)
        # entry -> the gear item a roll on it must use for the Talent's dice to add (talents.yaml, condition)
        self.talent_gear = dict(talent_gear or {})
        self.left = False           # left the Titan Engagement (positions.yaml, leaving)
        self.rule_talents = set(rule_talents)
        self.specialty = specialty
        self.min_stress = max(min_stress, scars * R.min_stress_per_scar)
        self.stress = max(stress, self.min_stress)
        self.horse_gone = False     # a soldier who sits a fight out never passes through Fight.add
        self.odm_max = R.issue["odm_gear_rating"] if odm is None else odm
        self.odm = self.odm_max
        self.gas = R.full_gas
        self.spares = R.issue["spare_canisters"] if spares is None else spares
        self.blade = R.issue["blade_set_rating"] if blade is None else blade
        self.blades = R.issue["blade_sets"] if blades is None else blades
        self.handles = self.blades > 0
        self.horse_max = R.issue["horse_rating"] if horse is None else horse
        self.horse = self.horse_max
        self.kit_max = kit          # medical kit rating, or None when the soldier holds none
        self.kit = kit
        self.pc = pc
        self.lasting = set()
        self.next_pen = 0
        # dicts: row, limit, gained (turn count when gained), treated, scar_due, days (healing time left), healed
        self.cis = []
        self.gained_perm = set()
        self.health_lost = 0
        self.down = False
        self.dead = False
        self.retiring = False
        self.carrying = None
        self.carried_by = None

    # ------------------------------------------------------------------ derived values
    @property
    def resolve(self):
        return self.resolve_base + self.scars - min(self.grief, R.grief_max)

    def a(self, attribute):
        return self.attr[attribute]

    def can_push(self):
        return self.pc and not self.down

    def penalty(self, entry):
        p = 0
        for c in self.cis:
            # healing.yaml, healing_time, heals: a healed injury's effects end; its permanent effects stay
            p += c["row"]["pen_perm" if c.get("healed") else "pen"].get(entry, 0)
        for rid in self.lasting:
            p += R.sr_by_id[rid]["pen"].get(entry, 0)
        for rid in self.scar_rows:
            p += R.scar_rows[rid]["pen"].get(entry, 0)
        return p

    def push_stress(self):
        return sum(R.sr_by_id[rid]["push_stress"] for rid in self.lasting)

    def odm_working(self):
        return self.odm > 0 and self.gas > 0

    def gear_dice(self, item):
        if item == "odm":
            return self.odm if self.odm_working() else 0
        if item == "blade":
            return self.blade if self.handles else 0
        if item == "horse":
            return self.horse
        if item == "kit":
            return self.kit or 0
        return 0

    def untreated(self):
        return [c for c in self.cis if not c["treated"] and not c.get("healed")]

    def held(self):
        """Critical Injuries still held: every one not healed (healing.yaml, healing_time, heals)."""
        return [c for c in self.cis if not c.get("healed")]

    def current_health(self):
        """health.yaml: each untreated Critical Injury crosses off a box, to at most Health; damage marks the rest."""
        crossed = min(len(self.untreated()), self.health)
        return max(0, self.health - crossed - self.health_lost)

    def check_down(self):
        if self.current_health() == 0 or any(c["row"]["down"] for c in self.untreated()):
            self.down = True

    def try_end_down(self):
        """down.yaml: Down ends once current Health is above 0 and no untreated down row holds the soldier."""
        if self.down and not self.dead and self.current_health() > 0 and not any(c["row"]["down"] for c in self.untreated()):
            self.down = False
            return True
        return False

    def has_scar(self, rid):
        return rid in self.scar_rows


# ---------------------------------------------------------------------- builds
BUILD_ALIASES = {"levi": "levi_grade"}


def make_build(build, name, pc=True, stress=None, **over):
    """A reference build (data/engagement/tuning.yaml, builds): Talent dice at the build's level on each entry
    talent_dice_on names; items at the build's ratings, spares and Blade Sets from Standard Issue. A reference
    build holds the items Standard Issue gives it, so no medical kit unless a case gives one (kit=rating)."""
    b = R.builds[BUILD_ALIASES.get(build, build)]
    kw = dict(attributes=b["attributes"], health=b["health"], resolve_base=b["resolve_total"] - b["scars"],
              talents={e: b["talent"] for e in R.talent_dice_on}, stress=b["stress"] if stress is None else stress,
              min_stress=b["min_stress"], scars=b["scars"], odm=b["odm"], horse=b["horse"], blade=b["blade"], pc=pc)
    kw.update(over)
    return Soldier(name, **kw)


def make_template(tid, name, pc=True, stress=1, **over):
    """A Squadmate template (data/character/squadmates.yaml) with Standard Issue, including its Specialty's item
    (standard-issue.yaml, by_specialty); its one dice Talent adds to the entries data/character/talents.yaml
    names for it."""
    t = R.templates[tid]
    tal = {e: t["talent"]["level"] for e in R.talent_names.get(t["talent"]["id"], [])}
    item = R.specialty_items.get(tid)
    kw = dict(attributes=t["attributes"], health=t["health"], resolve_base=t["resolve"], talents=tal,
              stress=stress, pc=pc, specialty=tid, kit=item[1] if item and item[0] == "medical-kit" else None,
              talent_gear=R.talent_gear.get(t["talent"]["id"], {}))
    kw.update(over)
    return Soldier(name, **kw)


# ---------------------------------------------------------------------- rolls
def stress_response(rng, s):
    """Returns (lose, zero, spend_turns)."""
    total = rng.randint(1, 6) + s.stress - s.resolve
    i = R.sr_index(total)
    rows = R.sr_rows
    while rows[i]["lasting"] and rows[i]["id"] in s.lasting and i < len(rows) - 1:
        i += 1
    row = rows[i]
    if row["lasting"]:
        s.lasting.add(row["id"])
        return 0, False, 0
    s.stress += row["stress"]
    return row["lose"], row["zero"], row["spend_turns"]


def roll(rng, s, entry, bonus=0, gear=None, push_to=1, cover=None, extra_pen=0, allow_push=True,
         attribute=None, talent=None, responses=True):
    """One attribute roll. attribute defaults to the Catalog entry's; talent to the soldier's dice Talent on
    the entry. cover: the Covering soldier, who takes the Push's Stress, or True for a Coverer the family does
    not track (the Jam test's Covered columns). responses False leaves out Stress Responses, for the figures
    tuning.yaml reports without them."""
    COUNT["pools"] += 1
    attr = s.a(attribute or R.entry_attribute[entry])
    tal = s.talents.get(entry, 0) if talent is None else talent
    if talent is None and tal and s.talent_gear.get(entry) not in (None, gear):
        tal = 0      # talents.yaml, condition: Horsemanship adds to a dodge only with the horse's Gear Dice (OQ-121)
    pen = s.penalty(entry) + extra_pen
    if s.next_pen:
        pen += s.next_pen
        s.next_pen = 0
    base = max(R.min_base_dice, attr + tal + min(bonus, R.bonus_cap) - pen)
    ri = rng.randint
    bd = [ri(1, 6) for _ in range(base)]
    gd = [ri(1, 6) for _ in range(s.gear_dice(gear))] if gear else []
    sd = [ri(1, 6) for _ in range(s.stress)]
    succ = bd.count(SF) + gd.count(SF) + sd.count(SF)
    pushed = False
    covered = None
    sr = responses and 1 in sd
    if entry in RECKLESS_ENTRIES and s.has_scar("reckless-blade"):
        allow_push = True      # scars.yaml, reckless-blade: must Push when short and allowed to
    if allow_push and not (1 in sd) and succ < push_to and s.can_push():
        pushed = True
        extra = s.push_stress()
        if cover:
            covered = cover
            if cover is not True:
                cover.stress += R.cover_stress
                if cover.has_scar("carrying-their-weight"):
                    cover.stress += R.scar_rows["carrying-their-weight"]["stress"]
        else:
            s.stress += 1
            sd.append(0)
        s.stress += extra
        bd = [x if x == SF else ri(1, 6) for x in bd]
        sd = [x if x == SF else ri(1, 6) for x in sd]
        succ = bd.count(SF) + gd.count(SF) + sd.count(SF)
        sr = responses and 1 in sd
    spend = 0
    if sr:
        lose, zero, spend = stress_response(rng, s)
        succ = 0 if zero else max(0, succ - lose)
    return Roll(succ, pushed, gd.count(1) if pushed else 0, spend, covered)


# ---------------------------------------------------------------------- harm
def gain_ci(rng, s, loc=None, cannot_be_lethal=False, gained=0):
    """data/harm/critical-injuries.yaml, gaining. Returns the row, or "dead"."""
    if loc is None:
        r = rng.randint(1, 6)
        loc = next(l for res, l in R.ci_location_rows if covers(res, r))
    table = R.ci_tables[loc]
    # critical-injuries.yaml, worsening: held injuries at the location, and healed ones with permanent effects
    held = sum(1 for c in s.cis if c["row"]["loc"] == loc and (not c.get("healed") or c["row"]["perm"]))
    total = rng.randint(1, 6) + rng.randint(1, 6) + R.ci_per_held * held
    row = next(rw for rw in table["rows"] if covers(rw["results"], total))
    if row["perm"] and row["id"] in s.gained_perm:
        row = table["by_id"][row["repeat"]]
    if cannot_be_lethal and (row["lethal"] or row["instant_death"]):
        row = table["by_id"][table["cap"]]
    if row["instant_death"]:
        s.dead = True
        return "dead"
    if row["perm"]:
        s.gained_perm.add(row["id"])
    untreated = len(s.untreated())
    crossed_before = min(untreated, s.health)
    clean = s.health - crossed_before - s.health_lost
    s.cis.append({"row": row, "limit": row["limit"], "gained": gained, "treated": False, "scar_due": False,
                  "days": row["heal_days"], "healed": False})
    if clean <= 0 and crossed_before < s.health and s.health_lost > 0:
        s.health_lost -= 1
    s.stress += row["stress"]
    s.check_down()
    return row


def fall_damage(rng, s, band, gained=0):
    """data/gear/falls.yaml, procedure, with data/harm/health.yaml, harm_kinds, damage. Returns a Critical
    Injury row, "dead", or None."""
    dmg = R.fall_damage(rng.randint(1, 6) + R.fall_adds[band])
    if dmg == 0:
        return None
    if s.current_health() > 0:
        room = s.health - min(len(s.untreated()), s.health) - s.health_lost
        s.health_lost += min(dmg, room)
        if s.current_health() == 0:
            s.down = True
            return gain_ci(rng, s, gained=gained)
        return None
    return gain_ci(rng, s, gained=gained)


def gain_scar(rng, s):
    """scars.yaml, gaining, steps: D66, rolling again on a row held (and, for a Squadmate, on a row it rerolls);
    minimum Stress and Resolve rise; five Scars mark the soldier retiring. Returns the row id or None."""
    if s.scars >= R.scar_max:
        return None
    while True:
        rid = R.scar_by_result[10 * rng.randint(1, 6) + rng.randint(1, 6)]
        if rid in s.scar_rows or (not s.pc and R.scar_rows[rid]["squadmate_rerolls"]):
            continue
        break
    s.scar_rows.add(rid)
    s.scars += 1
    s.min_stress += R.min_stress_per_scar
    s.stress = max(s.stress, s.min_stress)
    if s.scars >= R.scar_max:
        s.retiring = True
    return rid


def fear_roll(rng, s, triggers=(), scar_rng=None):
    """data/mind/fear-rolls.yaml. Adds a Scar row's Fear Roll total for its triggers (scars.yaml), applies
    Stress, the next-roll penalty, and a Scar (its D66 on scar_rng); returns the row for the caller to spend
    turns and actions and set the ban on Reactions."""
    extra = sum(R.scar_rows[rid]["fear_total"] for rid in s.scar_rows
                if set(R.scar_rows[rid]["fear_triggers"]) & set(triggers))
    row = R.fear_row(rng.randint(1, 6) + s.stress - s.resolve + extra)
    s.stress += row["stress"]
    s.next_pen += row["next_pen"]
    if row["scar"]:
        gain_scar(scar_rng or rng, s)
    return row


def death_roll(rng, s, ci):
    """data/harm/death-rolls.yaml: the attribute plus a Talent naming death-roll, minus the injury's penalty; no
    Stress Dice, Help, Gear Dice, or Push. Returns the outcome id."""
    COUNT["pools"] += 1
    n = max(R.min_base_dice, s.a(R.death_attribute) + s.talents.get("death-roll", 0) - ci["row"]["dr_pen"])
    succ = sum(1 for _ in range(n) if rng.randint(1, 6) == SF)
    return R.death_outcome(succ)
