"""Runs every simulator case, the bar's second seeds, and the re-checks; writes tools/sim/results/results.json;
and renders docs/reviews/simulator-report.md. One command, from the repository root:

    uv run --with pyyaml python tools/sim/run.py

Options:
    --scale 0.05   every case at 5% of its trials, into results/results-scale.json and results/report-scale.md
                   (a smoke run; results.json and the committed report are left alone)
    --report       re-render the report from results/results.json only; refuses when any file of the rules
                   snapshot or the engine differs from the one the results record
    --stale-ok     with --report, render anyway and list those files, and report.ENGINE_CHANGES_SINCE_RUN when the
                   engine differs, at the top of the report

Passes, all inside the one command:
1. every case (cases.all_cases);
2. second seeds: the bar's (decision batch 4b, 4b-4), each Abnormal row, in the bar or its Grab-alone variant,
   past a limit under either death reading in an order, re-run with its twins in that order; and the targets'
   (decision batch 5, 5-11; targets.py), each case with a judged figure past a band's edge by at most 2 standard
   errors. results.json keeps each case pooled over both seeds under pooled, by its first key;
3. re-checks (recheck.py): every case with a figure past 3 standard errors from its committed probe figure is
   re-run on new seeds, and a Chapter 6 full-fight row on the committed probe as well;
4. the move-up shares and the lone route search, which are exact enumerations.

The rules snapshot is the SHA-256 of every file under docs/rules/ and data/, and of the simulator's own source.
docs/rules/OPEN-QUESTIONS.md and docs/rules/PROGRESS.md are hashed and listed but left out of the staleness test:
no case reads them, and report.py only checks that the Open Question ids it cites exist.
"""
import sys

sys.dont_write_bytecode = True     # the re-checks import the committed probe; nothing is written under tools/

import argparse   # noqa: E402
import copy       # noqa: E402
import datetime   # noqa: E402
import hashlib    # noqa: E402
import json       # noqa: E402
import os         # noqa: E402
import time       # noqa: E402
from multiprocessing import Pool   # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import barcheck as B   # noqa: E402
import cases as C      # noqa: E402
import families as F   # noqa: E402
import recheck as RC   # noqa: E402
import targets as TG   # noqa: E402

SNAPSHOT_DIRS = ("docs/rules", "docs/adr", "data")     # report.py reads ADR-0014's target words
NOT_RULES = {"docs/rules/OPEN-QUESTIONS.md", "docs/rules/PROGRESS.md"}
ENGINE_FILES = ("rules.py", "dice.py", "engine.py", "policy.py", "families.py", "cases.py", "barcheck.py",
                "targets.py", "recheck.py", "run.py")
RENDER_FILES = ("report.py", "README.md")

JOBS = {"fight": F.fight_job, "lone": F.lone_job, "solo": F.solo_job, "grab": F.grab_job, "jam": F.jam_job,
        "gas": F.gas_job, "dodge": F.dodge_job, "sequence": F.sequence_job}
COST = {"fight": 6, "lone": 4, "grab": 3, "solo": 1, "jam": 1, "gas": 1, "dodge": 1, "sequence": 24}


# ---------------------------------------------------------------------- the rules snapshot
def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        h.update(fh.read())
    return h.hexdigest()


def snapshot():
    files = {}
    for d in SNAPSHOT_DIRS:
        for dirpath, dirnames, names in os.walk(os.path.join(ROOT, d)):
            dirnames.sort()
            for name in sorted(names):
                if name.startswith("."):
                    continue
                p = os.path.join(dirpath, name)
                files[os.path.relpath(p, ROOT)] = sha(p)
    for name in ENGINE_FILES + RENDER_FILES:
        p = os.path.join(HERE, name)
        files[os.path.relpath(p, ROOT)] = sha(p)

    def combined(pred):
        h = hashlib.sha256()
        for p in sorted(files):
            if pred(p):
                h.update(f"{p}\0{files[p]}\n".encode())
        return h.hexdigest()
    sim = os.path.relpath(HERE, ROOT)
    return dict(files=files, taken_utc=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                rules_hash=combined(lambda p: not p.startswith(sim) and p not in NOT_RULES),
                docs_and_data_hash=combined(lambda p: not p.startswith(sim)),
                engine_hash=combined(lambda p: p.startswith(sim) and os.path.basename(p) in ENGINE_FILES),
                stale_test_excludes=sorted(NOT_RULES) + [os.path.join(sim, n) for n in RENDER_FILES])


def render_snapshot():
    """The hashes of the simulator's source when the report is rendered, printed beside the run's snapshot: report.py
    holds the coverage map, the target statuses, and the explanations, so the renderer that wrote a report's text
    is named even when --report renders results an earlier renderer's run wrote."""
    files = {os.path.relpath(os.path.join(HERE, n), ROOT): sha(os.path.join(HERE, n)) for n in ENGINE_FILES + RENDER_FILES}
    h = hashlib.sha256()
    for p in sorted(files):
        if os.path.basename(p) in ENGINE_FILES:
            h.update(f"{p}\0{files[p]}\n".encode())
    return dict(files=files, engine_hash=h.hexdigest(),
                taken_utc=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"))


def stale_files(recorded, after=None, noted=()):
    """Files that differ from the run's snapshot. A file that changed while the run was going is not stale when
    report.SNAPSHOT_CHANGE_NOTES explains the change and the file still matches the snapshot taken after the run:
    the report then prints both snapshots and the note."""
    now = snapshot()["files"]
    old = recorded["files"]
    skip = set(recorded["stale_test_excludes"])
    out = []
    for p in sorted(set(now) | set(old)):
        if p in skip or now.get(p) == old.get(p):
            continue
        if after is not None and p in noted and now.get(p) == after["files"].get(p):
            continue
        out.append(p)
    return out


# ---------------------------------------------------------------------- running cases
def work(args):
    fam, cfg, n, seed, idx = args
    if fam == "probe":
        return idx, RC.probe_job((cfg, n, seed))
    return idx, JOBS[fam]((cfg, n, seed))


def summarize(case, acc):
    fam = case["family"]
    n = acc["n"]
    if fam == "fight":
        return F.summarize_fight(acc)
    if fam == "lone":
        return F.summarize_lone(acc)
    if fam == "solo":
        return F.summarize_solo(acc)
    if fam == "grab":
        return F.summarize_grab(acc)
    if fam == "dodge":
        return F.summarize_rate(acc, "ok")
    if fam == "jam":
        out = F.summarize_rate(acc, "jammed")
        out["jammed"] = out["rate"]
        return out
    if fam == "gas":
        return dict(trials=n, median=F.median_from(acc["hist"]["rounds"], n), mean=acc["sum"]["rounds"] / n)
    if fam == "sequence":
        return F.summarize_sequence(acc)
    raise ValueError(fam)


def run_cases(pool, cases, t0, label):
    jobs = []
    for ci, c in enumerate(cases):
        base, rem = divmod(c["n"], C.CHUNKS)
        for i in range(C.CHUNKS):
            jobs.append((c["family"], c["cfg"], base + (rem if i == 0 else 0), c["seed"] * 1000 + i, ci))
    jobs.sort(key=lambda j: -COST.get(j[0], 8) * j[2])
    accs = [None] * len(cases)
    for done, (ci, acc) in enumerate(pool.imap_unordered(work, jobs, chunksize=1), 1):
        if cases[ci]["family"] == "probe":
            accs[ci] = (accs[ci] or []) + acc
        else:
            accs[ci] = F.merge(accs[ci], acc)
        if done % 1000 == 0 or done == len(jobs):
            print(f"{label}: {done}/{len(jobs)} chunks, {time.time() - t0:.0f} s", flush=True)
    return accs


def second_seed_cases(cases, summ):
    """The rows 4b-4 re-runs, with every twin they are read against, in the same order, under either reading; and
    every case holding a judged figure past a band's edge by at most 2 standard errors (targets.edge_keys)."""
    rows_def = C.PF["bar"]["rows"]
    ref_med = rows_def[0]["medium"]
    by_key = {c["key"]: c for c in cases}
    need = set()
    for prefix in ("bar", "grab_alone"):
        for order, _, _ in C.ORDERS:
            for r in rows_def:
                k = f"{prefix}/{order}/{r['abnormal']}"
                twins = [f"bar/{order}/{r['medium']}", f"bar/{order}/{r['large']}", f"bar/{order}/{ref_med}"]
                for reading in B.READINGS:
                    res = B.check(summ[k], *[summ[t] for t in twins], C.PF["fight"][r["abnormal"]]["cfg"].get("reference"),
                                  reading)
                    if B.past_any(res):
                        need.update([k] + twins)
    need.update(TG.edge_keys(summ))
    out = []
    seeds = {c["seed"] for c in cases}
    for k in sorted(need):
        c = by_key[k]
        seed = c["seed"] + C.SECOND_SEED_OFFSET
        if seed in seeds:
            raise ValueError(f"second seed {seed} for {k} repeats a seed already used")
        seeds.add(seed)
        out.append(dict(c, key=k.replace("/", "2/", 1), seed=seed, first_key=k))
    return out


def recheck_cases(cases, res):
    """Every case with a figure past 3 standard errors from its committed probe figure, on new seeds."""
    import report
    by_key = {c["key"]: c for c in cases}
    flagged = {}
    for cmp in report.comparisons(res):
        if abs(cmp["z"]) > 3 and not cmp.get("explained_by_rule") and cmp["key"] in by_key:
            fields = flagged.setdefault(cmp["key"], [])
            if cmp["field"] not in fields:
                fields.append(cmp["field"])
    out = []
    for k in sorted(flagged):
        c = by_key[k]
        out.append(dict(c, key="recheck/" + k, first_key=k, n=c["n"] * C.RECHECK_FACTOR,
                        seed=c["seed"] + C.RECHECK_SEED_OFFSET, figures=flagged[k]))
        if k.startswith("ch6/"):
            out.append(dict(family="probe", key="probe/" + k, first_key=k, cfg=c["cfg"], n=c["n"] * C.RECHECK_FACTOR,
                            seed=c["seed"] + C.PROBE_SEED_OFFSET, figures=flagged[k]))
    return out


# ---------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--scale", type=float, default=1.0)
    ap.add_argument("--report", action="store_true")
    ap.add_argument("--stale-ok", action="store_true",
                    help="with --report: render even if files differ from the run's snapshot, and list them at the top")
    args = ap.parse_args()
    full = args.scale >= 1
    out_path = os.path.join(HERE, "results", "results.json" if full else "results-scale.json")
    import report
    if args.report:
        with open(out_path) as fh:
            res = json.load(fh)
        stale = stale_files(res["snapshot"], res.get("snapshot_after_run"), report.SNAPSHOT_CHANGE_NOTES)
        if stale and not args.stale_ok:
            print("refusing to render: these files differ from the snapshot the results record "
                  "(re-run `uv run --with pyyaml python tools/sim/run.py`, or add --stale-ok to render with them "
                  "listed at the top of the report):")
            for p in stale:
                print("  " + p)
            sys.exit(1)
        report.write(res, full=full, render=render_snapshot(), stale=stale)
        return

    previous = None
    if os.path.exists(out_path):
        with open(out_path) as fh:
            try:
                previous = report.headlines(json.load(fh))
            except (KeyError, ValueError, TypeError) as exc:
                print(f"previous results unreadable for headline figures: {exc!r}")
    snap = snapshot()
    C.SCALE = args.scale
    cases = C.all_cases()
    t0 = time.time()
    procs = os.cpu_count() or 1
    with Pool(procs) as p:
        accs = run_cases(p, cases, t0, "cases")
        summ = {c["key"]: summarize(c, a) for c, a in zip(cases, accs)}
        second = second_seed_cases(cases, summ)
        print(f"second seed: {len(second)} cases (the bar and the targets)", flush=True)
        accs2 = run_cases(p, second, t0, "second seeds") if second else []
        first_acc = {c["key"]: a for c, a in zip(cases, accs)}
        pooled = {}
        for c, a in zip(second, accs2):
            pooled[c["first_key"]] = summarize(c, F.merge(copy.deepcopy(first_acc[c["first_key"]]), a))
        rows = [dict(c, summary=summ[c["key"]]) for c in cases]
        rows += [dict(c, summary=summarize(c, a)) for c, a in zip(second, accs2)]
        res = dict(scale=args.scale, cpus=procs, chunks=C.CHUNKS, cases=rows, pooled=pooled)
        rc = recheck_cases(cases, res)
        print(f"re-checks: {len(rc)} runs", flush=True)
        accs3 = run_cases(p, rc, t0, "re-checks") if rc else []
    rechecks = {}
    for c, a in zip(rc, accs3):
        entry = rechecks.setdefault(c["first_key"], {"figures": c["figures"]})
        if c["family"] == "probe":
            entry["probe"] = RC.probe_summary(a)
            entry["probe_seeds"] = f"{c['seed'] * 1000} to {c['seed'] * 1000 + C.CHUNKS - 1}"
        else:
            entry["sim"] = summarize(c, a)
            entry["sim_seeds"] = f"{c['seed'] * 1000} to {c['seed'] * 1000 + C.CHUNKS - 1}"
    res["rechecks"] = rechecks
    res["shares"] = {tid: F.share_report(tid) for tid in C.TITANS + ["reference-medium"]}
    res["route"] = F.route_check()
    res["runtime_seconds"] = round(time.time() - t0, 1)
    res["snapshot"] = snap
    after = snapshot()
    res["snapshot_changed_during_run"] = sorted(p for p in set(after["files"]) | set(snap["files"])
                                                if after["files"].get(p) != snap["files"].get(p))
    res["snapshot_after_run"] = after     # the report prints both, so a hash never stands for files that changed
    res["previous_headlines"] = previous
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w") as fh:
        json.dump(res, fh, indent=1, sort_keys=True)
    print(f"{len(rows)} cases, {sum(c['n'] for c in rows):,} trials, {res['runtime_seconds']:.0f} s on {procs} "
          f"processes -> {out_path}")
    report.write(res, full=full, render=render_snapshot(), stale=[])


if __name__ == "__main__":
    main()
