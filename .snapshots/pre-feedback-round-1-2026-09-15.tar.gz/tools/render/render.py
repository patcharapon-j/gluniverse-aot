"""Renders the rulebook's tables from data/ YAML into Chapters 2 to 5 of docs/rules/ (ADR-0012).

Run from the repository root with PyYAML:
- `uv run --with pyyaml python tools/render/render.py write` replaces every rendered block in Chapters 2 to 5.
- `uv run --with pyyaml python tools/render/render.py check` exits 1 if any rendered block differs from its YAML,
  names a source other than the file it renders, is unknown, is missing from its chapter, or appears twice.
- `uv run --with pyyaml python tools/render/render.py list` prints every block with its chapter and source.

A rendered block sits between `<!-- BEGIN RENDERED: name from data/....yaml -->` and
`<!-- END RENDERED: name -->`. The source named is the file whose rows the block renders; names of entries,
Talents, attributes, items, Positions, and Titans are looked up in their own files. Nothing between the markers
is written by hand.

Every renderer checks the keys of the rows it reads, so a value that YAML silently splits into extra keys (an
unquoted comma or colon in a flow mapping) fails the check instead of rendering half a rule.

Chapter 6's stat blocks, Behavior Tables, and probe figures stay on tools/probes/chapter-06/render.py, whose
blocks read titans.py's share enumeration and the collected probe results; check them with `render.py check`
in that folder.
"""
import os
import re
import sys

import yaml

sys.dont_write_bytecode = True
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

CH2 = "docs/rules/02-character-creation.md"
CH3 = "docs/rules/03-harm-and-mind.md"
CH4 = "docs/rules/04-gear.md"
CH5 = "docs/rules/05-titan-engagement.md"
CHAPTERS = [CH2, CH3, CH4, CH5]

ATTR = "data/character/attributes.yaml"
ORIG = "data/character/origins.yaml"
ENL = "data/character/enlistment.yaml"
TY = "data/character/training-years.yaml"
CR = "data/character/class-rank.yaml"
EXAM = "data/character/graduation-exam.yaml"
SPEC = "data/character/specialties.yaml"
TAL = "data/character/talents.yaml"
CAT = "data/character/action-catalog.yaml"
SQ = "data/character/squadmates.yaml"
CI = "data/harm/critical-injuries.yaml"
EFF = "data/harm/effect-types.yaml"
SR = "data/mind/stress-responses.yaml"
FR = "data/mind/fear-rolls.yaml"
SC = "data/mind/scars.yaml"
FALL = "data/gear/falls.yaml"
ISSUE = "data/gear/standard-issue.yaml"
ITEMS = "data/gear/items.yaml"
SUP = "data/gear/squad-supply.yaml"
SETUP = "data/engagement/engagement-setup.yaml"
ANCH = "data/engagement/anchor-ratings.yaml"
SIZE = "data/engagement/size-classes.yaml"
POSN = "data/engagement/positions.yaml"
TIDX = "data/titans/index.yaml"

_CACHE = {}


class RenderError(Exception):
    pass


def load(rel):
    if rel not in _CACHE:
        with open(os.path.join(ROOT, rel)) as fh:
            _CACHE[rel] = yaml.safe_load(fh)
    return _CACHE[rel]


# ------------------------------------------------------------------ formatting
def cell(v):
    if isinstance(v, bool):
        raise RenderError(f"a true/false value reached a table cell unformatted: {v}")
    if v is None:
        raise RenderError("an empty value reached a table cell")
    return " ".join(str(v).split()).replace("|", "\\|")


def table(headers, rows):
    out = ["| " + " | ".join(headers) + " |", "|" + "---|" * len(headers)]
    for r in rows:
        if len(r) != len(headers):
            raise RenderError(f"row has {len(r)} cells for {len(headers)} columns: {r}")
        out.append("| " + " | ".join(cell(c) for c in r) + " |")
    return "\n".join(out)


def expect_keys(row, allowed, where, required=()):
    extra = set(row) - set(allowed)
    if extra:
        raise RenderError(f"{where}: unexpected keys {sorted(map(str, extra))} (an unquoted comma or colon splits a value)")
    missing = [k for k in required if k not in row]
    if missing:
        raise RenderError(f"{where}: missing keys {missing}")


def yes_no(v):
    if not isinstance(v, bool):
        raise RenderError(f"expected true or false, got {v!r}")
    return "yes" if v else "no"


def runs(values):
    """Die results as ranges: [11, 12, 13] reads 11–13."""
    vals = sorted(values)
    parts, start, prev = [], vals[0], vals[0]
    for v in vals[1:]:
        if v == prev + 1:
            prev = v
            continue
        parts.append((start, prev))
        start = prev = v
    parts.append((start, prev))
    return ", ".join(str(a) if a == b else f"{a}–{b}" for a, b in parts)


def bounds(lo, hi):
    """A min and max where null is open-ended."""
    if lo is None and hi is None:
        return "any"
    if lo is None:
        return f"{hi} or less"
    if hi is None:
        return f"{lo} or more"
    return str(lo) if lo == hi else f"{lo}–{hi}"


def signed(n):
    return f"+{n}" if n > 0 else str(n)


def chapter(ref):
    m = re.match(r"^(\d\d)-", ref)
    if m:
        return f"Chapter {int(m.group(1))}"
    if ref == "rules-not-yet-written":
        return "not yet written"
    return ref


# ------------------------------------------------------------------ lookups
def attr_name(aid):
    names = {a["id"]: a["name"] for a in load(ATTR)["attributes"]}
    if aid not in names:
        raise RenderError(f"unknown attribute {aid}")
    return names[aid]


def specialty_name(sid):
    names = {s["id"]: s["name"] for s in load(SPEC)["specialties"]}
    if sid not in names:
        raise RenderError(f"unknown Specialty {sid}")
    return names[sid]


def catalog():
    return {e["id"]: e for e in load(CAT)["entries"]}


def entry_status(e):
    return "dormant" if e.get("dormant") else "reserved" if e.get("reserved") else None


def entry_name(eid, status=True):
    cat = catalog()
    if eid not in cat:
        raise RenderError(f"unknown Action Catalog entry {eid}")
    e = cat[eid]
    st = entry_status(e)
    return f"{e['name']} ({st})" if status and st else e["name"]


def talents():
    return {t["id"]: t for t in load(TAL)["talents"]}


def talent_name(tid, status=True):
    ts = talents()
    if tid not in ts:
        raise RenderError(f"unknown Talent {tid}")
    t = ts[tid]
    if status:
        flags = [entry_status(catalog()[e]) for e in t["names"]]
        if all(flags):
            return f"{t['name']} ({' or '.join(sorted(set(flags)))})"
    return t["name"]


def item_name(iid):
    names = {i["id"]: i["name"] for i in load(ITEMS)["items"]}
    if iid not in names:
        raise RenderError(f"unknown gear item {iid}")
    return names[iid]


def position_name(pid):
    names = {p["id"]: p["name"] for p in load(POSN)["positions"]}
    if pid not in names:
        raise RenderError(f"unknown Position {pid}")
    return names[pid]


def titan_name(tid):
    return load(f"data/titans/{tid}.yaml")["name"]


EFFECT_KEYS = {"type", "dice", "entries", "amount", "turns", "text", "applies_to", "applies_after"}


def effect(e):
    expect_keys(e, EFFECT_KEYS, f"effect {e.get('type')}", required=("type",))
    known = {t["id"] for t in load(EFF)["effect_types"]}
    t = e["type"]
    if t not in known:
        raise RenderError(f"effect type {t} is not in {EFF}")
    if t == "penalty":
        base = f"{e['dice']}-die penalty on " + ", ".join(entry_name(x, False) for x in e["entries"])
    elif t == "next-roll-penalty":
        base = f"{e['dice']}-die penalty on the next roll"
    elif t == "stress-gain":
        base = f"gain {e['amount']} Stress"
    elif t == "push-stress":
        base = f"{e['amount']} extra Stress on every Push"
    elif t == "lose-successes":
        base = f"lose {e['amount']} success" + ("" if e["amount"] == 1 else "es")
    elif t == "zero-successes":
        base = "the roll fails"
    elif t == "spend-next-turn":
        base = "next turn spent" if e["turns"] == 1 else f"next {e['turns']} turns spent"
    elif t == "spend-next-action":
        base = "next action spent"
    elif t == "no-reactions":
        base = "no Reactions"
    elif t == "fear-roll-total":
        base = f"Fear Roll total +{e['amount']}"
    elif t == "gain-scar":
        base = "gain a Scar"
    elif t == "other":
        base = e["text"]
    else:
        raise RenderError(f"effect type {t} has no rendering")
    if e.get("applies_to"):
        base += f" ({e['applies_to']})"
    if e.get("applies_after"):
        base += f", after {e['applies_after']}"
    return base


def effects(lst, empty):
    return "; ".join(effect(e) for e in lst) if lst else empty


# ------------------------------------------------------------------ Chapter 2
def b_attributes():
    rows = []
    for a in load(ATTR)["attributes"]:
        expect_keys(a, {"id", "name", "summary", "used_by", "key_attribute_of"}, f"{ATTR} {a.get('id')}")
        rows.append([a["name"], a["summary"], ", ".join(entry_name(x) for x in a["used_by"]),
                     ", ".join(specialty_name(s) for s in a["key_attribute_of"])])
    return table(["Attribute", "Covers", "Action Catalog entries that name it", "Key attribute of"], rows)


def b_origins():
    d = load(ORIG)
    rows = []
    for r in d["rows"]:
        expect_keys(r, {"id", "results", "name", "description", "attributes", "talent_choice", "haven_choice",
                        "canon_tie", "condition"}, f"{ORIG} {r.get('id')}")
        tie = f"{r['canon_tie']['character']}: {r['canon_tie']['link']}" if r["canon_tie"] else "none"
        if r["condition"] is None:
            cond = "no condition"
        else:
            parts = []
            for k, v in r["condition"].items():
                if k not in d["condition_fields"]:
                    raise RenderError(f"{ORIG} {r['id']}: condition {k} is not in condition_fields")
                if k == "campaign_year_min":
                    parts.append(f"Campaign Year {v} or later")
                else:
                    raise RenderError(f"{ORIG}: condition {k} has no rendering")
            cond = "; ".join(parts)
        rows.append([runs(r["results"]), r["name"], ", ".join(attr_name(a) for a in r["attributes"]),
                     " or ".join(talent_name(t) for t in r["talent_choice"]), "<br>".join(r["haven_choice"]),
                     tie, cond, r["description"]])
    return ("**Origin (D66)**\n\n" +
            table(["D66", "Origin", "+1 to each", "Talent level 1 in one of", "Haven, one of", "Canon Tie (optional)",
                   "Keep the row only with", "Description"], rows))


def b_enlistment():
    rows = []
    for r in load(ENL)["rows"]:
        expect_keys(r, {"id", "results", "reason", "attribute", "drive"}, f"{ENL} {r.get('id')}")
        dv = r["drive"]
        expect_keys(dv, {"id", "name", "trigger", "test", "acts", "target", "needs_named_comrade", "notes"},
                    f"{ENL} {r['id']} drive")
        trigger = dv["trigger"] + (" " + dv["notes"] if dv.get("notes") else "")
        acts = ", ".join("Push" if a == "push" else entry_name(a, False) for a in dv.get("acts", [])) or "—"
        rows.append([runs(r["results"]), r["reason"], attr_name(r["attribute"]), dv["name"], trigger,
                     f"`{dv['test']}`", acts, f"`{dv['target']}`", yes_no(dv["needs_named_comrade"])])
    return ("**Why You Enlisted (D66)**\n\n" +
            table(["D66", "Why you enlisted", "+1", "Drive", "Trigger", "Test", "Acts", "Target",
                   "Needs a named comrade"], rows))


def b_training_years():
    rows = []
    for y in load(TY)["years"]:
        rows.append([y["name"], " and ".join(attr_name(a) for a in y["performance_attributes"]),
                     ", ".join(talent_name(t) for t in y["curriculum"])])
    return (table(["Training Year", "Performance attributes", "Curriculum"], rows) +
            "\n\nA Talent marked dormant or reserved names only dormant or reserved Action Catalog entries (section 2.8).")


def b_year(yid):
    years = {y["id"]: y for y in load(TY)["years"]}
    y = years[yid]
    rows = []
    for e in y["events"]:
        expect_keys(e, {"results", "name", "description", "attribute", "talent_choice", "merit_change"},
                    f"{TY} {yid} {e.get('name')}")
        rows.append([runs(e["results"]), e["name"], attr_name(e["attribute"]),
                     " or ".join(talent_name(t) for t in e["talent_choice"]), signed(e["merit_change"]), e["description"]])
    return (f"**{y['name']}: events (D66)**\n\n" +
            table(["D66", "Event", "+1", "Talent level in one of", "Merit", "Description"], rows))


def b_merit():
    rows = []
    for r in load(TY)["performance_roll"]["merit_from_successes"]:
        expect_keys(r, {"successes_min", "successes_max", "merit"}, f"{TY} merit_from_successes")
        rows.append([bounds(r["successes_min"], r["successes_max"]), r["merit"]])
    return table(["Performance roll successes", "Merit"], rows)


def b_class_rank():
    rows = []
    for r in load(CR)["rows"]:
        expect_keys(r, {"merit_min", "merit_max", "class_rank", "top_10"}, f"{CR} row")
        rows.append([bounds(r["merit_min"], r["merit_max"]), r["class_rank"], yes_no(r["top_10"])])
    return table(["Merit total", "Class Rank", "Top 10"], rows)


def merit_rule(rows):
    for r in rows:
        expect_keys(r, {"successes_min", "successes_max", "merit"}, f"{EXAM} merit")
    return "; ".join(f"{bounds(r['successes_min'], r['successes_max'])} successes: {r['merit']} Merit" for r in rows)


def b_exam():
    d = load(EXAM)
    trials = {t["id"]: t for t in d["trials"]}
    rows = []
    for i, tid in enumerate(d["order"], 1):
        t = trials[tid]
        if "entry" in t:
            entry, gear = entry_name(t["entry"], False), t["gear_item"] or "none"
        else:
            entry, gear = "one of the entry choices below", "listed with each choice"
        help_ = "none" if t["help"] == "none" else "fixed by the Trial's roll order (see the list below)"
        rows.append([i, t["name"], entry, gear, yes_no(t["push"]), help_, merit_rule(t["merit"])])
    out = table(["Order", "Trial", "Action Catalog entry", "Gear item", "Can be Pushed", "Help", "Merit"], rows)
    for t in d["trials"]:
        if "entry_choice" in t:
            choices = []
            for c in t["entry_choice"]:
                expect_keys(c, {"entry", "gear_item"}, f"{EXAM} entry_choice")
                choices.append([entry_name(c["entry"], False), c["gear_item"] or "none"])
            out += (f"\n\n**{t['name']}: entry choices** (each needs {t['needs']} successes)\n\n" +
                    table(["Entry", "Gear item"], choices))
    return out


def b_specialties():
    rows = []
    for s in load(SPEC)["specialties"]:
        expect_keys(s, {"id", "name", "key_attribute", "summary", "talents", "squadmate_template"}, f"{SPEC} {s.get('id')}")
        rows.append([s["name"], attr_name(s["key_attribute"]), s["summary"], ", ".join(talent_name(t) for t in s["talents"])])
    return table(["Specialty", "Key attribute", "Summary", "Talent list"], rows)


def b_templates():
    attrs = [a["id"] for a in load(ATTR)["attributes"]]
    rows = []
    for t in load(SQ)["templates"]:
        expect_keys(t, {"id", "specialty", "attributes", "talent", "health", "resolve"}, f"{SQ} template {t.get('id')}")
        if set(t["attributes"]) != set(attrs):
            raise RenderError(f"{SQ} template {t['id']}: attributes {sorted(t['attributes'])}")
        rows.append([specialty_name(t["specialty"])] + [t["attributes"][a] for a in attrs] +
                    [f"{talent_name(t['talent']['id'], False)} {t['talent']['level']}", t["health"], t["resolve"]])
    return table(["Template"] + [attr_name(a) for a in attrs] + ["Talent", "Health", "Resolve"], rows)


def b_squadmate_rules():
    rows = []
    for r in load(SQ)["rules_applicability"]:
        expect_keys(r, {"rule", "applies", "source", "note"}, f"{SQ} rules_applicability", required=("rule", "applies"))
        applies = yes_no(r["applies"]) if isinstance(r["applies"], bool) else r["applies"]
        rows.append([r["rule"], applies, chapter(r["source"]) if r.get("source") else "—", r.get("note", "—")])
    return table(["Rule", "Applies to a Squadmate", "Chapter", "Note"], rows)


TALENT_KEYS = {"id", "name", "description", "type", "max_level", "names", "specialties", "decided", "trigger", "effect",
               "limit", "rules", "condition"}


def b_talents(kind):
    limits = load(TAL)["talent_rules"]["limit_terms"]
    rows = []
    for t in load(TAL)["talents"]:
        expect_keys(t, TALENT_KEYS, f"{TAL} {t.get('id')}")
        if t["type"] != kind:
            continue
        cond = t.get("condition") or {}
        for x in cond:
            if x not in t["names"]:
                raise RenderError(f"{TAL} {t['id']}: condition names {x}, which the Talent does not name")
        names = ", ".join(entry_name(x) + (f" ({cond[x]})" if x in cond else "") for x in t["names"])
        specs = ", ".join(specialty_name(s) for s in t["specialties"]) or "none"
        if kind == "dice":
            rows.append([t["name"], names, t["max_level"], specs, t["description"]])
        else:
            if t["limit"] == "none":
                limit = "none"
            elif t["limit"] in limits and t["limit"] == "once_per_titan_engagement":
                limit = "once per Titan Engagement"
            else:
                raise RenderError(f"{TAL} {t['id']}: limit {t['limit']} has no rendering")
            rows.append([t["name"], names, t["trigger"], t["effect"], limit, t["max_level"], specs, t["description"]])
    if kind == "dice":
        return table(["Talent", "Names", "Max level", "Specialty lists", "Description"], rows)
    return table(["Talent", "Names", "Trigger", "Effect", "Limit", "Max level", "Specialty lists", "Description"], rows)


ENTRY_KEYS = {"id", "name", "kind", "rolled", "attribute", "gear", "requires_gear", "without_gear", "context",
              "requirements", "needs", "changes", "help_outside_titan_engagement", "rules", "decided", "adrs", "notes",
              "option_of", "reserved", "dormant"}
KIND = {"action": "action", "reaction": "Reaction", "roll": "roll", "option": "option", "fixed-roll": "fixed roll"}
ROLLED = {"when_taken": "when taken", "when_a_rule_calls": "when a rule calls for it", "never": "never"}
CONTEXT = {"titan-engagement": "in a Titan Engagement", "any": "anywhere", "lifepath": "in the Lifepath"}
WITHOUT = {"not_possible": "yes; without it the entry cannot be used", "attribute_alone": "yes; without it, attribute alone"}


def lookup(table_, key, where):
    if key not in table_:
        raise RenderError(f"{where}: {key!r} has no rendering")
    return table_[key]


def b_catalog():
    rows = []
    for e in load(CAT)["entries"]:
        expect_keys(e, ENTRY_KEYS, f"{CAT} {e.get('id')}")
        where = f"{CAT} {e['id']}"
        if e["attribute"] is None:
            attribute = "—"
        elif e["attribute"] == "from_performance_attributes":
            attribute = "the Training Year's performance attribute"
        else:
            attribute = attr_name(e["attribute"])
        gear = e.get("gear", [])
        if e.get("requires_gear") is True:
            needs_gear = lookup(WITHOUT, e["without_gear"], where)
        elif e.get("requires_gear") is False and gear:
            needs_gear = "no"
        else:
            needs_gear = "—"
        rows.append([e["name"], f"`{e['id']}`", lookup(KIND, e["kind"], where), lookup(ROLLED, e["rolled"], where),
                     attribute, ", ".join(item_name(g) for g in gear) or "none", needs_gear,
                     lookup(CONTEXT, e["context"], where), entry_status(e) or "—"])
    return table(["Entry", "Id", "Kind", "Rolled", "Attribute", "Gear items", "Needs its gear", "Used", "Status"], rows)


def tracked_values():
    tvs = load(CAT)["tracked_values"]
    for tv in tvs:
        expect_keys(tv, {"id", "name", "rules", "changed_by"}, f"{CAT} tracked_values {tv.get('id')}")
    return {tv["id"]: tv for tv in tvs}


def b_catalog_requirements():
    tvs = tracked_values()
    rows = []
    for e in load(CAT)["entries"]:
        expect_keys(e, ENTRY_KEYS, f"{CAT} {e.get('id')}")
        req = e.get("requirements", "—")
        if e.get("option_of"):
            req = f"Option of {e['option_of']}. " + (req if req != "—" else "")
        changes = ", ".join(lookup({k: v["name"] for k, v in tvs.items()}, c, f"{CAT} {e['id']} changes")
                            for c in e.get("changes", [])) or "none"
        rows.append([e["name"], req.strip(), e.get("needs", "—"), changes, e.get("help_outside_titan_engagement", "—"),
                     e.get("notes", "—"), ", ".join(chapter(r) for r in e.get("rules", [])) or "—"])
    return table(["Entry", "Requirements", "Needs", "Changes", "Help outside a Titan Engagement", "Notes", "Rules in"], rows)


def b_tracked_values():
    entries = load(CAT)["entries"]
    rows = []
    for tid, tv in tracked_values().items():
        by = ", ".join(e["name"] for e in entries if tid in e.get("changes", [])) or "none"
        rows.append([f"`{tid}`", tv["name"], by, tv.get("changed_by", "—"), ", ".join(chapter(r) for r in tv["rules"])])
    return table(["Id", "Tracked value", "Entries that change it", "Otherwise changed by", "Rules in"], rows)


# ------------------------------------------------------------------ Chapter 3
def b_injury_location():
    rows = []
    for r in load(CI)["injury_location_table"]["rows"]:
        expect_keys(r, {"results", "injury_location"}, f"{CI} injury_location_table")
        rows.append([bounds(r["results"]["min"], r["results"]["max"]), r["injury_location"]])
    return table(["D6", "Injury Location"], rows)


CI_KEYS = {"id", "name", "results", "down", "lethal", "time_limit", "death_roll_penalty", "instant_death", "effects",
           "healing_days", "permanent_effects", "repeat_row"}


def b_critical_injuries(loc):
    d = load(CI)
    tab = d["tables"][loc]
    by_id = {r["id"]: r for r in tab["rows"]}
    rows = []
    for r in tab["rows"]:
        expect_keys(r, CI_KEYS, f"{CI} {r.get('id')}")
        res = bounds(r["results"]["min"], r["results"]["max"])
        if r.get("instant_death"):
            rows.append([res, r["name"], "—", "instant death", "—", "—", "—", "—", "—"])
            continue
        if r["down"] == "until_treated":
            down = "until treated"
        elif r["down"] is False:
            down = "no"
        else:
            raise RenderError(f"{CI} {r['id']}: down {r['down']!r} has no rendering")
        lethal = f"yes, `{r['time_limit']}` limit" if r["lethal"] else "no"
        repeat = by_id[r["repeat_row"]]["name"] if r.get("repeat_row") else "—"
        rows.append([res, r["name"], down, lethal, r["death_roll_penalty"], effects(r["effects"], "none"),
                     r["healing_days"], effects(r.get("permanent_effects"), "—"), repeat])
    cap = by_id[tab["non_lethal_cap"]]["name"]
    per = d["worsening"]["per_held_injury"]
    head = (f"**{loc.capitalize()}** (2D6 + {per} for each {loc} Critical Injury that counts toward worsening; "
            f"a Critical Injury that cannot be lethal uses {cap} in place of a lethal or instant-death row)")
    return head + "\n\n" + table(["2D6 total", "Critical Injury", "Down", "Lethal", "Death Roll penalty",
                                  "Effects while held", "Healing days", "Permanent effects", "If gained before, use"], rows)


def b_stress_responses():
    t = load(SR)["table"]
    rows = []
    for r in t["rows"]:
        expect_keys(r, {"id", "name", "results", "duration", "effects"}, f"{SR} {r.get('id')}")
        rows.append([bounds(r["results"]["min"], r["results"]["max"]), r["name"], r["duration"], effects(r["effects"], "none")])
    return table(["D6 + Stress − Resolve", "Stress Response", "Duration", "Effects"], rows)


FORBIDS = {"reaction": "Reactions", "push": "Pushing", "help": "Help", "cover": "Covering"}


def b_fear_rolls():
    t = load(FR)["table"]
    rows = []
    for r in t["rows"]:
        expect_keys(r, {"id", "name", "results", "effects", "forbids"}, f"{FR} {r.get('id')}")
        forbids = ", ".join(lookup(FORBIDS, f, f"{FR} {r['id']} forbids") for f in r.get("forbids", [])) or "—"
        rows.append([bounds(r["results"]["min"], r["results"]["max"]), r["name"], effects(r["effects"], "none"), forbids])
    return table(["D6 + Stress − Resolve", "Result", "Effects", "Forbids"], rows)


def b_scars():
    rows = []
    for r in load(SC)["table"]["rows"]:
        expect_keys(r, {"id", "name", "results", "trigger", "effects", "squadmate_rerolls"}, f"{SC} {r.get('id')}")
        rerolls = yes_no(r["squadmate_rerolls"]) if "squadmate_rerolls" in r else "no"
        rows.append([runs(r["results"]), r["name"], r["trigger"], effects(r["effects"], "none"), rerolls])
    return table(["D66", "Scar", "Trigger", "Effect", "A Squadmate rolls again"], rows)


# ------------------------------------------------------------------ Chapter 4
def b_fall_bands():
    rows = []
    for b in load(FALL)["height"]["bands"]:
        expect_keys(b, {"id", "adds"}, f"{FALL} bands")
        rows.append([b["id"].capitalize(), signed(b["adds"]) if b["adds"] else "+0"])
    return table(["Band", "Adds to the D6"], rows)


def b_fall_damage():
    rows = []
    for r in load(FALL)["damage_table"]["rows"]:
        expect_keys(r, {"id", "results", "damage"}, f"{FALL} damage_table")
        rows.append([bounds(r["results"]["min"], r["results"]["max"]), r["id"].replace("-", " ").capitalize(), r["damage"]])
    return table(["D6 + the band's value", "Landing", "Damage"], rows)


def funding_label(n):
    default = load(ISSUE)["funding"]["until_funding_rules"]
    return f"{n} (used until the Funding rules are written)" if n == default else n


def b_standard_issue():
    d = load(ISSUE)
    every = d["every_row"]
    expect_keys(every, {"fitted_canister", "blade_set_rating"}, f"{ISSUE} every_row")
    fitted = every["fitted_canister"].split(" (")[0]
    rows = []
    for r in d["by_funding"]:
        expect_keys(r, {"funding", "odm_gear_rating", "spare_canisters", "blade_sets", "horse_rating"}, f"{ISSUE} by_funding")
        rows.append([funding_label(r["funding"]), r["odm_gear_rating"], fitted, r["spare_canisters"], r["blade_sets"],
                     every["blade_set_rating"], r["horse_rating"]])
    out = ("**By Funding**\n\n" +
           table(["Funding", "ODM Gear rating", "Fitted canister", "Spare canisters",
                  "Blade Sets, counting the one in the handles", "Blade Set rating", "Horse rating"], rows))
    spec = []
    for r in d["by_specialty"]["rows"]:
        expect_keys(r, {"specialty", "item", "rating"}, f"{ISSUE} by_specialty")
        spec.append([specialty_name(r["specialty"]), item_name(r["item"]), r["rating"]])
    out += "\n\n**By Specialty**\n\n" + table(["Specialty", "Item", "Rating"], spec) + "\n\n" + d["by_specialty"]["others"]
    return out


def b_squad_supply():
    d = load(SUP)
    kinds = [k for k in d["kinds"] if k["id"] != "rations"]
    rows = []
    for r in d["stock"]["by_funding"]:
        expect_keys(r, {"funding"} | {k["id"] for k in kinds}, f"{SUP} stock", required=[k["id"] for k in kinds])
        rows.append([funding_label(r["funding"])] + [r[k["id"]] for k in kinds])
    return table(["Funding"] + [k["name"] for k in kinds], rows) + f"\n\nRations: {d['stock']['rations']}."


# ------------------------------------------------------------------ Chapter 5
def b_interim_setup():
    d = load(SETUP)
    anchors = {r["id"]: r["name"] for r in load(ANCH)["ratings"]}
    sizes = {c["id"]: c for c in load(SIZE)["classes"]}
    std = load(TIDX)["standard_titans"]
    t1 = []
    for r in d["anchor_rating"]["rows"]:
        expect_keys(r, {"results", "anchor_rating"}, f"{SETUP} anchor_rating")
        t1.append([runs(r["results"]), lookup(anchors, r["anchor_rating"], f"{SETUP} anchor_rating")])
    t2 = []
    for r in d["size_class"]["rows"]:
        expect_keys(r, {"results", "size_class"}, f"{SETUP} size_class")
        c = sizes[r["size_class"]]
        t2.append([runs(r["results"]), f"{c['name']} ({c['height']})", titan_name(std[r["size_class"]])])
    t3 = []
    for r in d["medium_abnormal"]["rows"]:
        expect_keys(r, {"results", "titan"}, f"{SETUP} medium_abnormal")
        t3.append([runs(r["results"]), titan_name(r["titan"])])
    t4 = []
    for r in d["background_titans"]["rows"]:
        expect_keys(r, {"results", "clocks"}, f"{SETUP} background_titans")
        t4.append([runs(r["results"]), len(r["clocks"]) or "none", ", ".join(str(c) for c in r["clocks"]) or "—"])
    return ("**Anchor Rating (D6)**\n\n" + table(["D6", "Anchor Rating"], t1) +
            "\n\n**Size Class (D6), for the Focus Titan and for each Background Titan**\n\n" +
            table(["D6", "Size Class", "Standard Titan"], t2) +
            "\n\n**On Medium: `medium_abnormal` (D6)**\n\n" + table(["D6", "Focus Titan"], t3) +
            "\n\n**Background Titans (D6)**\n\n" + table(["D6", "Background Titans", "Clock lengths, in order"], t4) +
            f"\n\n**Retreat clock:** {d['retreat_clock']} segments, for every Titan Engagement this table sets up (no roll).")


def b_position_steps():
    rows = []
    for rt in load(ANCH)["ratings"]:
        for s in rt["steps"]:
            expect_keys(s, {"between", "on_foot", "mounted", "odm", "fly_roll"}, f"{ANCH} {rt['id']} step")
            a, b = s["between"]
            fly = "—"
            if s.get("fly_roll"):
                expect_keys(s["fly_roll"], {"needs", "failure_ends_at"}, f"{ANCH} {rt['id']} fly_roll")
                fly = (f"needs {s['fly_roll']['needs']}; on a failure the move ends at "
                       f"{position_name(s['fly_roll']['failure_ends_at'])}")
            rows.append([rt["name"], f"{position_name(a)} to {position_name(b)}", yes_no(s["on_foot"]),
                         yes_no(s["mounted"]), yes_no(s["odm"]), fly])
    return table(["Anchor Rating", "Position step (either way)", "On foot", "Mounted", "ODM", "Fly roll"], rows)


# ------------------------------------------------------------------ registry
BLOCKS = {}


def block(name, chapter_, source, fn):
    if name in BLOCKS:
        raise RenderError(f"block {name} registered twice")
    BLOCKS[name] = dict(chapter=chapter_, source=source, fn=fn)


block("attributes", CH2, ATTR, b_attributes)
block("origins", CH2, ORIG, b_origins)
block("why-you-enlisted", CH2, ENL, b_enlistment)
block("training-years", CH2, TY, b_training_years)
for _y in ("year-1", "year-2", "year-3"):
    block(f"training-year-events {_y}", CH2, TY, lambda y=_y: b_year(y))
block("performance-merit", CH2, TY, b_merit)
block("class-rank", CH2, CR, b_class_rank)
block("graduation-exam-trials", CH2, EXAM, b_exam)
block("specialties", CH2, SPEC, b_specialties)
block("squadmate-templates", CH2, SQ, b_templates)
block("squadmate-rules", CH2, SQ, b_squadmate_rules)
block("talents-dice", CH2, TAL, lambda: b_talents("dice"))
block("talents-rule", CH2, TAL, lambda: b_talents("rule"))
block("action-catalog", CH2, CAT, b_catalog)
block("action-catalog-requirements", CH2, CAT, b_catalog_requirements)
block("tracked-values", CH2, CAT, b_tracked_values)
block("injury-location", CH3, CI, b_injury_location)
for _loc in ("arm", "leg", "torso", "head"):
    block(f"critical-injuries {_loc}", CH3, CI, lambda loc=_loc: b_critical_injuries(loc))
block("stress-responses", CH3, SR, b_stress_responses)
block("fear-rolls", CH3, FR, b_fear_rolls)
block("scars", CH3, SC, b_scars)
block("fall-bands", CH4, FALL, b_fall_bands)
block("fall-damage", CH4, FALL, b_fall_damage)
block("standard-issue", CH4, ISSUE, b_standard_issue)
block("squad-supply", CH4, SUP, b_squad_supply)
block("interim-setup", CH5, SETUP, b_interim_setup)
block("position-steps", CH5, ANCH, b_position_steps)


def marker(name):
    b = BLOCKS[name]
    return f"<!-- BEGIN RENDERED: {name} from {b['source']} -->\n<!-- END RENDERED: {name} -->"


PATTERN = re.compile(r"<!-- BEGIN RENDERED: (?P<name>.+?) from (?P<src>\S+) -->\n(?P<body>.*?)<!-- END RENDERED: (?P=name) -->",
                     re.S)


def render_chapter(rel):
    with open(os.path.join(ROOT, rel)) as fh:
        text = fh.read()
    problems, changed, seen = [], [], []

    def sub(m):
        name = m.group("name")
        b = BLOCKS.get(name)
        if b is None:
            problems.append(f"{rel}: unknown block {name!r}")
            return m.group(0)
        if b["chapter"] != rel:
            problems.append(f"{rel}: block {name!r} belongs in {b['chapter']}")
            return m.group(0)
        seen.append(name)
        try:
            body = b["fn"]()
        except (RenderError, KeyError, TypeError, ValueError, FileNotFoundError) as exc:
            problems.append(f"{rel}: block {name!r} cannot render: {type(exc).__name__}: {exc}")
            return m.group(0)
        new = f"<!-- BEGIN RENDERED: {name} from {b['source']} -->\n{body}\n<!-- END RENDERED: {name} -->"
        if new != m.group(0):
            changed.append(name if m.group("src") == b["source"] else f"{name} (marker names {m.group('src')})")
        return new

    new_text = PATTERN.sub(sub, text)
    if text.count("<!-- BEGIN RENDERED:") != len(PATTERN.findall(text)):
        problems.append(f"{rel}: a BEGIN RENDERED marker has no matching END RENDERED marker")
    for name in sorted(set(n for n in seen if seen.count(n) > 1)):
        problems.append(f"{rel}: block {name!r} appears more than once")
    for name, b in BLOCKS.items():
        if b["chapter"] == rel and name not in seen:
            problems.append(f"{rel}: block {name!r} is missing")
    return text, new_text, problems, changed


def main(argv):
    if len(argv) != 2 or argv[1] not in ("write", "check", "list"):
        print(__doc__)
        return 2
    cmd = argv[1]
    if cmd == "list":
        for name, b in BLOCKS.items():
            print(f"{b['chapter']}\t{name}\t{b['source']}")
        return 0
    failed, total = False, 0
    for rel in CHAPTERS:
        text, new_text, problems, changed = render_chapter(rel)
        total += len(PATTERN.findall(new_text))
        for p in problems:
            print(p)
        failed |= bool(problems)
        if cmd == "write":
            if new_text != text:
                with open(os.path.join(ROOT, rel), "w") as fh:
                    fh.write(new_text)
                print(f"{rel}: rewrote {len(changed)} blocks")
        elif changed:
            print(f"{rel}: rendered blocks differ from the YAML: {', '.join(changed)}; run render.py write")
            failed = True
    if cmd == "check" and not failed:
        print(f"every rendered block matches the YAML ({total} blocks in {len(CHAPTERS)} chapters)")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
