# Rulebook progress

Phase 1 only. Each chapter goes draft, review, fix, re-review, with at most 3 review rounds. A chapter is Done when its latest review has zero Critical findings and every unresolved Major finding and PROVISIONAL decision is logged in `docs/rules/OPEN-QUESTIONS.md`.

Status values: Not started, Drafting, Drafted, In review, Fixing, Awaiting decision, Applying decisions, Conformance review, Done.

Reviewers: Chapter 1 was reviewed by wof-reviewer on Fable. From Chapter 2 on, every round has two independent reviews: wof-reviewer on Opus (`<slug>-review-<n>.md`) and Codex CLI on gpt-5.6-sol (`<slug>-review-<n>-codex.md`). Counts are shown as Opus + Codex. A chapter needs zero Critical in both latest reviews. The orchestrator may escalate a narrow item (a disputed Critical or Major, a multi-rule odds claim, a subtle cross-chapter interaction, or a finding that would force an ADR change) to a Fable 5.1 reviewer, written to `<slug>-review-<n>-fable.md`; its Critical and Major findings count toward the chapter.

Process changes (2026-09-14, during Chapter 3 round 3): fixes driven by a later chapter's review may change earlier chapters, including Done ones. Open questions get a decider who may amend ADRs. The decider is a Fable 5.1 subagent: it made the first pass (OQ-01 to OQ-57, recorded in `docs/rules/DECISIONS-2026-09-14.md`) and applies the ADR, glossary, and OPEN-QUESTIONS edits. A brief switch to Codex CLI gpt-6-astra was stopped before it edited anything except an appended section of the decisions file, which Fable reviews. wof-drafter applies decisions to the chapters. After each chapter closes, Fable decides that chapter's open questions (batch 2: OQ-59 to OQ-73, after Chapter 4; batch 2b: OQ-91 and OQ-92, conformance leftovers; batch 3: OQ-74 to OQ-90 and OQ-93 to OQ-99, after Chapter 5; batch 3b: the Chapters 1 to 5 conformance round 1 dispute over OQ-81 Break Attention, revising OQ-50, OQ-79, OQ-81, OQ-89 and OQ-97 and amending ADR-0010 and ADR-0014; batch 3c: the conformance round 2 findings on held-card flags and the grounded-Titan Feint, amending ADR-0003, ADR-0010 and ADR-0014; batch 3d: OQ-111; batch 3e: the conformance round 3 and Chapter 6 round 3 Criticals on flag lifetime and the nearest rung. Chapter 6 used its 3 review rounds; its round 3 Critical was a Chapter 5 procedure question, so it is closed by batch 3e and verified by a combined conformance review of Chapters 5 and 6 (slug `05-06-decisions-conformance`); batch 4: Chapter 6 OQ-100 to OQ-110 plus that review's Abnormal tie-break and parking findings, amending ADR-0003, ADR-0010 and ADR-0014; batch 4b: that review's round 2 loud-rider Critical (every ladder now starts with hooked-into-its-body) and the four-strikers Major, logged as OQ-112; batch 5: the owner's final full review (Fable and Codex gpt-6-astra) and the simulator round 2 rules questions, deciding OQ-113 and OQ-119 to OQ-127 and amending ADR-0010 and ADR-0014; batch 5 items 5-13 to 5-18 (batch 5b): the full review round 2 findings, deciding OQ-129 to OQ-131; item 5-19: the Medium deaths band reading, logged as OQ-132; batch 6, item 6-1: the playtest packet round 3 source note, deciding OQ-134 that a retreat stops only the Background and retreat clocks while Regeneration still fills), the drafter applies them, and a conformance review of all drafted chapters runs in parallel with the next chapter's draft (which may not edit earlier chapters while that review runs).

| # | Chapter | Chapter file | Status | Review round | Open Critical | Open Major | Latest review |
|---|---------|--------------|--------|--------------|---------------|------------|---------------|
| 1 | Core Rules | `docs/rules/01-core-rules.md` | Done | 3 + conformance 4 + 01-05 conformance 3 | 0 + 0 | 0 + 0 | `docs/reviews/01-05-decisions-conformance-review-3.md`, `-review-3-codex.md` |
| 2 | Character Creation | `docs/rules/02-character-creation.md` | Done | 3 + conformance 4 + 01-05 conformance 3 | 0 + 0 | 0 + 0 | `docs/reviews/01-05-decisions-conformance-review-3.md`, `-review-3-codex.md` |
| 3 | Harm and Mind | `docs/rules/03-harm-and-mind.md` | Done | 3 + conformance 4 + 01-05 conformance 3 | 0 + 0 | 0 + 0 | `docs/reviews/01-05-decisions-conformance-review-3.md`, `-review-3-codex.md` |
| 4 | Gear | `docs/rules/04-gear.md` | Done | 3 + conformance 2 + 01-05 conformance 3 | 0 + 0 | 0 + 0 | `docs/reviews/01-05-decisions-conformance-review-3.md`, `-review-3-codex.md` |
| 5 | Titan Engagement | `docs/rules/05-titan-engagement.md` | Done | 3 + 01-05 conformance 3 + 05-06 conformance 3 | 0 + 0 | 0 + 0 | `docs/reviews/05-06-decisions-conformance-review-3.md`, `-review-3-codex.md` |
| 6 | Standard Titans | `docs/rules/06-standard-titans.md` | Done | 3 + 05-06 conformance 3 | 0 + 0 | 0 + 0 (round 3 Major logged as OQ-113, since decided by 5-8; Minors in OQ-114) | `docs/reviews/05-06-decisions-conformance-review-3.md`, `-review-3-codex.md` |

## Chapter scope

1. Core Rules: dice pool, Push, Stress, Help, Bonus Dice.
2. Character Creation: Lifepath, Specialties, Talents, Action Catalog, Squadmates.
3. Harm and Mind: Health, Critical Injuries, Down, Death Rolls, Stress Responses, Fear Rolls, Scars, Grief.
4. Gear: ODM Gear, gas, Blade Sets, horses, carrying, Standard Issue.
5. Titan Engagement: Positions, Attention, Behavior Tables, Grab, Regeneration, Openings, Read, Background Titans, Wings.
6. Standard Titans: Small, Medium, Large Behavior Tables and one Abnormal.

## Simulator (ADR-0014)

| Item | Status | Review round | Open Critical | Open Major | Report |
|------|--------|--------------|---------------|------------|--------|
| Dice simulator in `tools/` | Done (round 3 Majors fixed; Medium deaths Missed, logged OQ-132; unmeasured cases OQ-115 to OQ-118, OQ-133) | 3 | 0 + 0 | 1 + 2 (fixed) | `docs/reviews/simulator-report.md`, reviews `docs/reviews/simulator-review-3.md`, `-review-3-codex.md` |

## Playtest packet

Added by the owner on 2026-09-15: after the chapters, the simulator, and the final full review are done, wof-drafter builds a single HTML playtest packet with every Phase 1 rule in a concise, readable form, written like a real TRPG playtest packet with minimal styling, in language suited to a published TRPG product (table language, consistent capitalised game terms, no design-document or data-model wording). It is one file for players and GM, with GM-only material (Titan stat blocks and Behavior Tables, hidden values, the procedures only the GM runs) at the back. One wof-reviewer pass checks it against the chapters for contradictions and omissions, and checks that its language reads like a TRPG product. The owner reviews it and gives feedback before the first playtest. It is also published as a private Claude Artifact (owner request, 2026-09-15), so the file follows the Artifact format (no html, head, or body tags; light and dark theme tokens).

| Item | Status | Review round | Open Critical | Open Major | File |
|------|--------|--------------|---------------|------------|------|
| Playtest packet (HTML) | Published for owner review (round 3 findings fixed; Fable check 0 + 0, 1 Minor fixed) | 3 | 0 + 1 (fixed) + 0 | 1 + 2 (fixed) + 0 | `docs/playtest/wings-of-freedom-playtest-packet.html`, reviews `docs/reviews/playtest-packet-review-3.md`, `-review-3-codex.md`, `-review-3-fable.md`; Artifact https://claude.ai/artifact/WoUmYA8rYpDnoB9skQdsEq |

## Final full review

Added by the owner on 2026-09-15: after the chapters and the simulator are done and before the playtest packet is written, one more full review of all six chapters runs in parallel on Fable 5.1 (wof-reviewer, `docs/reviews/01-06-full-review-1-fable.md`) and Codex CLI gpt-6-astra (`docs/reviews/01-06-full-review-1-astra.md`). Findings are resolved (the Fable decider for decisions, wof-drafter for fixes) before the packet is built.

| Item | Status | Review round | Open Critical | Open Major | Latest review |
|------|--------|--------------|---------------|------------|---------------|
| Full review, Chapters 1 to 6 | Done (round 3 Major fixed: retreat actions row) | 3 | 0 + 0 (Fable + Astra) | 0 + 0 | `docs/reviews/01-06-full-review-3-fable.md`, `docs/reviews/01-06-full-review-3-astra.md` (rounds 1 and 2: `-review-1-*.md`, `-review-2-*.md`) |
