# Chapter 3: Harm and Mind

This chapter covers what happens to a soldier's body and nerve. The body half covers Health, Critical Injuries, Down, lethal Critical Injuries and Death Rolls, Treat Injury, and healing time. The mind half covers Resolve, Stress Responses, Rally, Fear Rolls, Scars, Retirement, and Grief.

It builds on Chapter 1 (dice pools, Pushing, Stress, Help, turns and Reactions) and Chapter 2 (Health and Resolve formulas, Drives, Talents, the Action Catalog, and Squadmates). It changes no rule in either chapter. Later chapters own these rules, and this chapter only refers to them:

- **Chapter 4, Gear:** falls and any other damage from gear, gear damage of every kind, the medical kit and medical Squad Supply, what happens to a soldier who becomes Down while airborne or mounted, and carrying a Down comrade.
- **Chapter 5, Titan Engagement:** the Grab procedure, including its lift and devour steps (section 5.9); Titan attack targeting, including whether the Attention Ladder can choose a Down soldier (sections 5.5 and 5.6); who witnesses a Fear Roll trigger (section 5.9); when a Titan Engagement ends and how a soldier leaves one while it goes on (section 5.11); and which Position changes a Down soldier's move can make (section 5.2).
- **Chapter 6, Standard Titans:** each Behavior Table entry's Injury Location and whether it can be lethal, and which behaviors have a grab effect (`data/titans/`; section 6.1).

Some rules this chapter needs are not yet written:

- **The Expedition rules:** when a day passes on an Expedition, and the Waypoint camp Stress relief. Until they and the Downtime rules are written, one day passes at the start of each session (section 3.6).
- **The Downtime rules:** how many days a Downtime spans, and how Havens and the Honoring the Fallen Squad Action lower Stress and Grief.
- **Instructors and contacts:** the rules that give a retired soldier an effect as an instructor or contact.

This chapter mentions them only where it has to.

**Tables.** Every table and procedure in this chapter is a YAML file. Those files are the only source of truth (ADR-0012). The result tables (the Injury Location roll, the four Injury Location tables, and the Stress Response, Fear Roll, and Scar tables) are rendered from them by `tools/render/render.py` where each procedure uses them, between `BEGIN RENDERED` and `END RENDERED` markers that name each block's source file; nothing between the markers is written by hand, and `render.py check` fails if a rendered block and its YAML differ. The files are:

- `data/harm/health.yaml`: Health, the kinds of harm, Titan attacks, and getting Health back.
- `data/harm/critical-injuries.yaml`: gaining a Critical Injury, the Injury Location roll, and the four Injury Location tables.
- `data/harm/down.yaml`: becoming Down, what a Down soldier can and cannot do, and ending Down.
- `data/harm/death-rolls.yaml`: time limits, the Death Roll and its outcomes, and dying.
- `data/harm/treat-injury.yaml`: the Treat Injury procedure, care windows, and aftermath rolls.
- `data/harm/healing.yaml`: healing time and what happens when a day passes.
- `data/harm/effect-types.yaml`: the effect types every table row in this chapter uses.
- `data/harm/engagement-end.yaml`: what this chapter resolves when a Titan Engagement ends, in order, and how its rules treat a soldier who left before the end.
- `data/harm/sheet-fields.yaml`: what this chapter adds to the character sheet and Squadmate stat block.
- `data/mind/stress-responses.yaml`: the Stress Response table, lasting results, and Rally.
- `data/mind/fear-rolls.yaml`: the closed list of Fear Roll triggers and the Fear Roll table.
- `data/mind/scars.yaml`: gaining Scars, the Scar table, and Retirement.
- `data/mind/grief.yaml`: gaining Grief, its limit, and its effect.

This chapter adds no rows to Chapter 1's or Chapter 2's files. Stress gained or lost from its tables uses Chapter 1's named-gain and named-reduction rows in `data/core/stress-changes.yaml`. Its penalties use Chapter 1's penalty step (section 1.3, step 5).

**No rulings.** The GM never decides whether harm happens, its kind, its amount, its Injury Location, a row, or how long an effect lasts. Every harm comes from a rule that names it, and every result comes from a table row.

Where the ADRs left a question open, the rule below cites its entry in `docs/rules/OPEN-QUESTIONS.md` as (OQ-nn). Every entry this chapter cites was decided on 2026-09-14 (`docs/rules/DECISIONS-2026-09-14.md`), including the owner's decision that Health is a row of boxes (ADR-0005, as amended), and the text states the decided rule. OQ-58 was decided the same day, under *Conformance follow-up* in that file, and OQ-70 and OQ-71 under *Batch 2*. Design notes give the reasons.

---

# Part One: Body

## 3.1 Health and harm

### Health

- A soldier's Health is the formula in `data/character/attributes.yaml` (`derived_values`): half of Strength plus Agility, rounded up. Attributes never rise (ADR-0011), so Health never changes.
- **The row of boxes.** The sheet keeps Health as a row of that many boxes (`health` in `data/harm/health.yaml`). Each box is clean, marked by damage, or crossed off by a Critical Injury.
- **Crossed-off boxes.** Each untreated Critical Injury the soldier holds crosses off one box, whatever inflicted it. The boxes crossed off are the smaller of the untreated Critical Injuries held and Health. So a soldier can hold more untreated Critical Injuries than they have Health: the extra ones cross off nothing, and treating one of them gives back no box until fewer untreated Critical Injuries remain than the soldier has Health.
- **Health lost.** The sheet records **Health lost** to damage. It is never more than Health minus the boxes crossed off.
- **Current Health** is Health minus the boxes crossed off minus Health lost, and it never goes below 0.
- Health measures how much punishment a soldier can take before they can no longer act. It is small on purpose, because Titan attacks bypass it (ADR-0005): they cross off boxes through Critical Injuries and never add to Health lost.

### The kinds of harm

`harm_kinds` in `data/harm/health.yaml` lists every kind of harm a rule can inflict. A rule that harms a soldier names one kind and its parameters:

- **Damage** adds an amount to Health lost, marking that many boxes. It is named by rules for harm that is not a Titan attack, such as a fall (Chapter 4).
- **Critical Injury** gives the soldier a Critical Injury (section 3.2). While untreated it crosses off one Health box. It never adds to Health lost.
- **Death** kills the soldier (section 3.4). It is named by rules such as the Grab's devour step (Chapter 5, section 5.9), and never by a Behavior Table entry.

### Losing Health

Follow the damage `procedure`:

1. If current Health is above 0, add the amount to Health lost, up to Health minus the boxes crossed off.
2. If that brings current Health to 0, the soldier becomes Down (section 3.3) and gains one Critical Injury at once. Then check Down again.
3. If current Health was already 0, Health lost does not change, and the soldier gains one Critical Injury at once.

The Critical Injury's Injury Location is rolled, unless the damage's rule names one.

**A Critical Injury with no clean box.** A new untreated Critical Injury crosses off a clean box if one is left. If none is, it crosses off a box marked by damage instead, and Health lost falls by 1. If every box is already crossed off, it crosses off none. This keeps Health lost from ever exceeding Health minus the boxes crossed off.

**A Critical Injury that crosses off the last box** makes the soldier Down (section 3.3) and inflicts no further Critical Injury. Only damage that brings current Health to 0, or damage taken at 0, inflicts one.

Harm comes in three kinds: damage, Critical Injury, and death. Damage at 0 current Health gives another Critical Injury instead of more Health lost. A Titan attack is the harm a Behavior Table entry inflicts when a Titan's card resolves it, and it is always a Critical Injury. The Grab's lift and devour are steps of the Grab procedure, not Titan attacks (OQ-39).

### Titan attacks bypass Health

ADR-0005 has Titan attacks skip Health and inflict Critical Injuries directly (`titan_attacks`):

- **A Titan attack is the harm a Behavior Table entry inflicts on a soldier when a Titan's card resolves that behavior against them.** Every such harm is a Titan attack. It is always a Critical Injury and never damage, whatever the soldier's Health. No Behavior Table entry names death. A Titan attack is only the harm the entry itself names. Harm that another rule causes as a result, such as a fall when a soldier becomes Down while airborne (Chapter 4), is the kind that other rule names.
- Each Behavior Table entry that harms lists, in its effects, its Injury Location (fixed or rolled) and whether its Critical Injury cannot be lethal (`data/titans/`; Chapter 6, section 6.1).
- A Titan attack lands unless the target's Reaction meets its Severity (ADR-0015; Chapter 1, section 1.9). A soldier who cannot make a Reaction, such as a Down soldier, takes it.
- **The Grab's crushing Critical Injury** is a torso Critical Injury that cannot be lethal (ADR-0015). Section 3.7 explains how this chapter supports ADR-0014's Grab target.
- **The Grab countdown is not a Titan attack** (`grab_countdown`). ADR-0015 lifts a Grabbed soldier after their next turn and devours them after the turn after that. Both steps belong to the Grab procedure (Chapter 5, section 5.9) and are never Behavior Table entries. They have no Severity, and no Reaction answers them, because a Reaction answers a card that resolves a behavior (Chapter 1, section 1.9). The devour names death as its harm. Chapter 5 states what the lift does (section 5.9, `data/engagement/grab.yaml`, `countdown`).

A soldier with no Health lost can be Down, or dying, from Titan attacks alone: each Critical Injury crosses off a box, and a row can say Down or be lethal. A soldier at 0 current Health takes a Titan attack exactly as any other soldier does.

### Getting Health back

Health comes back only through the `restoring` rows:

- **Revive:** a successful Treat Injury on a Down soldier at 0 current Health whose Health lost is above 0 restores 1 Health lost per success, erasing that many damage marks (section 3.5).
- **A day passes,** including the interim day at the start of each session: every living soldier gets back all Health lost to damage (section 3.6). Crossed-off boxes stay crossed off.
- **Treating or healing a Critical Injury** gives back the box it crossed off, unless the soldier still holds at least as many untreated Critical Injuries as Health (*Crossed-off boxes*, above; sections 3.2, 3.5, and 3.6).

Treat Injury restores Health lost only to a Down soldier at 0 current Health, and all Health lost to damage comes back each time a day passes. Nothing else restores Health lost in the field (OQ-40).

## 3.2 Critical Injuries

A Critical Injury is a lasting injury tied to an Injury Location. Each row says whether it puts the soldier Down, whether it is lethal and how fast, its effects, and its healing time.

### Gaining a Critical Injury

Follow `gaining` in `data/harm/critical-injuries.yaml`:

1. **Injury Location.** Use the Injury Location the harm's rule names. Otherwise roll D6 on the Injury Location table below: arm, leg, torso, or head.
2. **Roll.** Roll 2D6 and add **2 for each Critical Injury at that Injury Location that counts toward worsening** (`worsening`). Every Critical Injury the soldier holds there counts, treated or not. So does every healed one there whose row has permanent effects. Find the row of that Injury Location's table whose `results` include the total. The bonus makes a worse row more likely, not certain: the row comes from the new total alone and is never compared with an earlier Critical Injury's row.
3. **Gained before.** If that row has permanent effects and the soldier has gained it before, whether it is still held or has healed, use the row its `repeat_row` names instead. A soldier loses an arm, a leg, or an eye at most once.
4. **Cannot be lethal.** If the harm's rule says the Critical Injury cannot be lethal, and the row now found is lethal or instant death, use the table's `non_lethal_cap` row instead.
5. **Record** the Critical Injury as untreated, with its time limit and healing time. It crosses off one Health box (section 3.1). Apply its effects and permanent effects. A Stress gain on the row is gained once, now. If the row is instant death, the soldier dies instead.
6. **Check Down** (section 3.3). If the Critical Injury crossed off the last box, the soldier is Down, and no further Critical Injury follows.

Every table has an open-ended first row and last row, so every total has a row, however many Critical Injuries count toward worsening.

The Injury Location roll weights arm and leg twice as heavily as torso and head. No side of the body is tracked: a second arm Critical Injury is held at the arm Injury Location whichever arm the fiction describes (OQ-41).

<!-- BEGIN RENDERED: injury-location from data/harm/critical-injuries.yaml -->
| D6 | Injury Location |
|---|---|
| 2 or less | arm |
| 3–4 | leg |
| 5 | torso |
| 6 or more | head |
<!-- END RENDERED: injury-location -->

### Reading a row

| Field | Meaning |
|---|---|
| `results` | The 2D6 totals the row covers, after worsening. |
| `down` | `false`, or `until_treated`: the soldier is Down while this Critical Injury is untreated. |
| `lethal`, `time_limit` | Whether it can kill, and how fast (`turn`, `engagement`, or `day`; section 3.4). |
| `death_roll_penalty` | Base dice removed from each Death Roll made for this Critical Injury. |
| `instant_death` | The soldier dies at once. |
| `effects` | Effects from `data/harm/effect-types.yaml` that apply while the Critical Injury is held and end when it heals. |
| `healing_days` | Days until it heals (section 3.6). |
| `permanent_effects` | Effects that apply from the moment the Critical Injury is gained and stay after it heals, for as long as the soldier lives. |
| `repeat_row` | On a row with permanent effects: the row used instead if the soldier has gained this row before. |

Each table runs from light injuries at low totals to lethal and fatal ones at high totals. Instant death appears only at totals a first Critical Injury at that Injury Location cannot reach, so a soldier's first Critical Injury there never kills them outright.

### The four Injury Location tables

<!-- BEGIN RENDERED: critical-injuries arm from data/harm/critical-injuries.yaml -->
**Arm** (2D6 + 2 for each arm Critical Injury that counts toward worsening; a Critical Injury that cannot be lethal uses Fractured Arm in place of a lethal or instant-death row)

| 2D6 total | Critical Injury | Down | Lethal | Death Roll penalty | Effects while held | Healing days | Permanent effects | If gained before, use |
|---|---|---|---|---|---|---|---|---|
| 4 or less | Wrenched Shoulder | no | no | 0 | 1-die penalty on Break Free | 2 | — | — |
| 5–6 | Gashed Forearm | no | no | 0 | 1-die penalty on Nape strike, Body Part strike | 4 | — | — |
| 7 | Dislocated Elbow | no | no | 0 | 1-die penalty on Nape strike, Body Part strike, Break Free, Treat Injury, Field Repair | 7 | — | — |
| 8–9 | Fractured Arm | no | no | 0 | 2-die penalty on Nape strike, Body Part strike, Break Free | 21 | — | — |
| 10–11 | Torn Artery | no | yes, `engagement` limit | 0 | 1-die penalty on Nape strike, Body Part strike | 10 | — | — |
| 12 | Mangled Arm | until treated | yes, `engagement` limit | 1 | 2-die penalty on Nape strike, Body Part strike, Break Free | 28 | — | — |
| 13 or more | Lost Arm | until treated | yes, `turn` limit | 1 | none | 28 | 2-die penalty on Nape strike, Body Part strike, Break Free, Treat Injury, Field Repair | Mangled Arm |
<!-- END RENDERED: critical-injuries arm -->

<!-- BEGIN RENDERED: critical-injuries leg from data/harm/critical-injuries.yaml -->
**Leg** (2D6 + 2 for each leg Critical Injury that counts toward worsening; a Critical Injury that cannot be lethal uses Fractured Leg in place of a lethal or instant-death row)

| 2D6 total | Critical Injury | Down | Lethal | Death Roll penalty | Effects while held | Healing days | Permanent effects | If gained before, use |
|---|---|---|---|---|---|---|---|---|
| 4 or less | Twisted Ankle | no | no | 0 | 1-die penalty on Fly | 2 | — | — |
| 5–6 | Gashed Thigh | no | no | 0 | 1-die penalty on Dodge | 4 | — | — |
| 7 | Wrenched Knee | no | no | 0 | 1-die penalty on Fly, Ride, Dodge | 7 | — | — |
| 8–9 | Fractured Leg | no | no | 0 | 2-die penalty on Fly, Ride, Dodge | 21 | — | — |
| 10–11 | Opened Artery | no | yes, `engagement` limit | 0 | 1-die penalty on Dodge | 10 | — | — |
| 12 | Shattered Knee | until treated | yes, `engagement` limit | 1 | 2-die penalty on Fly, Ride, Dodge | 28 | — | — |
| 13 or more | Lost Leg | until treated | yes, `turn` limit | 1 | none | 28 | 2-die penalty on Fly, Ride, Dodge | Shattered Knee |
<!-- END RENDERED: critical-injuries leg -->

<!-- BEGIN RENDERED: critical-injuries torso from data/harm/critical-injuries.yaml -->
**Torso** (2D6 + 2 for each torso Critical Injury that counts toward worsening; a Critical Injury that cannot be lethal uses Caved-In Chest in place of a lethal or instant-death row)

| 2D6 total | Critical Injury | Down | Lethal | Death Roll penalty | Effects while held | Healing days | Permanent effects | If gained before, use |
|---|---|---|---|---|---|---|---|---|
| 4 or less | Winded | no | no | 0 | gain 1 Stress | 1 | — | — |
| 5–6 | Cracked Ribs | no | no | 0 | 1-die penalty on Nape strike, Body Part strike, Break Free | 7 | — | — |
| 7 | Deep Bruising | no | no | 0 | 1-die penalty on Fly, Dodge, Break Free | 5 | — | — |
| 8–9 | Crushed Ribs | no | no | 0 | 2-die penalty on Nape strike, Body Part strike, Break Free | 14 | — | — |
| 10 | Caved-In Chest | until treated | no | 0 | 1-die penalty on Fly, Dodge, Break Free | 21 | — | — |
| 11 | Punctured Lung | no | yes, `engagement` limit | 0 | 1-die penalty on Fly, Dodge | 14 | — | — |
| 12 | Internal Bleeding | until treated | yes, `turn` limit | 1 | 1-die penalty on Fly, Dodge, Break Free | 21 | — | — |
| 13–14 | Torn Open | until treated | yes, `turn` limit | 2 | 2-die penalty on Fly, Dodge, Break Free | 28 | — | — |
| 15 or more | Crushed | — | instant death | — | — | — | — | — |
<!-- END RENDERED: critical-injuries torso -->

<!-- BEGIN RENDERED: critical-injuries head from data/harm/critical-injuries.yaml -->
**Head** (2D6 + 2 for each head Critical Injury that counts toward worsening; a Critical Injury that cannot be lethal uses Head Blow in place of a lethal or instant-death row)

| 2D6 total | Critical Injury | Down | Lethal | Death Roll penalty | Effects while held | Healing days | Permanent effects | If gained before, use |
|---|---|---|---|---|---|---|---|---|
| 4 or less | Dazed | no | no | 0 | gain 1 Stress; 1-die penalty on Read | 1 | — | — |
| 5–6 | Split Scalp | no | no | 0 | 1-die penalty on Read, Break Attention | 3 | — | — |
| 7 | Concussion | no | no | 0 | 1-die penalty on Read, Break Attention, Treat Injury, Field Repair, Fly | 7 | — | — |
| 8–9 | Head Blow | until treated | no | 0 | 1-die penalty on Read, Break Attention | 5 | — | — |
| 10–11 | Fractured Skull | until treated | yes, `engagement` limit | 0 | 1-die penalty on Read, Break Attention, Fly | 21 | — | — |
| 12 | Bleeding Inside the Skull | until treated | yes, `turn` limit | 1 | 1-die penalty on Read, Break Attention, Fly | 28 | — | — |
| 13–14 | Lost Eye | until treated | yes, `engagement` limit | 0 | none | 28 | 1-die penalty on Read, Break Attention, Nape strike | Fractured Skull |
| 15 or more | Crushed Skull | — | instant death | — | — | — | — | — |
<!-- END RENDERED: critical-injuries head -->

### Holding and treating

- A soldier **holds** a Critical Injury from when it is gained until it heals. Held Critical Injuries count toward worsening, treated or not. A healed Critical Injury whose row has permanent effects keeps counting (section 3.6).
- A Critical Injury becomes **treated** when a Treat Injury roll succeeds on it (section 3.5). Treating it never removes its effects or permanent effects, and a treated Critical Injury keeps its healing time and still counts toward worsening. Treating does three things: it stabilizes a lethal Critical Injury, it ends a `down: until_treated` row's hold on the soldier, and it gives back the Health box the Critical Injury crossed off, unless the soldier still holds at least as many untreated Critical Injuries as Health (section 3.1).
- **Effects stack.** Penalties from several Critical Injuries, and from lasting Stress Responses and Scars, add up. As with every penalty, they never take a pool below 1 base die and never remove Gear Dice or Stress Dice (Chapter 1, section 1.3, step 5).
- No Critical Injury damages or removes gear. Chapter 4 owns gear damage.

> **Design note (OQ-42):** The table shape is made of these parts:
>
> - 2D6 plus 2 per Critical Injury counting toward worsening at the same Injury Location.
> - The rows and their effects, and a non-lethal cap row on every table.
> - Instant death only at totals a first Critical Injury cannot reach.
> - Permanent effects on the worst arm, leg, and head rows. They apply from the moment the row is gained, and each of those rows can be gained once.
>
> The rows are the starting values for the ADR-0014 simulator. From the current rows, a soldier's first Critical Injury at a rolled Injury Location is lethal 15.3% of the time and puts them Down 10.6% of the time. A torso Critical Injury is lethal 8.3% of the time with none held there, 27.8% with one, and 50.0% with two; with two it is also instant death 8.3% of the time. A head Critical Injury puts the soldier Down 41.7% of the time with none held there; with two held it is lethal 63.9% and instant death 8.3% of the time.
>
> **Injuries before Down.** With untreated Titan-attack Critical Injuries at rolled Injury Locations, the first puts a soldier Down 10.6% of the time whatever their Health, through Down rows. After that, Health decides. A Health 2 soldier is Down by the second (a mean of 1.89 Critical Injuries before Down). A Health 3 soldier is Down by the third (mean 2.65). A Health 4 soldier is Down by the third 39.6% of the time and by the fourth always (mean 3.25). A Health 5 soldier is Down by the third 39.5% of the time and by the fourth 55.5% (mean 3.70). A Health 6 soldier, a legal build, is Down by the third 39.6% of the time, by the fourth 55.5%, by the fifth 70.0%, and by the sixth 99.7% (mean 3.99; OQ-71).
>
> **Reference builds (OQ-58, OQ-70, OQ-71).** ADR-0014, as amended, names each reference build's attributes, and so its Health. Strength is the key attribute of all three, because the solo Nape-strike and Grab targets are Strength rolls. The Rookie has the Slayer Squadmate template's attributes, Strength 4, Agility 3, Wits 2, and 3 elsewhere, with Health 4 and Resolve 3. It has Talent 1 in the Talent that names the Nape strike, the Body Part strike, Break Free, or Treat Injury (decision batch 2b), and the Veteran's Talent 2 and the Levi-grade soldier's Talent 3 apply to the same rolls. No other roll a target measures carries Talent dice, including the dodge, Fly, Break Attention, Ride, and Read, so the Death Roll and Rally carry none in a target's baseline, and Hard to Kill stays a simulator check (OQ-94). It is not the Slayer template itself, whose one Talent names only the Nape strike. It is the victim in the lone Grab model of Chapter 5 (section 5.13, `data/engagement/tuning.yaml`, `grab`), whose figures section 3.7 quotes. The Veteran is Strength 5, Agility 3, Wits 2, and 3 elsewhere (19 points, a Top 10 Rookie with two Scars), with Health 4 and Resolve 5 from its two Scars. The Levi-grade soldier is Strength 6, Agility 4, and 4 elsewhere, with Health 5 and Resolve 4, deliberately above any buildable total. The targets are measured on these builds.
>
> The targets that depend on Health are the Expedition PC Critical Injury and PC death targets and a Grab on a victim already carrying untreated Critical Injuries. Each is also reported, not tuned, for the reference Squad with each soldier's Health set to 3 and nothing else changed, so the report isolates Health, and this chapter's Health 2, 5, and 6 figures are reported beside them. The Talent-dependent targets (the lone Grab, the rescue cells in section 3.7, and the prepared-Squad kill) are also reported, not tuned, for a Squad built literally from the Squadmate templates; with the Slayer template's Talents the lone Grab kills about 69% of the time. The dodge is also reported, not tuned, for the Flier template alone (Agility 4, Slip Away 1, ODM Gear 2, Stress 1, Pushing when short): it dodges Severity 3 38.0% of the time and Severity 2 66.6% (decision batch 2b). A Squad drawn from the nine templates in equal shares sits between Health 3 and Health 4, at a mean of 2.92 untreated Critical Injuries before Down. Every figure in this chapter that depends on Health names the Health it assumes.
>
> **Lethal is not the same as fatal.** Of the 15.3 points of lethal first results, 14.4 have an `engagement` limit, so whether they kill depends on treatment during the fight and at its end (section 3.16). Across first Critical Injuries at a rolled Injury Location, `engagement` rows kill a Strength 3 soldier at the end of the fight about 8.5% of the time with no treatment, 3.4% with one aftermath roll by a Wits 2 treater without a medical kit, and 0.9% with one by a Rookie Medic. With no treatment a Strength 4 soldier dies on 7.1%. If the "PC dies every 3 to 4 missions" target comes out low, the first lever is moving the 11 and 12 results at arm and leg from `engagement` to `turn` limits.

## 3.3 Down

A Down soldier can do little more than crawl. `data/harm/down.yaml` holds the whole rule.

### Becoming Down

A soldier is Down while at least one of these `conditions` is true:

1. **0 current Health.** Their current Health is 0 (section 3.1), whether from damage, from untreated Critical Injuries crossing off every box, or both. Damage that brings current Health to 0 gives one Critical Injury (section 3.1). A Critical Injury that crosses off the last box gives none, and this condition never gives a further one.
2. **A Down row.** They hold an untreated Critical Injury whose row says `down: until_treated`.

Check these whenever Health lost changes, a Critical Injury is gained or heals, or a Critical Injury becomes treated.

### What a Down soldier can do

- **Turns still happen.** Each turn has its move and no action. A Down soldier's turn still counts as a turn for every rule that counts turns, such as a `turn` time limit or a Grab (Chapter 5, section 5.9).
- **Moving.** A Down soldier's move can make only the change Chapter 5 allows (section 5.2, `data/engagement/positions.yaml`, `moves`, `down_soldier`).
- **Death Rolls.** A Down soldier makes Death Rolls (section 3.4).
- **Being helped.** A Down soldier can be the patient of Treat Injury, the target of Rally, and lifted with Lift Comrade (Chapters 4 and 5).
- Stress, lasting Stress Responses, Grief, Scars, and a Grabbed state all stay as they are. A Down soldier can still gain Stress, Critical Injuries, Scars, and Grief from any rule that names them.

### What a Down soldier cannot do

- **Take any action.** That includes Help (Chapter 1, section 1.8) and every Action Catalog entry whose kind is `action`. See *Down and this round's turns* for the action of a turn that has already begun.
- **Push, Help, Cover, or make a Reaction.** Down's own row names all four (`forbids: [push, help, cover, reaction]` in `data/harm/down.yaml`), which is Chapter 1's shared hook for a state that forbids them (section 1.9). Chapter 1's core requirements also exclude a Down helper and a Down Coverer (sections 1.5 and 1.8). A behavior a Down soldier cannot react to lands (ADR-0015).
- **Make any attribute roll except a Death Roll.** So a Down soldier never Pushes, never rolls Stress Dice, and never suffers a Stress Response while Down. Their Death Rolls cannot be Helped or Covered in any case, so whether a Down roller can be Helped never arises.
- **Make a Fear Roll** (section 3.12).

A Grabbed soldier who becomes Down stays Grabbed and cannot take Break Free, because it is an action. A comrade can still free them, for example with a Body Part strike on the hand or with Pry Loose (Chapter 5, section 5.9, `data/engagement/grab.yaml`, `escapes`).

### Ending Down

Down ends at once when current Health is above 0 and the soldier holds no untreated Critical Injury whose row says `down: until_treated` (`ending`). Only these can bring that about:

- **Treating or healing a Critical Injury** gives back its box if the soldier then holds fewer untreated Critical Injuries than Health (sections 3.1, 3.5, and 3.6), and ends a `down: until_treated` row's hold if it is that row.
- **A revive** erases damage marks (section 3.5).
- **A day passing** erases all damage marks (section 3.6).

Nothing else ends Down.

### Down and this round's turns

Becoming Down or ending Down never spends or restores a turn by itself (`becoming_down_mid_round`, `after_ending`):

- **Becoming Down after this round's turn has begun or ended:** the soldier loses any action of that turn they still hold, even if Down ends before the round does. That action counts as spent for every rule that asks, such as which turn a Reaction spends (Chapter 1, section 1.9).
- **Becoming Down before this round's turn comes up:** nothing is taken from that turn. If Down has ended by the time it comes up, it has its move and action.
- **A turn that begins while the soldier is Down** has its move, and its action counts as spent for every rule that asks, such as whether the soldier can Help or which turn a Reaction spends. The action stays spent if Down ends during or after that turn. A turn that has not yet begun keeps its action.
- **Ending Down restores nothing already spent.** A turn or action that a Reaction or a result has spent stays spent, and a future turn already spent in full stays wholly spent (section 3.9).

> **Design note (OQ-45):** Down has exactly two conditions under Health boxes (ADR-0005, as amended): 0 current Health and a Down row. A soldier's frame therefore decides how many untreated Critical Injuries they carry before they drop. A Down soldier's turn has only a move, which Chapter 5 must allow before it changes anything (section 5.2). Becoming Down takes the unused action of a turn already begun or ended this round, but not of a turn still to come, and ending Down restores nothing already spent. A Down soldier cannot Push, Help, Cover, make a Reaction, or make a Fear Roll, and makes no attribute roll but the Death Roll, so Down never needs a rule that removes Stress Dice from a roll.

## 3.4 Lethal Critical Injuries and Death Rolls

`data/harm/death-rolls.yaml` holds the time limits, the Death Roll, its outcomes, and what dying does.

### Time limits

A lethal Critical Injury has one of three time limits, listed fastest first. "Slows one step" moves it to the next:

- **`turn`:** runs out at the end of each of the soldier's turns in a Titan Engagement. The first one is the soldier's first turn that begins after the Critical Injury was gained. These turns all count:
  - turns spent in advance;
  - turns spent by a result;
  - a Down soldier's turns;
  - the turns of a soldier who has left the Titan Engagement while it goes on (section 3.16).

  When the Titan Engagement ends, a `turn` limit becomes `engagement` (section 3.16).
- **`engagement`:** runs out once, when the Titan Engagement in which it was gained ends, after that end's aftermath rolls and before its care window (section 3.16). Only treatment during the fight or a successful aftermath roll prevents that Death Roll.
- **`day`:** runs out each time a day passes, after that day's care window (section 3.6).
- Past `day` is **stabilized**: the Critical Injury is no longer lethal and never causes a Death Roll again.

**Outside a Titan Engagement,** there are no turns. A Critical Injury gained there with a `turn` or `engagement` limit runs out once, right after the care window held for that harm (section 3.5). After a Death Roll made outside a Titan Engagement, including those made when a Titan Engagement ends (section 3.16), a `turn` or `engagement` limit that the soldier survived becomes `day`.

### The Death Roll

A Death Roll is made each time a lethal Critical Injury's time limit runs out. It is an attribute roll for the Catalog entry `death-roll`:

- **Pool:** Strength, plus the dice of one Talent that names `death-roll` (such as Hard to Kill), minus the Critical Injury's `death_roll_penalty`.
- **Left out:** no Stress Dice, no Help, and no Push (`roll_exceptions` in `data/core/dice-pool.yaml`; Chapter 1, OQ-03). The entry allows no gear, and no Bonus Dice source applies to it.
- **Needs:** 1 success.
- **One roll per Critical Injury.** If several lethal Critical Injuries run out at the same moment, the soldier's player chooses the order. The first failed roll kills the soldier, and no more are made.
- A Death Roll is not an action and spends nothing.

### Outcomes

Find the row of `outcomes` for the roll's successes:

- **0 successes:** the soldier dies.
- **1 success:** the soldier lives, and the time limit runs out again as it states.
- **2 or more successes:** the soldier lives, and the time limit slows one step. A `day` limit that slows is stabilized.

### Dying

A soldier dies from a failed Death Roll, an `instant_death` row, or any rule that names death, such as the Grab's devour step (Chapter 5, section 5.9). A dead soldier leaves play and holds no Position.

- A dead player character is replaced by promotion or a new character when the procedure in which the death happened ends (Chapter 2, section 2.10). Several promotions due together use Chapter 2's contest (OQ-31, OQ-38).
- A dead Squadmate leaves the Squad Pool.
- Every Drive that named the dead soldier can never trigger again (Chapter 2, section 2.5).
- The death is the `comrade-dies` Fear Roll trigger (section 3.12) and gives Grief (section 3.14).
- Chapter 4 states what happens to the dead soldier's gear (`leaving_play` in `data/gear/carrying.yaml`).

> **Design note (OQ-43):** "Two or more successes slows the limit" gives a soldier with no medic a way to live, and gives Hard to Kill a use beyond staying alive one more turn. A Death Roll with no penalty succeeds 42.1% of the time with 3 dice, 51.8% with 4, and 59.8% with 5. It slows the limit 7.4%, 13.2%, and 19.6% of the time. A soldier with Strength 4 and a `turn` Critical Injury with a Death Roll penalty of 1, whom nobody treats, is alive after their first turn 42.1% of the time and after their third 15.1%.

## 3.5 Treat Injury

Treat Injury is the Wits action `treat-injury` (Chapter 2). It uses a medical kit for Gear Dice, and without one it rolls Wits alone (`gear_requirement`). `data/harm/treat-injury.yaml` gives the procedure.

### Uses

The treater declares one use and one patient before rolling. It needs 1 success.

- **Revive:** the patient is Down at 0 current Health, and their Health lost is above 0. On a success, restore 1 Health lost per success, up to the patient's Health lost, erasing that many damage marks. Crossed-off boxes do not come back. If a `down: until_treated` row still holds the patient, Down goes on, and the roll still counts as that treater's roll.
- **Treat:** the patient holds an untreated Critical Injury, and the treater names one. On a success, it becomes treated and gives back the Health box it crossed off, unless the patient still holds at least as many untreated Critical Injuries as Health (section 3.1). A lethal Critical Injury is also stabilized: it is no longer lethal and has no time limit.

Treat and revive are separate uses, and the players choose which one a roll makes. When damage brought a soldier to 0 and the Critical Injury it gave crossed off a box marked by damage (section 3.1), one success on a revive raises current Health to 1 and ends Down, unless a Down row holds them.

On a failure nothing happens.

### Patients

- Any other living soldier, player character or Squadmate.
- **Self:** a soldier may use treat on their own Critical Injury, with a penalty of 2 base dice. A soldier can never revive themselves, because a Down soldier takes no action and makes no roll but the Death Roll.
- **In a care window,** the patient must also be a living soldier in that window's scope (see *Care windows*).

### In a Titan Engagement

- Treat Injury is an action. The patient must hold the same Position as the treater (Chapter 5, section 5.2, `data/engagement/positions.yaml`, `comparison`). Two soldiers who have both left the Titan Engagement while it goes on count as holding the same Position, including for Help and Covering on the roll (section 3.16).
- It can be Helped (Chapter 1, section 1.8), Pushed, and Covered (section 1.5). Sure Hands allows a second Push.
- A failed use can be tried again on a later turn.

### Care windows

Outside a Titan Engagement, Treat Injury is rolled only in a **care window** (`care_windows`) or as an **aftermath roll** when a Titan Engagement ends (see *Aftermath rolls*). Each window has a **scope**, the soldiers who take part in it. A care window is held:

- **When a Titan Engagement ends,** after its Death Rolls (section 3.16). Its scope is every soldier in the Squad who held a Position at any point during that Titan Engagement.
- **After an event outside a Titan Engagement that makes a soldier Down or gives a soldier a lethal Critical Injury** with a `turn` or `engagement` limit.
  - One window is held per event, however many soldiers it harms. It is held as soon as the event has been resolved, unless the rule that caused the harm names a later point in its own procedure. The Death Rolls for those Critical Injuries follow the window.
  - Its scope is the soldiers that rule names as taking part, such as a Chase's riders. If it names none, the scope is every soldier in the Squad on the same Expedition as a harmed soldier, or every soldier in the Squad when no Expedition is under way.
  - A roll in this window may only treat a Critical Injury that the event gave, or revive a soldier that the event made Down.
- **Each time a day passes,** before `day` limits run out (section 3.6). Its scope is every soldier in the Squad on the Expedition during which the day passes. For a day that passes in Downtime it is every soldier in the Squad, and the Downtime rules may narrow this. For the interim day (section 3.6) it is every soldier in the Squad (decision batch 5, OQ-130).

In a care window:

- A care-window patient must be a living soldier in that window's scope. Its scope restricts patients as well as rollers, helpers, and Coverers.
- Every living soldier in the scope who is not Down may make one Treat Injury roll, for any legal use and patient within this window's scope. There is no Position requirement.
- A living soldier in the scope who is not Down, and is not the soldier rolling, qualifies to Help a roll. They may Help only if they have not yet made or Helped a roll in the window. Help is declared before the roll and spends that soldier's roll for the window. At most 3 soldiers Help one roll.
- Any soldier who qualifies to Help a roll can Cover its Push, even one who has already made or Helped a roll in the window. Covering spends nothing (Chapter 1, OQ-06).
- The players choose the order of rolls, using Chapter 2's roll-off if they disagree. Squadmates take part, directed as Chapter 2 states.
- A failed roll can be tried again only in a later care window.

### Aftermath rolls

When a Titan Engagement ends, each dying soldier gets one chance at treatment before the end-of-fight Death Rolls (`aftermath_rolls`; section 3.16, step 5):

- **Patient:** a living soldier with an untreated lethal Critical Injury that has an `engagement` limit, including a `turn` limit that has just become one. The patient may be Down.
- **One roll per patient.** Each patient gets at most one aftermath roll. The players choose its treater: a living soldier who is not Down and who, when the Titan Engagement ended, held the patient's Position or a Position one step from it, or the patient, if not Down, treating themselves with the self-treatment penalty. Positions are compared as they stood at that moment, relative to the Focus Titan alive last, using each soldier's last Position relative to it if it died (when more than one Focus Titan was alive, relative to the one Chapter 5 compares Positions by; Chapter 5, section 5.2; decision batch 5, OQ-122). Two soldiers who had both left count as holding the same Position (section 3.16).
- **One roll per treater.** Each soldier makes at most one aftermath roll.
- **The roll** uses treat on one untreated lethal `engagement` Critical Injury of the patient's, chosen by the players. On a success, that Critical Injury becomes treated and stabilized and gives back its Health box as treat does (*Uses*), which can end the patient's Down before the Death Rolls (section 3.3).
- **A failure uses up the patient's attempt.** No other treater, and no other Critical Injury of the same patient, can reopen it before the Death Rolls.
- No one can Help or Cover an aftermath roll. It can be Pushed, and Sure Hands allows a second Push. It is not a care window, so it does not use up the treater's roll in the care window that follows.
- The players choose the order of rolls, using Chapter 2's roll-off if they disagree.

> **Design note (OQ-57):** One aftermath roll per patient keeps an immediate chance to save a comrade without serial free attempts from everyone nearby. With only one roll per treater, three untrained soldiers within one step left an untreated `engagement` row fatal just 3.8% of the time, which would make treatment during the fight nearly worthless. A Squad can still gain by delaying the end of a fight, at the price of further Titan cards. A treatment probe (aftermath roll at Stress 0, one Push on 0 successes, a Strength 3 patient, no Help, Cover, Sure Hands, or further Titan cards) gives the patient's chance of dying if the fight ends now, against one more in-fight roll at Stress 1 followed by the aftermath roll:
>
> - Wits 2 treater, no medical kit: 23.2% against 7.8%.
> - Wits 2 treater, kit rated 1: 19.4% against 5.5%.
> - Rookie Medic (Wits 4, Field Medicine 1, kit rated 1): 6.4% against 0.8%.
> - Wits 2 treater two steps away, no kit: 57.9% with no eligible aftermath treater, against 23.2% when one move brings the treater within one step.
>
> The delay figures multiply independent treatment estimates and leave out the harm of the extra Titan cards.

### Talents and supplies

- **Field Medicine** adds dice, and **Sure Hands** allows a second Push.
- **Careful Nursing** halves the healing time of a comrade's Critical Injury that the soldier treats (section 3.6).
- Chapter 4 sets the medical kit, the medical Squad Supply uses (a Bonus Die on a care-window roll, which is the `medical-supplies` row of `data/core/bonus-dice-sources.yaml`, and restocking a kit), and Field Repair rolls in the care windows held when a Titan Engagement ends, when a day passes during an Expedition, or on the interim day (`data/gear/squad-supply.yaml`, `data/gear/field-repair.yaml`).

> **Design note (OQ-44):** The procedure has two uses with 1 success each, no effect on a failure, self-treatment at a 2-dice penalty, and the same Position in a Titan Engagement. Each care window has a stated scope that limits patients as well as rollers, helpers, and Coverers, so no one treats a soldier who is not taking part. A window allows one roll or one Help per soldier, there is one window per event outside a Titan Engagement, and a soldier who has already rolled or Helped can still Cover.

## 3.6 Healing time

`data/harm/healing.yaml` measures healing time in **days**.

- **When a day passes.** During an Expedition, a day passes at each night camp. ADR-0009 counts days outside the Walls by night camps, and the Expedition rules will give the procedure. The Downtime rules will state how many days a Downtime spans. Until the Expedition and Downtime rules are written, one day also passes at the start of each session, before the interim issue (Chapter 4, section 4.9), or, if a session begins partway through a procedure, once that procedure has ended. Stress and Grief do not change on that day (`day_passes`, `interim`; decision batch 5, OQ-120). That day's care window has every soldier in the Squad in its scope, and Field Repair is rolled in it as on an Expedition day (section 3.5; Chapter 4, section 4.8; decision batch 5, OQ-130). No day passes inside a Titan Engagement.
- **Each time a day passes,** in this order (`each_day`):
  1. Hold a care window.
  2. Every lethal Critical Injury with a `day` limit causes a Death Roll.
  3. Every living soldier gets back all Health lost to damage, erasing every damage mark. Crossed-off boxes stay crossed off.
  4. Every held Critical Injury's remaining healing time drops by 1 day. One that reaches 0 heals.
- **Lethal Critical Injuries** cannot heal while still lethal. Their healing time stops at 1 day until they are stabilized.
- **When it heals.** A Critical Injury that heals stops being held. Its effects end, and if it was untreated it gives back its Health box, unless the soldier still holds at least as many untreated Critical Injuries as Health (section 3.1). It leaves the sheet's Critical Injuries (section 3.17). If its row has permanent effects, they stay, and it keeps counting toward worsening at its Injury Location. Any other healed Critical Injury stops counting toward worsening.
- **Careful Nursing.** When a Treat Injury roll by a soldier with Careful Nursing succeeds on a comrade's Critical Injury, its remaining healing time is halved, rounding up, once per Critical Injury. The Talent never applies to the soldier's own Critical Injury.

Healing time counts days, and a day passes at each night camp and, until the Expedition and Downtime rules replace that stopgap, at the start of each session. The Expedition and Downtime rules must confirm both. A lethal Critical Injury cannot heal before it is stabilized (OQ-53).

## 3.7 The Grab and ADR-0014

ADR-0014 wants a Grab to kill about 1 time in 3 with comrades close, and about 2 times in 3 when the soldier is alone. Chapter 5 gives the Grab procedure (section 5.9) and tunes it (section 5.13). This chapter gives Chapter 5 these parts:

- **The crushing Critical Injury never kills.** It is a torso Critical Injury that cannot be lethal (ADR-0015), so it never adds a Death Roll or instant death. What kills a Grabbed soldier is the devour step of Chapter 5's Grab procedure (section 3.1; Chapter 5, section 5.9).
- **It can put the soldier Down.** The torso table's non-lethal cap row is a `down: until_treated` row. A Down soldier cannot take Break Free, so only a comrade can free them. From the current rows, the crushing Critical Injury's row puts the soldier Down 16.7% of the time with no torso Critical Injury held, 41.7% with one, and 72.2% with two. The cap row takes the place of every lethal and instant-death row, so this is more often than an ordinary torso Critical Injury puts a soldier Down (11.1%, 30.6%, and 47.2%). The crushing Critical Injury also crosses off a Health box like any other (section 3.1), so a victim whose last box it crosses off is Down in the Titan's hand whatever the row.
- **It can make Break Free harder.** With no torso Critical Injury held, the crushing Critical Injury leaves Break Free with no penalty 16.7% of the time, gives a 1-die penalty 41.7% of the time, and a 2-die penalty 25.0%. The remaining 16.7% is the Down row.
- **Down soldiers cannot dodge.** A soldier crushed Down by an earlier Grab, or Down for any other reason, takes the next Titan attack with no Reaction.
- **Comrades pay a mind price.** Witnesses make the `comrade-grabbed` Fear Roll (section 3.12). At Resolve 3, a witness loses their next action or their whole turn 2 times in 6 at Stress 1, 3 times in 6 at Stress 2, and 4 times in 6 at Stress 3. Losing the action is enough to lose a rescue. Chapter 5 decides who witnesses (section 5.9, `data/engagement/engagement-flow.yaml`, `witnesses`).

**How the target is measured.** ADR-0014, as amended in decision batch 3 (OQ-95), defines both halves of the target. Chapter 5 measures them with these parts and its own Grab procedure and rescue structure (section 5.9), where Break Free needs 2 successes, with a 2-die penalty once the soldier is lifted. Chapter 5's section 5.13 and `data/engagement/tuning.yaml` (`grab`) are the only source of the Grab figures. The models this chapter recorded before Chapter 5 was drafted, with Break Free at 3 successes and two candidate rescue structures, are withdrawn.

- **Alone.** A Rookie victim with no untreated Critical Injury whose dodge failed dies 69.9% of the time, and one who did not dodge 73.1%: about 2 in 3.
- **Comrades close.** This means one comrade in reach with the reference build and starting state: a Rookie with Talent 1 on the Body Part strike, at In Reach. It is met when all six cells of OQ-50's acceptance test, witness Stress 1, 2, and 3 with Grief 0 and 1, are under 50% and the witness Stress 2, Grief 0 cell is near 1 in 3. Chapter 5's cells are 28.7%, 33.4%, and 39.1% at witness Stress 1, 2, and 3 with no Grief, and 34.1%, 39.7%, and 45.1% with 1 Grief.
- **Reported beside the target, not tuned.** A victim already carrying untreated Critical Injuries (`grab`, `health_reports`), and the share of Grabs that the reference Squad's victims die from in a full fight, with every written rescue in play (section 5.13).

---

# Part Two: Mind

## 3.8 Resolve

- A soldier's Resolve is the formula in `data/character/attributes.yaml`: half of Instinct plus Empathy, rounded up, plus 1 per Scar, minus 1 per point of Grief (Grief is at most 3; section 3.14).
- **Resolve counts against Stress Response and Fear Roll totals**: each of those rolls is D6 plus Stress minus Resolve.
- Resolve has no floor. With enough Grief it can fall to 0 or below, which raises both totals (OQ-52).
- **Iron Nerve** counts the soldier's Resolve as 1 higher on their own Stress Response roll.
- **Unshaken Command** can let a nearby comrade's Fear Roll use the Talent holder's Resolve instead, if it is higher. Its trigger and limit are in `data/character/talents.yaml`.

## 3.9 Effects that change rolls, turns, and Reactions

Every row in this chapter names its effects by type from `data/harm/effect-types.yaml`, so every effect has exactly one reading. In brief:

- **Dice penalties** remove base dice from rolls for named Action Catalog entries, or from the soldier's next attribute roll other than a Death Roll. They follow Chapter 1's penalty step.
- **Stress gains** use Chapter 1's named-gain row and happen once each time the row takes effect. On a Critical Injury that is when it is recorded; holding it gains nothing more.
- **Extra Stress on a Push** adds Stress each time the soldier Pushes, whether or not the Push is Covered, and adds no Stress Die.
- **Losing successes** and **the roll fails** change the success count of the roll that caused the result, at step 2 of *Finishing a roll* (Chapter 1, section 1.5). The changed count is the roll's count for every later use, including a dodge's comparison with later behaviors.
- **Next turn spent** spends the soldier's earliest turn, starting with the current round's, whose move and action are both unspent. This is exactly how a Reaction spends a turn (Chapter 1, section 1.9). The spent turn still happens and counts as a turn, but begins its round with its move and action already spent.
- **Next action spent** spends the action of the soldier's earliest turn, starting with the current round's, whose action is unspent. That turn keeps its move. An action spent in a later round begins that round already spent (Chapter 1, section 1.9), so the soldier cannot Help that round or make a Reaction with that turn.
- **No Reactions** forbids the soldier's Reactions from when the result takes effect until the end of the first of their turns that begins after that. For a row that spends two turns, it lasts until the end of the second such turn. Which turn the row spends does not change how long the ban lasts, and the ban ends when the Titan Engagement ends. Each row that carries it also names `forbids: [reaction]`, Chapter 1's shared hook (section 1.9); the hook reads this ban and adds no second timer. A behavior the soldier cannot react to lands.
- **Gain a Scar** and **Fear Roll total raised** point to section 3.13 and section 3.12.
- **Stated effect** is used only by Scars, for an effect written out in closed words on the row.

Outside a Titan Engagement there are no turns or Reactions, so the turn, action, and Reaction effects do nothing there unless the rule that called for the roll states what they do.

**What no row does.** No table row in this chapter forbids a soldier to Help or to Cover. A row may, by naming it in a `forbids` field (Chapter 1, section 1.9; OQ-18); the Down state names both (section 3.3). No row damages gear.

> **Design note (OQ-46):** A result that spends a turn or an action uses Chapter 1's turn-spending rule, so Chapters 1 and 3 spend turns the same way. A turn a result spends begins its round with its move and action spent, exactly like a turn a Reaction spends, so the soldier cannot Help that round (OQ-17). A ban on Reactions lasts until the end of the soldier's next turn to begin, so a soldier already in turn debt is not left unable to dodge for longer than one who is not.

## 3.10 Stress Responses

`data/mind/stress-responses.yaml` holds the Stress Response table, rendered under *The roll* below, and its rules.

### When a Stress Response happens

A Stress Response happens only when a Stress Die shows 1 on an attribute roll, or after a Push of it. A roll never causes more than one (Chapter 1, section 1.5; ADR-0004). It is resolved at step 2 of *Finishing a roll*, after successes are counted and before the roll's effect.

A roll whose own rule names another resolution for its Stress Response, such as a Graduation Exam Trial (Chapter 2, section 2.4), still has the Stress Response and still cannot be Pushed after it, but does not use this table (Chapter 1, section 1.5, OQ-05).

### The roll

- Roll **D6 + Stress − Resolve** and find the row whose `results` include the total. It is the fixed roll `stress-response-roll`: no pool, no Push, no Help, no Stress Dice.
- Use the soldier's Stress after any Push of the roll, and their current Resolve.
- The table's first row covers every total of 0 or less, and its last row every total from its minimum up.

<!-- BEGIN RENDERED: stress-responses from data/mind/stress-responses.yaml -->
| D6 + Stress − Resolve | Stress Response | Duration | Effects |
|---|---|---|---|
| 0 or less | Steady | instant | none |
| 1 | Racing Thoughts | lasting | 1-die penalty on Read, Treat Injury, Field Repair |
| 2 | Narrowed Sight | lasting | 1-die penalty on Break Attention, Rally |
| 3 | Shaking Hands | lasting | 1-die penalty on Nape strike, Body Part strike, Break Free |
| 4 | Weak Knees | lasting | 1-die penalty on Fly, Ride, Dodge |
| 5 | Hair Trigger | lasting | 1 extra Stress on every Push |
| 6 | Flinch | instant | lose 1 success |
| 7 | Locked Up | instant | lose 1 success; next turn spent |
| 8 or more | Botched | instant | the roll fails; gain 1 Stress |
<!-- END RENDERED: stress-responses -->

### Instant and lasting results

Every row is **instant** or **lasting** (`result_rules`):

- An **instant** result applies once, to the roll that caused it. The table's instant rows can take successes from the roll, make it fail, spend the soldier's next turn, or add Stress.
- A **lasting** result is held by the soldier. Its effects apply from the next roll on and never change the roll that caused it. Each lasting row either puts a 1-die penalty on the Action Catalog entries it names or adds Stress to every Push. A soldier can hold several different lasting results.
- **Already held.** If the row found is a lasting row the soldier already holds, use the next row down the table instead. Repeat while that row is also one the soldier holds.

### When lasting results end

A lasting Stress Response ends when:

- Rally clears it (section 3.11);
- the Titan Engagement in which it was gained ends (section 3.16); or
- outside a Titan Engagement, the rule that called for the roll says it ends. If that rule says nothing, it ends when a day passes.

A result gained at the steps after a Titan Engagement ends, such as on a care-window roll, was gained outside it. The sheet records which ending applies. A Down soldier keeps the lasting results they hold.

> **Design note (OQ-47):** The rows are the starting values for the ADR-0014 simulator. A Stress trajectory model with these rows shows no Stress spiral for a Rookie who Pushes every short roll. The table keeps its lasting penalties to 1 die each, because six attributes share the rows instead of Alien's four. At Resolve 3, a Stress Response at Stress 1 is a lasting penalty or nothing. At Stress 3 it takes a success 1 time in 6, and at Stress 5 it takes a success or worse half the time.

## 3.11 Rally

Rally is the Empathy action `rally` (Chapter 2). `rally` in `data/mind/stress-responses.yaml` gives the procedure.

- **Target:** a comrade, player character or Squadmate, who holds at least one lasting Stress Response. A soldier can never Rally themselves. The target may be Down.
- **Needs:** 1 success. **Each success clears one** of the target's lasting Stress Responses, chosen by the Rallying soldier's player.
- On a failure nothing happens.
- **Rally never lowers Stress.**
- **In a Titan Engagement:**
  - It is an action.
  - The target must hold the same Position as the Rallying soldier or one Position step away, and Carrying Voice adds one more step. Two soldiers who have both left the Titan Engagement while it goes on count as holding the same Position, including for Help and Covering on the roll (section 3.16).
  - It can be Helped as Chapter 1 states, and a failed Rally can be tried again on a later turn.
- **Outside a Titan Engagement:**
  - Any soldier who is not Down may Rally a comrade, with no Help and no Covering.
  - A soldier can Rally a given comrade once, and again only after that comrade gains another lasting Stress Response. The sheet records who has Rallied the comrade.
- Steady Voice adds dice.

> **Design note (OQ-48):** Rally uses Help's Position test, clears one lasting result per success, and outside a Titan Engagement can be used on a comrade once per lasting result gained, so no judgment decides who can reach whom or how often.

## 3.12 Fear Rolls

`data/mind/fear-rolls.yaml` holds the triggers and the table, which is rendered under *Results* below.

### Triggers

A Fear Roll is made only when an event on the closed list of `triggers` happens (ADR-0003, item 1). The dice never cause one (ADR-0004). A later chapter that creates a new trigger adds a row to the file. The Phase 1 triggers are:

- **`first-titan-engagement`:** the soldier's first Titan Engagement. The sheet's `faced_a_titan` is set when the soldier first holds a Position in one, even if they make no Fear Roll, for example because they are Down.
- **`abnormal`:** an Abnormal is a Focus Titan when a Titan Engagement starts, or becomes one during it.
- **`second-focus-titan`:** a Background Titan enters as a second Focus Titan.
- **`comrade-grabbed`:** a comrade becomes Grabbed.
- **`comrade-dies`:** a comrade dies.

Each row states who rolls:

- `first-titan-engagement`: only that soldier, when they first hold a Position in a Titan Engagement.
- `abnormal` and `second-focus-titan`: every soldier who holds a Position in that Titan Engagement.
- `comrade-grabbed`: every witness, as Chapter 5 defines a witness in a Titan Engagement (section 5.9, `data/engagement/engagement-flow.yaml`, `witnesses`), never the Grabbed soldier.
- `comrade-dies`: every witness, as Chapter 5 defines one. A witness who is Grabbed still rolls.

Each row also marks whether its event can arise outside a Titan Engagement (`can_arise_outside_titan_engagement`), such as a comrade Grabbed in a Chase. Outside a Titan Engagement, such an event causes Fear Rolls only if the rule that creates the situation states who rolls.

### Limits

- **One Fear Roll per soldier per event,** even if the event matches several triggers.
- **A Down soldier makes no Fear Roll.**
- A death during the steps after a Titan Engagement ends (section 3.16) causes no Fear Roll.
- Fear Rolls are made as soon as the event has been fully resolved. Grief from a death applies only after every Fear Roll that death causes has resolved, including each Drive decision (section 3.14).

### The roll

- Roll **D6 + Stress − Resolve** and find the row. It is the fixed roll `fear-roll`: no pool, no Push, no Help, no Stress Dice, and no Stress Response.
- Unshaken Command can let the roll use a nearby comrade's higher Resolve, under the Talent's trigger and limit (section 3.8). Two Scars raise the total for certain triggers (section 3.13).
- A Squadmate makes Fear Rolls like a player character.

### Results

Every row is instant, and the rows escalate:

- Low totals add Stress or a penalty on the next roll.
- Middle totals spend the soldier's next action, then their next turn.
- High totals also forbid Reactions until the end of the soldier's next turn to begin. Shattered spends two turns, and its ban lasts until the end of the second turn spent.
- The top rows add a Scar, and the highest spends two turns.

<!-- BEGIN RENDERED: fear-rolls from data/mind/fear-rolls.yaml -->
| D6 + Stress − Resolve | Result | Effects | Forbids |
|---|---|---|---|
| 0 or less | Steeled | none | — |
| 1 | Unnerved | gain 1 Stress | — |
| 2 | Rattled | gain 1 Stress; 1-die penalty on the next roll | — |
| 3 | Hesitate | next action spent | — |
| 4 | Falter | next action spent; gain 1 Stress | — |
| 5 | Frozen | next turn spent | — |
| 6 | Unguarded | next turn spent; no Reactions | Reactions |
| 7 | Breaking Point | next turn spent; no Reactions; gain a Scar | Reactions |
| 8 or more | Shattered | next 2 turns spent; no Reactions; gain a Scar | Reactions |
<!-- END RENDERED: fear-rolls -->

**What counts as the result.** A Fear Roll's result is every effect of its row: any Stress gain, spent action or turn, ban on Reactions, and Scar. When a soldier's Drive shrugs off the result (Chapter 2, section 2.5), none of those effects happen. The Fear Roll still counts as made.

> **Design note (OQ-49):** Five triggers, one Fear Roll per soldier per event, no Fear Roll for a Down soldier, and Fear Rolls outside a Titan Engagement only where the creating rule names who rolls keep the list closed (ADR-0003, item 1). A soldier's first Titan Engagement sets `faced_a_titan` whether or not they roll. Chapter 5 defines who witnesses a comrade being Grabbed or dying (section 5.9).

**Acceptance test (OQ-50, OQ-95).** ADR-0014, as amended, reads "comrades close" as one comrade in reach with the reference build and starting state. Its "a Grab kills about 1 time in 3 with comrades close" counts as met only if the Grab and rescue rules pass all six cells of this band, with Rookie witnesses at Resolve 3 before Grief:

- Witness Stress 1, 2, and 3, each with 0 Grief and with 1 Grief, make six cells.
- At witness Stress 2 with 0 Grief, the comrades-close death rate is near 1 in 3.
- In every one of the six cells, the comrades-close death rate is below 50%.

Every Fear Roll row, including Hesitate, stays as written while Chapter 5 is tuned against this test. Chapter 5 gives the measured cells (section 5.13, `data/engagement/tuning.yaml`, `grab`), and section 3.7 quotes them.

> **Design note (OQ-50):** Every row is kept, and a Drive shrugs off every effect of the row. At Resolve 3, a Fear Roll costs a witness their next action or their whole turn 2 times in 6 at Stress 1, 3 in 6 at Stress 2, and 4 in 6 at Stress 3. It costs the whole turn 1 time in 6 at Stress 2 and 1 in 3 at Stress 3. It gives a Scar only on a total of 7 or more, which needs Stress above Resolve.

## 3.13 Scars

`data/mind/scars.yaml` holds how Scars are gained, the Scar table, which is rendered under *What a Scar does* below, and Retirement.

### Gaining a Scar

A soldier gains a Scar only from a trigger on the closed list in `gaining`:

- **A Fear Roll row with a Scar** takes effect. A result that a Drive shrugs off gives no Scar.
- **A lethal Critical Injury is stabilized** while the soldier is alive, by a Treat Injury success or by a Death Roll that slows a `day` limit. Each Critical Injury gives this Scar at most once.

Then, in order:

1. **Roll D66** on the Scar table. If the soldier already holds that Scar, roll again. A Squadmate also rolls again on a row marked `squadmate_rerolls`, whose trigger is a Push or a Cover.
2. **Record** the Scar. No rule removes a Scar.
3. **Minimum Stress rises by 1.** If the soldier's Stress is below the new minimum, it rises to it at once (Chapter 1, section 1.6).
4. **Resolve rises by 1** (ADR-0008).
5. **Five Scars:** the soldier must retire (see *Retirement*).

A soldier never holds more than five Scars. A Scar gained at five does nothing.

### What a Scar does

Every Scar raises minimum Stress and Resolve by 1 (ADR-0008, as amended). So a veteran always rolls Stress Dice and resists Stress Responses and Fear Rolls better. Each Scar row also names a trigger and an effect: a named trauma that bites in one kind of moment. Examples are a penalty on one kind of roll, extra Stress when a comrade dies or when the soldier Covers, a higher Fear Roll total for one trigger, or having to Push a failed strike.

<!-- BEGIN RENDERED: scars from data/mind/scars.yaml -->
| D66 | Scar | Trigger | Effect | A Squadmate rolls again |
|---|---|---|---|---|
| 11–13 | The Closing Hand | You make a dodge against a behavior whose Behavior Table entry has a grab effect, which Chapter 6 marks in each table's Grab column (data/titans/index.yaml, grab_mark). | 1-die penalty on Dodge (that dodge only) | no |
| 14–16 | Survivor's Guilt | A comrade in the Squad dies. | gain 1 Stress, after the soldier's comrade-dies Fear Roll for that death, if they make one (data/mind/fear-rolls.yaml); otherwise it applies when the death happens | no |
| 21–23 | Unsteady Hands | You roll for treat-injury or field-repair. | 1-die penalty on Treat Injury, Field Repair | no |
| 24–26 | Cannot Look Away | You make a Fear Roll for the comrade-grabbed trigger. | Fear Roll total +1 | no |
| 31–33 | Numb | A comrade in the Squad dies. | You make no Fear Roll for that death, and you gain 1 more Grief from it (data/mind/grief.yaml). | no |
| 34–36 | Reckless Blade | Your roll for nape-strike or body-part-strike falls short of what it needs, and you are allowed to Push it. | You must Push that roll. | yes |
| 41–43 | Nerves on Edge | For the first time in a Titan Engagement, a Titan's card resolves a behavior against you. | gain 1 Stress | no |
| 44–46 | Fear of Falling | You roll for fly. | 1-die penalty on Fly | no |
| 51–53 | Blood on the Blade | Your Nape strike kills a Titan. | gain 1 Stress, after the Nape kill Stress relief (data/core/stress-changes.yaml) | no |
| 54–56 | Carrying Their Weight | You Cover a comrade's Push. | gain 1 Stress (in addition to the Covering Stress) | yes |
| 61–63 | Second-Guessing | You roll for read or break-attention. | 1-die penalty on Read, Break Attention | no |
| 64–66 | Old Nightmare | You make a Fear Roll for the abnormal or second-focus-titan trigger. | Fear Roll total +1 | no |
<!-- END RENDERED: scars -->

When one death triggers both Survivor's Guilt and the soldier's `comrade-dies` Fear Roll, the Scar's Stress comes after that Fear Roll, so it never raises the roll's total. A soldier who makes no Fear Roll for the death gains the Stress when the death happens.

> **Design note (OQ-51):** The rule has two Scar triggers, a D66 Scar table of twelve rows, Survivor's Guilt after a death's Fear Roll, Squadmate re-rolls, and the Retirement timing below, which promotion shares (Chapter 2, section 2.10). Scars come from Stress well above a soldier's minimum, and from surviving lethal Critical Injuries. A Scar raises minimum Stress and Resolve together, so it does not by itself change a soldier's Fear Roll or Stress Response odds at minimum Stress.

### Retirement

A soldier with five Scars must retire (`retirement`):

- **When:** Retirement never interrupts a procedure.
  - A fifth Scar gained during a Titan Engagement, or at any of the steps after it ends (section 3.16), retires the soldier at the last of those steps.
  - One gained while a day passes retires the soldier after that day's last step (section 3.6).
  - One gained in a care window held for harm outside a Titan Engagement retires the soldier after that window and the Death Rolls that follow it, if any.
  - Any other fifth Scar, such as one from a Fear Roll that a Chase causes, retires the soldier when the procedure in which it was gained ends, as that procedure's rule states. If no procedure is under way, it retires the soldier at once.

  Until then the soldier follows every rule as normal.
- The soldier leaves play and becomes an NPC instructor or Squad contact. The rules that give instructors and contacts an effect are not yet written.
- A retiring player character is replaced by promotion or a new character (Chapter 2, section 2.10). A retiring Squadmate leaves the Squad Pool.
- Every Drive that named the retiring soldier can never trigger again.
- Retirement gives no Grief and is not a Fear Roll trigger.

## 3.14 Grief

`data/mind/grief.yaml` holds the rule.

- **Who gains it.**
  - A death during a Titan Engagement, including one at the steps after it ends (section 3.16), gives Grief to every other living soldier in the Squad who held a Position at any point during that Titan Engagement.
  - Any other death of a soldier in the Squad gives Grief to every other living soldier in the Squad.
- **How much.** The deaths of one Titan Engagement give each such soldier 1 Grief in total, however many comrades died. So do the deaths of one day passing, and the deaths from one event outside a Titan Engagement together with the Death Rolls that follow its care window. A later procedure, such as a Chase, may state that all deaths during it count as one event. Any other death gives 1 Grief. On top of that:
  - a soldier whose Drive named a dead soldier gains 1 more for that soldier;
  - a soldier with the Numb Scar gains 1 more for each death.

  These additions go only to a soldier who gains Grief from that death.
- **When** (`gaining.timing`, `gaining.applies_after`):
  - For a death during a Titan Engagement or at its end steps: at step 8 when the Titan Engagement ends (section 3.16). Grief does not change Resolve during the fight in which the comrade died.
  - For any other death: immediately after every Fear Roll that death causes has resolved, including each Drive decision and result; immediately if the death causes no Fear Roll.
  - Either way, a death's Grief never applies before that death's own Fear Rolls.
- **Limit.** A soldier holds at most **3** Grief. Grief gained beyond 3 is lost.
- **Effect.** Each point of Grief lowers Resolve by 1, with no floor. Grief has no other effect in the Phase 1 rules.
- **Losing Grief.** No field rule lowers Grief. The Downtime rules, not yet written, lower it through a soldier's Haven and the Honoring the Fallen Squad Action.
- Retirement, promotion, and a Squadmate leaving the Squad Pool give no Grief. Squadmates gain Grief like player characters.

> **Design note (OQ-52):** Grief goes only to soldiers who held a Position in the Titan Engagement where the death happened. The deaths of one Titan Engagement, one day passing, or one event outside a Titan Engagement give at most 1 Grief, plus 1 for each dead comrade a Drive named. A soldier holds at most 3, and Resolve has no floor. A death's Grief waits for that death's Fear Rolls: applying it first would raise a Stress 2, Resolve 3 witness's chance of losing an action or turn from 50.0% to 66.7%, which is the outcome delaying Grief exists to prevent. The Downtime rules must be able to remove at least 2 Grief per Downtime from a soldier who uses that relief.

## 3.15 Stress in the field

Phase 1 changes Stress in the field only through these rows in `data/core/stress-changes.yaml`:

- **Gains:** a Push, Covering, and any table result or Talent that names a gain. In this chapter those are some Critical Injury, Stress Response, Fear Roll, and Scar rows.
- **Losses:** the end of a Titan Engagement and a Nape kill, 1 each (ADR-0008; Chapter 1, section 1.6).
- **Minimum:** Stress never drops below the soldier's number of Scars, and rises to a new minimum at once.

Rally clears a lasting Stress Response but never lowers Stress. The Expedition rules, not yet written, will add the Waypoint camp relief as a new row. The Downtime rules will add Downtime relief through a soldier's Haven.

## 3.16 When a Titan Engagement ends

Chapter 5 states when a Titan Engagement ends (section 5.11, `data/engagement/engagement-flow.yaml`, `ending`). When it does, resolve the steps of `data/harm/engagement-end.yaml` in order:

1. Cancel turns spent in advance that have not come up (Chapter 1, OQ-15), along with turns and actions a result would have spent. Every ban on Reactions ends.
2. Apply the end-of-Engagement Stress relief. A Nape kill that ended the Titan Engagement applied its own relief when the kill happened.
3. End every lasting Stress Response gained during the Titan Engagement.
4. Every `turn` time limit becomes `engagement`.
5. Aftermath rolls: each patient with an untreated lethal `engagement` Critical Injury gets at most one aftermath roll, from a treater the players choose, and each soldier makes at most one (section 3.5, *Aftermath rolls*). A success gives back the Critical Injury's Health box as treating does (section 3.5) and can end Down.
6. Every lethal Critical Injury that still has an `engagement` limit runs out and causes a Death Roll, before the care window. These Death Rolls are made outside the Titan Engagement, so a limit the soldier survives becomes `day` (section 3.4). A death at this step causes no Fear Roll.
7. Hold a care window (section 3.5). A lethal Critical Injury stabilized here or at step 5 gives its Scar as usual.
8. Every soldier gains the Grief for the deaths during the Titan Engagement, including deaths at step 6 (section 3.14).
9. Every soldier with five Scars retires, including one who gained the fifth Scar at an earlier step, and a retiring Squadmate leaves the Squad Pool. Then promotion replaces, as one batch, every player character who died or retired during the Titan Engagement or at any end step, including step 6, using Chapter 2's contest (section 2.10).

The steps are resolved outside the Titan Engagement. No soldier retires, and no promotion happens, before step 9.

> **Design note (OQ-54):** The Death Rolls the end of the fight causes come after its aftermath rolls and before its care window, so only treatment during the fight or the patient's one aftermath roll prevents them. Section 3.5 gives the trade that remains when a Squad delays ending a fight (OQ-57). Grief comes after every death the fight caused, including those at its end. Every Retirement and promotion waits for the last step.

### Soldiers who left before the end

A living soldier who left the Titan Engagement while it went on holds no Position in it. Until it ends, they are still in it for every rule in this chapter (`soldiers_who_left`):

- They still take a turn each round, in the order Chapter 5 sets (section 5.3, `data/engagement/round.yaml`). Each of those turns counts for every rule that counts turns, so a `turn` limit keeps running out, and a result can spend the turn.
- For Treat Injury and Rally, for Help and Covering on those rolls, and for aftermath rolls, two soldiers who have both left count as holding the same Position. A soldier who has left never counts as holding the same Position as, or one step from, a soldier who still holds one.
- Every step above applies to them when the Titan Engagement ends.

Chapter 5 states how a soldier leaves a Titan Engagement and what their move and action can do after leaving (section 5.11, `data/engagement/positions.yaml`, `leaving`).

> **Design note (OQ-56):** A soldier who left a Titan Engagement that is still under way keeps taking turns in it, so one clock and one end procedure serve the whole fight. They can treat or Rally another soldier who has also left, and Help or Cover those rolls, and they go through its end steps with everyone else.

## 3.17 Who uses these rules

- **Player characters** use every rule in this chapter.
- **Squadmates** use every rule in this chapter as well (Chapter 2, section 2.10, `rules_applicability`), with three differences that follow from Chapter 2:
  - A Squadmate has no Drive, so it never shrugs off a Fear Roll result.
  - A Squadmate never Pushes, so extra Stress on a Push does nothing for it.
  - A Squadmate re-rolls a Scar whose trigger is a Push or a Cover.
- **Titans** never take harm from this chapter. They have no Health (ADR-0007), and Chapter 5 gives Body Part States and Regeneration (section 5.7).
- **The sheet.** `data/harm/sheet-fields.yaml` lists what this chapter adds to the character sheet and the Squadmate stat block:
  - how current Health is derived, with no field of its own: Health minus the smaller of Health and the untreated Critical Injuries held, minus Health lost, never below 0, where Health lost is never more than Health minus the boxes crossed off. Only Critical Injuries still held count: one that heals leaves the Critical Injuries list, and goes on the healed list below if its row has permanent effects. The recorded Down state must always match section 3.3's two conditions. On paper, the Health row takes a slash in a box for damage and an X for an untreated Critical Injury; treating erases an X, and a day passing or a revive erases slashes;
  - each Critical Injury's treated state, time limit, healing days left, and whether Careful Nursing has halved it;
  - healed Critical Injuries whose rows have permanent effects;
  - the lasting Stress Responses held, and when each ends;
  - who has Rallied the soldier outside a Titan Engagement;
  - a pending next-roll penalty;
  - whether the soldier has faced a Titan;
  - which Critical Injuries have already given a Scar;
  - a pending Retirement.

  Promotion keeps every one of these fields in its current state, as it keeps everything else a Squadmate has (Chapter 2, section 2.10; `promotion` in the same file).

> **Design note (OQ-55):** This chapter lists its fields in its own file. Chapter 2's sheet list (`record_on_sheet`) and stat block (`stat_block.fields`) each end with a row that includes `data/harm/sheet-fields.yaml`, and promotion keeps every field in it. Health boxes add no stored field: boxes crossed off are the untreated entries in `critical_injuries`.

**Every act in this chapter has a tracked value and a Catalog entry** (ADR-0003, item 12; OQ-71), both in `data/character/action-catalog.yaml`.

- Treating a Critical Injury, reviving a Down soldier, and ending Down are `treat-injury`, which changes `critical-injury-treat`, `health-restore`, and `down-end`.
- Clearing a Stress Response is `rally`, which changes `stress-response-clear`.
- Carrying a Down comrade is `lift-comrade`, which changes `comrade-carry`.

The Death Roll is a roll its rule calls for, not an act, so it needs no tracked value. It keeps its Catalog entry, `death-roll`, marked as not an action, so a Talent can name it. No act in this chapter needs the procedure for actions outside the Catalog.

---

## Example: a bad round

*The numbers in this example are for illustration only. Real Severity values and Titan attacks come from Chapters 5 and 6, and the rows below follow the YAML files at the time of writing. If the files change, the files govern.*

Private Oskar Wendt has Strength 3 and Agility 3, so Health 3: a row of 3 boxes. He has Instinct 3 and Empathy 3, so Resolve 3. He has Wits 2 and carries his own medical kit, rated 1. His Stress is 1.

- **A Titan attack.** Before Oskar's turn comes up, a Titan's card resolves an attack against him. He dodges, which spends this round's turn, because none of it was spent yet. The dodge falls short. The attack's Injury Location is rolled: D6 shows 5, torso. He holds no torso Critical Injury, so there is no worsening. 2D6 shows 11: Punctured Lung. It is lethal with an `engagement` limit, it does not put him Down, and it gives 1 die less on `fly` and `dodge`. A Titan attack adds nothing to Health lost, but the untreated Punctured Lung crosses off one box: his current Health is 2.
- **A second attack.** A later card that round resolves an attack with a fixed head Injury Location. Oskar has already made his one Reaction against this Titan this round, and his dodge's successes do not meet this attack's Severity, so it lands. 2D6 shows 8: Head Blow, `down: until_treated`. It crosses off a second box, leaving current Health 1, and its row puts Oskar Down. He cannot make Reactions and makes no Fear Rolls. Had Oskar's Health been 2, the Head Blow would have crossed off his last box, and he would be Down from that as well.
- **Treatment.** Private Mila Brandt holds Oskar's Position and has an unspent action. She declares Treat Injury with the treat use on the Head Blow. Wits 2, medical kit 1, and Stress 1 give 4 dice, and she rolls a 6. The Head Blow is treated, and its box comes back: current Health 2. Oskar's current Health is above 0 and no untreated Down row holds him, so Down ends. Ending Down restores nothing, so this round's turn, which his dodge spent, stays spent. Nothing has spent his turn next round, so it will begin with its move and action.
- **The end of the Titan Engagement.** A comrade's Nape strike kills the Titan and ends the Titan Engagement. Every soldier gets the Nape kill relief and the end-of-Engagement relief. Oskar's Stress and Mila's each drop to their minimum of 0.
- **The aftermath roll.** The Punctured Lung is untreated with an `engagement` limit, so Oskar gets one aftermath roll before its Death Roll. Mila still holds his Position, so the players choose her as the treater rather than Oskar himself. Wits 2 and her medical kit give 3 dice at Stress 0, with no 6, and she does not Push. That failure uses up Oskar's attempt: he cannot now roll on himself, and no one could Help or Cover the roll.
- **The Death Roll.** The Punctured Lung still has its `engagement` limit, which now runs out. Oskar rolls Strength 3 with no penalty and gets one 6: he lives. The roll was made outside a Titan Engagement, so the limit becomes `day`. Only a treatment during the fight or a successful aftermath roll could have spared him this roll. The Punctured Lung still crosses off one of his boxes.
- **The care window.** The aftermath roll used up no one's roll in the window, and Oskar, Mila, and Hale all held a Position in the fight, so all three are in its scope. Mila uses treat on the Punctured Lung and fails. Private Hale, who has no medical kit, rolls on it too: Wits 2 at Stress 0 gives 2 dice, with no 6. Hale's Help on Oskar's own roll would have added nothing, because the self-treatment penalty takes Wits 2 plus 1 Bonus Die down to the same 1 base die that Wits 2 alone reaches. Oskar then treats himself with 1 base die and his medical kit's Gear Die: no 6.
- **Later.** When the next day passes (at a night camp once the Expedition rules exist, and until then at the start of the next session, section 3.6) there is a care window before his next Death Roll. If a comrade stabilizes the Punctured Lung then, its box comes back, and Oskar also gains a Scar for surviving it. He rolls D66 on the Scar table, and his minimum Stress and Resolve each rise by 1. If nobody treats it, the day restores no box: a day passing gives back only Health lost to damage, and Oskar has none.
