# Chapter 2: Character Creation

This chapter covers how a player creates a soldier of the Survey Corps: the Lifepath from Origin to Graduation, attributes and the values derived from them, Drives, Specialties, and Talents. It also sets out the Action Catalog that Talents name, and the Squadmates who ride with the player characters.

It builds on Chapter 1. Every roll here follows the dice pool, Push, Stress, and Help rules from that chapter, except where a roll's own procedure lists an exception. Later chapters own these rules, and this chapter only refers to them:

- **Chapter 3, Harm and Mind:** Health, Critical Injuries, Down, Death Rolls, Stress Responses, Fear Rolls, Scars, Grief, and Retirement.
- **Chapter 4, Gear:** ODM Gear, Gas Rolls, Blade Sets, horses, carrying and Overloaded, and Standard Issue.
- **Chapter 5, Titan Engagement:** Positions and Position steps (section 5.2), Attention (section 5.6), Openings (section 5.7), Read and Call It (section 5.8), the Grab (section 5.9), and Wings in a Titan Engagement (section 5.3).

Some of that content is not yet written: XP and how Talents are bought after creation, Downtime and the Train Downtime Action, Rank and Commendations, Requisition, Funding, Faction Standing, Expeditions, Chases, the Canon Clock, and Operation Frames. This chapter mentions them only where creation has to.

**Tables.** Every table in this chapter is a YAML file in `data/character/`. Those files are the only source of truth (ADR-0012). The chapter's tables are rendered from them by `tools/render/render.py`, between `BEGIN RENDERED` and `END RENDERED` markers that name each block's source file; nothing between the markers is written by hand, and `render.py check` fails if a rendered block and its YAML differ. Each table appears where its procedure uses it, except the Talents and the Action Catalog, which are in Appendix 2A at the end of the chapter. The files are:

- `data/character/lifepath.yaml`: the order of creation steps, how shared choices are settled, and what goes on the character sheet.
- `data/character/attributes.yaml`: the six attributes, creation limits, and derived values.
- `data/character/origins.yaml`: the Origin table (D66).
- `data/character/enlistment.yaml`: the Why You Enlisted table (D66) with its Drives, and the rules every Drive follows.
- `data/character/training-years.yaml`: the three Training Year event tables (D66), curriculum lists, and the performance roll.
- `data/character/class-rank.yaml`: Merit to Class Rank, and what a Top 10 Class Rank does.
- `data/character/graduation-exam.yaml`: the optional Graduation Exam and its three Trials.
- `data/character/specialties.yaml`: the nine Specialties.
- `data/character/talents.yaml`: the Phase 1 Talent list.
- `data/character/action-catalog.yaml`: the Action Catalog, the gear rule, its tracked values, and the procedure for actions outside it.
- `data/character/squadmates.yaml`: Squadmate stat blocks, rules, actions, Wings, the starting Squad, and promotion.

This chapter also adds two rows to Chapter 1's files:

- `data/core/dice-pool.yaml`, under `roll_exceptions`: the performance roll. Chapter 1 lets a roll leave out Stress Dice when its own rule names it and it has a row there (OQ-03).
- `data/core/stress-changes.yaml`, under `reductions`: the end of the Graduation Exam, following section 1.6's "a later chapter adds a row" pattern.

It changes no Chapter 1 rule. A few reference texts in those files now point to this chapter's data.

Where the ADRs left a question open, the rule below cites its entry in `docs/rules/OPEN-QUESTIONS.md` as (OQ-nn). Every entry this chapter cites was decided on 2026-09-14 (`docs/rules/DECISIONS-2026-09-14.md`), and the text states the decided rule. OQ-58 was decided the same day, under *Conformance follow-up* in that file, and OQ-70 and OQ-71 under *Batch 2*. Design notes give the reasons.

---

## 2.1 What a soldier is made of

Every player character is a graduate of the Training Corps who has joined the Survey Corps. `data/character/lifepath.yaml` (`record_on_sheet`) lists everything the character sheet holds. In brief:

- **Attributes:** Strength, Agility, Wits, Perception, Instinct, and Empathy (section 2.2).
- **Derived values:** Health, kept as a row of boxes, Resolve, Stress, and minimum Stress (section 2.2).
- **Origin and Haven:** where the soldier grew up, and what they have to return to (section 2.3.1).
- **Drive:** what keeps them fighting, written as a trigger, and whether it has been used this session (sections 2.3.2 and 2.5).
- **Merit and Class Rank:** how they performed in the Training Corps (sections 2.3.3 and 2.3.4).
- **Specialty:** their trained specialization (section 2.6).
- **Talents:** narrow trained abilities, each naming the Action Catalog entries it applies to (sections 2.7 and 2.8). A once-per-Titan-Engagement Talent's use is recorded on the sheet beside that Talent.
- **Canon Tie:** an optional personal link to one canon character (section 2.3.1).
- **Rank:** every new soldier is a Private. The Rank rules are not yet written.
- **Harm:** Health lost to damage, whether the soldier is Down, Scars, Grief, and Critical Injuries. A new soldier has none of them. Chapter 3 adds further harm and mind fields in `data/harm/sheet-fields.yaml`, which `record_on_sheet` names as its last row (OQ-55).
- **Gear:** Standard Issue (Chapter 4).

Talents are the only trained abilities a soldier has. A roll is an attribute plus at most one Talent that names the roll's Action Catalog entry, plus Bonus Dice, Gear Dice, and Stress Dice (Chapter 1, section 1.3; ADR-0006).

## 2.2 Attributes and derived values

### The six attributes

The table below lists the six attributes, a summary of what each covers, and the Action Catalog entries that name each one. The summary is for players. Which attribute a roll uses is set only by its Action Catalog entry (section 2.8).

<!-- BEGIN RENDERED: attributes from data/character/attributes.yaml -->
| Attribute | Covers | Action Catalog entries that name it | Key attribute of |
|---|---|---|---|
| Strength | Force, cutting power, and physical endurance. | Nape strike, Body Part strike, Break Free, Block (reserved), Fight (reserved), Endure (dormant), Death Roll | Slayer, Brawler |
| Agility | Quickness, balance, and control on ODM Gear or in the saddle. | Dodge, Fly, Ride (dormant), Sneak (dormant) | Flier, Rider |
| Wits | Planning, mechanics, and medicine. | Treat Injury, Field Repair, Recall (dormant) | Medic, Engineer |
| Perception | Noticing, aiming, and placing a decoy where a Titan will look. | Break Attention, Spot (dormant) | Hunter |
| Instinct | Gut calls, survival, reading people, and Reading Titans. | Read, Size Up (dormant), Survive (dormant) | Tactician |
| Empathy | Steadying comrades and moving people to act. | Rally, Persuade (dormant) | Leader |
<!-- END RENDERED: attributes -->

- Attributes are rated **2 to 5**. The key attribute of the soldier's Specialty is the only one that can be rated **6** (ADR-0006).
- **Attributes never rise after the Lifepath** (ADR-0011). A soldier grows through Talents and Scars instead.

### How the Lifepath sets attribute ratings

1. Every attribute starts at **2**.
2. The Lifepath adds **6 points**, each to a named attribute: 2 from the Origin, 1 from Why You Enlisted, and 1 from each Training Year's event. Every one of these points comes from a rolled row.
3. **Before Graduation, no attribute can go above 5.** A point that would raise an attribute above 5 goes instead to another attribute rated below 5, chosen by the player.
4. **At Graduation**, after choosing a Specialty, in this order (`creation.graduation`):
   1. **Swap.** If any other attribute is rated higher than the key attribute, swap the key attribute's rating with the highest rating among the other five. If several share that rating, the player picks one. The key attribute now holds the soldier's highest rating.
   2. **Floor.** If the key attribute is still below 4, raise it to 4. For each point added, the player lowers by 1 another attribute rated 3 or more. This happens only when every attribute is 3.
   3. **Top 10.** If the soldier's Class Rank is Top 10, the key attribute gains **1**, to a maximum of 6.
5. There are no free points. The swap and the floor never change the total, so every new soldier has 18 attribute points, or 19 with a Top 10 Class Rank.

> **Design note (OQ-19):** A new soldier's attributes come from 6 rolled Lifepath points on a base of 2, a Graduation swap and floor that give the key attribute the soldier's highest rating and at least 4 without adding points, and +1 to the key attribute for a Top 10 Class Rank. In simulation the key attribute ends at 4 about 64% of the time, at 5 about 34%, and at 6 about 2%, only through a Top 10 Class Rank. Because the swap always moves the highest rating into the key attribute, these figures hold whichever Specialty the player chooses, and no player strategy changes them. The other five attributes average about 2.7. This follows ADR-0014, as amended, whose default Squad is all Rookies (key attribute 4, other attributes 3 with one at 2), with the reference Rookie having the Slayer template's attributes (Strength 4, Agility 3, Wits 2, and 3 elsewhere) and Talent 1 in the Talent that names the Nape strike, the Body Part strike, Break Free, or Treat Injury (OQ-58, OQ-70; decision batch 2b), and the Veteran at Strength 5, Agility 3, Wits 2, and 3 elsewhere, 19 points (OQ-71). No other roll a target measures carries Talent dice, including the dodge, Fly, Break Attention, Ride, and Read (OQ-94). It leaves 5 and 6 reachable, as ADR-0006 and ADR-0011 require. Health and Resolve come from the final ratings, after the swap. The swap costs some Hunters, Medics, and Engineers Health and Resolve: about 11% of them have Health 2, and a Health 2 soldier is Down by their second untreated Critical Injury (Chapter 3). That cost is accepted. Beside the reference builds, the simulator reports every target that depends on Health for the reference Squad with each soldier's Health set to 3 and nothing else changed, and reports the Health 2, 5, and 6 builds Chapter 3 quotes (OQ-58, OQ-71). It reports the Talent-dependent targets for a Squad built literally from the Squadmate templates as well (OQ-70).

### Derived values

`data/character/attributes.yaml` (`derived_values`) gives each formula and its rounding:

- **Health** is half of Strength plus Agility, kept as a row of that many boxes (Chapter 3). Chapter 3 says what Health does: each untreated Critical Injury crosses off one box, up to Health; damage marks the boxes left; at 0 the soldier is Down. ADR-0005 has Titan attacks bypass it.
- **Resolve** is half of Instinct plus Empathy, plus 1 per Scar, minus 1 per point of Grief, counting at most 3 points of Grief. At creation the soldier has no Scars and no Grief. Chapter 3 says what Resolve does.
- **Stress** starts at 0, which is the minimum Stress of a soldier with no Scars (Chapter 1, section 1.6).
- **Carrying limit:** Strength + 4 items before the soldier is Overloaded (Chapter 4).

Health and Resolve both round the halved attributes up, and both are computed from the final attributes, after the Graduation swap and floor (OQ-24).

## 2.3 The Lifepath

The Lifepath takes a Cadet from their Origin through three Training Years to Graduation. Players create their characters together, step by step, because the optional Graduation Exam (section 2.4) and the starting Squad (section 2.10) involve every character at once. `data/character/lifepath.yaml` (`steps`) gives the order and exactly what each step records.

**The GM plays no part in the Lifepath beyond reading tables with the players.** Every result comes from a roll, a table row, or a choice the table gives the player.

**Shared choices.** Some choices belong to the players together: whether to run the Graduation Exam, the Campaign Year, and the templates of starting Squadmates. When players disagree, each proposed choice is rolled for once, with a D6 rolled by one player who proposed it. The highest roll decides, and choices tied for highest roll again (`group_choices`). The order of Cadets in a Trial is rolled, not chosen (section 2.4).

### Before the Lifepath: the Campaign Year and the Exam vote

1. **Campaign Year.** If the campaign has not yet recorded one, the players record the Campaign Year, from 845 to 850: the year the campaign begins. It changes only when a rule names a change. No Phase 1 rule does; the Canon Clock rules, not yet written, will advance it. Every Origin condition is tested against the current Campaign Year, so a character created or promoted later uses the year the campaign has reached (OQ-32).
2. **Exam vote.** The players decide whether to run the Graduation Exam (section 2.4). A replacement character created later decides before rolling their own Lifepath, and takes the Exam alone (OQ-22).

### 2.3.1 Origin

1. Set every attribute to 2.
2. Roll D66 on the Origin table below. If the row has a condition that the current Campaign Year does not meet, roll again.
3. Add 1 to each of the row's two attributes.
4. Take level 1 in one of the row's two Talents.
5. Record one of the row's two Havens. A Haven is what the soldier has to return to. The Downtime rules, not yet written, say how it lets a soldier recover Stress and Grief.
6. If the row has a Canon Tie, the player may record it.

A Canon Tie is optional and has no mechanical effect in the Phase 1 rules. A soldier can have at most one, and the only way to gain one is from an Origin row. The Canon Clock rules, not yet written, may give Canon Ties effects, and will decide what happens to a tie whose canon character is dead or absent when the campaign starts (OQ-32).

<!-- BEGIN RENDERED: origins from data/character/origins.yaml -->
**Origin (D66)**

| D66 | Origin | +1 to each | Talent level 1 in one of | Haven, one of | Canon Tie (optional) | Keep the row only with | Description |
|---|---|---|---|---|---|---|---|
| 11–13 | Shiganshina District | Agility, Instinct | Quiet Step (dormant) or Slip Away | A younger sibling you promised to look after<br>A childhood friend now serving in the Garrison | Hannes: The Garrison soldier at the district gate who knew every child on your street. | no condition | A childhood in the walled district on Wall Maria's southern face, watching Survey Corps columns ride out through the outer gate. |
| 14–16 | Wall Maria Refugee | Strength, Instinct | Hard to Kill or Fieldcraft (dormant) | A younger sibling still living in the camps<br>The farm family who took you in | Armin Arlert: Another refugee child from Shiganshina who stood in the same bread line. | Campaign Year 848 or later | Fled north by boat when Wall Maria fell in 845, then grew up hungry in the refugee camps of Wall Rose. |
| 21–23 | Trost Merchant Family | Wits, Empathy | Silver Tongue (dormant) or Steady Voice | The family shop<br>A sweetheart who works the market square | none | no condition | Raised at a shop counter in Trost District, the southern gate town of Wall Rose. |
| 24–26 | Wall Rose Farm | Strength, Perception | Strong Back or Horsemanship | The family farm<br>A grandparent too old to work the fields | none | no condition | Hauled grain, mended fences, and drove the cart to market on farmland inside Wall Rose. |
| 31–33 | Forest Hunting Village | Perception, Instinct | Keen Eyes (dormant) or Lure | A parent who still hunts the old forest<br>The village elder who taught you to track | Sasha Braus: A hunter's daughter from a mountain village much like yours, met at a market fair. | no condition | Learned to track game and move quietly through the trees in a mountain village that lived by the bow. |
| 34–36 | Garrison Family | Strength, Wits | Gearwright or Make Do | A parent who still serves on the Wall<br>The barracks family that raised you | none | no condition | The child of a Garrison soldier, raised in barracks housing among the Wall's lifts and cannon. |
| 41–43 | Underground City | Agility, Instinct | Quiet Step (dormant) or Grip Breaker | Friends still living below<br>The one adult who got you out | none | no condition | Born in the lightless streets beneath Mitras, where a soldier's pay and a bunk were the only way to reach the surface for good. |
| 44–46 | Interior Merchant House | Wits, Empathy | Book Learning (dormant) or Titan Reader | A sibling who writes to you every month<br>The family townhouse, if they will still open the door | none | no condition | Raised among ledgers and guild dinners in a rich merchant family inside Wall Sina, who never forgave you for enlisting. |
| 51–53 | Minor Noble House | Empathy, Agility | Horsemanship or Judge of Character (dormant) | An old family servant who raised you<br>A cousin who still speaks to you | none | no condition | A younger child of a lesser noble family, taught riding and manners and then left free to throw your life away. |
| 54–56 | Church Orphanage | Empathy, Strength | Steady Voice or Iron Nerve | The orphanage and the children still in it<br>The priest who raised you | none | no condition | Raised by the Church of the Walls after losing your parents, the eldest of a crowded dormitory of children. |
| 61–63 | Doctor's Household | Wits, Perception | Field Medicine or Careful Nursing | Your parent's clinic<br>A patient who owes you their life | none | no condition | Grew up fetching bandages and holding patients still for a town doctor. |
| 64–66 | Horse Ranch | Agility, Perception | Horsemanship or Loose the Horse | The ranch and its horses<br>A sibling who still trains the young horses | none | no condition | Raised on a ranch on the plains of Wall Rose that breeds horses for the military. |
<!-- END RENDERED: origins -->

### 2.3.2 Why You Enlisted

1. Roll D66 on the Why You Enlisted table below.
2. Add 1 to the rolled row's attribute.
3. Record the rolled row's Drive, or instead the Drive of any other row. Choosing another row's Drive never changes which attribute gained the point (`use`). Section 2.5 explains how Drives work.

A Drive whose row says it needs a named comrade names its comrade when the Squad forms (section 2.3.5).

<!-- BEGIN RENDERED: why-you-enlisted from data/character/enlistment.yaml -->
**Why You Enlisted (D66)**

| D66 | Why you enlisted | +1 | Drive | Trigger | Test | Acts | Target | Needs a named comrade |
|---|---|---|---|---|---|---|---|---|
| 11–13 | A Titan killed someone you loved, and you watched it happen. | Strength | Vengeance | When I made a Nape strike or a Body Part strike on my most recent turn. | `most_recent_turn` | Nape strike, Body Part strike | `any` | no |
| 14–16 | You want to see what lies beyond the Walls, and to learn what Titans are. | Perception | Beyond the Walls | When I made a Read on my most recent turn. | `most_recent_turn` | Read | `any` | no |
| 21–23 | Someone you could not let go alone was enlisting, so you enlisted too. | Empathy | Stay Beside Them | When I Helped my named comrade's roll, Covered their Push, or took Lift Comrade on them since the start of my most recent turn. | `since_most_recent_turn_start` | Help, Cover, Lift Comrade | `named_comrade` | yes |
| 24–26 | A soldier once gave their life to save yours, and you mean to repay it. | Agility | Pay It Forward | When I Helped, Covered, treated, lifted, or struck to free a comrade who was Grabbed or Down, since the start of my most recent turn. | `since_most_recent_turn_start` | Help, Cover, Treat Injury, Lift Comrade, Break Free, Body Part strike | `grabbed_or_down_comrade` | no |
| 31–33 | Nobody believed you would survive the Training Corps, let alone a Titan. | Agility | Prove Them Wrong | When I hold Blind Spot or On Body, having moved there myself. | `own_state` | — | `any` | no |
| 34–36 | Your family has always served, and you were raised to put the soldier beside you first. | Empathy | Duty | When I Helped a roll or Covered a Push since the start of my most recent turn. | `since_most_recent_turn_start` | Help, Cover | `any` | no |
| 41–43 | You want to stand between the Titans and the people living inside the Walls. | Strength | Shield the Walls | When I took Draw Attention on my most recent turn. | `most_recent_turn` | Draw Attention | `any` | no |
| 44–46 | The Training Corps meant three meals a day and a bed, and you mean to live to enjoy them. | Instinct | Full Belly | When I dodged since the start of my most recent turn. | `since_most_recent_turn_start` | Dodge | `any` | no |
| 51–53 | Humanity will lose until someone learns how Titans can be beaten. | Wits | Knowledge | When I made a Read or a Body Part strike on my most recent turn. | `most_recent_turn` | Read, Body Part strike | `any` | no |
| 54–56 | Everything you had is already gone. | Instinct | Nothing Left | When I Pushed a roll since the start of my most recent turn. | `since_most_recent_turn_start` | Push | `any` | no |
| 61–63 | You made a promise to someone who did not live to see you keep it. | Perception | The Promise | When I took Break Attention on my most recent turn. | `most_recent_turn` | Break Attention | `any` | no |
| 64–66 | Living inside the Walls felt like living in a cage. | Wits | Freedom | When I am airborne on ODM Gear through my own ODM use. Chapter 4 defines when a soldier is airborne. | `own_state` | — | `any` | no |
<!-- END RENDERED: why-you-enlisted -->

### 2.3.3 Training Years

Each of the three Training Years is resolved the same way, using its own event table in *The Training Year tables* below.

1. **Event.** Roll D66 on the year's `events`.
   - Add 1 to the event's attribute.
   - Gain 1 level in one of the event's two Talents.
   - Add the event's `merit_change` to the Cadet's Merit. It can be negative.
2. **Performance roll.** The Cadet makes the year's performance roll and adds the Merit it earns (see below).

**Talent levels during the Lifepath.** No Talent can be above level 2 at creation (ADR-0006), and a rule Talent cannot go above its `max_level` in `data/character/talents.yaml`, usually 1.

**Choosing a Talent.** Every Origin row and every event offers at least one Talent that names an entry a current rule uses. A Talent that names only dormant entries (section 2.8) does nothing until later rules call for them. A player may still take it.

Two fallbacks cover an event whose Talents are capped (`talent_cap` in `data/character/training-years.yaml`; OQ-20):

- If neither of the event's two Talents can gain a level, the Cadet takes 1 level in any Talent on that Training Year's `curriculum` list that can gain one.
- If the only one of the two that can gain a level names only dormant or reserved entries, the Cadet may take that level, or instead 1 level in any Talent on the `curriculum` list that can gain one.

A new player character gains exactly 5 Talent levels: 1 from the Origin, 3 from the Training Year events, and 1 from the Specialty (`talent_levels_at_creation` in `data/character/lifepath.yaml`).

Eight roll entries exist only for rules not yet written and are marked dormant. No Origin or event choice offers only Talents that name dormant or reserved entries, and with the fallbacks above no Cadet is ever forced to take a level in such a Talent (OQ-33).

### The Training Year tables

<!-- BEGIN RENDERED: training-years from data/character/training-years.yaml -->
| Training Year | Performance attributes | Curriculum |
|---|---|---|
| First Year, Conditioning and Discipline | Strength and Instinct | Iron Nerve, Long Haul (dormant), Strong Back, Hard to Kill, Grip Breaker, Quiet Step (dormant) |
| Second Year, ODM Gear and the Blade Set | Agility and Perception | Clean Cut, Hamstringer, Slip Away, Wirework, Gearwright, Lure |
| Third Year, Field Exercises | Wits and Empathy | Titan Reader, Field Medicine, Steady Voice, Keen Eyes (dormant), Horsemanship, Judge of Character (dormant) |

A Talent marked dormant or reserved names only dormant or reserved Action Catalog entries (section 2.8).
<!-- END RENDERED: training-years -->

<!-- BEGIN RENDERED: training-year-events year-1 from data/character/training-years.yaml -->
**First Year, Conditioning and Discipline: events (D66)**

| D66 | Event | +1 | Talent level in one of | Merit | Description |
|---|---|---|---|---|---|
| 11–13 | The first inspection | Instinct | Iron Nerve or Long Haul (dormant) | +1 | An instructor screamed a finger's width from your face on the first morning, and you did not flinch. |
| 14–16 | Found in the storehouse | Agility | Quiet Step (dormant) or Slip Away | -1 | You were found stealing bread from the storehouse and ran laps until you collapsed. |
| 21–23 | Upside down in the harness | Agility | Wirework or Slip Away | 0 | You hung upside down in the balance harness on the first day and practiced every night until you could hold it. |
| 24–26 | The storm march | Strength | Strong Back or Long Haul (dormant) | +1 | On a mountain march in a storm you carried a Cadet who collapsed the last five kilometers. |
| 31–33 | Top of the written test | Wits | Book Learning (dormant) or Titan Reader | +1 | You placed first in the class on the written tactics test. |
| 34–36 | A winter in the infirmary | Wits | Field Medicine or Hard to Kill | -1 | A fall from the obstacle course fractured your wrist, and you spent the winter helping the infirmary staff. |
| 41–43 | A fight in the barracks | Strength | Hand-to-Hand (reserved) or Grip Breaker | 0 | A barracks argument turned into a fight, and you finished it. |
| 44–46 | Fire in the stables | Perception | Keen Eyes (dormant) or Horsemanship | +1 | On night watch you smelled smoke from the stables before anyone else and raised the alarm. |
| 51–53 | A homesick bunkmate | Empathy | Steady Voice or Judge of Character (dormant) | 0 | You talked a homesick Cadet out of deserting on their first winter night. |
| 54–56 | Stable duty | Perception | Horsemanship or Fieldcraft (dormant) | 0 | You were assigned to the stables for a month and learned every horse by name. |
| 61–63 | Three days alone | Instinct | Fieldcraft (dormant) or Iron Nerve | +1 | The survival exercise left you alone in the woods for three days, and you came back first. |
| 64–66 | The dismissal list | Empathy | Silver Tongue (dormant) or Iron Nerve | -1 | Your name went on the dismissal list, and you argued your way off it. |
<!-- END RENDERED: training-year-events year-1 -->

<!-- BEGIN RENDERED: training-year-events year-2 from data/character/training-years.yaml -->
**Second Year, ODM Gear and the Blade Set: events (D66)**

| D66 | Event | +1 | Talent level in one of | Merit | Description |
|---|---|---|---|---|---|
| 11–13 | The wooden nape | Strength | Clean Cut or Relentless | +2 | On your first run of the Titan dummy course you cut the wooden nape clean through. |
| 14–16 | A snapped wire | Instinct | Slip Away or Hard to Kill | -1 | An anchor wire snapped mid-swing and dropped you through the branches, and you walked away from it. |
| 21–23 | Workshop duty | Wits | Gearwright or Well-Kept Rig | 0 | You took apart a Cadet's jammed ODM Gear and rebuilt it before the morning drill. |
| 24–26 | The gas race | Agility | Wirework or Light Trigger | 0 | You raced another Cadet through the training forest and emptied your canister doing it. |
| 31–33 | Paired with the best | Perception | Hamstringer or Wirework | +1 | You were paired with the best in the class on ODM Gear and learned by watching every swing. |
| 34–36 | Three Blade Sets in a week | Wits | Blade Discipline or Gearwright | -1 | You ruined three Blade Sets in one week, and the instructors had you sharpen for the whole class. |
| 41–43 | From saddle to trees | Agility | Horsemanship or Sure Seat | +1 | You mastered firing your anchors from horseback and swinging straight into the trees. |
| 44–46 | The decoy drill | Perception | Lure or Loose the Horse | +1 | In the decoy drill you pulled the instructors' mock Titan crew off your squad with a flare. |
| 51–53 | Thrown in the yard | Strength | Hand-to-Hand (reserved) or Grip Breaker | +1 | In hand-to-hand training you threw a Cadet twice your size. |
| 54–56 | Frozen on the high wires | Empathy | Iron Nerve or Steady Voice | -1 | You froze on the high wires, and an instructor had to talk you down one anchor at a time. |
| 61–63 | The repair drill | Instinct | Gearwright or Quick Refit | 0 | In the timed repair drill you found a fault in your gear by feel, with your eyes shut. |
| 64–66 | Coaching the course | Empathy | Hamstringer or Carrying Voice | +1 | You coached a struggling squad through the dummy course until every one of them passed. |
<!-- END RENDERED: training-year-events year-2 -->

<!-- BEGIN RENDERED: training-year-events year-3 from data/character/training-years.yaml -->
**Third Year, Field Exercises: events (D66)**

| D66 | Event | +1 | Talent level in one of | Merit | Description |
|---|---|---|---|---|---|
| 11–13 | The signal relay | Perception | Keen Eyes (dormant) or Horsemanship | +1 | On a mock formation ride you relayed every signal flare without a single mistake. |
| 14–16 | Taking command | Empathy | Carrying Voice or Unshaken Command | +2 | When your exercise squad leader was ruled dead, you took command and brought the squad home. |
| 21–23 | The mock casualty | Wits | Field Medicine or Sure Hands | +1 | You kept a mock casualty alive through a timed treatment drill in the rain. |
| 24–26 | The adopted plan | Wits | Titan Reader or Sharp Call | +1 | The instructors adopted your route plan for the whole class's field exercise. |
| 31–33 | Lost at night | Instinct | Fieldcraft (dormant) or Wide Awareness | 0 | Your squad got lost on the night exercise, and you found the way back by the stars. |
| 34–36 | Arguing with an instructor | Empathy | Wide Awareness or Silver Tongue (dormant) | -1 | You told an instructor his exercise plan would get everyone killed. You were right, and you were punished for it. |
| 41–43 | The notebook | Perception | Titan Reader or Book Learning (dormant) | 0 | You filled a notebook with sketches from the Titan lectures, noting how each kind moved. |
| 44–46 | An afternoon on the Wall | Instinct | Titan Reader or Hunter's Eye | 0 | On cannon drill atop an outer district's wall you watched a Titan wander the plain beyond it for an entire afternoon. |
| 51–53 | The falling Cadet | Agility | Wirework or Shoulder the Load | 0 | A Cadet's anchor tore loose in the forest exercise, and you reached them before they hit the ground. |
| 54–56 | The forced march | Strength | Strong Back or Long Haul (dormant) | +1 | You carried half your squad's gear on the final forced march. |
| 61–63 | The rescue drill | Strength | Pry Loose or Grip Breaker | +1 | In the rescue drill you pried a dummy loose from a mock Titan's grip before the whistle. |
| 64–66 | The runaway wagon | Agility | Rescue Ride or Horsemanship | -1 | You left formation to ride down a runaway supply wagon and were disciplined for it. |
<!-- END RENDERED: training-year-events year-3 -->

### The performance roll

The performance roll is an attribute roll made for the Action Catalog entry `performance-roll`.

- **Attribute:** the higher of the year's two `performance_attributes`. If they are equal, the player picks. Each of the six attributes is a performance attribute in exactly one Training Year.
- **Pool:** attribute dice only, with no Talent dice, Bonus Dice, Gear Dice, or Stress Dice. It cannot be Pushed or Helped. These exceptions are the `performance-roll` row under `roll_exceptions` in `data/core/dice-pool.yaml`.
- **Merit:** find the row of the table below that includes the roll's successes. It gives 0, 1, 2, or 3 Merit, and 3 for three or more successes.
- **No retry.** Each Training Year has exactly one performance roll. It can never be tried again (Chapter 1, section 1.1, item 4).

<!-- BEGIN RENDERED: performance-merit from data/character/training-years.yaml -->
| Performance roll successes | Merit |
|---|---|
| 0 | 0 |
| 1 | 1 |
| 2 | 2 |
| 3 or more | 3 |
<!-- END RENDERED: performance-merit -->

If the players voted to run the Graduation Exam, it replaces the third year's performance roll. The third year's event still happens (section 2.4).

> **Design note (OQ-21):** Performance rolls use the attribute alone and cannot be Pushed, so a Cadet's Merit reflects their attributes and their events rather than their Stress. The Cadet has no Stress to roll during the Lifepath anyway.

### 2.3.4 Graduation

Resolve Graduation in this order (`graduation` step in `data/character/lifepath.yaml`):

1. **Class Rank.** Add up the Merit from all three Training Years. Find the row of the Class Rank table below that includes the total, and record its Class Rank. Several graduates can share a Class Rank.
2. **Specialty.** The player chooses one of the nine Specialties (section 2.6). It is not rolled and has no requirement.
3. **Swap and floor.** Apply the swap and then the floor to the Specialty's key attribute (section 2.2).
4. **Top 10.** If the Class Rank row says Top 10:
   - The graduate is offered a place in the Military Police and declines it. Record "Declined the Military Police".
   - The key attribute gains 1, to a maximum of 6.
5. **Specialty Talent.** Gain 1 level in one Talent on the Specialty's list, to a maximum of level 2.

<!-- BEGIN RENDERED: class-rank from data/character/class-rank.yaml -->
| Merit total | Class Rank | Top 10 |
|---|---|---|
| 0 or less | 180 | no |
| 1 | 150 | no |
| 2 | 120 | no |
| 3 | 90 | no |
| 4 | 55 | no |
| 5 | 25 | no |
| 6 | 10 | yes |
| 7 | 7 | yes |
| 8 | 4 | yes |
| 9 | 2 | yes |
| 10 or more | 1 | yes |
<!-- END RENDERED: class-rank -->

> **Design note (OQ-21):** A Top 10 Class Rank needs a Merit total of 6 or more. In simulation that is about 6% of Cadets, and about 15% reach 5 or more. The events' `merit_change` values favour Strength and Perception events over Agility ones; that decides which Cadets reach the Top 10, not what any Specialty can hold, and it is accepted as written. The Military Police offer is always declined because the game is about the Survey Corps. The +1 to the key attribute gives the offer a mechanical reason to matter, and it is the only way to reach an attribute of 6. Class Rank has no other effect in the Phase 1 rules. The Rank and Commendations rules, not yet written, may use it.

### 2.3.5 Finishing the soldier and joining the Squad

1. **Derived values.** Record Health as a row of that many boxes, Resolve, Stress 0, and minimum Stress 0 (section 2.2).
2. **Rank.** Record Private.
3. **Harm.** Record Health lost 0, not Down, no Scars, Grief 0, and no Critical Injuries.
4. **Gear.** The soldier receives Standard Issue as Chapter 4 states.
5. **Name** the soldier.

Once every player character is finished:

6. **Starting Squadmates.** Create them as section 2.10 states.
7. **Named comrade.** Each player whose Drive needs a named comrade names one now: a living player character or Squadmate in the Squad, other than their own soldier.

---

## 2.4 The Graduation Exam (optional)

The Graduation Exam is the optional played prologue of three Trials whose Merit replaces the third Training Year's performance roll, and so helps decide each Cadet's Class Rank. It belongs in character creation because the glossary lists it with the Lifepath terms and it feeds Class Rank, which Graduation sets. `data/character/graduation-exam.yaml` holds the whole procedure.

### Using the Exam

- **The vote.** The players decide whether to run the Exam before the Lifepath begins (section 2.3, *Before the Lifepath*). If they run it, every Cadet being created at the same time takes it. A replacement character created later decides before rolling their own Lifepath, and takes the Exam alone (`use`).
- **When.** The Exam happens after every Cadet has applied their Year 3 event, and before Graduation.
- It **replaces the Year 3 performance roll.** The Merit from its three Trials is added to the Cadet's Merit total instead. The Year 3 event still happens.

### How the Exam is played

- **It is not a Titan Engagement.** It has no rounds, turns, Positions, Attention, or Titans. `requirements_ignored` lists the entry requirements that do not apply, such as those needing a Titan, a Position, a patient, a comrade with a Stress Response, or a worn item.
- **Exam issue.** Each Cadet uses training ODM Gear, a training Blade Set, a training medical kit, and a training tool kit, each with a Gear Dice rating of 1. There are no Gas Rolls and no Blade Set counting. Wear during the Exam applies during the Exam and has no effect after it.
- **Pools.** Every Trial roll uses the full Chapter 1 pool: attribute, one dice Talent that names the entry, Bonus Dice only from the squad field exercise's Help, Gear Dice from the listed exam issue item, and Stress Dice. Rule Talents that name the entry apply. Only the squad field exercise can be Pushed; the first two Trials forbid a Push by their own rule (Chapter 1, section 1.5).
- **Stress.** Every Cadet starts at Stress 0. Stress gained in one Trial stays for the later Trials and adds Stress Dice to their rolls. When the Exam ends, every Cadet's Stress returns to 0. This is the `graduation-exam-ends` row in `data/core/stress-changes.yaml`.
- **Stress Responses.** A Stress Response during the Exam still happens, and the roll cannot be Pushed after it. The Exam names its resolution, as Chapter 1 allows (section 1.5, *Finishing a roll*, step 2): it is not resolved on the Chapter 3 table, and instead costs the Cadet 1 Merit on the Trial whose roll caused it. Nothing else happens, and no Chapter 3 result arises during the Exam (`stress_responses`).
- **Order.** Every Cadet completes a Trial before the next Trial begins. Before each Trial, every Cadet taking the Exam rolls a D6, and they roll that Trial in descending order of result. Cadets tied for the same result roll again among themselves. The players do not choose the order (`roll_order_within_a_trial`).

### The three Trials

<!-- BEGIN RENDERED: graduation-exam-trials from data/character/graduation-exam.yaml -->
| Order | Trial | Action Catalog entry | Gear item | Can be Pushed | Help | Merit |
|---|---|---|---|---|---|---|
| 1 | The ODM balance test | Fly | training ODM Gear | no | none | 0–1 successes: 0 Merit; 2 or more successes: 1 Merit |
| 2 | The Titan dummy course | Nape strike | training Blade Set | no | none | 0–1 successes: 0 Merit; 2 or more successes: 1 Merit |
| 3 | The squad field exercise | one of the entry choices below | listed with each choice | yes | fixed by the Trial's roll order (see the list below) | 0–2 successes: 0 Merit; 3 or more successes: 1 Merit |

**The squad field exercise: entry choices** (each needs 3 successes)

| Entry | Gear item |
|---|---|
| Read | none |
| Break Attention | training ODM Gear |
| Body Part strike | training Blade Set |
| Treat Injury | training medical kit |
| Field Repair | training tool kit |
| Rally | none |
<!-- END RENDERED: graduation-exam-trials -->

The three Trials, with their Help and Cover rules:

1. **The ODM balance test:** a roll for `fly` with training ODM Gear. It pays 1 Merit at 2 or more successes and 0 otherwise. It cannot be Pushed, Helped, or Covered.
2. **The Titan dummy course:** a roll for `nape-strike` with a training Blade Set. It pays 1 Merit at 2 or more successes and 0 otherwise. It cannot be Pushed, Helped, or Covered.
3. **The squad field exercise:** each Cadet picks one entry from `entry_choice` and needs **3** successes for 1 Merit. It can be Pushed.
   - **Help is fixed.** Every Cadet taking the Exam, other than the roller, qualifies to Help each roll in this Trial (Chapter 1, section 1.8), but only one of them Helps it: the Cadet who rolls next in this Trial's order Helps the current roller, and the first roller Helps the last. Each Cadet Helps exactly one roll, declared before that roll, and that one Help is all it spends. A Cadet taking the Exam alone has no Help.
   - **Covering.** Every Cadet who qualifies to Help a roll can Cover its Push (Chapter 1, section 1.5), whether or not they Helped it, unless they hold the rolled state: a Cadet who has made their own roll in this Trial holds a state that forbids Covering for the rest of the Trial (`forbids: [cover]`), using Chapter 1's shared hook (section 1.9). So only a Cadet who has not yet made their own roll can Cover. Covering spends nothing.
   - Each Cadet's Merit comes only from their own roll. There is no bonus for the whole group succeeding.

> **Design note (OQ-22, OQ-37):** Trials 1 and 2 pay at 2 successes and forbid a Push, so they are solo tests of attribute, Talent, and gear; a Cadet at Stress 0 who cannot Push never has a Stress Response there. Trial 3 needs 3 successes with exactly one helper. In the payout model, the Year 3 performance roll pays a mean of 0.583 Merit, 2 or more Merit 10.5% of the time, and 3 or more 1.3%. The Exam with one cycle helper pays 0.612, 13.4%, and 1.1%, and a Cadet taking it alone pays 0.506, 10.8%, and 0.8%. Three free helpers on Trial 3 would pay 0.803, which is why Help is fixed at one. The vote before the Lifepath, the rolled order, and cycle Help leave no Exam choice made with Merit known; a rolled order with cycle Help measured a Top 10 share of 6.48% against 6.20% for four Cadets.
>
> **Simulator target:** mean Exam Merit within 0.1 of the Year 3 performance roll it replaces, and the Top 10 share with the Exam within 0.3 points of the share without it, for 1 to 6 Cadets, under the aimed policy of Chapter 2 review 3, with every Cadet who has not yet rolled able to Cover. If the target fails, tune first the successes Trial 3 needs, then the threshold of Trials 1 and 2 (2, then 3).

---

## 2.5 Drives

A Drive is what keeps a soldier fighting. It lets them shrug off one Fear Roll result per session while its trigger is met by their own act, a Position they moved into, or their own ODM flight. Every Drive is written as a trigger beginning "When I ..." (ADR-0003, item 3). Each Drive is a row of the Why You Enlisted table (section 2.3.2), and the rules they share are in `data/character/enlistment.yaml` (`drive_rules`).

### Using a Drive

1. A Fear Roll result (Chapter 3) is about to take effect on the soldier.
2. The player checks whether the soldier's Drive trigger is met, using the trigger's `test` and `target` (see below).
3. If it is met and the Drive has not been used this session, the player may **shrug off** the result: it does not take effect. Chapter 3 states what counts as a Fear Roll's result.
4. A Drive can shrug off one Fear Roll result per session. Record on the sheet when it has been used.

### Trigger tests

Every trigger is met by something the soldier did, or by where the soldier has put themselves. Each Drive's `test` says how to check it:

- **`own_state`:** the trigger names Positions the soldier holds, or the soldier's own flight on ODM Gear, such as "When I am airborne on ODM Gear through my own ODM use". It is met if that state is true when the result is about to take effect.
  - A Position counts only if the soldier's own move put them in it: their most recent change of Position was a move they made. A Position the soldier was placed at when the Titan Engagement began, or by any rule other than their own move, does not count until their own move changes it. A Grab counts as a change of Position made by another rule, even when the soldier's Position stays On Body (Chapter 5, section 5.9, `data/engagement/grab.yaml`, `grabbed_state`).
  - Flight counts only through the soldier's own ODM use. A soldier carried by a comrade is not airborne on their own ODM Gear. Chapter 4 defines airborne.
  - The test never names a Focus Titan's Attention, a comrade's state, a Titan's Body Parts, or the soldier's Stress, Grief, or injuries.
- **`most_recent_turn`:** the trigger names acts. It is met if the soldier took one of them on their most recent turn in the current Titan Engagement, whether that turn came earlier this round or in an earlier round.
- **`since_most_recent_turn_start`:** the trigger names acts. It is met if the soldier took or used one of them at any time from the start of their most recent turn in the current Titan Engagement until now, on that turn or outside it. This reaches Help, Cover, a dodge, and a Push made on a comrade's turn.

The two turn tests are never met before the soldier's first turn in a Titan Engagement. Outside a Titan Engagement they are never met, unless a later rule that gives soldiers turns there, such as the Chase rules, states that these tests count those turns (`outside_titan_engagement`). A Position exists only in a Titan Engagement, so an `own_state` Position trigger is met only there. An `own_state` flight trigger can be met anywhere.

**Acts** are Action Catalog entries, plus `push`, which means Pushing a roll (Chapter 1, section 1.5).

**Targets.** A Drive's `target` says whom an act must be used on:

- **`any`:** the act counts whoever it was used on.
- **`named_comrade`:** only an act used on the soldier's named comrade counts: Help to their roll, Cover of their Push, or an entry taken on them.
- **`grabbed_or_down_comrade`:** an act counts only if it was used on a comrade who was Grabbed or Down when the act was used, or who is Grabbed or Down when the Fear Roll result is about to take effect. The act must already have been used; an intention to act later never counts. `drive_rules.targets` lists which uses qualify, including a Body Part strike against the hand that holds a Grabbed comrade.

### Named comrades and replacing a Drive

- A named comrade is a living player character or Squadmate in the Squad, other than the soldier.
- A Drive recorded when the Squad forms names its comrade then (section 2.3.5). A Drive recorded later names its comrade when it is recorded: a replacement Drive, a promoted Squadmate's Drive, or a new character's Drive.
- If no other living soldier is in the Squad when a Drive that needs a named comrade would be recorded, the player records instead the Drive of a row whose Drive does not need one.
- If a Drive's named comrade dies, retires, or leaves the Squad, the Drive can never trigger again. **Promotion does not make a soldier leave the Squad**, so a Squadmate who is promoted stays the named comrade.
- At the start of the next session after a Drive can no longer trigger, the player picks a new Drive from any row of the Why You Enlisted table. No attribute point is gained (ADR-0011).

> **Design note (OQ-23):** The timing (checked when the result is about to take effect), the three trigger tests with their acts and targets, the rule that a Position counts only if the soldier moved into it, the per-session count, the named-comrade and replacement rules, and a rolled attribute point with a Drive the player may take from any row make "while acting on it" a test the table can check without a judgment call. Pay It Forward also counts a comrade who is Grabbed or Down when the result is about to take effect, so a soldier who has already been looking after a comrade can shrug off the Fear Roll that begins that comrade's rescue.

> **Design note (OQ-36):** Position triggers need a Titan Engagement. Turn triggers work outside one only when a rule that gives soldiers turns there, such as the Chase rules, extends them. Freedom's own-flight trigger can be met anywhere. So until a later rule extends them, 11 of the 12 Drives can be met only in a Titan Engagement.

---

## 2.6 Specialties

A Specialty is a soldier's trained specialization. The table below gives each of the nine Specialties its key attribute, a summary, and a list of four Talents.

<!-- BEGIN RENDERED: specialties from data/character/specialties.yaml -->
| Specialty | Key attribute | Summary | Talent list |
|---|---|---|---|
| Slayer | Strength | Trained to finish the job. Slayers make the Nape strike and cut the Body Parts that set it up. | Clean Cut, Hamstringer, Relentless, Blade Discipline |
| Flier | Agility | The best on the wires. Fliers reach the hard Positions, dodge what others cannot, and make a canister last. | Slip Away, Wirework, Light Trigger, Well-Kept Rig |
| Hunter | Perception | Patient and sharp-eyed. Hunters turn a Titan's head with a decoy and spot danger first. | Lure, Keen Eyes (dormant), Hunter's Eye, Fieldcraft (dormant) |
| Tactician | Instinct | Reads the Titan and the field. Tacticians learn a Titan's Next Behavior and put the Squad where it can help. | Titan Reader, Sharp Call, Wide Awareness, Judge of Character (dormant) |
| Leader | Empathy | The voice that keeps soldiers in the fight. Leaders Rally, steady nerves, and take on others' Stress. | Steady Voice, Unshaken Command, Carrying Voice, Shoulder the Load |
| Medic | Wits | Keeps the injured alive long enough to get them home. | Field Medicine, Careful Nursing, Sure Hands, Book Learning (dormant) |
| Engineer | Wits | Keeps ODM Gear flying and repairs it in the field. | Gearwright, Make Do, Quick Refit, Well-Kept Rig |
| Rider | Agility | At home in the saddle. Riders use the horse as a decoy, a shield, and a way to carry the fallen out. | Horsemanship, Loose the Horse, Sure Seat, Rescue Ride |
| Brawler | Strength | Hard to hold and hard to kill. Brawlers tear free of a Titan's grip and drag comrades out with them. | Grip Breaker, Pry Loose, Strong Back, Hard to Kill |
<!-- END RENDERED: specialties -->

- **Choosing.** The player chooses a Specialty at Graduation (section 2.3.4). It is not rolled, has no requirement, and never changes.
- **What it grants:**
  - The key attribute. It is the only attribute that can be rated 6.
  - At Graduation, the swap and floor, which give the key attribute the soldier's highest rating, and at least 4, without adding points (section 2.2).
  - At Graduation, 1 level in one Talent on the Specialty's list, to a maximum of level 2.
- **What it never grants is permission.** Every soldier, player character or Squadmate, can attempt every Action Catalog entry, and any soldier can hold any Talent, including one on another Specialty's list (ADR-0006). A soldier without the right Talent still rolls their full attribute. The Squadmate rules still apply whatever the Specialty: a Squadmate never Pushes or Covers, and its only Reaction is the dodge (section 2.10).
- **The Talent list** limits only the Talent level gained at Graduation. The XP rules, not yet written, state whether it matters when a soldier buys Talents later.

A Specialty grants nothing beyond the key attribute, the swap and floor, and one Talent level. Separately, through Standard Issue (Chapter 4), a Medic also receives a medical kit and an Engineer a tool kit (`by_specialty` in `data/gear/standard-issue.yaml`; OQ-28, OQ-59).

## 2.7 Talents

A Talent is a narrow trained ability that adds dice or bends a rule, but only for the Action Catalog entries it names. The Phase 1 list is in Appendix 2A: [2A.1 Dice Talents](#2a1-dice-talents) and [2A.2 Rule Talents](#2a2-rule-talents). For each Talent it gives a `description` for players, its type, `max_level`, the entries it `names`, any `condition` on one of them, and its Specialty lists. A rule Talent also has a `trigger`, an `effect`, and a `limit`. The description only summarizes; the other fields are the rule.

### Levels

- Talents run from level 0 to level 3. No Talent can be above level 2 at creation.
- A rule Talent has a `max_level` of 1 unless its row says otherwise. Holding it at level 1 means having it.

### Dice Talents

- A dice Talent adds base dice equal to its level to a roll made for one of the entries it names (Chapter 1, section 1.3, step 3). If its row gives a `condition` for that entry, it adds them only to a roll that meets the condition: Horsemanship adds its dice to a dodge only when the dodge is made mounted, with the horse as its gear item (decision batch 5, OQ-121).
- **A roll uses at most one dice Talent.** If more than one qualifies, the roller picks one.
- A dice Talent can name only entries whose `kind` is `action`, `reaction`, or `roll` (section 2.8). Only those are attribute rolls.
- A Talent that does not name the roll's entry adds no dice, however close the action seems. Section 2.9 decides which entry an unusual action is.
- A Talent whose named entries are all dormant or reserved does nothing until a rule calls for one of them (`dormant_talents`).

### Rule Talents

- A rule Talent applies its `effect` every time its `trigger` occurs, subject to its `limit`.
- **Declared triggers.** A trigger that begins "You declare" is met when the soldier declares that they take, make, or use the named entry, before its requirements, targets, pool, and cost are checked. The effect changes those checks for that use. If the use still does not qualify, it is not taken and nothing is spent. Every other trigger is met when the event it describes happens (`trigger_timing`).
- Rule Talents stack with each other and with the roll's dice Talent.
- **Once per Titan Engagement** means once between the start and end of each Titan Engagement, and never outside one, unless a later rule that creates another procedure with a start and an end, such as a Chase, states that this limit applies to it (`limit_terms`, OQ-36).
- A rule Talent changes only what its effect states. Unless its effect says so, it does not add Bonus Dice, change Stress, or make a roll that its trigger does not call for.
- Several rule Talents change a value that a later chapter sets, such as a Position requirement for Rally (Chapter 3) or what changing a canister spends (Chapter 4). They apply to whatever that chapter sets.

A rule Talent that changes who qualifies for an entry, its target, its attribute, its gear item, or its cost uses a "You declare" trigger, so it applies before those checks rather than after them (OQ-34).

### Gaining Talents

- **At creation:** 5 levels in total (section 2.3.3).
- **After creation:** through XP and the Train Downtime Action (ADR-0011). Those rules are not yet written.

> **Design note (OQ-28):** The list has 40 Talents (20 dice, 20 rule), rule Talents are usually single-level, and each rule Talent has a closed trigger. **Relentless** gives a Nape strike that falls short with at least 1 success 1 extra Opening instead of a second Push, so it feeds the next striker and leaves a soldier's first solo Nape strike at ADR-0014's targets. **Sure Seat** gives the Rider the relationship to the horse that Well-Kept Rig gives the Flier and Engineer to ODM Gear: it ignores 1 point of horse wear from a Pushed dodge, Ride, or Break Attention, once per Titan Engagement. Every mounted soldier's dodge can already use the horse (ADR-0015, as amended), so no Talent is needed to make it, and Horsemanship adds its dice to it (decision batch 5, OQ-121), and Sure Seat needs no simulator check. Its limit is once per Titan Engagement, so it never applies outside one until the Chase or Expedition rules state that the limit extends to their procedures (OQ-36). Eight Talents need a simulator check: **Relentless** against the prepared Squad target and against a lone soldier's follow-up strike; **Light Trigger** against the gas target, which is why it is limited to once per Titan Engagement; **Wide Awareness** and **Shoulder the Load**, which extend Help and Covering to two Position steps; **Sure Hands** and **Hard to Kill** against the player character death target; **Pry Loose** against the Grab target; and **Unshaken Command** against Fear Roll outcomes.

## 2.8 The Action Catalog

The Action Catalog is the complete list of named actions and rolls a soldier can make, and the list Talents name. Its entries are in Appendix 2A: [2A.3 Action Catalog entries](#2a3-action-catalog-entries), [2A.4 What each entry requires and changes](#2a4-what-each-entry-requires-and-changes), and [2A.5 Tracked values](#2a5-tracked-values). Every attribute roll is made for one Catalog entry (Chapter 1, section 1.3, step 1).

### What an entry states

| Field | Meaning |
|---|---|
| `kind` | `action`: taken as a soldier's action in a Titan Engagement. `reaction`: made when an enemy acts against the soldier, outside the soldier's own turn, spending a turn (Chapter 1, section 1.9). `roll`: an attribute roll made when a rule calls for it, not an action. `option`: a use of another entry or rule, not an action and not a roll. `fixed-roll`: a roll that is not an attribute roll, which only rule Talents can name. |
| `rolled` | `when_taken`, `when_a_rule_calls`, or `never`. |
| `attribute` | The attribute the roll uses. `from_performance_attributes` means the Training Year's performance attributes decide it. |
| `gear` | The gear items (Chapter 4) that can supply Gear Dice. The roller picks one if more than one qualifies. |
| `requires_gear`, `without_gear` | Whether the entry needs one of its gear items, and what happens without one (see *Entries that need gear*). |
| `context` | Where the entry is used: `titan-engagement`, `any`, or `lifepath`. |
| `requirements`, `needs` | What the soldier must meet, and how many successes the roll needs. Many of these point to the owning chapter. |
| `changes` | The tracked values the entry can change (section 2.9). |
| `help_outside_titan_engagement` | The Help requirement Chapter 1 asks every roll outside a Titan Engagement to state (section 1.8, OQ-08). |
| `rules` | The chapter that owns the entry's procedure and full effect. |
| `reserved` | The entry exists for enemies that later rules add. No Phase 1 rule uses it. |
| `dormant` | No current rule calls for the entry. The rule that later calls for it may change its attribute. |

### Entries that need gear

This rule (`gear_requirement`) applies every time an entry is taken, made, or called for: whether the player names the entry or reaches it through section 2.9, and whether the soldier is a player character or a Squadmate.

- If an entry has `requires_gear: true` and the soldier has none of its gear items, apply its `without_gear` value. An item worn down to 0 counts as not had (Chapter 1, section 1.3, step 6; for ODM Gear, a Jam), and so does an item in any other state a Chapter 4 rule names as counting as not had:
  - `attribute_alone`: roll the entry's attribute with no Talent dice and no Gear Dice. Everything else about the entry still applies. Only a rule Talent that names this case changes it (Make Do).
  - `not_possible`: the entry cannot be taken, made, or used.
- An entry with `requires_gear: false` and no gear item available is rolled without Gear Dice (Chapter 1, section 1.3, step 6).

For example, a soldier whose last Blade Set is gone cannot make a Nape strike, however the player describes it. A soldier with no medical kit who takes Treat Injury rolls Wits alone.

### How far this chapter defines an entry

Entries owned by later chapters are defined here only as far as a Talent needs to name them and a pool needs to be built: kind, attribute, gear, and what they can change. The owning chapter gives the procedure, the successes needed where the entry says "set by Chapter N", and the full effect. Where a Chapter 5 entry names a requirement that ADRs already settle, the entry states it: a Nape strike only from Blind Spot and never by the soldier holding Attention (ADR-0010), and a dodge against a behavior's Severity (ADR-0015). Chapter 4 adds that, in a Titan Engagement, a Nape strike, and a Body Part strike made from On Body or Blind Spot, needs ODM Gear that counts as had (`strikes` in `data/gear/odm-gear.yaml`; OQ-60), unless the Titan is grounded (Chapter 5, `grounded` in `data/engagement/titan-harm.yaml`).

The attribute and gear assignments for Titan Engagement entries are (OQ-25):

- Nape strike and Body Part strike: Strength, with a Blade Set.
- Break Attention: Perception, with ODM Gear or a horse.
- Read: Instinct, with no gear.
- Break Free: Strength, with a Blade Set if the soldier has one.
- Draw Attention: not rolled.
- Fly (ODM Gear): an Agility roll a Chapter 4 or Chapter 5 rule calls for, not an action.
- Ride (horse): an Agility roll, not an action, dormant until the Chase rules call for it (decision batch 5, OQ-121).
- Dodge: Agility, with ODM Gear, or with the horse while the soldier is mounted (ADR-0015, as amended). When a dodge made with the horse is Pushed, its Gear Dice showing 1 wear the horse, not ODM Gear, and it does not by itself make the Gas Roll three dice. Chapter 4 defines mounted.

The Catalog has entries that are not attribute rolls, so that rule Talents can name them: Help and Draw Attention (unrolled actions), Cover and Call It (options), and the Fear Roll, Stress Response roll, and Gas Roll (fixed rolls). This extends OQ-11, which added the dodge, block, and Death Roll entries (OQ-26).

### Groups of entries

- **Titan Engagement actions:** `nape-strike`, `body-part-strike`, `break-attention`, `draw-attention`, `read`, and `break-free`. `call-it` is an option of `read`.
- **Actions used in and out of a Titan Engagement:** `lift-comrade`, `change-canister`, `pass-item`, and `take-item`, and also `treat-injury`, `rally`, and `field-repair`, listed below with harm, gear, and mind.
- **Options Chapter 4 adds:** `mount-or-dismount` (part of a move), `swap-blade-set` and `shed-load` (parts of a soldier's turn), and `restock-medical-kit` (part of a care window). Outside a Titan Engagement, where there are no moves or turns, each is used as its Chapter 4 row states.
- **Options Chapter 5 adds:** `swap-initiative-card` (part of a round's swap step; section 5.3, `data/engagement/round.yaml`, `swapping`) and `squad-tactic` (using a Squad Tactic the Squad holds; section 5.12, `data/engagement/squad-tactics.yaml`).
- **Core entries:** `help` (an action) and `cover` (an option), both defined in Chapter 1.
- **Reactions:** `dodge`. `block` is reserved.
- **Harm, gear, and mind:** `treat-injury`, `rally`, `field-repair`, `fly`, and `death-roll`. The fixed rolls are `fear-roll`, `stress-response-roll`, and `gas-roll`.
- **Reserved human-scale action:** `fight`.
- **Dormant rolls:** `spot`, `size-up`, `survive`, `persuade`, `endure`, `sneak`, `recall`, and `ride` (decision batch 5, OQ-121). No current rule calls for these. They exist so the rules for Expeditions, Downtime, and Chases have entries to call, and those rules may change their attributes. Each such rule states its roll's effect and its Help requirement.
- **Lifepath:** `performance-roll` (section 2.3.3).

## 2.9 Actions outside the Catalog

A player may describe an action that has no Catalog entry. Under ADR-0003 item 9, such an action changes only a tracked value: it uses a Catalog entry that changes the value the player names, or, for a value whose creating rule names an attribute roll, that attribute alone. An action that changes no tracked value has no mechanical effect. `uncatalogued_actions` in `data/character/action-catalog.yaml` gives the procedure. Follow its steps in order:

1. **Name the change.** The player names the one tracked value ([2A.5 Tracked values](#2a5-tracked-values)) the action is meant to change. The description of the action never limits which value the player names; the named value alone decides which entries can be used. If it is meant to change none of them, the action needs no roll and has no mechanical effect. Stop.
2. **Moves.** If the value is changing Position, the action is a move, resolved by Chapter 5 (section 5.2). Stop.
3. **Match.** List every entry whose `changes` include that value. If the soldier meets the requirements of at least one of them, the player picks one. **The action is that entry for every purpose:** its kind, attribute, gear items, successes needed, effect, what it spends, and every Talent that names it.
4. **Gear.** Apply *Entries that need gear* (section 2.8) to the picked entry, as for any entry. An entry that is `not_possible` for the soldier cannot be used.
5. **No match.** If no listed entry can be used:
   - If the value is a `rule-named-value`, make the attribute roll that the value's creating rule names, using the attribute alone (see *Rolls called by attribute*).
   - Otherwise the action cannot change that value. It needs no roll and has no mechanical effect.

**Rule-named values.** A later rule that creates a clock, counter, or obstacle soldiers can change by acting, such as an Operation Frame's clock or a hazard, either adds it to `tracked_values` with the entries that change it, or creates it as a `rule-named-value` and names the attribute roll that changes it. No Phase 1 rule creates one yet.

**Rolls called by attribute.** A rule that calls for an attribute roll without naming a Catalog entry calls for that attribute alone: no Talent dice, and Gear Dice only from a gear item that rule names. Every other step of Chapter 1, section 1.3, applies, and the rule states its Help requirement.

**No rulings.** The GM does not decide whether an action is possible, which entry it uses, or what it changes. The steps decide. Anything a soldier does that changes no tracked value is described freely and has no mechanical effect.

For example:

- A soldier wants to bind a comrade's Critical Injury with a torn cloak. The value is "treat or stabilize a Critical Injury", the entry is `treat-injury`, and the soldier has no medical kit, so they roll Wits alone.
- A soldier wants to shout so a comrade can avoid a Titan's hand. If the player names "add dice to a comrade's Reaction", the only entry that changes it is `call-it`, which needs successes from a Read. With no Read to spend, it cannot be used, and the shout has no mechanical effect. If the player names "add a die to a comrade's roll" instead, the entry is `help`, and the shout is Help, with Help's requirements and what it spends (Chapter 1, section 1.8).
- A soldier wants to calm themselves with a prayer. No entry lowers the soldier's own Stress, so the prayer has no mechanical effect.

> **Design note (OQ-27, OQ-35):** The procedure is ADR-0003 item 9: matching by a closed list of tracked values, the player choosing between qualifying entries, the gear rule applied to every use of an entry, the route to the attribute alone through rule-named values, and "no match means no effect". ADR-0003 item 12 requires every rule that creates a value soldiers change by acting to add it to the tracked values. Chapter 4 adds the tracked values `item-give`, `item-take`, `mount-change`, `blade-set-swap`, and `load-shed`, with the unrolled actions `pass-item` (giving a carried item to a comrade) and `take-item` (taking an item from a Down comrade, or from where a dead comrade's items lie) and the options `mount-or-dismount` (at the soldier's Position as part of a move, with no roll), `swap-blade-set`, `shed-load`, and `restock-medical-kit`. Chapter 5 adds the tracked values `initiative-swap` and `squad-tactic-use`, with the options `swap-initiative-card` (exchanging initiative cards with a comrade, section 5.3) and `squad-tactic` (using a Squad Tactic, section 5.12). Character creation itself has no act a soldier changes a tracked value with: the performance roll and the Graduation Exam's Trial rolls are rolls their own rules call for, made for Catalog entries and paying Merit by those rules, and every other Lifepath step is a table roll, a record, or a choice.

---

## 2.10 Squadmates

A Squadmate is a named NPC soldier who rides into the field with the player characters. Any player can direct a Squadmate, Titans can target it like anyone else, and it can be promoted to a player character. The Squadmates currently serving are the Squad Pool. `data/character/squadmates.yaml` holds everything in this section.

### The stat block

- A Squadmate is built from one of nine `templates`, one per Specialty. Its key attribute is 4, four other attributes are 3, and one is 2, for 18 points: the total of a new player character without a Top 10 Class Rank. It has one dice Talent at level 1. Its attributes follow ADR-0014's Rookie build, with Health 3 or 4 by template. The simulator's reference Rookie has the Slayer template's attributes (Strength 4, Agility 3, Wits 2, and 3 elsewhere; Health 4, Resolve 3), and Talent 1 in the Talent that names the Nape strike, the Body Part strike, Break Free, or Treat Injury. No other roll a target measures carries Talent dice, including the dodge, Fly, Break Attention, Ride, and Read. It is not the Slayer template itself, whose one Talent names only the Nape strike (ADR-0014 as amended; OQ-58, OQ-70; decision batch 2b; OQ-94). The reference Veteran is Strength 5, Agility 3, Wits 2, and 3 elsewhere (OQ-71). Targets that depend on Health are also reported for the reference Squad with each soldier's Health set to 3 and nothing else changed, and the Talent-dependent targets for a Squad built literally from these templates (Chapter 3, section 3.2).
- `stat_block.fields` lists what a Squadmate records: name, Specialty, attributes, Talent, Health (a row of boxes, 3 or 4 on the templates) and Health lost to damage, Resolve, Stress, minimum Stress, Scars, Grief, Critical Injuries, whether it is Down, its gear, its Wing, and the Chapter 3 fields in `data/harm/sheet-fields.yaml`. A Squadmate's boxes crossed off are the untreated entries in its Critical Injuries, as for a player character (Chapter 3).
- `stat_block.not_recorded` lists what it does not record: Origin, Haven, Drive, Canon Tie, Merit, Class Rank, and XP.
- **Gear.** A Squadmate receives Standard Issue and records its gear exactly as a player character does, including Gas Rating, spare canisters, Blade Sets, carried items, and Gear Dice ratings (Chapter 4). A rating changes only when a rule names a change. A Squadmate never Pushes, so Push wear never lowers its ratings.

<!-- BEGIN RENDERED: squadmate-templates from data/character/squadmates.yaml -->
| Template | Strength | Agility | Wits | Perception | Instinct | Empathy | Talent | Health | Resolve |
|---|---|---|---|---|---|---|---|---|---|
| Slayer | 4 | 3 | 2 | 3 | 3 | 3 | Clean Cut 1 | 4 | 3 |
| Flier | 3 | 4 | 2 | 3 | 3 | 3 | Slip Away 1 | 4 | 3 |
| Hunter | 3 | 3 | 3 | 4 | 3 | 2 | Lure 1 | 3 | 3 |
| Tactician | 3 | 2 | 3 | 3 | 4 | 3 | Titan Reader 1 | 3 | 4 |
| Leader | 3 | 2 | 3 | 3 | 3 | 4 | Steady Voice 1 | 3 | 4 |
| Medic | 3 | 2 | 4 | 3 | 3 | 3 | Field Medicine 1 | 3 | 3 |
| Engineer | 3 | 3 | 4 | 3 | 3 | 2 | Gearwright 1 | 3 | 3 |
| Rider | 3 | 4 | 2 | 3 | 3 | 3 | Horsemanship 1 | 4 | 3 |
| Brawler | 4 | 3 | 2 | 3 | 3 | 3 | Grip Breaker 1 | 4 | 3 |
<!-- END RENDERED: squadmate-templates -->

### Which rules apply

`rules_applicability`, rendered after this list, gives each rule and whether it applies to a Squadmate. This settles the questions Chapter 1 (section 1.10, OQ-13) left to this chapter:

- A Squadmate **rolls Stress Dice** and suffers Stress Responses.
- A Squadmate **never Pushes** and **never Covers**.
- A Squadmate **can Help**, because Help is on its action list, and can be Helped.
- It loses Stress through the two field relief triggers (Chapter 1, OQ-13).
- It makes Reactions and Fear Rolls, and suffers damage, Critical Injuries, Down, Death Rolls, Scars, Retirement, and Grief (Chapter 3).
- It makes **Gas Rolls**, always of two dice because it never Pushes, counts Blade Sets and carried items, and can be Overloaded (Chapter 4).
- It has no Drive.
- No current rule gives a Squadmate XP, Talent levels, or Downtime Actions. The XP and Downtime rules, not yet written, decide these.

<!-- BEGIN RENDERED: squadmate-rules from data/character/squadmates.yaml -->
| Rule | Applies to a Squadmate | Chapter | Note |
|---|---|---|---|
| attribute rolls and dice pools | yes | Chapter 1 | — |
| Stress Dice | yes | Chapter 1 | — |
| Stress Responses | yes | Chapter 3 | — |
| Push | no | — | A Squadmate never Pushes. |
| Help (as helper) | yes | — | Help is on the action list. |
| Help (as roller) | yes | — | — |
| Cover (as the Covering soldier) | no | — | — |
| Cover (as the Pushing soldier) | no | — | A Squadmate never Pushes, so there is no Push to Cover. |
| field Stress relief (end of Titan Engagement and Nape kill) | yes | Chapter 1 | — |
| Reactions | yes | Chapter 1 | — |
| Fear Rolls | yes | Chapter 3 | — |
| Health, Critical Injuries, Down, and Death Rolls | yes | Chapter 3 | — |
| Scars and Retirement | yes | Chapter 3 | — |
| Grief | yes | Chapter 3 | — |
| Drive | no | — | — |
| Gas Rolls | yes | Chapter 4 | Always two dice, because a Squadmate never Pushes. |
| Blade Sets, carried items, and Overloaded | yes | Chapter 4 | — |
| Talent dice and rule Talents | yes | — | Only the template Talent. |
| XP and gaining Talents | set by the XP rules (not yet written) | — | No current rule gives a Squadmate XP or Talent levels. |
| Downtime Actions | set by the Downtime rules (not yet written) | — | No current rule gives a Squadmate a Downtime Action. |
<!-- END RENDERED: squadmate-rules -->

> **Design note (OQ-29, OQ-58, OQ-70):** The template build has the attributes of ADR-0014's Rookie, as amended, and the Slayer template's attributes are the reference Rookie's (OQ-58, OQ-70). The reference Rookie has Talent 1 in the Talent that names the Nape strike, the Body Part strike, Break Free, or Treat Injury (decision batch 2b), and no other roll a target measures carries Talent dice, including the dodge, Fly, Break Attention, Ride, and Read (OQ-94). So a Squad built from the templates is reported beside it for the Talent-dependent targets, and the Flier template's dodge is reported alone. A Squadmate never Covers, which answers the Covering sponge concern in OQ-06. Full gear tracking makes a Squadmate's ODM use spend gas as a player character's does. A Squadmate never Pushes, so its gear never wears, its ODM Gear never Jams from wear, and its Blade Sets are never ruined; Chapter 4 gives a one-line Squad sheet row for a Squadmate's gear so six fully tracked soldiers stay playable. A Squadmate can take every action a player character can.

### Actions

- A Squadmate can take **every Action Catalog entry a player character can take as an action**, including Help, and every option of those entries, such as Call It. It must meet each entry's requirements, as a player character must. Its Specialty never limits what it can attempt (section 2.6).
- It uses section 2.9 for actions outside the Catalog, exactly as a player character does.
- It can dodge, and it makes any roll a rule calls for, such as `fly`, `ride`, or `death-roll`.
- A Squadmate's own Reaction spends its own turn under Chapter 1, section 1.9 (OQ-09). On a Wing, that is the turn it takes right after its player character's turn.

### Wings (summary)

Chapter 5 gives the full procedure for Wings in a Titan Engagement (section 5.3). The `wing` block states the parts creation needs:

- During a Titan Engagement, a Squadmate can be attached to one player character's Wing.
- It acts **right after that player character's turn**, with one move and one action.
- If the player character's turn has no move and no action because a Reaction or a result spent it in advance (Chapter 1, section 1.9), the Squadmate still acts right after that turn.
- A Wing holds at most one Squadmate.
- Chapter 5 sets when Squadmates are assigned to Wings and what a Squadmate on no Wing does (section 5.3, `data/engagement/round.yaml`, `wings`).

**Directing a Squadmate:**

- Any player can propose what a Squadmate does.
- If players disagree about a Squadmate on a Wing, the player whose character's Wing it is decides.
- If players disagree about a Squadmate on no Wing, each proposed choice is rolled for once, with a D6 rolled by one player who proposed it. The highest roll decides, and choices tied for highest roll again.
- The GM never directs a Squadmate.

> **Design note (OQ-30):** One Squadmate per Wing, a Squadmate acting after a turn spent in advance, the rules for directing Squadmates, and the D6 roll-off for every choice the players share keep the GM out of every Squadmate decision.

### The starting Squad

- The Squad aims for 6 soldiers. The Rank rules, not yet written, may change that number.
- **Starting Squadmates = 6 minus the number of player characters, minimum 0.** Four player characters start with two Squadmates, which matches ADR-0014's default Squad.
- The players choose a template for each starting Squadmate, name it, and give it Standard Issue. It starts with Health lost 0, not Down, Stress 0, and no Scars, Grief, or Critical Injuries.

### Promotion

`promotion` gives the procedure for replacing a player character who dies or retires:

1. **When:** when the procedure in which the death or Retirement happened ends, exactly as Retirement is timed (Chapter 3, section 3.13): the last end step of a Titan Engagement, the last step of a day passing, the end of an outside-harm care window and its Death Rolls, or the end of any other procedure as its rule states. Promotion happens at once only if no procedure is under way (`promotion.timing`, OQ-31).
2. **Who chooses** (`promotion.contested`, OQ-38):
   - First, every soldier due to retire at that moment retires, and a retiring Squadmate leaves the Squad Pool.
   - Every player whose character died or retired chooses a living Squadmate in the Squad Pool, all at the same time.
   - If two or more choose the same Squadmate, each of them rolls a D6. The highest takes it, and ties roll again.
   - Every player who loses chooses again from the living Squadmates no player has taken, repeating the roll for any Squadmate chosen by more than one of them, until every player has a Squadmate or none is left. A player with none left follows step 4.
   - Promotions fall due together whenever step 1 resolves them at the same moment.
3. **Conversion:** follow `promotion.steps`.
   - The soldier keeps everything it has, in its current state: attributes, Talent, Health and the Health it has lost to damage, Resolve, Stress, Scars, Grief, Critical Injuries, Down state, gear, and every field in `data/harm/sheet-fields.yaml`. Nothing is recalculated, and attributes never rise (ADR-0011).
   - Its template Talent counts as the Talent level a new soldier gains from the Specialty.
   - It rolls an Origin for a Haven and an optional Canon Tie, and gains 1 level in one of the row's two Talents, following the same caps. A Talent it already holds, such as its template Talent, rises by 1 level.
   - It rolls Why You Enlisted for a Drive, as a new soldier does, and names a comrade now if the Drive needs one.
   - It rolls once on each Training Year's events and gains 1 level in one of each event's two Talents, following the same caps and fallback. This gives it 5 Talent levels in total, from the same sources as a new soldier.
   - It gains no attribute points and no Merit. It records Merit and Class Rank as none, and Rank as Private.
   - It follows every player character rule from then on, leaves any Wing, and is no longer a Squadmate. It stays in the Squad.
4. **No Squadmate available:** the player creates a new character with the Lifepath. Until the rules for joining the Squad mid-campaign are written, the new character joins at the start of the next session.

> **Design note (OQ-31, OQ-38):** Promotion shares Retirement's timing, so a player character who dies partway through a procedure and one who retires at its end are replaced at the same moment, and no promotion interrupts a procedure. The contest changes nothing when no Squadmate is contested, and uses the roll-off every other shared choice uses. The conversion keeps the Squadmate's current state and takes its 4 new Talent levels from the Lifepath's rolled sources; it is also how a promoted Squadmate gains a Drive.

---

## Example: creating a soldier

*The rolls and row values below follow the YAML files at the time of writing. If the files change, the files govern.*

Mira's player rolls her Lifepath.

- **Before the Lifepath.** The players record Campaign Year 846 and vote not to run the Graduation Exam.
- **Start.** Every attribute is 2.
- **Origin.** The roll of 25 gives Wall Rose Farm. Strength and Perception go to 3. She takes level 1 in Horsemanship and records the family farm as her Haven.
- **Why You Enlisted.** The roll of 42 gives the row about protecting the people inside the Walls. Strength goes to 4. Her player keeps the rolled row's Drive, Shield the Walls: "When I took Draw Attention on my most recent turn."
- **First Year.**
  - The event roll of 44 gives Fire in the stables. Perception goes to 4, and her Merit is 1. Her player takes Keen Eyes 1 for the story, knowing it names the dormant `spot` entry. Horsemanship was the other choice.
  - The performance attributes are Strength (4) and Instinct (2), so she rolls 4 dice. One success adds 1 Merit, for 2.
- **Second Year.**
  - The event roll of 13 gives The wooden nape. Strength goes to 5, she takes Clean Cut 1, and Merit rises by 2, to 4.
  - The performance attributes are Agility (2) and Perception (4), so she rolls 4 dice. One success brings Merit to 5.
- **Third Year.** The players voted not to run the Graduation Exam, so Mira makes the Year 3 performance roll.
  - The event roll of 34 gives Arguing with an instructor. Empathy goes to 3, she takes Silver Tongue 1 (another dormant Talent; Wide Awareness was the usable choice), and Merit drops to 4.
  - She rolls Empathy (3) rather than Wits (2). One success brings Merit to 5.
- **Graduation.**
  - A Merit total of 5 is Class Rank 25. That is not Top 10, so there is no Military Police offer and no key attribute bonus.
  - She chooses Slayer. Its key attribute is Strength, already 5, so there is no swap. Had she chosen Tactician, her Instinct (2) would have swapped with her Strength (5), leaving Instinct 5 and Strength 2. Had she chosen Hunter, her Perception (4) would have swapped with her Strength (5) in the same way.
  - Her Specialty Talent level goes into Clean Cut, raising it to 2.
- **Finish.**
  - Attributes: Strength 5, Agility 2, Wits 2, Perception 4, Instinct 2, Empathy 3, for 18 points.
  - Talents: Clean Cut 2, Horsemanship 1, Keen Eyes 1, Silver Tongue 1, which is 5 levels.
  - Health is (5 + 2) / 2 = 3.5, rounded up to 4: a row of 4 boxes. Resolve is (2 + 3) / 2 = 2.5, rounded up to 3. Stress is 0.
  - She is a Private.

Mira's Nape strike rolls 7 dice before Gear, Bonus, and Stress Dice. On ODM Gear her dodge's base dice are only Agility 2. Horsemanship adds its die only to a dodge made mounted with the horse as its gear item, which rolls Agility 2 and Horsemanship 1. She will want a comrade Helping, or a Read and Call It, when a Titan's hand comes for her.

---

## Appendix 2A: Talents and the Action Catalog

These reference tables are rendered from `data/character/talents.yaml` and `data/character/action-catalog.yaml`. A name marked dormant or reserved is an entry that no Phase 1 rule calls for, or a Talent that names only such entries (section 2.8).

### 2A.1 Dice Talents

<!-- BEGIN RENDERED: talents-dice from data/character/talents.yaml -->
| Talent | Names | Max level | Specialty lists | Description |
|---|---|---|---|---|
| Clean Cut | Nape strike | 3 | Slayer | Practice at the single deep cut through the Nape that kills. |
| Hamstringer | Body Part strike | 3 | Slayer | Practice at cutting ankles, arms, and eyes to bring a Titan down. |
| Slip Away | Dodge | 3 | Flier | A knack for twisting clear of a Titan's hands and teeth. |
| Wirework | Fly | 3 | Flier | Control on the wires when a hard swing or landing is called for. |
| Lure | Break Attention | 3 | Hunter | Placing a flare, a horse, or a cloak where a Titan will turn to look. |
| Keen Eyes | Spot (dormant) | 3 | Hunter | Noticing movement, smoke, and danger at a distance. |
| Fieldcraft | Survive (dormant) | 3 | Hunter | Living off the land and keeping a camp safe outside the Walls. |
| Titan Reader | Read | 3 | Tactician | Watching a Titan closely enough to see what it will do next. |
| Judge of Character | Size Up (dormant) | 3 | Tactician | Reading what a person wants and whether they are lying. |
| Steady Voice | Rally | 3 | Leader | Talking a comrade back to their senses in the middle of a Titan Engagement. |
| Field Medicine | Treat Injury | 3 | Medic | Binding injuries and keeping the injured alive in the field. |
| Book Learning | Recall (dormant) | 3 | Medic | Remembering what the lectures, books, and reports said. |
| Gearwright | Field Repair | 3 | Engineer | Repairing ODM Gear and other equipment with field tools. |
| Horsemanship | Ride (dormant), Dodge (while mounted, with the horse as the dodge's gear item) | 3 | Rider | Riding hard and well, whatever the ground and whatever gives chase: it adds its dice to Ride and to the dodge a mounted soldier makes with the horse's Gear Dice. |
| Grip Breaker | Break Free | 3 | Brawler | Tearing free of a grip, even a Titan's. |
| Hard to Kill | Death Roll | 3 | Brawler | Holding on to life when an injury should be fatal. |
| Hand-to-Hand | Fight (reserved), Block (reserved) | 3 | none | Fighting people up close, with blades or bare hands. |
| Silver Tongue | Persuade (dormant) | 3 | none | Talking people into things. |
| Quiet Step | Sneak (dormant) | 3 | none | Moving without being seen or heard. |
| Long Haul | Endure (dormant) | 3 | none | Keeping going through hunger, cold, and exhaustion. |
<!-- END RENDERED: talents-dice -->

### 2A.2 Rule Talents

<!-- BEGIN RENDERED: talents-rule from data/character/talents.yaml -->
| Talent | Names | Trigger | Effect | Limit | Max level | Specialty lists | Description |
|---|---|---|---|---|---|---|---|
| Relentless | Nape strike | Your Nape strike falls short of the struck Titan's Nape Depth with at least 1 success. | The strike creates 1 more Opening than data/engagement/titan-harm.yaml (nape_strikes) gives it for its successes. It does not change the roll, its successes, or whether the Titan dies. | none | 1 | Slayer | A cut that falls short still leaves the Titan open for the next soldier. |
| Blade Discipline | Nape strike, Body Part strike, Break Free, Block (reserved) | A Pushed roll made for a named entry, with a Blade Set as its gear item, is about to wear that Blade Set. | Ignore 1 point of that wear. | once per Titan Engagement | 1 | Slayer | Care that keeps blades sharp through a long Titan Engagement. |
| Light Trigger | Gas Roll | Your Gas Roll this round would be three dice because you made a Pushed roll whose gear item was ODM Gear. | The Gas Roll is two dice instead. | once per Titan Engagement | 1 | Flier | A gentle hand on the gas trigger that makes a canister last. |
| Well-Kept Rig | Dodge, Fly, Break Attention | A Pushed roll made for a named entry, with your ODM Gear as its gear item, is about to wear your ODM Gear. | Ignore 1 point of that wear. | once per Titan Engagement | 1 | Flier, Engineer | Maintenance that keeps ODM Gear working when it is pushed hard. |
| Hunter's Eye | Read | You declare a Read. | The roll may use Perception instead of Instinct. It is still made for read, so a Talent that names read still adds its dice. | none | 1 | Hunter | Reading a Titan by sight rather than by gut. |
| Sharp Call | Call It | You declare Call It. | Calling It needs one fewer success from your Read than data/engagement/read.yaml (call_it) states, to a minimum of 1. | none | 1 | Tactician | Calling It in time with less to go on. |
| Wide Awareness | Help | You declare Help for a roll in a Titan Engagement. | You may be up to two Position steps from the roller instead of one. Every other Help requirement in Chapter 1, section 1.8, still applies. | none | 1 | Tactician | Seeing where Help is needed across the field. |
| Unshaken Command | Fear Roll | In a Titan Engagement, a comrade who holds your Position or a Position one step from you makes a Fear Roll, and you are not Down. | That Fear Roll uses your Resolve in place of the comrade's, if yours is higher. | once per Titan Engagement | 1 | Leader | A calm presence that steadies nearby comrades against terror. |
| Carrying Voice | Rally | You declare rally. | You may target a comrade one Position step farther from you than Chapter 3 allows. | none | 1 | Leader | A voice that reaches a comrade farther away. |
| Shoulder the Load | Cover | You declare that you Cover a comrade's Push in a Titan Engagement. | You may be up to two Position steps from the Pushing soldier instead of one. Every other Covering requirement in Chapter 1, section 1.5, still applies. | none | 1 | Leader | Taking on the Stress of comrades farther away. |
| Careful Nursing | Treat Injury | Your roll for treat-injury succeeds on a comrade's Critical Injury. | That Critical Injury's healing time, as Chapter 3 gives it, is halved, rounding up. Each Critical Injury can be halved only once. | none | 1 | Medic | Aftercare that speeds healing. |
| Sure Hands | Treat Injury | You have Pushed a roll made for treat-injury, and no Stress Die shows 1. | You may Push that roll a second time, following the Push procedure in Chapter 1 again. A roll never causes more than one Stress Response. | none | 1 | Medic | A second attempt at treatment under pressure. |
| Make Do | Field Repair | You declare a roll for field-repair, and gear_requirement in data/character/action-catalog.yaml applies the entry's without_gear value (attribute_alone) because you have no tool kit that counts as had. | The roll still adds dice from one Talent that names field-repair. | none | 1 | Engineer | Improvising repairs without a proper tool kit. |
| Quick Refit | Change Canister | You declare change-canister in a Titan Engagement. | If Chapter 4 makes changing a canister spend your action, you may spend your move on it instead. | none | 1 | Engineer | Swapping gas canisters with practiced speed. |
| Loose the Horse | Break Attention | You declare a roll for break-attention with your horse as its gear item. | The roll may use Agility instead of Perception. | none | 1 | Rider | Sending a horse where a Titan will chase it. |
| Sure Seat | Dodge, Ride (dormant), Break Attention | A Pushed roll made for a named entry, with your horse as its gear item, is about to wear your horse. | Ignore 1 point of that wear. | once per Titan Engagement | 1 | Rider | A seat that keeps the horse sound when a dodge, Ride, or Break Attention made with the horse is Pushed in a Titan Engagement. |
| Rescue Ride | Lift Comrade | You declare lift-comrade while mounted. | You may take it as part of your move instead of as your action. | none | 1 | Rider | Scooping a fallen comrade onto the saddle at a gallop. |
| Pry Loose | Break Free | You declare break-free on behalf of a Grabbed comrade who holds your Position, and you are not Grabbed. | You may take break-free as your action on that comrade's behalf, although you are not Grabbed. You roll your own pool for break-free, including your dice Talent that names it. If the roll succeeds, the comrade is freed exactly as if they had succeeded on break-free themselves. | none | 1 | Brawler | Prying a comrade out of a Titan's grip. |
| Strong Back | Lift Comrade | You carry a comrade you lifted with lift-comrade. | The comrade's own 5 items do not count toward the items you carry. The items that comrade carries still count (data/gear/carrying.yaml, items_counted). | none | 1 | Brawler | Carrying a comrade without their weight slowing you down. |
| Iron Nerve | Stress Response roll | You roll for a Stress Response. | Your Resolve counts as 1 higher for that roll. | none | 1 | none | Keeping steady as Stress mounts. |
<!-- END RENDERED: talents-rule -->

### 2A.3 Action Catalog entries

<!-- BEGIN RENDERED: action-catalog from data/character/action-catalog.yaml -->
| Entry | Id | Kind | Rolled | Attribute | Gear items | Needs its gear | Used | Status |
|---|---|---|---|---|---|---|---|---|
| Nape strike | `nape-strike` | action | when taken | Strength | Blade Set | yes; without it the entry cannot be used | in a Titan Engagement | — |
| Body Part strike | `body-part-strike` | action | when taken | Strength | Blade Set | yes; without it the entry cannot be used | in a Titan Engagement | — |
| Break Attention | `break-attention` | action | when taken | Perception | ODM Gear, Horse | no | in a Titan Engagement | — |
| Draw Attention | `draw-attention` | action | never | — | none | — | in a Titan Engagement | — |
| Read | `read` | action | when taken | Instinct | none | — | in a Titan Engagement | — |
| Call It | `call-it` | option | never | — | none | — | in a Titan Engagement | — |
| Break Free | `break-free` | action | when taken | Strength | Blade Set | no | in a Titan Engagement | — |
| Swap Initiative Card | `swap-initiative-card` | option | never | — | none | — | in a Titan Engagement | — |
| Squad Tactic | `squad-tactic` | option | never | — | none | — | in a Titan Engagement | — |
| Lift Comrade | `lift-comrade` | action | never | — | none | — | anywhere | — |
| Change Canister | `change-canister` | action | never | — | none | — | anywhere | — |
| Pass Item | `pass-item` | action | never | — | none | — | anywhere | — |
| Take Item | `take-item` | action | never | — | none | — | anywhere | — |
| Mount or Dismount | `mount-or-dismount` | option | never | — | none | — | anywhere | — |
| Swap Blade Set | `swap-blade-set` | option | never | — | none | — | anywhere | — |
| Shed Load | `shed-load` | option | never | — | none | — | anywhere | — |
| Restock Medical Kit | `restock-medical-kit` | option | never | — | none | — | anywhere | — |
| Help | `help` | action | never | — | none | — | anywhere | — |
| Cover | `cover` | option | never | — | none | — | anywhere | — |
| Dodge | `dodge` | Reaction | when taken | Agility | ODM Gear, Horse | no | in a Titan Engagement | — |
| Block | `block` | Reaction | when taken | Strength | Blade Set | no | in a Titan Engagement | reserved |
| Fight | `fight` | action | when taken | Strength | Blade Set | no | anywhere | reserved |
| Treat Injury | `treat-injury` | action | when taken | Wits | Medical kit | yes; without it, attribute alone | anywhere | — |
| Rally | `rally` | action | when taken | Empathy | none | — | anywhere | — |
| Field Repair | `field-repair` | action | when taken | Wits | Tool kit | yes; without it, attribute alone | anywhere | — |
| Fly | `fly` | roll | when a rule calls for it | Agility | ODM Gear | yes; without it the entry cannot be used | anywhere | — |
| Ride | `ride` | roll | when a rule calls for it | Agility | Horse | yes; without it the entry cannot be used | anywhere | dormant |
| Death Roll | `death-roll` | roll | when a rule calls for it | Strength | none | — | anywhere | — |
| Fear Roll | `fear-roll` | fixed roll | when a rule calls for it | — | none | — | anywhere | — |
| Stress Response roll | `stress-response-roll` | fixed roll | when a rule calls for it | — | none | — | anywhere | — |
| Gas Roll | `gas-roll` | fixed roll | when a rule calls for it | — | none | — | anywhere | — |
| Spot | `spot` | roll | when a rule calls for it | Perception | none | — | anywhere | dormant |
| Size Up | `size-up` | roll | when a rule calls for it | Instinct | none | — | anywhere | dormant |
| Survive | `survive` | roll | when a rule calls for it | Instinct | none | — | anywhere | dormant |
| Persuade | `persuade` | roll | when a rule calls for it | Empathy | none | — | anywhere | dormant |
| Endure | `endure` | roll | when a rule calls for it | Strength | none | — | anywhere | dormant |
| Sneak | `sneak` | roll | when a rule calls for it | Agility | none | — | anywhere | dormant |
| Recall | `recall` | roll | when a rule calls for it | Wits | none | — | anywhere | dormant |
| Performance roll | `performance-roll` | roll | when a rule calls for it | the Training Year's performance attribute | none | — | in the Lifepath | — |
<!-- END RENDERED: action-catalog -->

### 2A.4 What each entry requires and changes

<!-- BEGIN RENDERED: action-catalog-requirements from data/character/action-catalog.yaml -->
| Entry | Requirements | Needs | Changes | Help outside a Titan Engagement | Notes | Rules in |
|---|---|---|---|---|---|---|
| Nape strike | The soldier holds Blind Spot and does not hold the struck Titan's Attention (ADR-0010). The soldier is not Grabbed. In a Titan Engagement, the soldier's ODM Gear counts as had: not Jammed, and with a Gas Rating above 0 (data/gear/odm-gear.yaml, strikes), unless the Titan is grounded (data/engagement/titan-harm.yaml, grounded). No retreat is under way (data/engagement/background-titans.yaml, retreat, actions). Making the strike counts as hooking into the Titan. | the struck Titan's Nape Depth | kill a Titan, create Openings | not taken outside a Titan Engagement | — | Chapter 5, Chapter 4 |
| Body Part strike | The Position and state requirements in data/engagement/titan-harm.yaml (body_part_strikes) and data/engagement/grab.yaml (escapes). In a Titan Engagement, a strike made from On Body or Blind Spot also needs the soldier's ODM Gear to count as had (data/gear/odm-gear.yaml, strikes), unless the Titan is grounded. | 1; successes add up toward the Body Part's Toughness (data/engagement/titan-harm.yaml) | add successes toward a Body Part's Toughness, move a Body Part toward Broken, create Openings, free a Grabbed soldier | not taken outside a Titan Engagement | Striking the hand that holds a Grabbed soldier is a Body Part strike (Chapter 5, ADR-0015). | Chapter 5, Chapter 4 |
| Break Attention | data/engagement/attention.yaml (break_attention) | 1 for the soldier holding the Titan's Attention, otherwise 2, and 2 against a Titan holding a Grabbed soldier; 1 more for a Feint; plus 1 for each decoy the Titan has fallen for since its last card that resolved a behavior; extra successes create Openings (data/engagement/attention.yaml, break_attention, needs_rule) | shift a Focus Titan's Attention onto a decoy and raise its decoys in a row, create Openings, free a Grabbed soldier | not taken outside a Titan Engagement | Against a Titan holding a Grabbed soldier, a success frees them (data/engagement/grab.yaml) | Chapter 5 |
| Draw Attention | data/engagement/attention.yaml (draw_attention) | — | become the loudest or brightest stimulus on the Attention Ladder | — | Not from Distant (decision batch 5, OQ-113). Sets the loudest flag, which lasts until the end of the Titan's next card that resolves a behavior; a card that resolves nothing, under a decoy's hold, while the Titan holds a Grabbed soldier, or with no one holding its Attention, leaves it standing (ADR-0003, item 2, as amended in decision batch 3e; data/engagement/attention.yaml, flag_duration). | Chapter 5 |
| Read | data/engagement/read.yaml (read) | 1; each success reveals one fact or pays toward Call It (data/engagement/read.yaml, facts, call_it) | learn a fact about a Titan such as its Next Behavior | not taken outside a Titan Engagement | — | Chapter 5 |
| Call It | Option of read. Spends successes from a Read (data/engagement/read.yaml, call_it) | — | add dice to a comrade's Reaction | — | — | Chapter 5 |
| Break Free | The soldier is Grabbed and not Down, or holds Pry Loose (data/engagement/grab.yaml, escapes) | 2, with a 2-die penalty once lifted (data/engagement/grab.yaml, escapes) | free a Grabbed soldier | not taken outside a Titan Engagement | — | Chapter 5 |
| Swap Initiative Card | Option of the swap step of a round in a Titan Engagement (data/engagement/round.yaml, round_steps, swap). data/engagement/round.yaml (swapping) | — | exchange initiative cards with a comrade | — | Not an action, and spends neither the move nor the action (data/engagement/round.yaml, swapping). | Chapter 5 |
| Squad Tactic | Option of a Squad Tactic the Squad holds (data/engagement/squad-tactics.yaml, rules, held). data/engagement/squad-tactics.yaml (rules, tactics) | — | use a Squad Tactic | — | — | Chapter 5 |
| Lift Comrade | data/gear/carrying.yaml (lifting_a_comrade), in and out of a Titan Engagement. In one, a Down comrade who is not Grabbed or already carried holds the soldier's Position, and the soldier is not Down, carries no other comrade, and is not carried. | — | pick up and carry a Down comrade | — | — | Chapter 4, Chapter 5 |
| Change Canister | The soldier carries a spare gas canister. data/gear/odm-gear.yaml (change_canister) states what changing it spends. | — | restore a Gas Rating | — | — | Chapter 4 |
| Pass Item | In a Titan Engagement, the passer is not Down, and the receiver is a living comrade who holds the passer's Position; the receiver may be Down or Grabbed. Outside a Titan Engagement, data/gear/carrying.yaml (passing_items) sets the requirement. | — | give a carried item to a comrade | — | data/gear/carrying.yaml (passing_items) lists which items can be passed and what passing spends. | Chapter 4 |
| Take Item | In a Titan Engagement, the taker is not Down, and either a Down comrade who is not Grabbed holds the taker's Position, or a dead comrade's left items lie at that Position, relative to the Focus Titan recorded with them (data/gear/carrying.yaml, leaving_play, death, where_left). Outside a Titan Engagement, data/gear/carrying.yaml (taking_items) sets the requirement. | — | take an item from a Down comrade or from where a dead comrade's items lie | — | data/gear/carrying.yaml (taking_items) lists which items can be taken and what taking spends. | Chapter 4 |
| Mount or Dismount | Option of a move in a Titan Engagement; outside one, the procedure under way, or no procedure when none is under way (data/gear/horses.yaml, mounted, outside_titan_engagement). data/gear/horses.yaml (mounted). | — | mount or dismount a horse | — | Part of a move in a Titan Engagement, never an action (OQ-35). | Chapter 4, Chapter 5 |
| Swap Blade Set | Option of the soldier's own turn in a Titan Engagement; outside one, no turn (data/gear/blade-sets.yaml, swap). data/gear/blade-sets.yaml (swap). | — | fit a carried Blade Set into empty handles | — | Spends neither the move nor the action. | Chapter 4 |
| Shed Load | Option of the soldier's own turn in a Titan Engagement; outside one, no turn (data/gear/carrying.yaml, shedding). data/gear/carrying.yaml (shedding). | — | drop a carried item, set down a carried comrade, or stop being carried | — | Spends neither the move nor the action. | Chapter 4 |
| Restock Medical Kit | Option of a care window (data/harm/treat-injury.yaml, care_windows). data/gear/squad-supply.yaml (medical_uses, restock-kit). | — | restore a gear item's Gear Dice rating or end a Jam | — | Spends 1 medical unit of Squad Supply, and no roll. | Chapter 4, Chapter 3 |
| Help | Chapter 1, section 1.8. | — | add a die to a comrade's roll | — | Outside a Titan Engagement, Help is allowed only where the rule that calls for the roll allows it (OQ-08). | Chapter 1 |
| Cover | Option of a comrade's Push. Chapter 1, section 1.5 (Covering). | — | raise a soldier's Stress | — | — | Chapter 1 |
| Dodge | Chapter 1, section 1.9. | the behavior's Severity (ADR-0015) | avoid a behavior or attack aimed at oneself | not made outside a Titan Engagement | — | Chapter 1, Chapter 5 |
| Block | Only against an enemy whose rules allow blocking. No enemy in Chapters 5 and 6 allows it. | — | avoid a behavior or attack aimed at oneself | set by the rules that add an enemy that can be blocked | — | Chapter 1 |
| Fight | Only against a human enemy whose rules later chapters add. Nothing in Chapters 1 to 6 uses it. | — | none | set by the rules that add human enemies | — | not yet written |
| Treat Injury | Set by Chapter 3, including which comrades can be treated from which Position. | set by Chapter 3 | restore Health, treat or stabilize a Critical Injury, end the Down state | stated by the Chapter 3 procedure that calls for the roll | — | Chapter 3 |
| Rally | Set by Chapter 3, including which comrades can be Rallied from which Position. | set by Chapter 3 | end a Stress Response | stated by the Chapter 3 procedure that calls for the roll | Rally clears a Stress Response but does not lower Stress. | Chapter 3 |
| Field Repair | data/gear/field-repair.yaml (target, in_titan_engagement, outside_titan_engagement). | 1 | restore a gear item's Gear Dice rating or end a Jam | data/gear/field-repair.yaml (outside_titan_engagement) | — | Chapter 4 |
| Fly | Called by a Chapter 4 or Chapter 5 rule, such as a Position change that needs a roll. | — | none | stated by the rule that calls for the roll | — | Chapter 4, Chapter 5 |
| Ride | Called by the Chase rules (not yet written). | — | none | stated by the rule that calls for the roll | — | not yet written |
| Death Roll | Called by Chapter 3. Exceptions to the pool are in data/core/dice-pool.yaml. | — | none | never Helped (data/core/dice-pool.yaml) | — | Chapter 3 |
| Fear Roll | Called by the closed list of Fear Roll triggers in Chapter 3. | — | none | — | — | Chapter 3 |
| Stress Response roll | Called when a Stress Die shows 1 (Chapter 1, section 1.5). Chapter 3 holds the table. | — | none | — | — | Chapter 3 |
| Gas Roll | Called each round a soldier uses ODM Gear (data/gear/odm-gear.yaml, gas_roll). | — | none | — | — | Chapter 4 |
| Spot | — | — | none | stated by the rule that calls for the roll | — | not yet written |
| Size Up | — | — | none | stated by the rule that calls for the roll | Judging a person's intent. Observing a Titan is Read, not Size Up. | not yet written |
| Survive | — | — | none | stated by the rule that calls for the roll | — | not yet written |
| Persuade | — | — | none | stated by the rule that calls for the roll | — | not yet written |
| Endure | — | — | none | stated by the rule that calls for the roll | — | not yet written |
| Sneak | — | — | none | stated by the rule that calls for the roll | — | not yet written |
| Recall | — | — | none | stated by the rule that calls for the roll | — | not yet written |
| Performance roll | Called once per Training Year. Exceptions to the pool are in data/core/dice-pool.yaml. | — | none | never Helped | — | Chapter 2 |
<!-- END RENDERED: action-catalog-requirements -->

### 2A.5 Tracked values

<!-- BEGIN RENDERED: tracked-values from data/character/action-catalog.yaml -->
| Id | Tracked value | Entries that change it | Otherwise changed by | Rules in |
|---|---|---|---|---|
| `stress-raise` | raise a soldier's Stress | Cover | — | Chapter 1 |
| `stress-response-clear` | end a Stress Response | Rally | — | Chapter 3 |
| `health-restore` | restore Health | Treat Injury | — | Chapter 3 |
| `critical-injury-treat` | treat or stabilize a Critical Injury | Treat Injury | — | Chapter 3 |
| `down-end` | end the Down state | Treat Injury | — | Chapter 3 |
| `grabbed-end` | free a Grabbed soldier | Body Part strike, Break Attention, Break Free | — | Chapter 5 |
| `gear-restore` | restore a gear item's Gear Dice rating or end a Jam | Restock Medical Kit, Field Repair | — | Chapter 4 |
| `gas-restore` | restore a Gas Rating | Change Canister | — | Chapter 4 |
| `comrade-carry` | pick up and carry a Down comrade | Lift Comrade | — | Chapter 4, Chapter 5 |
| `item-give` | give a carried item to a comrade | Pass Item | — | Chapter 4 |
| `item-take` | take an item from a Down comrade or from where a dead comrade's items lie | Take Item | — | Chapter 4 |
| `mount-change` | mount or dismount a horse | Mount or Dismount | — | Chapter 4, Chapter 5 |
| `blade-set-swap` | fit a carried Blade Set into empty handles | Swap Blade Set | — | Chapter 4 |
| `load-shed` | drop a carried item, set down a carried comrade, or stop being carried | Shed Load | — | Chapter 4 |
| `attention-shift` | shift a Focus Titan's Attention onto a decoy and raise its decoys in a row | Break Attention | — | Chapter 5 |
| `draw-attention-set` | become the loudest or brightest stimulus on the Attention Ladder | Draw Attention | — | Chapter 5 |
| `toughness-add` | add successes toward a Body Part's Toughness | Body Part strike | — | Chapter 5 |
| `body-part-worsen` | move a Body Part toward Broken | Body Part strike | — | Chapter 5 |
| `openings-create` | create Openings | Nape strike, Body Part strike, Break Attention | — | Chapter 5 |
| `titan-kill` | kill a Titan | Nape strike | — | Chapter 5 |
| `titan-facts-reveal` | learn a fact about a Titan such as its Next Behavior | Read | — | Chapter 5 |
| `reaction-dice-add` | add dice to a comrade's Reaction | Call It | — | Chapter 5 |
| `initiative-swap` | exchange initiative cards with a comrade | Swap Initiative Card | — | Chapter 5 |
| `squad-tactic-use` | use a Squad Tactic | Squad Tactic | — | Chapter 5 |
| `roll-dice-add` | add a die to a comrade's roll | Help | — | Chapter 1 |
| `behavior-avoid` | avoid a behavior or attack aimed at oneself | Dodge, Block | — | Chapter 1, Chapter 5 |
| `position-change` | change Position | none | a move, not a Catalog entry | Chapter 5 |
| `rule-named-value` | change a clock, counter, or obstacle that a rule creates and for which that rule names an attribute roll | none | the attribute roll its creating rule names, made with the attribute alone, when no Catalog entry changes it | the rule that creates the value |
<!-- END RENDERED: tracked-values -->
