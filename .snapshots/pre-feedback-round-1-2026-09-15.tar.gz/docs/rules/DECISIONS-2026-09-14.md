# Open-question decisions, 2026-09-14

Decisions on OQ-01 to OQ-57 in `docs/rules/OPEN-QUESTIONS.md`, made by the lead designer with the owner's authority to settle every open question and to amend ADRs. Each entry records the decision as a rule precise enough to draft from (no GM discretion, ADR-0003), the reasoning, and what changes in the ADRs, the glossary (`CONTEXT.md`), and the chapters and YAML.

Step 1 (2026-09-14, morning) wrote the decisions. Step 2 (the same day, after the third Chapter 3 reviews) folded in the six Round-3 notes, integrated the owner's decision on Health boxes, and applied the ADR amendments, the glossary edits, and the OPEN-QUESTIONS status lines. The chapter drafts, their YAML, and the review files are unchanged; the drafter applies the chapter impacts recorded here, gathered for Chapters 1 to 3 near the end of this file. The register ended at OQ-57 when step 2 was applied; OQ-58 and later entries are decided in the *Conformance follow-up*, *Batch 2*, *Batch 2b*, *Batch 3*, *Batch 3b*, *Batch 3c*, *Batch 3d*, *Batch 3e*, *Batch 4*, *Batch 4b*, *Batch 5*, and *Batch 6* sections below. A `Revised on apply:` line marks a section whose earlier text contradicted another decision; a `Revised by owner decision: Health boxes` line marks one the owner's decision overrides.

Odds quoted below without a source come from throwaway Python scripts run outside the repository (200k trials unless stated): an Exam payout model (`exam_sim.py`), a Stress trajectory model with the Chapter 3 Stress Response rows (`stress_sim.py`), a dodge model with Help and Gear Dice (`dodge_help_sim.py`), a Health boxes model over the real Critical Injury tables (`health_boxes_sim.py`), and the Round-3 Grab and treatment probes described under *Round-3 notes*. Odds with a source are quoted from the review that measured them. Every number is a starting value for the ADR-0014 simulator, not a final one.

## Reading guide

Five decisions touch many entries. They are:

- **Spent state is set at the start of a round** (OQ-17). A turn spent in advance, or spent by a result, begins its round with its move and action already spent, and every rule reads that state.
- **One shared forbid hook** (OQ-18). A state or result forbids Pushing, Helping, Covering, or Reactions only by naming what it forbids on its own row. The Grabbed case is decided now: no Help, no Cover, no Reaction.
- **The mounted dodge uses the horse** (OQ-25, ADR-0015 amended). Saddle Dodge is replaced.
- **Actions outside the Catalog change only tracked values** (OQ-35, ADR-0003 item 9 amended), and Chapter 4 owns passing an item and mounting or dismounting.
- **The Graduation Exam is rebuilt for parity** (OQ-22 and OQ-37): the vote comes before the Lifepath, the order is rolled, Help is a fixed cycle, Trials 1 and 2 pay at 2 successes and cannot be Pushed, the squad field exercise needs 3.
- **Health is a row of boxes** (owner decision, ADR-0005 amended): each untreated Critical Injury crosses off one, damage marks the rest, and 0 is Down. The three-untreated-injuries condition is gone (OQ-24, OQ-39, OQ-40, OQ-42, OQ-44, OQ-45, OQ-53, OQ-55 revised).

Counts: 57 entries decided, plus OQ-58 and three conformance Minors under *Conformance follow-up*, plus OQ-59 to OQ-73 under *Batch 2*, the four batch 2b rulings (OQ-91 and OQ-92 record the two Majors), and OQ-74 to OQ-90 and OQ-93 to OQ-99 under *Batch 3*, revised for OQ-50, OQ-79, OQ-81, OQ-89, and OQ-97 under *Batch 3b* and again for OQ-81 under *Batch 3c* and *Batch 3e*, and OQ-111 under *Batch 3d*, revised under *Batch 3e*, and OQ-100 to OQ-110 under *Batch 4*, which also revises OQ-81's ties and 3e-6, and *Batch 4b*, which revises 4-3 and 4-4 and opens OQ-112; and *Batch 5*, which revises 4-4 and the Chapter 6 constraints, decides OQ-113 and opens and decides OQ-119 to OQ-127 and, in 5-15 to 5-18 after the round 2 reviews, OQ-129 to OQ-131, opens OQ-132 (a Simulator target, the Medium deaths band missed through the end of the Titan Engagement, 5-19), and keeps OQ-112 open after the final review; and *Batch 6*, which decides OQ-134; OQ-01 to OQ-111, OQ-113, OQ-119 to OQ-127, OQ-129 to OQ-131, and OQ-134 are all marked Decided in OPEN-QUESTIONS.md. 43 keep the provisional choice, sometimes with a wording fix; 14 change a rule or a data value (OQ-05, OQ-17, OQ-18, OQ-22, OQ-23, OQ-25, OQ-28, OQ-31, OQ-32, OQ-35, OQ-37, OQ-38, OQ-55, OQ-57), and the owner's Health boxes decision changes Health, Down, and treatment on top of them. Four ADRs are amended (0003, 0005, 0014, 0015), ADR-0003 and ADR-0014 again in the conformance follow-up, ADR-0014 and ADR-0015 again in batch 2, ADR-0014's body in batch 2b, ADR-0014's targets, Talent sentence, and baseline policy in batch 3, and ADR-0014's lone-band wording and gas medians and ADR-0010's decoy hold (an `## Amended` paragraph) in batch 3b, and ADR-0003's flag moment and ADR-0010's and ADR-0014's batch 3b sentences in batch 3c, ADR-0003 item 2 again in batch 3d, and ADR-0003 item 2 (the list itself), ADR-0010, and ADR-0014 in batch 3e, and ADR-0003, ADR-0010, and ADR-0014 in batch 4, and ADR-0010 and ADR-0014 in batch 4b, and ADR-0010 and ADR-0014 in batch 5; no new ADR. 27 distinct glossary entries are edited (the new Retreat clock in batch 5; Attention in batch 4b; Nape Depth, Regeneration, and the Attention Ladder in batch 4; the new Feint and the Shifter Intent Table in batch 3c; Standard Issue in batch 2; Blind Spot and Break Attention in batch 3, which also rewrites Opening; and Gear Dice, Stress Dice, Covering, Help, Reaction, Gas Roll, Squadmate, Grabbed, Graduation Exam, Training Year, Drive, Health, Resolve, Opening, Critical Injury, Down, Grief, and the new Campaign Year). Chapters 1, 2, and 3 all need changes; Chapters 4, 5, and 6 inherit the constraints listed at the end.

## Summary table

| OQ | Decision (one line) | ADR change | Glossary change | Chapter impact |
|---|---|---|---|---|
| 01 | Keep (b): Gear Dice never re-rolled; Bonus Dice are base dice | none | Gear Dice | none |
| 02 | Keep (a): one Push unless a Talent allows more | none | none | none |
| 03 | Keep registered component exceptions, including the performance roll; own-rule eligibility bans stand | none | Stress Dice | Ch1 1.3, 1.8 |
| 04 | Keep (a): no maximum Stress | none | none | none |
| 05 | Keep (a); add the hook that lets a roll's own rule replace the Stress Response's resolution | none | none | Ch1 1.5 step 2 |
| 06 | Keep (a): one Coverer per Push, no per-round limit; sponge case stands | none | Covering | none |
| 07 | Keep (a) | none | none | none |
| 08 | Keep (a) and (f) | none | Help | none |
| 09 | Earliest wholly unspent turn, including accumulated debt | none | Reaction | Ch1 1.9 |
| 10 | Keep (a) and (f) | none | none | none |
| 11 | Keep (a) | none | none | none |
| 12 | Keep (a); a Pushed dodge made with the horse is not a Pushed ODM roll | none | Gas Roll | none |
| 13 | Keep (b), now settled by Chapter 2 | none | Squadmate | none |
| 14 | Keep (a) | none | none | none |
| 15 | Keep (a) | none | none | none |
| 16 | Keep (a), with the review 3 wording | none | none | Ch1 1.9 wording |
| 17 | **Change:** (c), spent state set at the start of the round; no Help from a spent turn | none | none | Ch1 1.8, 1.9; `bonus-dice-sources.yaml`; Ch3 3.9, `effect-types.yaml` |
| 18 | Shared state/result hook; Grabbed bans Help, Cover, Reaction; preserve existing eligibility | ADR-0003 item 13 | Grabbed | Ch1 core rules; Ch2 Exam; Ch3 Fear rows; Ch5 |
| 19 | Keep (h); derived values from the final ratings; reference builds get non-key attributes | ADR-0014 amended | none | none |
| 20 | Keep (a), (d), (g) | none | none | none |
| 21 | Keep; the Merit skew is accepted, not retuned | none | none | none |
| 22 | **Change:** Exam rebuilt (see OQ-37): Trials 1 and 2 pay at 2 successes and cannot be Pushed, Trial 3 needs 3, one cycle helper | none | Graduation Exam, Training Year | Ch2 2.3, 2.4; `graduation-exam.yaml`, `lifepath.yaml` |
| 23 | Prior aid can meet Pay It Forward; preserve Freedom outside fights | none | Drive | Ch2 2.5, enlistment.yaml |
| 24 | Keep (a): round up, from the final attributes; Health text superseded by Health boxes | none | Health, Resolve | none |
| 25 | **Change:** the dodge may use the horse while mounted; other assignments kept | ADR-0015 amended | Reaction | Ch1 1.9; Ch2 `action-catalog.yaml` dodge; Ch4 |
| 26 | Keep (a) | none | none | none |
| 27 | Keep (e), now backed by ADR-0003 item 9 as amended (OQ-35) | see OQ-35 | none | Ch2 2.9 PROVISIONAL text |
| 28 | **Change:** Saddle Dodge becomes Sure Seat; everything else kept | none | Opening | Ch2 2.7; `talents.yaml`, `specialties.yaml`, `training-years.yaml` |
| 29 | Keep; add `health_lost`; Chapter 4 gives a one-line Squad sheet row | none | none | Ch2 `squadmates.yaml` |
| 30 | Keep (a), (d), (g) | none | none | none |
| 31 | **Change:** promotion waits for the end of the procedure, like Retirement | none | none | Ch2 2.10; `squadmates.yaml` |
| 32 | **Change:** the campaign year is a current year, advanced only by the Canon Clock rules | none | Campaign Year (new) | Ch2 2.3; `lifepath.yaml`, `origins.yaml` |
| 33 | Keep (a) | none | none | none |
| 34 | Keep (a) | none | none | none |
| 35 | Tracked-value rule; Ch4 owns passing items and mounting | ADR-0003 items 9, 12 | none | Ch1 ADR paraphrase; Ch2 2.9; Ch4 |
| 36 | Keep extensions hook and Freedom flight exception | none | Drive with OQ-23 | Ch2 2.5 |
| 37 | **Change:** (e): vote before the Lifepath, rolled order, cycle Help | none | see OQ-22 | see OQ-22 |
| 38 | **Change:** (c): losers choose again from untaken Squadmates | none | none | Ch2 2.10; `squadmates.yaml` |
| 39 | Keep (a) as revised; damage marks the boxes left (Health boxes) | none | none | Ch3 3.1; `health.yaml` |
| 40 | Keep (a); a day restores Health lost to damage, treating gives boxes back (Health boxes) | none | none | Ch3 3.1, 3.6; `health.yaml`, `healing.yaml` |
| 41 | Keep (a) | none | none | none |
| 42 | Keep injury rows; correct worsening language and rescue/treatment models | none | Critical Injury | Ch3 3.2, 3.7 |
| 43 | Keep (a), (c), (e), (i) | none | none | none |
| 44 | Keep treatment; require patient inside care-window scope | none | none | Ch3 3.5, treat-injury.yaml |
| 45 | Down at 0 current Health or a Down row; three-untreated condition deleted (Health boxes); Down turn action counts as spent; forbids hook | none | Down | Ch3 3.3, down.yaml |
| 46 | Keep (e); the OQ-17 dependency is closed | none | none | Ch3 3.9 wording |
| 47 | Keep (a), (d), (g) | none | none | none |
| 48 | Keep (a), (c), (e) | none | none | none |
| 49 | Keep (a), (d), (f), (h); the Drive note is resolved by OQ-23 | none | none | none |
| 50 | Keep Fear rows and band; permit both rescue structures | none | none | Ch3 3.7, 3.12; Ch5 |
| 51 | Keep (a), (e), (i), (j) | none | none | none |
| 52 | Grief follows the death's Fear Rolls; caps and relief retained | none | Grief | Ch3 3.12, 3.14; grief.yaml |
| 53 | Keep (a); a healed untreated injury gives its box back (Health boxes) | none | none | `healing.yaml` |
| 54 | Keep nine steps with capped aftermath and full promotion batch | none | none | Ch3 3.16, engagement-end.yaml |
| 55 | Keep (a); Chapter 2 now refers to `sheet-fields.yaml`; current Health derived, no new field (Health boxes) | none | none | Ch2 `lifepath.yaml`, `squadmates.yaml`; `sheet-fields.yaml` |
| 56 | Keep (a) | none | none | none |
| 57 | One aftermath roll per patient and per treater | none | none | Ch3 care procedure, end steps, example |
| 58 | (a): reference builds fixed (Rookie Strength 4, Agility 3, Health 4; Veteran Health 4; Levi-grade Health 5), Health 3 Squad reported beside the targets | ADR-0014 amended | none | Ch2 2.2, 2.10; Ch3 3.2; `squadmates.yaml` |
| Owner | Health boxes: untreated Critical Injuries cross off Health boxes, damage marks the rest, 0 is Down | ADR-0005 amended | Health, Critical Injury, Down | Ch2 2.1, 2.2; Ch3 3.1, 3.2, 3.3, 3.5, 3.6, example; `health.yaml`, `down.yaml`, `critical-injuries.yaml`, `treat-injury.yaml`, `healing.yaml`, `sheet-fields.yaml`, `squadmates.yaml` |

---

## OQ-01: Which dice a Push re-rolls

- **Decision:** (b), as drafted. A Push re-rolls base dice (including Bonus Dice) and Stress Dice not showing 6, and adds the new Stress Die. Gear Dice are never re-rolled. When a Pushed roll is final, each Gear Die showing 1 wears its item by 1. An unpushed roll never wears gear.
- **Why:** It is what ADR-0004 step 2 and the glossary say, it keeps one die colour out of the player's hand during a Push, and its wear rate (30% of Pushed rolls with 2 Gear Dice, 42% with 3, review round 1) is the figure Chapter 4 tunes Gear Dice ratings against. Wear falling as Stress rises (0.067 per roll at Stress 0, 0.006 at Stress 6) is an emergent property worth keeping: a soldier who cannot Push is not burning gear. Chapter 4 tunes ratings at Stress 1.
- **ADR change:** none.
- **Glossary change:** Gear Dice entry becomes: "Dice contributed by equipment. When a Pushed roll is final, each Gear Die showing 1 wears that equipment down by 1."
- **Chapter impact:** none, current text matches.

## OQ-02: How many times a roll can be Pushed

- **Decision:** (a). Once per roll, unless a Talent allows a second Push (Sure Hands). Every Push follows the same procedure, and a Stress Die 1 after any Push forbids further Pushes.
- **Why:** Both parent games. Unlimited Pushes would make ADR-0014's Levi-grade odds depend on the player's Stress appetite.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none.

## OQ-03: Which rolls include Stress Dice

- **Decision:** Every attribute roll includes Stress Dice unless its own rule explicitly excludes them and has a `roll_exceptions` row. The Death Roll and performance roll are the current exclusions. Component exclusions must be registered there; a roll may also forbid Help or Pushing in its own procedure, as the Exam Trials do. State and result bans follow OQ-18. A Down soldier makes no attribute roll but the Death Roll.
- **Why:** Review round 1's figures (a Strength 3 soldier surviving a Death Roll 42% at Stress 0 and 81% at Stress 6 under (a)) still decide it. Making the YAML row the only test closes Chapter 1 review 3 Minor 6.
- **ADR change:** none.
- **Glossary change:** Stress Dice entry becomes: "Dice added to attribute rolls equal to current Stress, unless the roll explicitly excludes them, which can succeed like any die but can also set off a Stress Response."
- **Chapter impact:** Chapter 1 errata when it is reopened for OQ-17: section 1.3 step 7 reads "Another roll leaves out Stress Dice only if its own rule names it and the roll has a row under `roll_exceptions` in `data/core/dice-pool.yaml`; a later chapter that creates such a roll adds the row." The last sentence of section 1.3 reads "It also lists the rolls with exceptions, such as the Death Roll and the performance roll." Section 1.8's requirement "The roll is not a Death Roll" reads "The roll's `roll_exceptions` row, if it has one, does not exclude Help." No YAML change.
- **Revised on apply:** The earlier blanket exception named only the Death Roll, contradicting OQ-21's performance roll. Requiring every Help or Push ban in `roll_exceptions` also contradicted OQ-22's explicit Trial rules. Component exclusions remain registered; roll-specific eligibility stays with the calling procedure.

## OQ-04: Maximum Stress

- **Decision:** (a). No maximum.
- **Why:** With the Chapter 3 rows in place the spiral the final review feared does not appear. A Rookie (base 5, Resolve 3) who Pushes every short roll over three Titan Engagements of four rolls, with Hair Trigger and Botched adding Stress, ends at median Stress 0 (90th percentile 0, worst 6) and peaks at median 2 (90th percentile 3, worst 8); a two-Scar Veteran ends at median 2 and peaks at 3 (90th percentile 4); a four-Scar Levi-grade soldier ends at 4 and peaks at 4 (90th percentile 5). Botched fired on fewer than 0.01% of rolls. Stress Die 1s block the Pushes that would drive Stress higher, so a cap would never bind in normal play and would only add edge cases (Push at the cap, Cover at the cap).
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none. Simulator: re-run this case with the Fear Roll rows and Grief once Chapter 5's witness rule exists (OQ-47's case).

## OQ-05: Order of resolution when a roll finishes

- **Decision:** (a): count successes, resolve the Stress Response, apply the effect, apply wear. Add one hook to step 2: a roll's own rule may replace how its Stress Response is resolved by naming what happens instead; the Graduation Exam's Merit cost is such a rule. A Stress Response still happens (ADR-0004 step 4) and the roll still cannot be Pushed after it; only its resolution changes.
- **Why:** Chapter 2 review 3 Minor 3 found the Exam replacing the table with no Chapter 1 hook. The hook keeps ADR-0004 intact and gives Chapter 2's exception a home. It is the same "the calling rule states it" pattern Chapter 1 already uses for Help.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Chapter 1 section 1.5 *Finishing a roll* step 2 adds: "unless the roll's own rule names another resolution, as the Graduation Exam does (Chapter 2)". `data/mind/stress-responses.yaml` `roll.exceptions` already says this; no YAML change.

## OQ-06: Covering procedure

- **Decision:** (a) as drafted: declared after the Push and before the re-roll, one Covering soldier per Push chosen by the Pushing soldier, Help's eligibility (Position in a Titan Engagement, the calling rule outside one), the Covering soldier gains the 1 Stress, the Push adds no new Stress Die, no per-round limit, and a Down soldier cannot Cover. Starting value for the sponge case: no limit. The case's acceptance test stands as written; if it fails, the fallback is option (e), once per soldier per round.
- **Why:** Chapter 1 review 3 measured the trade: a Covered Push at Stress 0 has 0% Stress Response chance at a cost of 4 to 10 points of success (need 1: 87% against 91%; need 2: 54% against 64%), and the trade vanishes by Stress 3. Squadmates never Cover (OQ-29), so the sponge is a player character who then rolls their own Stress Dice and Fear Rolls and can gain the Carrying Their Weight Scar. That is the price the case measures.
- **ADR change:** none.
- **Glossary change:** Covering entry becomes: "Taking on a comrade's Stress from their Push, so that the Push adds no new Stress Die."
- **Chapter impact:** none. The Exam's Cover limit is handled under OQ-18.

## OQ-07: Dice penalties

- **Decision:** (a). Penalties remove base dice only, after the Bonus Dice cap, never below 1 base die, never Gear Dice or Stress Dice.
- **Why:** Both parent games; Stress Dice must stay equal to Stress for ADR-0008.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none.

## OQ-08: Help timing, and Help outside Titan Engagements

- **Decision:** (a) and (f). Help can be given out of turn while the helper's action is unspent this round (read with OQ-17). Outside a Titan Engagement, the rule that calls for the roll states whether it can be Helped, who qualifies, and what Help spends; if it says nothing, the roll cannot be Helped or Covered.
- **Why:** Unchanged. Every later chapter has followed the pattern (Chapter 2's Catalog `help_outside_titan_engagement`, Chapter 3's care windows).
- **ADR change:** none.
- **Glossary change:** Help entry becomes: "Adding 1 die to a comrade's roll, up to 3 helpers. In a Titan Engagement it spends the helper's action and needs the same Position or one step away; outside one, the rule that calls for the roll states who can Help and what it spends."
- **Chapter impact:** none.

## OQ-09: When a Reaction can be made

- **Decision:** (b). A Reaction is always allowed unless a state or result forbids it (OQ-18) or one has been made against that Titan this round. It spends the soldier's earliest turn, starting with this round's, whose move and action are both unspent; a turn spent in advance still happens, counts as a turn, and begins its round spent (OQ-17). Chapter 3 has settled Down (no Reaction); Grabbed is settled under OQ-18 (no Reaction).
- **Why:** Unchanged. Review round 1's card-order figures (a Titan card after a given soldier's card 50% of the time) still make (a) unplayable.
- **ADR change:** none.
- **Glossary change:** Reaction entry becomes: "A dodge or block made during an enemy's turn, spending the soldier's earliest turn, starting with this round's, whose move and action are both unspent. Against a Titan, one dodge covers all of that Titan's cards for the round, and blocking is impossible."
- **Chapter impact:** none beyond OQ-17.
- **Revised on apply:** The glossary's proposed "otherwise the next" omitted accumulated turn debt. Use the earliest wholly unspent turn, as this decision already requires.

## OQ-10: Who loses Stress on a Nape kill and at the end of a Titan Engagement

- **Decision:** (a) and (f). Nape kill: every soldier holding a Position at the moment of the kill. End of Engagement: every soldier who held a Position at any point during it, including a retreat. Squadmates included (OQ-13).
- **Why:** Unchanged. Review round 2's Expedition Stress figures (median 0 with relief against 2 to 3 without) still hold.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none.

## OQ-11: Talents on rolls that are not actions

- **Decision:** (a). The Catalog has `dodge`, `block`, and `death-roll` entries marked as not actions; a Talent can name them. (b) stays the simulator fallback if Hard to Kill moves the PC death target.
- **Why:** Unchanged.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none.

## OQ-12: Whether a Pushed dodge burns extra gas

- **Decision:** (a). Any Pushed roll whose gear item is ODM Gear makes that round's Gas Roll three dice, however many such rolls there were. A Pushed dodge made with the horse (OQ-25) is not such a roll: it wears the horse and leaves the Gas Roll at two dice.
- **Why:** Unchanged; the horse clause is what Saddle Dodge already said and now applies to every mounted dodge.
- **ADR change:** none (the horse clause is in ADR-0015's amendment under OQ-25).
- **Glossary change:** Gas Roll entry becomes: "Two dice rolled each round a soldier uses ODM Gear, three after a Pushed roll that used ODM Gear. Each 1 lowers the Gas Rating by 1."
- **Chapter impact:** none.

## OQ-13: Squadmates and the core rules

- **Decision:** (b), which Chapter 2 has since settled: Squadmates roll Stress Dice, lose Stress through the field relief triggers, can Help and be Helped, never Push, never Cover.
- **Why:** Unchanged.
- **ADR change:** none.
- **Glossary change:** Squadmate entry adds, after "can be targeted by Titans like anyone else": "never Pushes or Covers,".
- **Chapter impact:** none.

## OQ-14: One dodge against behaviors of different Severity

- **Decision:** (a). One Reaction per Titan per round; its successes (after step 2 of *Finishing a roll*) are compared with each later behavior's Severity; a soldier may let an early card land and dodge a later one.
- **Why:** Unchanged.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none.

## OQ-15: Turns spent in advance when a Titan Engagement ends

- **Decision:** (a). Cancelled when the Titan Engagement ends.
- **Why:** Unchanged. Chapter 3's end step 1 already applies it.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none.

## OQ-16: Declining to use a move or action on one's turn

- **Decision:** (a). A soldier may decline their move, action, or both; what is left stays available until the round ends, only for Help and Reactions, and a Reaction needs both the move and the action. A move held alone can do nothing after the soldier's card has passed.
- **Why:** Unchanged; the two clarifications are Chapter 1 review 3 finding 7.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Chapter 1 section 1.9: add "(a Reaction needs both the move and the action)" to the OQ-16 block, and change the OQ-09 second bullet to "whatever is left of this round's turn can still be used on the soldier's card, if it has not yet come".

## OQ-17: Whether a soldier whose turn was spent in advance can Help

- **Decision:** (c). A turn spent in advance by a Reaction, or spent by a result, begins its round with its move and action already spent. Every rule that asks whether a soldier's move or action is spent this round reads that state, not what the soldier did during the round. So a soldier whose turn was spent in advance cannot Help that round, cannot make a Reaction with that turn, and holds nothing under OQ-16. The Help test in prose and YAML becomes "They have an unspent action this round."
- **Why:** A Reaction must cost exactly one whole turn, which is the glossary's price and the assumption behind OQ-09 (b), OQ-15, and Chapter 3's turn-spending results (OQ-46). Under (b) a dodge in turn debt would cost less than a turn, and the ADR-0014 Grab case would have to model Help from a soldier who has, by the rules, nothing to spend. The state is common: the soldier holding Attention enters the next round already spent after 77% of rounds at Tempo 1, 60% at Tempo 2, and 48% at Tempo 3 (Chapter 1 review 3), and that soldier is one step from the next Nape striker. Denying their Help is ADR-0010's pressure by design: the soldier the Titan is on cannot also steady a comrade's blade, and the comrades must relieve them with Break Attention. The cost is measurable and small: one Help die moves a Rookie's Severity 3 dodge from 24% to 33% (Gear 1, Stress 1) or a Nape strike by about the same. (c) is preferred over (a) because it fixes the state once, in *Turns and actions*, for every rule (Help, OQ-16, Reactions, Down, Chapter 3 results), and gives Foundry one flag set at the start of each round.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Chapter 1 section 1.9 *Turns and actions*: add "A turn spent in advance by a Reaction, or spent by a result (Chapter 3), begins its round with its move and action already spent. Every rule that asks whether a move or action is spent this round reads that state." Section 1.8 *Requirements*: "They have an unspent action this round." OQ-09 last bullet: "it begins its round with no move and no action, so the soldier cannot Help or hold anything that round." `data/core/bonus-dice-sources.yaml` `help.condition_in_titan_engagement`: "The helper has an unspent action this round (a turn spent in advance or by a result begins its round with its move and action spent) and is at the same Position as the roller or one Position step away." Chapter 3 section 3.9's OQ-46 block drops "Whether a soldier whose turn a result has spent in advance can still Help that round is the same open question as for a Reaction (OQ-17)" and states the answer; `data/harm/effect-types.yaml` `spend-next-turn.reading` adds "and begins its round with its move and action spent (Chapter 1, section 1.9)". While Chapter 1 is open, also apply Chapter 1 review 3 Minors 3 ("Rolled actions, Reactions, and Death Rolls"; the uncatalogued route covers rolls a rule calls for, which Chapter 2's `rolls_called_by_attribute` already does), 5 (lift the turn-spending sentence into *Turns and actions*), and 7 (drop or move "The Push would roll no dice"; list what section 1.10 settles about Squadmates).

## OQ-18: A rule that forbids Help or Covering

- **Decision:** (d): the shared hook of (c), and the Grabbed case decided now. Chapter 1 states once, in section 1.9 *Turns and actions*: "A state or result can forbid a soldier to Push, Help, Cover, or make a Reaction. It does so only by naming which of those it forbids on its own row (`forbids` in its YAML). This is the only route for a state or result to forbid them; the core eligibility requirements, roll-specific bans, and Squadmate restrictions still apply." The four eligibility lists (*When a soldier cannot Push*, Help *Requirements*, *Who can Cover*, the OQ-09 exceptions) each end with "No state or result the soldier holds forbids it (section 1.9)." Rows decided now:
  - Down (`data/harm/down.yaml`): `forbids: [push, help, cover, reaction]`, restating what Chapter 3 already says.
  - Grabbed (Chapter 5's Grabbed state row): `forbids: [help, cover, reaction]`. A Grabbed soldier can still Push their own rolls, including Break Free.
  - The Graduation Exam (`data/character/graduation-exam.yaml`): a Cadet who has made their own roll in the squad field exercise holds a state that `forbids: [cover]` for the rest of that Trial.
  - No Chapter 3 Stress Response, Fear Roll, or Scar row forbids Help or Cover. Unguarded, Breaking Point, and Shattered each carry `forbids: [reaction]`, implementing their existing `no-reactions` effect with its unchanged duration. The shared hook reads that active ban; it creates no second timer.
- **Why:** ADR-0003 item 8 needs a rule to point to. One hook, read by all four eligibility tests, keeps Chapter 1 closed and lets Chapters 3 and 5 add a field to their own rows instead of editing Chapter 1's conditions, which is ADR-0012's shape. Deciding Grabbed now closes the review 3 scenario (a soldier in a Titan's fist Helping the strike meant to free them, worth about 9 points on a Severity 3 dodge or a Nape strike) and settles the Reaction question OQ-09 left to Chapter 5 in the same breath, so one state is not split across chapters. Pushing stays allowed because Break Free is the Grabbed soldier's own fight, and ADR-0014's alone target (about 2 in 3) is tuned on a Grabbed soldier who can Push. The Exam's Cover limit becomes a legal use of the hook, which closes Chapter 2 review 3 Minor 3.
- **ADR change:** ADR-0003, drafting requirement 13, in the amendment given in full under OQ-35.
- **Glossary change:** Grabbed entry becomes: "Held in a Titan's hand, unable to Help, Cover, or make a Reaction. The Titan lifts the soldier after their next turn and devours them after the turn after that, unless they get free."
- **Chapter impact:** Chapter 1 sections 1.5, 1.8, and 1.9 as above; `data/core/bonus-dice-sources.yaml` `help.condition` and `data/core/stress-changes.yaml` `cover.condition` each add "No state or result the soldier holds forbids it (a forbids field on that state's or result's row)." `data/core/dice-pool.yaml` gains a comment naming the hook for Push. Chapter 3: `data/harm/down.yaml` adds the `forbids` row; `data/harm/effect-types.yaml` `never_used.forbid_help_or_cover` becomes "No Chapter 3 row uses the forbids hook for Help or Cover (Chapter 1, section 1.9); a row may, by adding forbids." Section 3.9's "What no row does" paragraph changes to match. Chapter 2: `graduation-exam.yaml` `trials[squad-field-exercise].cover` states the state and its `forbids: [cover]`; section 2.4 says the limit uses Chapter 1's hook; the introduction's "It changes no Chapter 1 rule" stands. `data/mind/fear-rolls.yaml` adds `forbids: [reaction]` to Unguarded, Breaking Point, and Shattered; `effect-types.yaml` `no-reactions` points to the shared hook while retaining its timer. Chapter 5: the Grabbed row carries `forbids: [help, cover, reaction]`.
- **Revised on apply:** "No other rule forbids them" would erase the Death Roll, Exam, and Squadmate restrictions. Limit that exclusivity to state and result bans. The three existing Fear rows that ban Reactions must also carry the hook; adding it changes no outcome or duration.

## OQ-19: Attribute points at creation

- **Decision:** (h), with every Lifepath point from a rolled row: 6 points on a base of 2, the Graduation swap whenever another attribute is higher than the key attribute, the floor of 4, +1 for Top 10. Health and Resolve are computed from the final ratings, after the swap (not before, as Chapter 2 review 3 Minor 4 offered). The Hunter, Medic, and Engineer cost in derived values (about 0.86 of Health plus Resolve; about 11% of them at Health 2) is accepted and recorded, and ADR-0014's reference builds are given non-key attributes so the simulator tunes against real dodgers.
- **Why:** (h) is the only option whose creation distribution (key 4 / 5 / 6 at 63.5 / 34.3 / 2.1%, 18 points) is independent of player strategy, which ADR-0014 needs. Computing derived values from pre-swap ratings would put a Health on the sheet that the attributes on the sheet do not produce, which is a Foundry derivation and a table-reading problem, for a benefit that Chapter 4's fall damage (sized against Health 2 to 5, OQ-39) already absorbs. Reference builds with key attribute 4 and no other attributes let Chapter 1 review 3 model a Rookie dodge at Agility 4, which only Fliers and Riders have; the Squadmate templates (key 4, four at 3, one at 2) are the right Rookie.
- **ADR change:** ADR-0014, add to `## Amended`: "After the open-question decisions (2026-09-14, OQ-19 and OQ-29): the reference builds' other attributes are 3 for the Rookie (one at 2, matching the Squadmate templates), 3 for the Veteran, and 4 for the Levi-grade soldier. Unless the build is a Flier or Rider, Severity is tuned against a Rookie dodging with Agility 3 and a Levi-grade soldier dodging with Agility 4, not the key attribute."
- **Glossary change:** none.
- **Chapter impact:** none. OQ-19's simulator note gains the derived-value table (step 2).
- **Revised by owner decision: Health boxes.** The Health 2 cost is larger than recorded: a Health 2 soldier is Down on their second untreated Critical Injury (mean 1.89 injuries before Down against 2.65 under the three-injury rule). Accepted as part of the owner's decision; the simulator reports Health 2 and Health 5 builds beside the reference builds.

## OQ-20: Talent levels at creation

- **Decision:** (a), (d), (g). Five levels: Origin 1, events 3, Specialty 1; a capped event falls back to the year's curriculum; a dormant-only pick may be swapped for a curriculum Talent.
- **Why:** Unchanged; 0 of 200k simulated soldiers are forced into a dormant level.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none.

## OQ-21: Performance roll, Merit, Class Rank, and the Top 10

- **Decision:** (a), (l), Merit equal to successes up to 3 plus the event's `merit_change`, (d) Top 10 at Merit 6 or more, (f) +1 key attribute, (i) the Military Police offer always declined. The `merit_change` skew (Strength +6, Perception +4, Agility -1) is accepted as written: it decides which Cadets reach the Top 10, not what any Specialty can hold, and canon's top graduates are the ones instructors reward for strength on the harness and the dummy course. It is not retuned.
- **Why:** 6.3% Top 10 and at least one Top 10 soldier in about 23% of four-player Squads is the rarity the calibration assumes. Retuning `merit_change` across 36 events for a within-class skew that no player can choose after the rolls is not worth the churn.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none.

## OQ-22: Graduation Exam structure

- **Decision:** The Exam is rebuilt with OQ-37. The whole rule:
  1. **Vote.** The players decide whether to run the Exam before the Lifepath begins, at the same step as the campaign year (OQ-32), with the roll-off if they disagree. A replacement character created later decides before rolling their own Lifepath, and takes the Exam alone.
  2. **When.** After every Cadet has applied their Year 3 event and before Graduation. It replaces the Year 3 performance roll; the Year 3 event still happens.
  3. **Order within a Trial.** Before each Trial, every Cadet taking the Exam rolls a D6. They roll in descending order; Cadets tied for the same result roll again among themselves. The order of Cadets in a Trial leaves `group_choices`.
  4. **Trial 1, the ODM balance test (`fly`, training ODM Gear)** and **Trial 2, the Titan dummy course (`nape-strike`, training Blade Set)**: each pays 1 Merit at 2 or more successes and 0 otherwise. Neither can be Pushed, Helped, or Covered.
  5. **Trial 3, the squad field exercise**: each Cadet picks one entry from `entry_choice` and needs **3** successes for 1 Merit. It can be Pushed. Help is fixed: the Cadet who rolls next in that Trial's order Helps the current roller, and the first roller Helps the last; each Cadet Helps exactly one roll; a lone Cadet has no Help. Only a Cadet who has not yet made their own roll in the Trial can Cover a Push (the OQ-18 `forbids: [cover]` state).
  6. **Stress.** Every Cadet starts at 0. A Stress Response costs 1 Merit on the Trial whose roll caused it (OQ-05's hook). Stress returns to 0 when the Exam ends (`graduation-exam-ends`).
  7. Exam issue at Gear Dice 1, no Gas Rolls, no Blade Set counting, wear only during the Exam, `requirements_ignored` as now.
  - **Simulator target:** mean Exam Merit within 0.1 of the Year 3 performance roll it replaces, and the share of Top 10 graduates with the Exam within 0.3 points of the share without, for 1 to 6 Cadets, under the aimed policy of Chapter 2 review 3. Tuning ladder if it fails: first Trial 3's successes needed (3, then 2 with 1 Merit only at 3 or more), then Trial 1 and 2's threshold (2, then 3).
- **Why:** Two problems had one cause. Trials 1 and 2 paid Merit on about 4 to 7% of rolls (review 3 Minor 6), so the canon Trials that decide Training Corps rankings were almost decorative, and the whole Exam rode on the squad field exercise, the one Trial the players could aim Help and order at (OQ-37). Paying Trials 1 and 2 at 2 successes and forbidding their Push makes them clean solo tests of attribute, Talent, and gear (a Cadet at Stress 0 with no Push never sees a Stress Response there), and raising Trial 3 to 3 successes with exactly one helper takes the mean back to parity. In the payout model: the Year 3 roll pays mean 0.583 Merit, 2 or more 10.5% of the time, 3 or more 1.3%; the new schedule with one cycle helper pays 0.612, 13.4%, and 1.1%; a lone Cadet 0.506, 10.8%, 0.8%. The same model shows why Help is fixed at one: three helpers on Trial 3 pay 0.803 and 18.2%, and under the current schedule with free Help the reviews measured Top 10 rising from 6.3% to 7.6%. Moving the vote before the Lifepath removes the one Exam choice made with Merit known (OQ-37 (e)). Keeping (d) Stress reset, (g) Merit cost, (k) no squad bonus, and (p) restricted Covering.
- **ADR change:** none.
- **Glossary change:** Graduation Exam entry becomes: "The optional played prologue of three Trials whose Merit replaces the third Training Year's performance roll and so helps decide each Cadet's Class Rank." Training Year entry adds: "The Graduation Exam, if played, replaces the third year's performance roll."
- **Chapter impact:** Chapter 2 section 2.3 (vote moved to the step before the Lifepath; `group_choices` loses Trial order), section 2.4 (all of *Using the Exam*, *How the Exam is played*, and *The three Trials* rewritten to the rule above; the PROVISIONAL block restates the new parity figures and the simulator target). `data/character/lifepath.yaml`: step 0 records the Exam vote with the campaign year; `group_choices` text. `data/character/graduation-exam.yaml`: `use.decided_by`, `roll_order_within_a_trial`, `trials[*].merit`, `trials[odm-balance-test].push` and `trials[titan-dummy-course].push` (false), `trials[squad-field-exercise].needs` (3), `.help` (the cycle), `.cover` (the OQ-18 state). `data/core/dice-pool.yaml`: no change (Trials 1 and 2 forbid a Push through their own rule, which section 1.5 allows).

## OQ-23: Drive timing, trigger tests, and replacement

- **Decision:** (a), (i), (e), (j), (l), (m), (p) as drafted, with two changes:
  1. **Pay It Forward** (`targets.grabbed_or_down_comrade`): the act counts if it was used on a comrade who was Grabbed or Down when the act was used, **or who is Grabbed or Down when the Fear Roll result is about to take effect.** So a witness who Helped, Covered, treated, or lifted a comrade since their most recent turn began, and now sees that comrade Grabbed, can shrug off the `comrade-grabbed` result.
  2. **Own-state edges** (`trigger_tests.own_state`): a Position the soldier was placed at when the Titan Engagement began, or by any rule other than their own move, does not count until their own move changes it; a Grab counts as a change of Position made by another rule even when the soldier's Position stays On Body; Freedom is met only by the soldier's own ODM use, and a soldier carried by a comrade is not airborne on their own ODM Gear. Chapter 4 still defines airborne.
- **Why:** The Drive written around rescue could never answer the Fear Roll that begins the rescue (OQ-49 Drive note, raised in both Chapter 3 rounds). Adding "or is Grabbed or Down now" keeps the test closed and keeps "while acting on it": the soldier has already been looking after that comrade. The three edges are Chapter 2 review 3 Minor 5; each is one closed sentence.
- **ADR change:** none.
- **Glossary change:** Drive entry becomes (with OQ-36): "What keeps a soldier fighting, written as a 'When I ...' trigger, which lets them shrug off one Fear Roll result per session while that trigger is met by their own act, a Position they moved into, or their own ODM flight. Position triggers require a Titan Engagement; turn triggers work outside one only when a rule extends them, while Freedom's flight trigger can work anywhere."
- **Chapter impact:** Chapter 2 section 2.5 (*Targets*, `grabbed_or_down_comrade`; *Trigger tests*, `own_state`), `data/character/enlistment.yaml` (`drive_rules.targets.grabbed_or_down_comrade`, `drive_rules.trigger_tests.own_state`, row `the-walls-are-a-cage` trigger "When I am airborne on ODM Gear through my own ODM use"). OQ-49's Drive note is closed.
- **Revised on apply:** The proposed glossary barred every Drive outside a Titan Engagement, contradicting OQ-36's retained Freedom exception. The glossary now distinguishes flight, Position, and turn triggers; Pay It Forward still requires an actual prior act, not a promise to rescue.

## OQ-24: Health formula and rounding of derived values

- **Decision:** (a). Health is half of Strength plus Agility, rounded up; Resolve is half of Instinct plus Empathy, rounded up, plus 1 per Scar, minus 1 per point of Grief (at most 3). Both from the final attributes after the Graduation swap (OQ-19).
- **Why:** Unchanged.
- **ADR change:** none.
- **Glossary change:** Health entry becomes: "How much punishment a character can absorb before they can no longer act: half of Strength plus Agility, rounded up." Resolve entry becomes: "A soldier's steadiness, half of Instinct plus Empathy, rounded up, plus 1 per Scar and minus 1 per point of Grief, which counts against Stress Response and Fear Roll results."
- **Chapter impact:** none.
- **Revised by owner decision: Health boxes.** The Health glossary text here is superseded by the Health boxes text; the formula and rounding stand.

## OQ-25: Attribute and gear for Titan Engagement entries

- **Decision:** (a) strikes on Strength with a Blade Set, (d) Break Attention on Perception with ODM Gear or a horse, (g) Draw Attention unrolled, (i) Fly and Ride as rolls a rule calls for, Read on Instinct, Break Free on Strength with an optional Blade Set, all kept. One change: **the dodge's gear items are ODM Gear, or the horse while the soldier is mounted** (one item per roll, ADR-0006). A Pushed dodge made with the horse wears the horse and does not make the Gas Roll three dice. Chapter 4 defines mounted and dismounted; mounting and dismounting are part of a move (OQ-35).
- **Why:** Every Titan Engagement that starts from a riding formation, and every Chase, has soldiers at Distant on horseback. Under the ODM-only pool they dodged with Gear Dice from gear they had not deployed and got nothing from the animal the design gives Gear Dice to (Chapter 1 review 3 Minor 4). Canon's riders live or die by their horses. The pool shape does not change (Agility plus 1 to 3 Gear Dice: a Rookie at Severity 3 dodges 24 / 29 / 34% with Gear 1 / 2 / 3), so no ADR-0014 target moves; what changes is the currency, horse wear instead of gas and ODM wear, which is the right cost for a mounted dodge. A Talent should bend a rule for one Specialty, not paper over a gap for everyone, so Saddle Dodge goes (OQ-28).
- **ADR change:** ADR-0015, add `## Amended`: "After the open-question decisions (2026-09-14, OQ-25): the Reaction's Gear Dice come from ODM Gear, or from the horse while the soldier is mounted, one item per roll (ADR-0006). A Pushed dodge made with the horse wears the horse, not ODM Gear, and does not raise the Gas Roll. Chapter 4 defines mounted."
- **Glossary change:** the Reaction entry as given under OQ-09 needs no gear wording. None further.
- **Chapter impact:** Chapter 1 section 1.9 *Against a Titan*: "The dodge is an Agility roll that takes its Gear Dice from ODM Gear, or from the horse while the soldier is mounted (ADR-0015)". Chapter 2 `data/character/action-catalog.yaml` `dodge.gear: [odm-gear, horse]` with a note "the horse only while mounted (Chapter 4)"; section 2.8's OQ-25 block adds the line. Chapter 3 section 3.7 is unchanged (a Down soldier still cannot dodge). Chapter 4 must define mounted, dismounted, and horse wear at 0 (lame).
- **Revised by batch 2:** The 24%, 29%, and 34% dodge figures were measured at Agility 4; at the amended reference (Agility 3, Stress 1, Severity 3) they are 16.0%, 20.6%, and 25.6% at Gear 1, 2, and 3, and OQ-72 gives the Rookie's ODM Gear rating 2. ADR-0015's wear sentence now says only Gear Dice showing 1 wear the horse (OQ-71 item 3).
- **Revised by batch 2b:** Parity between the horse dodge and the ODM dodge is restored by rating horses as ODM Gear (Major 2); the reference dodge carries no Talent dice (Major 1).

## OQ-26: Catalog entries that are not attribute rolls

- **Decision:** (a). `option` and `fixed-roll` kinds exist so rule Talents can name Help, Cover, Call It, the Fear Roll, the Stress Response roll, and the Gas Roll.
- **Why:** Unchanged.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none.

## OQ-27: Actions outside the Action Catalog

- **Decision:** (e), as drafted, and now the reading ADR-0003 item 9 states (OQ-35): the player names one tracked value; a matching entry is used, the gear rule applies to every use, a `rule-named-value` reaches the attribute alone, and an action that changes no tracked value has no mechanical effect.
- **Why:** With the ADR amended, the procedure is no longer a narrowing of the ADR but its text.
- **ADR change:** see OQ-35.
- **Glossary change:** none.
- **Chapter impact:** Chapter 2 section 2.9's OQ-27 block drops "Whether an action that changes no tracked value should still get a roll needs an ADR-0003 decision, and is logged as an Unresolved Major (OQ-35)" and cites ADR-0003 item 9 as amended.

## OQ-28: Talent list design and Specialty grants

- **Decision:** (a) single-level rule Talents, (c) four shareable Talents per Specialty, (e) key attribute plus swap, floor, and one Talent level, (k) Relentless creates 1 extra Opening on a Nape strike that falls short with at least 1 success. **Saddle Dodge is replaced by Sure Seat**, because OQ-25 gives every mounted soldier the horse on a dodge:
  - `id: sure-seat`, name Sure Seat, description "A seat that keeps the horse sound when a dodge or a hard ride is Pushed.", type rule, max_level 1, names `[dodge, ride, break-attention]`, trigger "A Pushed roll made for a named entry, with your horse as its gear item, is about to wear your horse.", effect "Ignore 1 point of that wear.", limit `once_per_titan_engagement`, rules `[01-core-rules, 04-gear]`, specialties `[rider]`.
  - Sure Seat replaces Saddle Dodge in `specialties.yaml` (Rider) and in the Year 3 event at `training-years.yaml` line 168 (`[horsemanship, sure-seat]`). The nine simulator-check Talents become eight (Saddle Dodge leaves the list; Sure Seat needs no check, it mirrors Well-Kept Rig).
- **Why:** Sure Seat gives the Rider the same relationship to the horse that the Flier and Engineer have to ODM Gear through Well-Kept Rig, stays a rule Talent with a closed trigger, and touches no ADR-0014 target.
- **ADR change:** none.
- **Glossary change:** Opening entry becomes: "A token on a Titan created by successes beyond Breaking a Body Part, extra successes on Break Attention, every success of a Nape strike that falls short, or a rule that names it, such as Relentless. Any ally can spend them as Bonus Dice on a Nape strike until Regeneration erases them."
- **Chapter impact:** Chapter 2 section 2.7 OQ-28 block (Sure Seat replaces the Saddle Dodge sentence; eight simulator checks); `data/character/talents.yaml` (row replaced), `data/character/specialties.yaml` (Rider list), `data/character/training-years.yaml` (line 168).
- **Revised by batch 2:** Sure Seat's description becomes "A seat that keeps the horse sound when a dodge, Ride, or Break Attention made with the horse is Pushed in a Titan Engagement.", since its once-per-Titan-Engagement limit never reaches a Hard Ride (OQ-71 item 3).
- **Revised by batch 3:** The Opening entry's "Any ally can spend them" is replaced under OQ-83: any comrade of the soldier who created it can spend it, and its creator never can.

## OQ-29: Squadmate stat block and which rules apply

- **Decision:** (j) key 4, four at 3, one at 2, one Talent at level 1; (d) never Cover; (g) full gear tracking; (h) Stress Dice; (m) every entry a player character can take. Add `health_lost` to `stat_block.fields` (Chapter 2 Codex review 3 Minor 4). Chapter 4 must give a one-line Squad sheet row for a Squadmate's gear (Gas Rating, spare canisters, Blade Sets, items, ratings) so the table load of six fully tracked soldiers stays within the fable final review's 12 to 20 minutes per round.
- **Why:** Unchanged; the templates are now ADR-0014's Rookie by amendment (OQ-19).
- **ADR change:** see OQ-19.
- **Glossary change:** see OQ-13.
- **Chapter impact:** `data/character/squadmates.yaml` `stat_block.fields` adds `health_lost`; Chapter 4 constraint recorded below.
- **Revised by owner decision: Health boxes.** Squadmates use the same row of boxes with their template Health; `health_lost` keeps its name and no field is added, since boxes crossed off are the untreated entries in their Critical Injuries.
- **Revised by batch 3:** The 12 to 20 minute band binds the typical round, one Focus Titan with 4 player characters and 2 Squadmates; a round against two Focus Titans is bounded at 30 minutes, and a timed paper test with pass criteria and pre-decided fallbacks is ordered (OQ-97).

## OQ-30: Wing limits and directing Squadmates

- **Decision:** (a) one Squadmate per Wing, (d) the Wing's player decides and the D6 roll-off settles the rest, (g) the Squadmate still acts after a turn spent in advance.
- **Why:** Unchanged.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none.

## OQ-31: Starting Squad size and promotion

- **Decision:** (a) 6 minus the player characters, (j) conversion keeping current state and rolling Origin, Why You Enlisted, and three events for 4 Talent levels, (i) Retirement also allows promotion. **Timing changes:** promotion happens when the procedure in which the death or Retirement happened ends, exactly as Retirement is timed (OQ-51 (i)): the last end step of a Titan Engagement, the last step of a day passing, the end of an outside-harm care window and its Death Rolls, or the end of any other procedure as its rule states; at once only if no procedure is under way. Several promotions due together follow OQ-38.
- **Why:** Chapter 3 review 2 (Opus Minor 5) found a player character who dies at step 2 of a day passing promoted at once while one who retires that night waits. One timing rule for both events removes the gap and keeps promotion out of the middle of any procedure.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Chapter 2 section 2.10 *Promotion* step 1 and `data/character/squadmates.yaml` `promotion.timing`: "When the procedure in which the death or Retirement happened ends (Chapter 3, Retirement timing); at once if none is under way."

## OQ-32: Campaign start year and Canon Tie

- **Decision:** (a) and (d), with the year made a current value: the players record the **campaign year** (845 to 850) before the Lifepath. It starts as the year the campaign begins and changes only when a rule names a change; in Phase 1 no rule does, and the Canon Clock rules will advance it. Every Origin condition is tested against the current campaign year, so a character created or promoted later uses the year the campaign has reached. A Canon Tie stays optional, at most one, from Origin rows only, with no Phase 1 effect.
- **Why:** Chapter 2 review 3 Minor 7: a refugee row rerolled in 850 for a campaign that started in 846. A current year is one field and needs no Canon Clock content now.
- **ADR change:** none.
- **Glossary change:** add under Campaign: "**Campaign Year**: The year the campaign has reached, from 845 to 850, recorded before the Lifepath and advanced only by the Canon Clock rules. Origin conditions are tested against it. _Avoid_: start year, current date."
- **Chapter impact:** Chapter 2 section 2.3 (*Before the Lifepath* becomes the campaign year and the Exam vote), `data/character/lifepath.yaml` step 0 (`campaign-year`, and the Exam vote), `data/character/origins.yaml` `condition_fields.campaign_start_year_min` renamed `campaign_year_min` with the text "The row can be kept only if the current campaign year is this year or later."

## OQ-33: Dormant Catalog entries and Lifepath Talent choices

- **Decision:** (a).
- **Why:** Unchanged.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none.

## OQ-34: When rule Talents that change eligibility or cost apply

- **Decision:** (a), the "You declare" trigger.
- **Why:** Unchanged.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none.

## OQ-35: Actions that change no tracked value

- **Decision:** (a) and (f). ADR-0003 item 9 is amended so that an action outside the Catalog changes only a tracked value, and every rule that creates a value soldiers change by acting must add it. Chapter 4 owns and must add, before it is Done:
  - tracked value `item-give` ("give a carried item to a comrade") and the unrolled action `pass-item`: kind action, rolled never, context any; requirement: in a Titan Engagement the receiving comrade holds the passer's Position and is alive (the receiver may be Down; the passer, taking an action, cannot be); outside one, the Chapter 4 rule states it; effect: one carried item moves from the passer to the receiver and counts against the receiver's carrying limit; Chapter 4 lists which items can be passed and may add a thrown pass to one Position step away as a roll it names;
  - mounting and dismounting a horse at the soldier's Position as part of a move, with no roll, and the mounted state that OQ-25 and Rescue Ride use.
  Scene values (an evacuation clock, a collapsing beam) are created by the Operation Frame and hazard rules as tracked values or `rule-named-value`s, which is where the Strength roll for bracing a beam comes from.
- **Why:** Both Codex reviews were right that (c) was unsound while item 9 read as it did, and Opus review 3 was right that the commonest uncatalogued act is Armin handing Mikasa his gas. Amending the ADR states what the game already does and forbids the judgment (b) brings back. Giving Chapter 4 the gear and horse rows puts them with carrying and horses, which that chapter owns.
- **ADR change:** ADR-0003, add `## Amended` (this text also carries OQ-18's item 13; after conformance Minor 9 the amended item 9 and items 12 and 13 stand in the numbered list itself, and `## Amended` is the change log):

  > ## Amended
  >
  > After the open-question decisions (2026-09-14, OQ-18 and OQ-35), item 9 now reads: "An action outside the Action Catalog changes only a tracked value. The player names the value; the action uses a Catalog entry that changes it, or, for a value whose creating rule names an attribute roll, that attribute alone. An action that changes no tracked value has no mechanical effect." Two drafting requirements were added:
  >
  > 12. Every rule that creates a clock, counter, obstacle, or other value that soldiers change by acting adds it to the tracked values with the entries or attribute roll that change it, and every chapter checks that each consequential act in its scope has a tracked value and an entry. Chapter 4 adds passing an item to a comrade and mounting or dismounting a horse.
  > 13. A state or result that forbids Pushing, Helping, Covering, or Reactions names what it forbids on its own row. The core eligibility rules carry one shared hook for state and result bans; core requirements, roll-specific bans, and Squadmate restrictions still apply.
- **Glossary change:** none.
- **Chapter impact:** Chapter 1 section 1.3 step 1 replaces the old "closest Catalog action" paraphrase with amended ADR-0003 item 9 and retains its pointer to Chapter 2; rules may still call directly for a named attribute. Chapter 2 section 2.9 cites the amended item 9 (see OQ-27) and states that Chapter 4 adds `item-give`, `pass-item`, and the mount and dismount move. Chapter 4 adds the rows to `data/character/action-catalog.yaml` (`tracked_values` and `entries`) under the "a later chapter adds a row" pattern.
- **Revised on apply:** The original chapter-impact list missed Chapter 1's quotation of the superseded ADR item 9. The drafter must replace that quotation too.

## OQ-36: Drives and once-per-Titan-Engagement Talents outside a Titan Engagement

- **Decision:** (d). Turn tests apply outside a Titan Engagement only when a rule that creates turns explicitly extends them; Position tests require a Titan Engagement. Freedom's own-flight test works anywhere. A once-per-Titan-Engagement Talent limit applies to another procedure only when that procedure explicitly extends it.
- **Why:** Unchanged.
- **ADR change:** none.
- **Glossary change:** in the Drive entry under OQ-23.
- **Chapter impact:** none.
- **Revised on apply:** Make Freedom's existing exception explicit so the ruling and OQ-23's glossary agree. No new outside-Engagement turn or Talent use is granted.

## OQ-37: Coordinated Help, roll order, and Covering in the Graduation Exam

- **Decision:** (e), folded into OQ-22: the vote comes before the Lifepath, the order within a Trial is rolled, Help in the squad field exercise is a fixed cycle of one helper, and Covering stays limited to a Cadet who has not yet rolled.
- **Why:** Review 3's aimed policy raised Top 10 from 6.3% to 7.6% with free Help and order. Option (a)'s rolled order and cycle Help measured 6.48% against 6.20% for four Cadets, and (e) also closes the vote, the one choice (a) still left with Merit known. The payout change in OQ-22 keeps the mean at parity with one helper (0.612 against 0.583 in the payout model).
- **ADR change:** none.
- **Glossary change:** see OQ-22.
- **Chapter impact:** see OQ-22.

## OQ-38: Several promotions at once

- **Decision:** (c). When several promotions fall due together, every affected player chooses a living Squadmate at the same time. If two or more choose the same one, each rolls a D6, highest takes it, ties roll again. Every player who loses chooses again from the living Squadmates no player has taken, repeating the roll for any Squadmate chosen by more than one of them, until every player has a Squadmate or none is left. A player with none left follows the no-Squadmate branch. Promotions fall due together whenever they resolve at the same moment under OQ-31's timing.
- **Why:** It changes nothing when no Squadmate is contested, adds no ordering roll and no list to record, and uses the roll-off every other shared choice uses.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Chapter 2 section 2.10 *Promotion* step 2 and `data/character/squadmates.yaml` `promotion.contested`. Chapter 3's OQ-38 note is closed.

## OQ-39: Kinds of harm, Titan attacks, and damage at 0 Health

- **Decision:** (a) as revised. Three kinds of harm; a Titan attack is only the harm a Behavior Table entry itself names, always a Critical Injury; the lift and devour are Grab procedure steps with no Severity and no Reaction; damage at 0 Health gives another Critical Injury.
- **Why:** Unchanged.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none. Chapter 4 sizes fall damage against Health 2 to 5; Chapters 5 and 6 never write a killing behavior.
- **Revised by owner decision: Health boxes.** Damage marks only the boxes not crossed off by untreated Critical Injuries; damage at 0 current Health still marks nothing and gives one Critical Injury. A Critical Injury still never adds Health lost, but it crosses off a box, and with no clean box left it takes a damage-marked one (rule 6).
- **Revised by batch 2:** Chapter 4 sizes damage against current Health 1 to 6, not 2 to 5 (OQ-71 item 7).

## OQ-40: Restoring Health

- **Decision:** (a).
- **Why:** Unchanged.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none.
- **Revised by owner decision: Health boxes.** A day passing restores Health lost to damage only; crossed-off boxes come back by treating or healing. Revive is legal only while Health lost to damage is above 0, and does not by itself end a Down caused by crossed-off boxes.

## OQ-41: The Injury Location roll

- **Decision:** (a): 1 to 2 arm, 3 to 4 leg, 5 torso, 6 head; no sides.
- **Why:** Unchanged.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none.

## OQ-42: Critical Injury tables and worsening

- **Decision:** (a) +2 per counting Critical Injury, (e) non-lethal cap rows, (h) instant death only beyond a first roll's reach, (j) healed permanent rows keep counting with `repeat_row`, (m) permanent effects from the moment gained. The rows in `data/harm/critical-injuries.yaml` are the starting values for the ADR-0014 simulator; no row moves now. If the "PC dies every 3 to 4 missions" target comes out low with OQ-54 and OQ-57 in place, the first lever is moving the 11 and 12 results at arm and leg from `engagement` to `turn` limits (Chapter 3 review 1's suggestion), before any Grab lever.
- **Why:** Every figure reproduces (lethal 15.3%, Down 10.6% on a first Critical Injury at a rolled Injury Location). Whether the rows kill enough depends on Chapter 5's Grab and the aftermath rolls, which the simulator measures together.
- **ADR change:** none.
- **Glossary change:** Critical Injury entry's last clause becomes: "Titan attacks inflict these directly, without reducing Health first, and a later injury to the same location is rolled with a worsening bonus."
- **Chapter impact:** Chapter 3 section 3.7 replaces the claim that only one rescue action can meet the target with both regimes and the six-cell probe under OQ-50 in *Round-3 notes*. Section 3.2 and the OQ register use OQ-57's one-patient aftermath model. Critical Injury rows, caps, and worsening remain unchanged.
- **Revised on apply:** The one-action-only conclusion conflicts with OQ-50's tolerance band. The earlier 2.8% treatment figure also rounds incorrectly and assumes Stress 1; use the Stress 0 aftermath figures in *Round-3 notes*. A worsening bonus changes the roll, not a guarantee that the new injury exceeds the old one.
- **Revised by owner decision: Health boxes.** Down on a first Critical Injury stays 10.6% (Down rows only), but the number of untreated injuries before Down now follows Health: mean 1.89 at Health 2, 2.65 at Health 3, 3.25 at Health 4, 3.70 at Health 5, against 2.65 for everyone before. The first lever stands.

## OQ-43: Lethal time limits and Death Roll outcomes

- **Decision:** (a) turn, engagement, day; (c) a `turn` limit runs out at the end of each of the soldier's turns from the first that begins after the injury; (e) 0 dies, 1 lives, 2 or more slows one step; (i) an immediate care window then one Death Roll outside a Titan Engagement.
- **Why:** Unchanged.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none.

## OQ-44: Treat Injury and care windows

- **Decision:** Keep (a), (d), (f), (h), (o), and (l), with every care-window patient required to be a living soldier in that window's scope. Outside-harm windows still treat only injuries or Down states caused by that event. The sentence: "A care-window patient must be a living soldier in that window's scope. Its scope restricts patients as well as rollers, helpers, and Coverers." No Position test is added inside a care window; aftermath rolls keep their own Position requirement and OQ-56's rule for leavers.
- **Why:** The same scope must constrain patients, rollers, helpers, and Coverers; otherwise a medic can treat an absent soldier. The existing uses, costs, and event-only retry restriction remain sound.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Chapter 3 section 3.5 and `data/harm/treat-injury.yaml` `care_windows.who_rolls` and `patients` add the patient scope sentence; `who_rolls` replaces "any use and patient" with "any legal use and patient within this window's scope".
- **Revised on apply:** The earlier (o) ruling closed remote rollers but left remote patients legal. Require both ends of treatment to be inside the same care window.
- **Revised by owner decision: Health boxes.** Revive's patient is a Down soldier at current Health 0 with Health lost to damage above 0; treat's `down-end` now works by giving back a box. Both stay separate uses the players choose.

## OQ-45: Down

- **Decision:** (a), (c), (f), (h), (j), (l), as drafted. `down.yaml` gains `forbids: [push, help, cover, reaction]` under OQ-18. A Down soldier can be the roller of no attribute roll but the Death Roll, so the question whether a Down roller can be Helped (Chapter 1 review 3 Minor 7) does not arise.
- **Why:** Unchanged.
- **ADR change:** none.
- **Glossary change:** Down entry becomes: "The state of a human at 0 Health, with three untreated Critical Injuries, or holding an untreated Critical Injury whose row says so, who can do little more than crawl. Reaching 0 Health also inflicts an immediate Critical Injury."
- **Chapter impact:** `data/harm/down.yaml` adds the `forbids` row (OQ-18). Its `ending.after_ending` and Chapter 3 section 3.3 state that the action of a turn that begins while Down counts as spent for every rule that asks, and remains spent if Down ends during or after that turn. A future turn already spent by a Reaction or result stays wholly spent.
- **Revised on apply:** Round-3 Minor 5 found that "has no action" could be read as an unspent action after recovery. Count it as spent under OQ-17, without removing an action from a turn that has not begun.
- **Revised by owner decision: Health boxes.** Down has two conditions, current Health 0 and a Down row; the three-untreated condition and the glossary text above are superseded by the Health boxes section, and the ending routes are those listed there. The forbids row and the spent-action ruling stand.

## OQ-46: Results that spend a turn or action, or forbid Reactions

- **Decision:** (e). A result spends a turn by the Reaction's rule; a ban on Reactions lasts until the end of the first of the soldier's turns to begin after it (the second for a two-turn row) and ends with the Titan Engagement. The OQ-17 dependency is closed: a turn a result spends begins its round with its move and action spent, so the soldier cannot Help that round.
- **Why:** Unchanged.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Chapter 3 section 3.9 OQ-46 block and `data/harm/effect-types.yaml` `spend-next-turn` (see OQ-17).

## OQ-47: The Stress Response table

- **Decision:** (a), (d), (g). The rows in `data/mind/stress-responses.yaml` are the starting values.
- **Why:** The OQ-04 trajectory run with these rows shows no spiral: Hair Trigger and Botched together move a Rookie's median peak Stress from 2 to 2.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none.

## OQ-48: Rally

- **Decision:** (a), (c), (e).
- **Why:** Unchanged.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none.

## OQ-49: Fear Roll triggers

- **Decision:** (a) five triggers, (d) one per soldier per event and none while Down, (f) outside a Titan Engagement only where the creating rule names who rolls, (h) `faced_a_titan` set when first holding a Position. The Drive note is resolved by OQ-23's change to Pay It Forward; Fear Roll timing ("as soon as the event has been fully resolved") does not change.
- **Why:** Unchanged.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none in Chapter 3. OQ-49's Drive note is closed in step 2.

## OQ-50: The Fear Roll table and what a Drive shrugs off

- **Decision:** Keep (a) and (d), all current Fear Roll rows including Hesitate, and the existing six-cell tolerance band. Reject the requirement that Chapter 5 allow only about one rescue action per comrade. Both one-action and two-action rescue structures are permitted, with reach and strike penalties stated in data; a single baseline result near one third does not satisfy the band. *Round-3 notes* records the supporting probe. No automatic future replacement of Hesitate is authorized.
- **Why:** The two-action probe meets the band without changing Fear, Toughness 1, or the victim-turn countdown. The one-action-only requirement was an inference from an unpenalized strike model, not a rule justified by ADR-0014.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Chapter 3 sections 3.7 and 3.12, OQ-42's model conclusion, and Chapter 5's drafting constraints adopt the distinction between the two rescue structures and the six-cell table in *Round-3 notes*. No Fear table YAML row changes; delete the conditional instruction to replace Hesitate.
- **Revised on apply:** The previous tuning order required a rescue structure that breaks its own worst-cell bound. Keep the table and the bound, remove the one-action restriction and automatic Hesitate fallback, and permit the two-action alternative demonstrated by the probe.
- **Revised by owner decision: Health boxes.** The Grab probes are unchanged for a fresh victim (60.0% against 60.1% alone in the lone-Rookie model); only a victim already carrying untreated injuries moves, as recorded under Health boxes. The six-cell band stands.
- **Revised by batch 3b:** "Both one-action and two-action rescue structures are permitted" is settled: Chapter 5 uses the one-strike-per-comrade structure with the reach narrowing after the lift (OQ-85), and ADR-0014 defines "comrades close" as one comrade in reach (OQ-95). Chapter 3 section 3.7's standing models and "permitted structures" are replaced by a pointer to Chapter 5 section 5.13 (3b-7); the six-cell band is unchanged.

## OQ-51: Scars and Retirement timing

- **Decision:** (a) two triggers, (e) D66 table, (i) Retirement at the end of the procedure in which the fifth Scar was gained, (j) Survivor's Guilt after the death's Fear Roll. Promotion now shares (i)'s timing (OQ-31).
- **Why:** Unchanged.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none.

## OQ-52: Grief

- **Decision:** Keep (k), (c) with (l) and (n), (e), (g), and (i), and relief of at least 2 Grief per Downtime when used. Grief from a death applies only after every Fear Roll caused by that death resolves, including any Drive choice; if none is made, apply it at the existing timing. Titan Engagement deaths still wait until end step 8. Outside one, apply it immediately after those Fear Rolls, preserving the event/day caps and per-death additions.
- **Why:** Unchanged.
- **ADR change:** none.
- **Glossary change:** Grief entry becomes: "The weight a soldier carries after a comrade dies, gained by the fight's participants when it ends, or by the Squad after other deaths and any Fear Rolls they cause. Each point lowers Resolve by 1, up to 3 held, until dealt with during Downtime."
- **Chapter impact:** Chapter 3 sections 3.12 and 3.14 and `data/mind/grief.yaml` `gaining.timing` add `gaining.applies_after: Every Fear Roll caused by the same death, including its Drive decision and result.` and the timing above; `fear-rolls.yaml` `limits.timing` cross-references it. No change to Survivor's Guilt's own post-Fear timing or to the cap.
- **Revised on apply:** "Otherwise at once" allowed a death's Grief to worsen its own Fear Roll, contrary to the reason for delayed Grief and OQ-51's Survivor's Guilt order. Resolve the death's Fear Rolls before applying its Grief everywhere.

## OQ-53: Healing time in days

- **Decision:** (a).
- **Why:** Unchanged.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none.
- **Revised by owner decision: Health boxes.** A Critical Injury that heals while untreated gives back its Health box; `healing.yaml` `heals` says so instead of "no longer counts toward Down".

## OQ-54: What resolves when a Titan Engagement ends, and in what order

- **Decision:** Keep (b), (c), (g), and (i), with step 5 using OQ-57's one-roll-per-patient and one-roll-per-treater limits. Step 9 includes every death and Retirement during the fight or any end step, including step-6 deaths, and uses OQ-38's complete contest procedure. Step 7 explicitly recognizes Scars from lethal injuries stabilized at step 5 as well as step 7.
- **Why:** Unchanged. Review round 2's stalling incentive is answered by OQ-57.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Chapter 3 section 3.16 and `data/harm/engagement-end.yaml` step 5 adopt OQ-57's limits; step 7 adds "or at the aftermath-rolls step"; step 9 names the full promotion batch. Update the OQ-54 aftermath reasoning to the one-patient model.
- **Revised on apply:** The retained nine-step order must use the revised OQ-57 limit. Calling the end steps outside the fight does not remove their deaths from the promotion batch or defer a stabilization Scar.
- **Revised by owner decision: Health boxes.** A successful aftermath roll at step 5 gives back the treated injury's box and can end Down there; step 8's Grief and step 9's batch are unchanged.

## OQ-55: Sheet fields Chapter 3 adds

- **Decision:** (a), and now that Chapter 2 is reopened: `data/character/lifepath.yaml` `record_on_sheet` and `data/character/squadmates.yaml` `stat_block.fields` each end with a reference row to `data/harm/sheet-fields.yaml`; `promotion.steps` names that file among what a promoted Squadmate keeps; and Chapter 2 states that once-per-Titan-Engagement Talent uses are recorded on the sheet beside the Talent.
- **Why:** Chapter 3 Codex review 2 Minor 4: a literal reading of the promotion list could drop a healed Lost Arm.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Chapter 2 sections 2.1 and 2.10; `lifepath.yaml`, `squadmates.yaml`.
- **Revised by owner decision: Health boxes.** No stored field is added: current Health is derived from `health`, `health_lost`, and the untreated entries in `critical_injuries`, and `sheet-fields.yaml` records the derivation, the invariant, and the paper marks (slash for damage, X for an untreated Critical Injury).

## OQ-56: A soldier who leaves a Titan Engagement while it goes on

- **Decision:** (a). Chapter 5 states how a soldier leaves and what their move and action can do after, and may narrow the same-Position rule for soldiers who left.
- **Why:** Unchanged.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none.

## OQ-57: Aftermath rolls at the end of a Titan Engagement

- **Decision:** One aftermath roll per patient and at most one per treater. The players choose an eligible living, non-Down treater at the patient's ending Position or one step away, or the non-Down patient treats themselves with the usual penalty. That roll treats one chosen untreated lethal `engagement` Critical Injury, including a converted `turn` limit. Failure consumes the patient's attempt; another treater or another injury cannot reopen it. No Help or Cover; Pushing, including Sure Hands, remains legal. OQ-56 governs leavers. This spends no roll in the subsequent care window.
- **Why:** The per-treater limit alone makes a clustered Squad nearly immune to engagement-limit bleeding. One patient attempt preserves an immediate chance to save a comrade without permitting serial free attempts. Delay can still buy another in-fight treatment or close a two-step gap, at the price of further Titan cards; the decision does not claim to eliminate that trade.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Chapter 3 sections 3.4, 3.5, 3.7, 3.16, and the worked example; `treat-injury.yaml` `aftermath_rolls`, `engagement-end.yaml` step 5, and `death-rolls.yaml` engagement-limit reference. The example chooses Mila for Oskar's sole aftermath roll and removes his second attempt. In the care window, Hale rolls Wits 2 without a kit on Oskar instead of spending Help for zero added dice. OQ-42 and OQ-54 use the revised lethality figures.
- **Revised on apply:** The earlier decision counted one attempt in its reasoning but allowed one from every nearby soldier. Cap attempts by patient as well as treater and replace "removes the stalling incentive" with the measured remaining trade.
- **Revised by owner decision: Health boxes.** A successful aftermath roll also gives back the injury's box, which can end a Down caused by crossed-off boxes before the Death Rolls.

## Round-3 notes

The third Chapter 3 reviews (`docs/reviews/03-harm-and-mind-review-3.md`, `-review-3-codex.md`) added six `Round-3 note:` lines to five entries. Each note was checked against the decision it questions; four changed a decision and one confirmed it. The rulings are folded into the OQ-38, OQ-44, OQ-50, OQ-52, and OQ-57 sections above, which are the text to draft from. This section records only what each note changed and the probes behind the numbers. The register ended at OQ-57 at the time; no note created a new entry.

- **OQ-38 (Opus M3, Codex M1): confirmed, scope made explicit.** OQ-31's timing already puts every death of a fight, including a failed step-6 Death Roll, into end step 9, so a player character never has two promotion times. OQ-38 (c) already gives the player who loses a contest their next step. Two things are added: five-Scar soldiers retire and retiring Squadmates leave the Squad Pool before anyone chooses a replacement, and the same contest procedure serves every batch that OQ-31 times together, not only end step 9.
- **OQ-44 (Codex M2): changed.** Every care-window patient must be a living soldier in that window's scope, the same scope that limits rollers, helpers, and Coverers. The outside-harm window still treats only the injuries and Down states its event caused.
- **OQ-50 (Opus M2): changed.** The earlier tuning order told Chapter 5 that about one rescue action per comrade was needed, and that regime breaks the band's worst cell. The Fear rows, the six-cell band, Toughness 1, and the victim-turn countdown all stay; Chapter 5 may use either rescue structure, must state reach and strike penalties in data, and must pass all six cells. The conditional instruction to replace Hesitate is withdrawn. The probe (30,000 trials per cell): victim Strength 4, Grip Breaker 1, Blade Set 1, Stress 2, Resolve 3, no prior torso injury, two unspent Break Free turns needing 3 successes, Pushing when short; crushing injury from the real torso rows with the non-lethal cap; rescuers Strength 4, Talent 1, Blade Set 1, Resolve 3 before Grief, striking before each victim turn, needing 2 accumulated hand successes, Pushing on 0 successes; Fear results spend rescue actions; Stress Responses lose successes, add Shaking Hands, Hair Trigger, and Locked Up debt. No Help, Cover, Drive, extra Scar, intervening Titan card, Regeneration, or gear depletion.

| Witness Stress | Grief | Two comrades, one strike each, no strike penalty | One comrade, two strikes, 3-die strike penalty |
|---|---|---|---|
| 1 | 0 | 26.2% | 30.4% |
| 2 | 0 | 33.6% | 32.3% |
| 3 | 0 | 42.7% | 35.8% |
| 1 | 1 | 35.6% | 35.5% |
| 2 | 1 | 43.0% | 38.1% |
| 3 | 1 | 52.5% | 40.6% |

- **OQ-52 (Codex M3): changed.** Grief from a death applies only after every Fear Roll that death causes has resolved, Drive choice included, everywhere: at end step 8 in a Titan Engagement, and "immediately after every Fear Roll caused by that death; immediately if none is made" outside one. Applying Grief first would raise a Stress 2, Resolve 3 witness's chance of losing an action or turn from 50.0% to 66.7% (exact D6 enumeration), which is the outcome delayed Grief exists to prevent.
- **OQ-57 (Opus M1): changed.** One aftermath roll per patient as well as one per treater. With one per treater only, three untrained soldiers within a step left an untreated `engagement` row fatal 3.8% of the time, near the figure review round 1 rejected. The treatment probe (100,000 trials per cell, Stress 0 aftermath, one Push on 0 successes, patient Strength 3, no Death Roll penalty, no Help, Cover, Sure Hands, or further Titan cards) gives the trade that remains when a Squad delays the end of a fight:

| Available treater | End now: one aftermath roll at Stress 0 | Delay: one in-fight roll at Stress 1, then aftermath at Stress 0 |
|---|---|---|
| Wits 2, no kit | 23.2% death | 7.8% death |
| Wits 2, kit 1 | 19.4% death | 5.5% death |
| Rookie Medic: Wits 4, Field Medicine 1, kit 1 | 6.4% death | 0.8% death |
| Wits 2, no kit, two steps away | 57.9% death, no eligible aftermath treater | 23.2% death, one move brings the treater within one step |

  Across first Critical Injuries at a rolled Injury Location, the `engagement`-limit contribution to death is about 8.5% with no treatment, 3.4% with one Wits 2 treater without a kit, and 0.9% with one Rookie Medic. The earlier untrained figure at Stress 1 rounds to 2.9%, not 2.8%. Delay rates multiply independent treatment estimates and leave out the extra Titan cards' harm.
- **OQ-45 (review 3 Minors 5 and 7): wording.** The action of a turn that begins while the soldier is Down counts as spent for every rule that asks, and stays spent if Down ends during that turn; a turn that has not begun keeps its action. Section 3.12 says that `first-titan-engagement` makes only that soldier roll, while the Abnormal and second-Focus-Titan triggers make every soldier holding a Position roll, as the YAML already does.

The probes ran in a temporary directory outside the repository; their assumptions are recorded above so nothing depends on those files surviving.

## Owner decision: Health boxes

- **Decision:** Final, by the owner; the rules below integrate it and settle its edge cases.
  1. **Health** is half of Strength plus Agility, rounded up, and the sheet keeps it as a row of that many boxes. A box is clean, marked by damage, or crossed off by a Critical Injury.
  2. **Each untreated Critical Injury crosses off one box**, whatever inflicted it. Titan attacks still inflict Critical Injuries directly and never add Health lost to damage.
  3. **Treating a Critical Injury gives its box back.** The injury keeps its effects, permanent effects, lethality, time limit, and healing time. A Critical Injury that heals while untreated also gives its box back.
  4. **Current Health** is Health minus boxes crossed off minus Health lost to damage, never below 0. Boxes crossed off is the smaller of the untreated Critical Injuries held and Health. So a soldier can hold more untreated Critical Injuries than Health: the extra ones cross off nothing, and treating one of them gives back no box until fewer untreated Critical Injuries remain than the soldier has Health.
  5. **Damage marks the boxes left.** Add the amount to Health lost to damage, up to Health minus boxes crossed off. Damage that brings current Health to 0 makes the soldier Down and inflicts one Critical Injury at once, as now. Damage taken while current Health is already 0 marks nothing and inflicts one Critical Injury at once, as now.
  6. **A Critical Injury with no clean box left crosses off a box marked by damage**, and Health lost to damage falls by 1. When every box is already crossed off, it crosses off none. Health lost to damage is therefore never more than Health minus boxes crossed off.
  7. **Down** has two conditions: current Health 0, or an untreated Critical Injury whose row says Down. The "three untreated Critical Injuries" condition is deleted. A Critical Injury that crosses off the last box makes the soldier Down and inflicts no further Critical Injury.
  8. **Down ends** at once when current Health is above 0 and no untreated Down-row Critical Injury is held. The routes are: treating or healing a Critical Injury gives back a box; a revive erases damage marks; a day passing erases all damage marks. Nothing else ends Down, and ending it restores nothing already spent (OQ-45).
  9. **Revive** is legal only on a Down soldier at current Health 0 whose Health lost to damage is above 0, and restores 1 per success. If the boxes crossed off still fill the row, the revive still counts as that treater's roll and Down goes on. Treat and revive stay separate uses that the players choose (OQ-44). When damage brought the soldier to 0 and the immediate Critical Injury crossed off a damage-marked box (rule 6), one success on a revive raises current Health to 1 and ends Down, exactly as before this decision.
  10. **Order.** Damage reaching 0: mark the damage, the soldier is Down, gain the Critical Injury (rule 6 applies), check Down again. A Critical Injury crossing off the last box: cross it off, the soldier is Down, no further step. A Death Roll, time limit, worsening bonus, non-lethal cap, and healing time are untouched.
  11. **Squadmates** use the same rule with their stat block's Health (3 or 4 on the templates) and Health lost; their Critical Injuries list gives the boxes crossed off. No Squadmate rule changes.
  12. **Sheet fields.** `health` (the rating) and `health_lost` (Health lost to damage) keep their names. Boxes crossed off are not a stored field: they are the untreated entries in `critical_injuries`. Current Health is derived as `max(0, health - min(untreated_critical_injuries, health) - health_lost)`, with the invariant `health_lost <= health - min(untreated_critical_injuries, health)`. On paper, the Health row of boxes takes a slash for damage and an X for an untreated Critical Injury; treating erases the X, a day or a revive erases slashes. `data/harm/sheet-fields.yaml` records the derivation and the invariant.
  13. **Chapter 4** sizes damage such as falls against current Health, since a soldier with boxes crossed off has fewer to lose; its range is 1 to 6 (Health 6 is a legal build; corrected under OQ-71 item 7).
- **Why:** The owner's reasons stand: one row of boxes on the sheet that every kind of harm reads, no separate injury count, and a soldier's frame deciding how much punishment they carry before they drop, which the flat three-injury rule ignored. Rules 4 and 6 are what make the row consistent (the marks never exceed the boxes) and keep the revive working with one success, which the current care-window odds assume. Deleting the three-injury condition rather than keeping it beside the boxes follows the owner's point 5. Odds, from a 100,000-trial model of untreated Titan-attack Critical Injuries at rolled Injury Locations using the real tables, worsening, and Down rows (`health_boxes_sim.py`):
  - **Injuries before Down.** The first Critical Injury puts a soldier Down 10.6% of the time under both rules (Down rows only), and the second 24% cumulative. Under the old rule every build was Down by the third untreated injury (mean 2.65 injuries). Under Health boxes: Health 2 (Strength 2 and Agility 2, about 11% of Hunters, Medics, and Engineers under OQ-19) is Down by the second, mean 1.89; Health 3 (a Rookie whose key attribute is neither Strength nor Agility, and the Health 3 Squadmate templates) is unchanged at 2.65; Health 4 (the ADR-0014 Rookie with Strength 4 and Agility 3, and the Veteran with Strength 5) is Down by the third 39.6% of the time and by the fourth always, mean 3.25; Health 5 (Levi-grade, Strength 6 and Agility 4) is Down by the third 39.5%, by the fourth 55.5%, mean 3.70.
  - **Grab.** In the lone-Rookie model (Strength 4, Grip Breaker 1, Blade Set 1, Stress 2, Resolve 3, two Break Free turns needing 3 successes, crushing injury from the real torso rows with the non-lethal cap), a fresh victim dies 60.0% of the time under the old rule and 60.1% under Health boxes, against ADR-0014's "about 2 in 3 when alone". The Down check the Grab hinges on is the crushing row itself, so the comrades-close case moves for the same reason not at all, and the targets are not changed. The rule moves only a victim already carrying untreated injuries: with two untreated leg injuries and Health 4, old 100% (the crushing injury was the third), new 60.1%; two untreated torso injuries, Health 4: 100% to 88.5% (the worsening bonus makes the Caved-In Chest cap likely); Health 3 with two prior: 100% under both; Health 5 with three prior leg injuries: 100% to 60.2%; Health 2 with one prior: 60.1% to 100%.
  - The simulator therefore reports Expedition and Grab results for Health 2 and Health 5 builds beside the reference builds, since Health now spreads the Down point across four values that the three-injury rule collapsed to one.
- **ADR change:** ADR-0005, add `## Amended`:

  > ## Amended
  >
  > After the owner decision on Health boxes (2026-09-14): Health is half of Strength plus Agility, rounded up, kept as a row of boxes. Each untreated Critical Injury crosses off one box and treating it gives the box back; Titan attacks still inflict Critical Injuries directly and cause no Health loss of their own. Damage marks the boxes left. A soldier whose current Health is 0, from crossed-off boxes, damage, or both, is Down, which replaces the earlier rule that three untreated Critical Injuries put a soldier Down; a row that says Down still does. Damage that brings current Health to 0 still inflicts one immediate Critical Injury; a Critical Injury that crosses off the last box does not. A day passing restores Health lost to damage, not crossed-off boxes.
- **Glossary change:** Health entry becomes: "How much punishment a character can absorb before they can no longer act: half of Strength plus Agility, rounded up, kept as a row of boxes. Each untreated Critical Injury crosses off one box, damage marks the boxes left, and at 0 the soldier is Down." Critical Injury entry becomes: "A lasting wound tied to an Injury Location, labeled with whether it puts the soldier Down, whether it is lethal and how fast, its effect, and its healing time. Titan attacks inflict these directly, without reducing Health first; each one crosses off a Health box until it is treated, and a later injury to the same location is rolled with a worsening bonus." Down entry becomes: "The state of a human at 0 current Health, whether from damage or from untreated Critical Injuries crossing off every Health box, or holding an untreated Critical Injury whose row says so, who can do little more than crawl. Reaching 0 Health through damage also inflicts an immediate Critical Injury." These supersede the Health text under OQ-24, the Critical Injury text under OQ-42, and the Down text under OQ-45.
- **Chapter impact:** Chapter 3 section 3.1 (Health as a row of boxes; current Health; the damage procedure marks from what is left, with rule 6; the OQ-39 and OQ-40 PROVISIONAL blocks), 3.2 (treating gives the box back; drop "stops the Critical Injury counting toward the three untreated"), 3.3 (two Down conditions; the check list; ending routes; the PROVISIONAL block's "third condition"), 3.5 (revive's patient and rule 9), 3.6 (a day restores Health lost to damage only; healing gives the box back), the sheet paragraph, and the worked example wherever it counts injuries toward Down. YAML: `data/harm/health.yaml` (`health.current`, `current_min`, the damage procedure, `harm_kinds[critical-injury].health_lost` becomes "crosses off one Health box while untreated", `restoring.revive.who`, `restoring.day-passes.amount`), `data/harm/down.yaml` (delete `three-untreated`; `ending.routes`), `data/harm/critical-injuries.yaml` (`held_injuries.treated`), `data/harm/treat-injury.yaml` (`uses.revive.patient`), `data/harm/healing.yaml` (`heals` and the day step), `data/harm/sheet-fields.yaml` (derived current Health and the invariant). Chapter 2 section 2.2 (Health line gains "kept as a row of boxes (Chapter 3)"), section 2.1's sheet list, and `data/character/squadmates.yaml` line 18's comment; no Chapter 1 text mentions the Down conditions. Chapter 4 constraint recorded below.

## Conformance follow-up

After the decisions were applied to Chapters 1 to 3, the conformance reviews (`docs/reviews/01-03-decisions-conformance-review-1.md`, `-codex.md`) left one new entry and three Minor findings that need an ADR or glossary edit. They are decided here in the file's format.

### OQ-58: The reference builds' Health under Health boxes

- **Decision:** (a), made exact. ADR-0014's reference builds name their Strength and Agility, and so their Health and Resolve:
  - **Rookie:** Strength 4, Agility 3, Wits 2, and 3 elsewhere; Health 4, Resolve 3, Talent 1, Gear Dice 1. This is the Slayer Squadmate template.
  - **Veteran:** Strength 5, Agility 3, and 3 elsewhere; Health 4, Resolve 5 with its two Scars, Talent 2, Gear Dice 2.
  - **Levi-grade:** Strength 6, Agility 4, and 4 elsewhere; Health 5, Resolve 4, Talent 3, Gear Dice 3.
  - The key attribute is Strength for every build. Every target that depends on Health is also **reported, not tuned**, for the same Squad with every soldier at Strength 3 and Agility 3 (Health 3), and the Chapter 3 figures that quote Health 2 and Health 5 builds are reported beside them. The targets themselves stay measured on the reference builds. Options (b) and (c) are rejected.
- **Why:** ADR-0014's solo targets are Strength rolls (the Nape strike; Break Free in the Grab), so the reference soldier's key attribute has been Strength since the ADR was written, and the OQ-19 amendment's "dodging with Agility 3" already treats Agility as a non-key 3. Under (a) no figure moves: the Health boxes odds, the lone-Rookie Grab model (Strength 4, Health 4), the OQ-50 probes, and the Chapter 3 design note all already assume it. (b) would take one base die off every strike and Break Free figure quoted so far and re-baseline PC death without a reason; (c) makes the baseline depend on which templates a table picks. The gap the entry asks for, from the Health boxes model: mean untreated injuries before Down are 3.25 at Health 4 and 2.65 at Health 3, and a Squad drawn from the nine templates in equal shares (four at Health 4, five at Health 3) sits at 2.92; the Grab does not move for a fresh victim (60.0% against 60.1% alone), and for a victim with one earlier untreated injury it is 60% at either Health, with two earlier injuries 60% at Health 4 and 100% at Health 3. Reporting the Health 3 Squad beside the target keeps that spread visible without splitting the baseline.
- **ADR change:** ADR-0014, appended to `## Amended`: "After the conformance review of the decisions (2026-09-14, OQ-58): each reference build names its Strength and Agility, and so its Health under ADR-0005 as amended. The Rookie is Strength 4, Agility 3, Wits 2, and 3 elsewhere (the Slayer template: Health 4, Resolve 3). The Veteran is Strength 5, Agility 3, and 3 elsewhere (Health 4, Resolve 5 with its two Scars). The Levi-grade soldier is Strength 6, Agility 4, and 4 elsewhere (Health 5, Resolve 4). The key attribute is Strength because the solo Nape-strike and Grab targets are Strength rolls. Every target that depends on Health is also reported, not tuned, for the same Squad with every soldier at Strength 3 and Agility 3 (Health 3, the majority of the Squadmate templates), and the Chapter 3 figures that quote Health 2 and Health 5 builds are reported beside them." Applied.
- **Glossary change:** none.
- **Chapter impact:** Chapter 3 section 3.2: the `PROVISIONAL (OQ-58)` block becomes a design note stating the decided builds and the Health 3 report, citing ADR-0014 as amended; section 3.7 *Earlier injuries* keeps its Health-named figures. Chapter 2 section 2.10: the `PROVISIONAL (OQ-58)` sentence becomes "The simulator's reference Rookie is the Slayer template (Strength 4, Agility 3, Health 4), ADR-0014 as amended (OQ-58); targets are also reported for a Squad of Health 3 soldiers." Section 2.2's OQ-19 design note and `data/character/squadmates.yaml` `templates` comment cite OQ-58 where they call the templates ADR-0014's Rookie; `squadmates.yaml` `decided:` adds OQ-58. The Chapter 3 YAML needs no change.
- **Revised by batch 2:** The Rookie has the Slayer template's attributes, not the template's Talent (OQ-70); the Veteran is Wits 2, 19 points (OQ-71 item 2); the Health 3 report Squad is the reference Squad with Health set to 3 and nothing else changed (OQ-71 item 1); the Rookie's ODM Gear is rated 2 (OQ-72); batch 2b rates the Rookie's horse 2 and fixes the no-Talent dodge.

### Conformance Minor 8: a Reaction is not made on an enemy's turn

- **Decision:** The glossary Reaction entry reads: "A dodge or block made when an enemy acts against the soldier, outside the soldier's own turn. It spends the soldier's earliest turn, starting with this round's, whose move and action are both unspent. Against a Titan, one dodge covers all of that Titan's cards for the round, and blocking is impossible."
- **Why:** Titans act from Behavior Tables and take no turns (ADR-0001); Chapter 1 section 1.9 already says a Reaction is made when a card resolves a behavior. The glossary kept the old "during an enemy's turn" through the OQ-09 edit.
- **ADR change:** none.
- **Glossary change:** Reaction, as above. Applied.
- **Chapter impact:** none; the drafter has already applied the same wording to Chapter 2 section 2.8's `kind` row and `data/character/action-catalog.yaml`.

### Conformance Minor 9: ADR-0003's checklist shows the superseded item 9

- **Decision:** Fix option 2. ADR-0003's numbered list now carries the amended item 9 and items 12 and 13 in the body; `## Amended` becomes the change log, quoting the original item 9 and noting why it was removed from the list.
- **Why:** The checklist is what drafters and reviewers apply item by item; ADR-0001's amendment set the precedent of removing superseded wording from the body. Leaving the old item 9 in the list invited a Chapter 4 row that borrows "the closest catalog action".
- **ADR change:** ADR-0003, body and `## Amended`, as above. Applied.
- **Glossary change:** none.
- **Chapter impact:** Chapter 1 section 1.3 and Chapter 2 section 2.9 may cite "ADR-0003 item 9" without "as amended"; no rule changes.

### Conformance Minor 11: glossary Health and Down wording

- **Decision:** Health reads "... kept as a row of boxes. Each untreated Critical Injury crosses off one box, up to Health; damage marks the boxes left; at 0 the soldier is Down." Down reads "The state of a human at 0 current Health, whether from damage, from untreated Critical Injuries crossing off every Health box, or both, or holding an untreated Critical Injury whose row says so, ...".
- **Why:** The Health boxes decision caps boxes crossed off at Health (rule 4) and ADR-0005 says "from crossed-off boxes, damage, or both"; the glossary omitted both, and a reader could take the Down causes as exclusive.
- **ADR change:** none.
- **Glossary change:** Health and Down, as above. Applied.
- **Chapter impact:** none; the drafter has already applied the `health.yaml` pointer and header fixes and the section 3.3 exception.

## Consistency check

- **Turn state.** OQ-17 (c) sets the spent state at the start of a round. OQ-09 (b), OQ-15, OQ-16, OQ-30 (g), OQ-45 (l), and OQ-46 (e) all read that state and none contradicts it: a Wing Squadmate still acts after a spent turn (OQ-30), a Down soldier's turn has a move and no action, that action counting as spent (OQ-45), and a result-spent turn is identical to a Reaction-spent one (OQ-46).
- **Forbid hook.** OQ-18's hook is used by Down (OQ-45), Grabbed (Chapter 5), the Exam's Cover limit (OQ-22), and the three Fear rows that ban Reactions. OQ-06's Cover rule and OQ-08's Help rule gain only the hook line. Pushing keeps its roll-rule exception (a Death Roll) and gains the state hook; a Grabbed soldier can Push, which the OQ-50 Grab probes assume.
- **Gear on the dodge.** OQ-25's horse clause, OQ-12's Gas Roll flag, OQ-28's Sure Seat, and ADR-0015's amendment say the same thing: a mounted dodge costs horse wear, not gas.
- **Tracked values.** OQ-35's ADR-0003 item 9 is OQ-27 (e)'s procedure; `pass-item` and mounting are Chapter 4 rows; scene values are Operation Frame and hazard rows. Chapter 1's ADR paraphrase and Chapter 2's reference text change; Chapter 3 needs no new tracked value.
- **Exam.** OQ-22, OQ-37, OQ-05 (the Stress Response hook), OQ-18 (the Cover state), and OQ-32 (the vote at the campaign-year step) fit together; `graduation-exam-ends` still resets Stress; Trials 1 and 2 forbid a Push through their own rule, which section 1.5 already allows.
- **Promotion and Retirement.** OQ-31's timing equals OQ-51 (i); OQ-38 (c) orders contested promotions and the Round-3 ruling puts every end-step death in the batch; Chapter 3's end step 9 names that batch.
- **Reference builds.** ADR-0014's amendment (OQ-19) matches the Squadmate templates (OQ-29) and Chapter 1 review 3's dodge figures move from Agility 4 to Agility 3 for non-Fliers, which is why Chapters 5 and 6 tune Severity against 3. OQ-58 fixes the builds' Strength and Agility, so the same builds give Health 4 (Rookie, Veteran) and 5 (Levi-grade) for the Health boxes figures, with a Health 3 Squad reported beside them. Batch 2 keeps the attributes, gives the Rookie Talent 1 per measured roll and ODM Gear 2, and makes the Veteran a 19-point build (OQ-70, OQ-71, OQ-72). Batch 2b fixes the no-Talent dodge, the rating 2 horse, and the ADR-0014 body text.
- **Drives.** OQ-23's Pay It Forward change and OQ-49's timing are consistent: the Fear Roll still resolves at once; the Drive's test looks back over acts since the last turn began and forward to the comrade's state now. OQ-52's Grief order comes after those Fear Rolls.
- **Health boxes.** The owner decision, OQ-39 (damage at 0 still gives a Critical Injury), OQ-40 (a day restores Health lost to damage), OQ-42 (first-injury Down odds unchanged), OQ-44 (revive and treat as separate uses), OQ-45 (Down conditions and ending), OQ-53 (healing gives the box back), OQ-55 (no new stored field), and OQ-57 (a successful aftermath roll gives back a box and can end Down at step 5) all read the same derived current Health. The Grab probes under OQ-50 are unaffected for a fresh victim.
- **Treatment.** OQ-44's scope rule, OQ-57's per-patient cap, and OQ-54's step order do not overlap: aftermath rolls are not a care window and use their own Position test.

## Chapter impacts, Chapters 1 to 3

Everything the drafter applies to the three drafted chapters and their YAML, gathered from the sections above. Each item names its source; the source section carries the exact wording.

**Chapter 1, Core Rules (`docs/rules/01-core-rules.md`, `data/core/*.yaml`):**
- Conformance follow-up: 1.3 may cite "ADR-0003 item 9" without "as amended" (Minor 9); nothing else.
- 1.3 step 1: replace the "closest Catalog action" paraphrase of ADR-0003 item 9 with the amended item 9 (OQ-35, OQ-27).
- 1.3 step 7 and the section's last sentence: Stress Dice are left out only by a rule with a `roll_exceptions` row; list the Death Roll and the performance roll (OQ-03).
- 1.5 *Finishing a roll* step 2: the "unless the roll's own rule names another resolution" hook (OQ-05). *When a soldier cannot Push* ends with the forbid-hook line (OQ-18).
- 1.8 *Requirements*: "They have an unspent action this round" (OQ-17); the `roll_exceptions` Help line (OQ-03); the forbid-hook line (OQ-18).
- 1.9 *Turns and actions*: the round-start spent state (OQ-17); the shared forbid hook (OQ-18); lift the turn-spending sentence here (review 3 Minor 5). OQ-09 block: earliest wholly unspent turn, the last bullet's "begins its round with no move and no action" (OQ-09, OQ-17); the OQ-16 block's "(a Reaction needs both the move and the action)" and "if it has not yet come" (OQ-16); the OQ-09 exceptions end with the forbid-hook line (OQ-18). *Against a Titan*: the dodge takes its Gear Dice from ODM Gear or the mounted horse (OQ-25).
- 1.10 and review 3 Minors 3 and 7: "Rolled actions, Reactions, and Death Rolls"; drop or move "The Push would roll no dice"; list what the section settles about Squadmates (OQ-17).
- YAML: `bonus-dice-sources.yaml` `help.condition_in_titan_engagement` and `help.condition` (OQ-17, OQ-18); `stress-changes.yaml` `cover.condition` (OQ-18); `dice-pool.yaml` comment naming the Push hook (OQ-18). No `roll_exceptions` change (OQ-03).

**Chapter 2, Character Creation (`docs/rules/02-character-creation.md`, `data/character/*.yaml`):**
- Conformance follow-up: 2.10's `PROVISIONAL (OQ-58)` sentence and 2.2's OQ-19 note cite the decided builds; `squadmates.yaml` `decided:` adds OQ-58 (OQ-58); 2.9 may drop "as amended" from its ADR-0003 item 9 citation (Minor 9).
- 2.1 sheet list and 2.2: the Health line gains the row of boxes (Health boxes); once-per-Titan-Engagement Talent uses recorded beside the Talent, and `record_on_sheet` ends with the `sheet-fields.yaml` reference (OQ-55).
- 2.3: *Before the Lifepath* records the campaign year and the Exam vote; `group_choices` loses Trial order (OQ-22, OQ-32).
- 2.4: *Using the Exam*, *How the Exam is played*, *The three Trials* rewritten; the Cover limit uses Chapter 1's hook; the PROVISIONAL block restates parity figures and the simulator target (OQ-22, OQ-37, OQ-18).
- 2.5: *Targets* `grabbed_or_down_comrade` and *Trigger tests* `own_state` (OQ-23).
- 2.7: Sure Seat replaces Saddle Dodge; eight simulator checks (OQ-28).
- 2.8: the dodge's gear line (OQ-25).
- 2.9: the OQ-27 block cites amended item 9; Chapter 4 adds `item-give`, `pass-item`, and the mount and dismount move (OQ-27, OQ-35).
- 2.10 *Promotion*: step 1 timing (OQ-31); step 2 contest and retirees removed first (OQ-38, Round-3); `promotion.steps` names `sheet-fields.yaml` (OQ-55).
- YAML: `lifepath.yaml` step 0 (campaign year, Exam vote), `group_choices`, `record_on_sheet` reference (OQ-22, OQ-32, OQ-55); `origins.yaml` `campaign_year_min` (OQ-32); `graduation-exam.yaml` `use.decided_by`, `roll_order_within_a_trial`, `trials[*].merit`, `push`, `needs`, `help`, `cover` (OQ-22, OQ-18); `enlistment.yaml` `drive_rules` and `the-walls-are-a-cage` (OQ-23); `talents.yaml`, `specialties.yaml`, `training-years.yaml` line 168 (OQ-28); `action-catalog.yaml` `dodge.gear` (OQ-25); `squadmates.yaml` `stat_block.fields` (`health_lost`, the reference row, line 18's comment), `promotion.timing`, `promotion.contested`, `promotion.steps` (OQ-29, OQ-31, OQ-38, OQ-55, Health boxes).

**Chapter 3, Harm and Mind (`docs/rules/03-harm-and-mind.md`, `data/harm/*.yaml`, `data/mind/*.yaml`):**
- Conformance follow-up: 3.2's `PROVISIONAL (OQ-58)` block becomes the decided design note (OQ-58).
- 3.1, 3.2, 3.3, 3.5, 3.6, the sheet paragraph, and the worked example: Health boxes, as listed in that section.
- 3.2: the worsening sentence (a later injury is rolled with a bonus, not guaranteed worse) (OQ-42).
- 3.3: the forbid row; the Down turn's action counts as spent (OQ-18, OQ-45).
- 3.4, 3.5, 3.7, 3.16, and the worked example: aftermath rolls one per patient and per treater; Mila's single roll on Oskar; Hale treats Oskar in the care window (OQ-57). 3.5: the care-window patient scope sentence (OQ-44).
- 3.7: both rescue structures and the six-cell table with its model limits; drop the one-action claim (OQ-50, OQ-42).
- 3.9: the OQ-46 block states OQ-17's answer; "What no row does" matches the forbid hook (OQ-17, OQ-18).
- 3.12: Fear rows unchanged; the six-cell acceptance test; `first-titan-engagement` wording (OQ-50, OQ-45); Grief after the death's Fear Rolls (OQ-52).
- 3.14: Grief timing (OQ-52). 3.16: step 5 limits, step 7 "or at the aftermath-rolls step", step 9's full batch (OQ-54, OQ-57, OQ-38).
- OQ register notes in the chapter: OQ-38's note closed; OQ-42 and OQ-54's treatment figures use the Round-3 numbers.
- YAML: `health.yaml`, `down.yaml`, `critical-injuries.yaml`, `treat-injury.yaml`, `healing.yaml`, `sheet-fields.yaml` (Health boxes); `down.yaml` `forbids` and `ending.after_ending` (OQ-18, OQ-45); `effect-types.yaml` `spend-next-turn.reading`, `never_used.forbid_help_or_cover`, `no-reactions` (OQ-17, OQ-18); `fear-rolls.yaml` `forbids: [reaction]` on Unguarded, Breaking Point, Shattered, and `limits.timing` (OQ-18, OQ-52); `grief.yaml` `gaining.applies_after` (OQ-52); `treat-injury.yaml` `care_windows.who_rolls`, `patients`, `aftermath_rolls.who_rolls` and `limit` (OQ-44, OQ-57); `engagement-end.yaml` steps 5, 7, 9 (OQ-54, OQ-57, OQ-38); `death-rolls.yaml` engagement-limit reference (OQ-57).

## Batch 2: Chapter 4 and conformance leftovers (OQ-59 to OQ-73)

Decided after Chapter 4's third review round (`docs/reviews/04-gear-review-3.md`, `-codex.md`) and the second conformance round on Chapters 1 to 3 (`docs/reviews/01-03-decisions-conformance-review-2.md`, `-codex.md`). Chapter 4 is `docs/rules/04-gear.md` with its YAML in `data/gear/`. Odds without a source come from `jam_gas_sim.py`, run outside the repository: it reproduces the Jam figures (rating 1 ODM Gear Jams within three rounds 27.7% and 31.7% of the time at Severity 2 and 3 against one Titan, 41.6% and 47.1% against two; rating 2 gives 8.4%, 10.7%, 17.8%, and 22.6%), the exact gas medians (Gas Rating 3 lasts a median of 8 rounds on two dice and 6 on three, means 9.25 and 6.33), and the Rookie dodge at Agility 3 and Stress 1 with no dodge Talent, Pushing when short: 16.0%, 20.6%, and 25.6% at Severity 3 with ODM Gear 1, 2, and 3, and 44.0% and 49.7% at Severity 2 with 1 and 2. The 24%, 29%, and 34% quoted under OQ-25 were measured at Agility 4, the reference before the OQ-19 amendment.

Two provisional choices change ((b) for OQ-72, (d) for OQ-67); the other eleven Chapter 4 choices are kept, several with an added rule from a review Minor. OQ-70 takes (a) with (e). ADR-0014 and ADR-0015 are amended; no ADR is created. Two glossary entries change (Standard Issue, Down).

### Summary table

| OQ | Decision (one line) | ADR change | Glossary change | Chapter impact |
|---|---|---|---|---|
| 59 | Keep (a); ODM Gear rating follows OQ-72 (1, 1, 2, 2, 2, 3 by Funding); a Jammed or lame exchange can be declined; the between-sessions rationale corrected | none (OQ-72's) | Standard Issue | Ch4 4.1, 4.9; `standard-issue.yaml`, `items.yaml` |
| 60 | Keep (a); the round's Gas Roll comes before a fitted canister can be passed, taken, or left by a death, and an emptied canister moves nowhere | none | none | Ch4 4.3, 4.7, 4.11; `odm-gear.yaml`, `carrying.yaml` |
| 61 | Keep (a); a recorded horse or left-item Position names its Focus Titan | none | none | Ch4 4.5, 4.11, 4.12, intro; `horses.yaml`, `carrying.yaml`, `sheet-fields.yaml` |
| 62 | Keep (a); Health 6 is legal and reported | none | none | Ch4 4.6 note only |
| 63 | Keep (a) | none | none | none |
| 64 | Keep (a) | none | none | none |
| 65 | Keep (a); takes outside a Titan Engagement use the roll-off | none | none | Ch4 4.7; `carrying.yaml` |
| 66 | Keep (a); rationale corrected, window figures recorded | none | none | Ch4 4.8 note, 4.9 block; `field-repair.yaml` |
| 67 | **Change:** (d), no ammo kind in Phase 1 | none | none (Squad Supply unchanged) | Ch4 4.10, 4.12, example; `squad-supply.yaml`, `sheet-fields.yaml` |
| 68 | Keep (e); the share-out in two steps | none | none | Ch4 4.11; `carrying.yaml` |
| 69 | Keep (a); item 10 applied | none | see 59, 67 | none |
| 70 | (a) with (e): the Slayer template's attributes, Talent 1 per measured roll; template Squad reported | ADR-0014 amended | none | Ch2 2.2, 2.10; Ch3 3.2; `squadmates.yaml` |
| 71 | Nine Minors ruled below | ADR-0014, ADR-0015 amended | Down | Ch1 1.9, 1.10; Ch2 2.7; Ch3 3.2, 3.17; `talents.yaml`; YAML `decided:` tags |
| 72 | **Change:** (b), ODM Gear rated 2 at Funding 3 to 5 and 3 at 6; the Jam test binds Chapter 5 | ADR-0014 amended | none | Ch4 4.9, example; `standard-issue.yaml` |
| 73 | Eight Minors ruled below | none | none | Ch4 as listed |

### OQ-59: Standard Issue contents, ratings, Funding, and resupply

- **Decision:** Keep (a) with three changes. (1) `by_funding.odm_gear_rating` is 1, 1, 2, 2, 2, 3 for Funding 1 to 6 (OQ-72); horse ratings, canisters, and Blade Sets are unchanged. (2) The decline step also covers the exchange of Jammed ODM Gear or a lame horse in any issue: a soldier who declines keeps the item at current rating 0, to be repaired or maintained later (OQ-73 item 3). (3) The stated reason for keeping a Jam through the interim issue is corrected: a Jam is nearly always repaired in the care window of its own fight, so what carries between sessions is a Jam the window could not repair, a spent kit, and the wear on any item rated at or above the row (OQ-73 item 2). The interim issue, its timing after a procedure's last step, the full issue's replacement of items rated below the row, the Specialty kits, Funding 3 until the Funding rules exist, and the several-kits sheet all stand.
- **Why:** Both round-3 reviews judged the entry sound. The rating follows OQ-72. Declining the exchange keeps a rating 2 harness or horse a soldier earned at higher Funding or through Requisition out of the bin when a poorer issue arrives, without granting a rating the Funding row does not pay for (the review's other fix). The rationale correction changes no rule; it stops OQ-59 and OQ-66 claiming a persistence the rolls almost never allow.
- **ADR change:** none beyond OQ-72's.
- **Glossary change:** Standard Issue entry becomes: "The gear every soldier receives when they join the Squad and whenever a rule issues it, such as before each Expedition, scaled by Funding: ODM Gear, gas canisters, Blade Sets, a horse, and a Specialty's kit." Applied.
- **Chapter impact:** Section 4.9: the `by_funding` sentence and the design note's "issues ODM Gear, horses, and Blade Sets at rating 1, which is ADR-0014's Rookie with Gear Dice 1" become ODM Gear rated 2 and the Rookie's ODM Gear Dice 2; step 6 covers the exchanges; both `PROVISIONAL (OQ-59)` blocks become design notes with the corrected rationale. Section 4.1 *Restoring*: "the interim issue replaces a lame horse, and Jammed ODM Gear only if it is rated below the Funding row" (OQ-73 item 6). `data/gear/standard-issue.yaml`: `by_funding`, `receiving.steps[decline]`, `provisional` to `decided`. `data/gear/items.yaml` `provisional` to `decided`.
- **Revised by batch 2b:** Horse ratings are 1, 1, 2, 2, 2, 3 by Funding (Major 2), and a full issue also replaces worn ODM Gear and worn horses, with the decline covering each exchange (Minor 5).
- **Revised by batch 3:** The interim issue also replaces a worn horse, decline included (OQ-93); wear carries between sessions only on ODM Gear and kits, which the care window can restore.

### OQ-60: ODM use, Gas Roll timing, running dry, strikes, and part-used canisters

- **Decision:** Keep (a), and settle the handover so that no canister moves before the gas it owes is rolled:
  1. A soldier who has used ODM Gear this round makes that round's Gas Roll **before** their fitted canister can be passed or taken: the passer makes it when they declare that they mean to pass it, and a Down comrade makes it when a taker declares that they mean to take it. It is that soldier's Gas Roll for the round, with the dice their rolls so far give, and none is made for them at the round's end.
  2. If that roll leaves the canister at Gas Rating 0, it is discarded: the soldier has no canister fitted, nothing moves, and the pass or take is not made and spends nothing, so the passer or taker may still take an action that turn. If gas remains, the canister moves with its Gas Rating, and the pass or take spends what it spends.
  3. A soldier who dies after using ODM Gear this round makes that round's Gas Roll at once, before their fitted canister becomes a left item. A canister at 0 is discarded and is never a left item.
  The strike requirement scoped to Titan Engagements, the end-of-round Gas Roll, running dry without a fall, a part-used canister kept as a spare, and the medians all stand. The Unresolved Major is closed.
- **Why:** The round-2 fix rolled after the act was declared, so a 1 on the roll (30.6% on two dice at Gas Rating 1, 42.1% on three) left three rules disagreeing about a canister at 0. Rolling first makes the act's own requirement, gas above 0, true or false at the moment the act is taken, so no refund or cancellation rule is needed: an act whose requirement fails is not taken, as everywhere else in the Catalog. The roll stands because the gas was spent by that round's flying, not by the handover. The death rule closes for a dead soldier's canister the same gain the round-2 fix closed for a passed one. Canon's handover (Armin's canister for Mikasa) still works: a full or part-used canister reaches the receiver with what it holds after the giver's own round.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Section 4.3 (the paragraph after the Gas Roll steps), 4.7 *Passing an item* and *Taking an item*, 4.11 *Death*, and both `PROVISIONAL (OQ-60)` blocks become design notes. `data/gear/odm-gear.yaml` `gas_roll.canister_removed` rewritten to rules 1 to 3 (which also removes the garbled dice phrase, OQ-73 item 6); `data/gear/carrying.yaml` `passing_items.passable` (fitted canister), `taking_items.effect`, `leaving_play.death.left_for_the_squad`; `odm-gear.yaml` `provisional` to `decided`.

### OQ-61: Airborne, mounted, and a soldier's horse

- **Decision:** Keep (a). Add (OQ-73 item 5): a dismounted horse's Position, and the Position where a dead soldier's left items lie, are recorded together with the Focus Titan that Position is held relative to, and the mount and take tests compare the soldier's Position relative to that same Titan. Chapter 5 states how a soldier's Positions relative to two Focus Titans relate, and what a recorded Position becomes when its Focus Titan dies or the Titan Engagement ends (it is cleared at the end, as now). The three forced dismounts all state that the horse stays at the Position (OQ-73 item 6).
- **Why:** Both reviews judged (a) sound. Positions are relative to a Focus Titan, and a Background Titan can enter as a second one, so a bare Position on the sheet read two ways; naming the Titan is one more mark on the Squad row (`@In Reach A`) and keeps the tests closed.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Sections 4.5, 4.11, 4.12, and the introduction's Chapter 5 list; `data/gear/horses.yaml` `horse_position`, `mount.requirements.in_titan_engagement`, `forced_dismount`; `data/gear/carrying.yaml` `where_left`, `taking_items.requirements.in_titan_engagement`; `data/gear/sheet-fields.yaml` `horse.position`, `left_at`, the Squad row marks; `PROVISIONAL (OQ-61)` blocks become design notes; `provisional` to `decided` in `odm-gear.yaml`, `horses.yaml`, `items.yaml`, `sheet-fields.yaml`.

### OQ-62: Falls

- **Decision:** Keep (a): the trigger list, the three bands, the procedure that ends airborne, mounted, and carried before the damage, and the damage table. Health 6 is a legal build and stays legal (OQ-71 item 7): Chapter 4 already sizes falls against current Health 1 to 6, and the Health boxes rule 13 and the Chapter 4 constraint are corrected to match.
- **Why:** Both reviews judged (a) sound. Capping Health at 5 would add a rule for 0.8% of Lifepaths; the fall table already covers Health 6 (never Down from full).
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Section 4.6's `PROVISIONAL (OQ-62)` block becomes a design note; `data/gear/falls.yaml` `provisional` to `decided`. No rule changes.

### OQ-63: Blade Sets, the handles, and the swap

- **Decision:** Keep (a). OQ-72 does not touch Blade Sets: every issued set stays rated 1, and a Squadmate never ruins one.
- **Why:** Both reviews judged it sound; the rating 2 and 3 figures stay recorded for the Requisition rules.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** the `PROVISIONAL (OQ-63)` block becomes a design note; `blade-sets.yaml` and `items.yaml` `provisional` to `decided`.

### OQ-64: Items, a carried comrade, Overloaded, and shedding load

- **Decision:** Keep (a), including the carried comrade at 5 plus their items, Strong Back removing the 5 only, dropped items leaving play, and the carrying end rows.
- **Why:** Both reviews judged it sound and the design note's arithmetic exact.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** the `PROVISIONAL (OQ-64)` block becomes a design note; `carrying.yaml` `provisional` to `decided`.

### OQ-65: Passing an item

- **Decision:** Keep (a), with the handover rule under OQ-60 and one addition (OQ-73 item 4): outside a Titan Engagement, when players disagree about who takes an item from a Down comrade, or in what order, they use the roll-off in `data/character/lifepath.yaml` (`group_choices`). The Down comrade's player has no veto, since a Down soldier takes no action and the take is the taker's act.
- **Why:** Both reviews judged the entry sound apart from the handover gap. Field Repair order and the share-out already use the roll-off, so takes use the same one.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Section 4.7 *Taking an item*; `carrying.yaml` `taking_items.requirements.outside_titan_engagement` gains the roll-off sentence; the `PROVISIONAL (OQ-65)` block becomes a design note.

### OQ-66: Field Repair

- **Decision:** Keep (a): ODM Gear and tool kits only, 1 current rating per success, one roll per soldier in the care windows held when a Titan Engagement ends or a day passes on an Expedition, never in Downtime. The rationale is corrected (OQ-73 item 2): the limit exists to keep gear restoration inside those windows and the Maintain Gear Downtime Action, not to carry a Jam between sessions; with one roll per soldier a Jam is still there after the end-of-fight window 0.1% of the time with six soldiers up, 2.1% with four, and 11.3% with three (review round 3's model, Wits 3, no kit). Those figures are the entry's simulator case, beside the PC death target.
- **Why:** The rule is sound and canon: soldiers see to their gear after a fight. One roll per item per window (the review's other fix) would make a Jam a between-sessions cost, which nothing in the design asks for; the cost of a Jam is the fall and the rounds lost in the fight.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Section 4.8's `PROVISIONAL (OQ-66)` block becomes a design note with the corrected reason and the window figures; section 4.9's OQ-59 block loses "so wear carries from one session to the next"; `field-repair.yaml` `provisional` to `decided`.

### OQ-67: Squad Supply kinds, stock, and medical uses

- **Decision:** (d). Squad Supply has three kinds in Phase 1: rations, flares, and medical supplies. Ammo is not a kind, is not stocked, and is not on the Squad sheet; one sentence in section 4.10 says that the rules beyond Phase 1 that add weapons which spend ammo will add it as a kind with its stock and uses. The stock by Funding, both medical uses, and restocking at any point in a window are kept.
- **Why:** ADR-0003 and ADR-0012 give every row a rule that reads it; a kind no Phase 1 rule reads or changes is Phase 2 content on a live sheet, as the Codex reviews said twice. The owner's brief names ammo for weapons that do not exist yet, and adding a kind when those rules arrive is one row. The glossary's "rations, flares, and medical supplies" therefore stands unchanged.
- **ADR change:** none.
- **Glossary change:** none. The proposed Squad Supply change is not made.
- **Chapter impact:** Sections 4.10 (*Kinds and units*, *Stock*), 4.12, the worked example's Supply line, and the `PROVISIONAL (OQ-67)` block; `data/gear/squad-supply.yaml` `kinds`, `stock.ammo`; `data/gear/sheet-fields.yaml` `squad_sheet` and its example; `provisional` to `decided`.

### OQ-68: The gear of a soldier who dies or retires

- **Decision:** Keep (e). The share-out is written as two ordered steps (OQ-73 item 8): first the players give each left item not yet taken to a living soldier who took part in the procedure; then every item they left unassigned leaves play. A dead soldier's fitted canister becomes a left item only after their Gas Roll for the round (OQ-60 rule 3).
- **Why:** Both reviews judged the substance sound; the closing clause could be read to bin an assigned item.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Section 4.11 *Sharing out* and *Death*; `carrying.yaml` `leaving_play.death.shared_out` and `left_for_the_squad`; the `PROVISIONAL (OQ-68)` block becomes a design note; `sheet-fields.yaml` `provisional` to `decided`.

### OQ-69: Rows and text Chapter 4 needs in Chapters 1 to 3

- **Decision:** Keep (a). Item 10 is now applied: the Standard Issue glossary change under OQ-59; the Squad Supply change is not made (OQ-67). Every other item stays applied as listed.
- **Why:** Both reviews found items 1 to 9 and 11 to 22 present in their owning files.
- **ADR change:** none.
- **Glossary change:** see OQ-59.
- **Chapter impact:** Section 4.13's `PROVISIONAL (OQ-69)` block becomes a design note saying the glossary changes are applied or withdrawn.

### OQ-70: The reference Rookie's Talent

- **Decision:** (a) with (e). The reference Rookie has the Slayer template's **attributes** (Strength 4, Agility 3, Wits 2, 3 elsewhere; Health 4, Resolve 3) and Talent 1 in the Talent that names each roll a target measures, as ADR-0014's body has always said; it is not the Slayer template, whose one Talent names only the Nape strike. The Grab models in Chapter 3 stand (60.4% lone, the six OQ-50 cells). The Talent-dependent targets (the lone Grab, the OQ-50 cells, the prepared-Squad kill) are also reported, not tuned, for a Squad built literally from the Squadmate templates, so the table sees what a Squadmate-heavy Squad faces (the lone Grab is about 69% with the Slayer template's Talents).
- **Why:** The split baseline came from wording, not from a choice: OQ-58 fixed attributes by pointing at a template, and the chapters then said the Rookie *is* it. (b) fails because Blade Discipline is a rule Talent. (c) and (d) re-measure or re-state figures Chapter 5 has not yet used, for no gain. (e) costs the simulator one more row and answers the review's worry directly.
- **ADR change:** ADR-0014's OQ-58 paragraph is rewritten with this wording and OQ-71's corrections (the text is in the ADR). Applied.
- **Glossary change:** none.
- **Chapter impact:** Chapter 3 section 3.2's *Reference builds* note: "has the Slayer template's attributes" and the template-Squad report; section 3.7 unchanged. Chapter 2 sections 2.2 and 2.10 (the same wording); `data/character/squadmates.yaml` `stat_block.matches_reference_build` and the `templates` comment: "the Slayer template's attributes are the reference Rookie's (OQ-58, OQ-70)".
- **Revised by batch 2b:** "Talent 1 in the Talent that names each roll a target measures" is narrowed to the Nape strike, the Body Part strike, Break Free, and Treat Injury; the dodge, Fly, Break Attention, Ride, and Read carry no Talent dice (Major 1).

### OQ-71: Open Minor findings from the Chapters 1 to 3 conformance round 2

- **Decision:** each item as follows.
  1. **Health 3 report Squad:** the reference Squad with each soldier's Health set to 3 and nothing else changed (a simulator override of the derived value), so the report isolates Health. The Health-dependent targets are the Expedition PC Critical Injury and PC death targets and a Grab on a victim already carrying untreated injuries. ADR-0014 says so (applied); Chapter 3 section 3.2 and Chapter 2 sections 2.2 and 2.10 match.
  2. **Veteran:** Strength 5, Agility 3, Wits 2, and 3 elsewhere (19 points: a Top 10 Rookie with two Scars), Health 4, Resolve 5. The Levi-grade soldier is stated to be deliberately above any buildable total. ADR-0014 (applied); Chapter 3 section 3.2 note.
  3. **Sure Seat and ADR-0015:** the Talent's description becomes "A seat that keeps the horse sound when a dodge, Ride, or Break Attention made with the horse is Pushed in a Titan Engagement."; Chapter 2 section 2.7's note drops "whatever its description says about a hard ride". ADR-0015's sentence becomes "When a dodge made with the horse is Pushed, its Gear Dice showing 1 wear the horse, not ODM Gear (ADR-0004), and the Push does not by itself raise the Gas Roll." (applied). This also settles items 8 and 9.
  4. **Chapter 1 act block and end bullet:** "Each act this chapter lets a soldier choose has a tracked value, and a Catalog entry unless it is a move"; the OQ-15 bullet reads "Turns and actions spent in advance, by a Reaction or a result, exist only inside the Titan Engagement where they were spent (Chapter 3, section 3.16, step 1)".
  5. **`decided:` tags:** `bonus-dice-sources.yaml` `help` adds OQ-17 and OQ-18; `stress-changes.yaml` `cover`, `down.yaml`, `fear-rolls.yaml`, and `effect-types.yaml` `no-reactions` add OQ-18; `fear-rolls.yaml` adds OQ-52.
  6. **Chapter 3 act check and glossary Down:** section 3.17 pairs each act with its tracked value (`treat-injury` changes `critical-injury-treat`, `health-restore`, and `down-end`; `rally` changes `stress-response-clear`; `lift-comrade` changes `comrade-carry`) and adds "The Death Roll is a roll its rule calls for, not an act, so it needs no tracked value." Glossary Down's last sentence reads "Reaching 0 current Health through damage also inflicts an immediate Critical Injury." (applied).
  7. **Health 6:** legal and kept. Chapter 3 section 3.2's *Injuries before Down* adds Health 6 (mean 3.99 untreated injuries before Down; Down by the third 39.6%, the fourth 55.5%, the fifth 70.0%, the sixth 99.7%, review round 2's run); the Health boxes rule 13 and the Chapter 4 constraint read current Health 1 to 6.
  8. and 9. See item 3.
- **Why:** Each is a wording, tag, or range correction that the reviews traced to a decision text; none changes odds. Item 1's override is what the OQ-58 comparison actually measured. Item 2 keeps every quoted Veteran Health and Resolve figure and makes the build one a table can hold.
- **ADR change:** ADR-0014 (items 1, 2) and ADR-0015 (item 3), merged into their `## Amended` sections. Applied.
- **Glossary change:** Down (item 6). Applied.
- **Chapter impact:** Chapter 1 sections 1.9 and 1.10 (item 4); `data/core/bonus-dice-sources.yaml`, `data/core/stress-changes.yaml` (item 5). Chapter 2 sections 2.2 and 2.10 (items 1, 2), 2.7 (item 3); `data/character/talents.yaml` `sure-seat.description` (item 3). Chapter 3 section 3.2 (items 1, 2, 7), 3.17 (item 6); `data/harm/down.yaml`, `data/mind/fear-rolls.yaml`, `data/harm/effect-types.yaml` (item 5).

### OQ-72: How often rating 1 ODM Gear Jams for the soldier holding Attention

- **Decision:** (b), made exact. Standard Issue rates ODM Gear 1 at Funding 1 and 2, **2 at Funding 3, 4, and 5**, and 3 at Funding 6. ADR-0014's Rookie keeps Gear Dice 1 except on ODM Gear, which is 2, so the reference dodge, Fly, and Break Attention roll two Gear Dice; the Veteran and Levi-grade builds are unchanged. The Jam test stays a binding Chapter 5 acceptance test and is recorded in this file's Chapter 5 constraints: at the Severity and Tempo Chapter 5 sets, the reference Rookie (Agility 3, ODM Gear 2, no dodge Talent, Stress 1 when the fight begins) who holds Attention and dodges for three rounds, receiving cards from every Titan Chapter 5 lets act on them in a round, Pushing when short with Stress rising and with Stress Responses, Help, Covering, and turn debt applied, Jams in no more than a third of those fights. Chapter 5 and 6 tune Severity against a Rookie dodging with Agility 3 and ODM Gear 2. Well-Kept Rig, Light Trigger, and the Blade Set ratings are unchanged. Options (c) and (e), the first-wear mark, and (d), the low band, are rejected. The Unresolved Major is closed.
- **Why:** Rating 1 fails its own threshold against two Titans before Chapter 5 adds anything (47.1% of three-round fights at Severity 3) and sits just under it against one (31.7%), every airborne Jam a high fall, and every Jam from wear on a player character. Canon soldiers lose to Titans, empty canisters, and spent blades; a harness that fails in a third to a half of hard fights is not the Survey Corps' gear. Rating 2 gives 10.7% and 22.6%, under the threshold with room for the Stress Responses the full model adds. It is a data change with no new mechanic: the mark of (c) and (e) is a new state on every sheet and makes Well-Kept Rig nearly redundant, and (d) changes what a Jam costs, not how often it happens. The price is the reference dodge, which at Agility 3 and Severity 3 moves from 16.0% to 20.6% (49.7% from 44.0% at Severity 2); Chapter 5 has not been drafted, so no Severity value is re-tuned, and Chapter 6's ladder is re-measured at Gear 2 from the start. The gas target does not move: Gas Rating 3 still lasts a median of 8 rounds on two dice and 6 on three, and fewer Pushes at Gear 2 only make gas last longer in play. Funding 5 rises with 3 and 4 so that the ladder never falls as Funding rises; Funding 6 takes rating 3 so that it still stands above the reference. Chapter 4's rating 2 Jam figures (8.3% to 22.6%) are already in section 4.9's tables.
- **ADR change:** ADR-0014, appended to `## Amended` (the text is in the ADR). Applied.
- **Glossary change:** none.
- **Chapter impact:** Section 4.9: the `PROVISIONAL (OQ-72)` block becomes a design note stating the decision; the reference-builds design note's first sentence names ODM Gear 2 and keeps its tables; `data/gear/standard-issue.yaml` `by_funding.odm_gear_rating` becomes 1, 1, 2, 2, 2, 3. The worked example: Jonas begins with ODM Gear `1/2`, worn by a Push earlier in the fight, so his Pushed dodge still Jams it, and his row and Ilse's read `ODM 1/2` and `ODM 2/2`. OQ-72's *Why* figure slip (27.8% and 31.6%) is moot once the entry is Decided.
- **Revised by batch 2b:** Standard Issue horse ratings follow the same ladder (1, 1, 2, 2, 2, 3), so the Rookie's horse is rated 2 (Major 2). The reference dodger carries no Talent dice (Major 1).
- **Revised by batch 3:** The Jam test is accepted on OQ-96's reading, the worst legal support pattern against Behavior Table behaviors: worst cell 32.7% (two Large Titans, Covered, no Help), with every card at kill Severity reported as an upper bound (35.4%). Break Attention's needs follow OQ-81.

### OQ-73: Open Minor findings from Chapter 4 review round 3

- **Decision:** each item as follows.
  1. **Gas Roll on a handed-over canister, and a dead soldier's canister:** OQ-60 rules 1 to 3.
  2. **Field Repair rationale:** review fix 1, under OQ-66 and OQ-59.
  3. **Downgrade of a broken item rated above the row:** review fix 2, under OQ-59: the soldier may decline the exchange and keep the item at 0.
  4. **Take order outside a Titan Engagement:** review fix 1, under OQ-65.
  5. **A recorded Position names its Focus Titan:** review fix 1 with the Chapter 5 addition, under OQ-61.
  6. **Wording and figure slips:** all three fixes. `canister_removed` is rewritten under OQ-60; section 4.1 *Restoring* reads "and Jammed ODM Gear only if it is rated below the Funding row"; section 4.3's Rookie gas note adds the medians (7 rounds needing 1 success, 10th to 90th percentile 4 to 14; 6 needing 2, 3 to 12); the lame and Down rows of `forced_dismount` add "The horse stays at the Position."
  7. **Ammo:** removed, under OQ-67.
  8. **Share-out wording:** review fix 1, under OQ-68.
- **Why:** Each item's rule is settled in the entry it belongs to; none changes an ADR-0014 figure.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** as listed under OQ-59, OQ-60, OQ-61, OQ-65, OQ-66, OQ-67, and OQ-68, plus section 4.3's medians and `horses.yaml` `forced_dismount` (item 6).
- **Revised by batch 3:** Item 6's "6 needing 2" predates OQ-72: at ODM Gear 2 the reference Rookie's roll needing 2 successes lasts a median of 7 rounds (mean 7.23, 10th to 90th percentile 3 to 12), as Chapter 4 section 4.3 states (OQ-94 item 4).

### Chapter impacts of batch 2

**Chapter 1, Core Rules:**
- 1.10 *Acts in this chapter*: "has a tracked value, and a Catalog entry unless it is a move" (OQ-71 item 4).
- 1.9 *Reactions*, the OQ-15 bullet: turns and actions spent in advance by a Reaction or a result end with the Titan Engagement (OQ-71 item 4).
- `data/core/bonus-dice-sources.yaml` `help.decided` adds OQ-17 and OQ-18; `data/core/stress-changes.yaml` `cover.decided` adds OQ-18 (OQ-71 item 5).

**Chapter 2, Character Creation:**
- 2.2 (OQ-19 note) and 2.10 (*The stat block*, the OQ-29/OQ-58 note): the reference Rookie has the Slayer template's attributes and Talent 1 per measured roll; the Veteran is Strength 5, Agility 3, Wits 2, 3 elsewhere; the Health 3 report Squad is the reference Squad with Health set to 3; the template Squad is reported (OQ-70, OQ-71 items 1 and 2).
- 2.7: the OQ-28 note drops "whatever its description says about a hard ride" (OQ-71 item 3).
- `data/character/talents.yaml` `sure-seat.description` (OQ-71 item 3); `data/character/squadmates.yaml` `stat_block.matches_reference_build` and the `templates` comment (OQ-70).

**Chapter 3, Harm and Mind:**
- 3.2 *Reference builds* and *Injuries before Down*: the OQ-70 wording, the Veteran, the report Squad definition, the Health-dependent targets, the template-Squad report, and the Health 6 row (OQ-70, OQ-71 items 1, 2, 7).
- 3.17: tracked values beside each act and the Death Roll sentence (OQ-71 item 6).
- `data/harm/down.yaml`, `data/mind/fear-rolls.yaml` (also OQ-52), `data/harm/effect-types.yaml` `no-reactions`: `decided:` adds OQ-18 (OQ-71 item 5).

**Chapter 4, Gear:**
- 4.1 *Restoring* wording (OQ-73 item 6).
- 4.3: the Gas Roll paragraph on a passed, taken, or left canister (OQ-60); the Rookie gas medians (OQ-73 item 6); the OQ-60 blocks become design notes.
- 4.5: the Focus Titan on a recorded horse Position; the forced dismounts (OQ-61, OQ-73 items 5 and 6).
- 4.7: passing and taking a fitted canister (OQ-60); the take roll-off outside a Titan Engagement (OQ-65).
- 4.8: the corrected rationale and window figures (OQ-66).
- 4.9: `by_funding` ODM Gear 1, 1, 2, 2, 2, 3; step 6 covers the Jammed or lame exchange; the reference-builds note names ODM Gear 2; the OQ-59 and OQ-72 blocks become design notes with the corrected rationale (OQ-59, OQ-72, OQ-73 items 2 and 3).
- 4.10, 4.12, and the example's Supply line: no ammo (OQ-67).
- 4.11: the dead soldier's Gas Roll; the share-out in two steps; the Focus Titan on `left_at` (OQ-60, OQ-68, OQ-61).
- The introduction's Chapter 5 list: Positions with two Focus Titans and what a recorded Position becomes when its Titan dies (OQ-61).
- The worked example: Jonas's ODM Gear `1/2` (OQ-72); `Supply | Rations 0 | Flares 2 | Medical 2` (OQ-67).
- 4.13 and every `PROVISIONAL (OQ-nn)` block: design notes; every `data/gear/*.yaml` `provisional:` becomes `decided:`.
- YAML: `standard-issue.yaml` (`by_funding`, `decline`), `odm-gear.yaml` (`gas_roll.canister_removed`), `carrying.yaml` (`passing_items.passable`, `taking_items.effect` and `.requirements.outside_titan_engagement`, `leaving_play.death.left_for_the_squad`, `where_left`, `shared_out`), `horses.yaml` (`horse_position`, `mount.requirements`, `forced_dismount`), `sheet-fields.yaml` (`horse.position`, `left_at`, Squad row marks, `squad_sheet`), `squad-supply.yaml` (`kinds`, `stock`), `items.yaml` (`odm-gear.restored_by` wording).

## Batch 2b: batch 2 conformance leftovers

Rulings on the four findings that `docs/reviews/01-04-decisions-conformance-review-1.md` (the Chapters 1 to 4 conformance review) left to the decider, Majors 1 and 2 and Minors 5 and 6, and the corrections its Minor 8 asked for in this file, all applied. OQ-91 and OQ-92 in OPEN-QUESTIONS.md record the two Majors. The Chapter 5 draft assumed the Major 1 ruling.

Odds without a source come from `jam_gas_sim.py` (300,000 rolls per figure, Push when short, Stress Responses not applied) run outside the repository. They reproduce the review's exact figures within 0.2 points: a lone Rookie with Agility 3, ODM Gear 2, Stress 1, and no dodge Talent dodges Severity 3 20.7% of the time and Severity 2 49.7%; with one Help die, 29.2%; with Slip Away 1 instead, 29.2% alone and 37.7% with Help; a lone Veteran (Agility 3, ODM Gear 2, Stress 2, no dodge Talent) 26.1% and 54.0%; the Flier template alone (Agility 4, Slip Away 1, ODM Gear 2, Stress 1) 38.0% and 66.6%; a lone Levi-grade soldier (Agility 4, ODM Gear 3, Stress 2, no dodge Talent) 38.6% at Severity 3 and 17.2% at Severity 4. A rating 2 horse in the same model goes lame within three rounds of dodging at Severity 3 10.6% of the time against one Titan and 22.6% against two, the rating 2 Jam figures. The gas target is untouched (Gas Rating 3, medians 8 and 6).

### Summary table

| Finding | Decision (one line) | ADR change | Glossary change | Chapter impact |
|---|---|---|---|---|
| Major 1 | The reference builds carry no Talent dice on the dodge, Fly, Break Attention, Ride, or Read; Talent applies to strikes, Break Free, and Treat Injury; the Jam test and the Chapter 6 ladder name full builds; the Flier template is reported | ADR-0014 body | none | Ch2 2.10; Ch3 3.2; Ch4 4.3, 4.9; `squadmates.yaml`; Ch5 and Ch6 constraints |
| Major 2 | Standard Issue horse ratings 1, 1, 2, 2, 2, 3 by Funding, matching ODM Gear; the saddle choice stays | ADR-0014 body (Rookie horse 2) | none | Ch4 4.5, 4.9, example; `standard-issue.yaml` |
| Minor 5 | A full issue also replaces worn ODM Gear and worn horses; the decline covers it; the interim issue is unchanged | none | none | Ch4 4.9; `standard-issue.yaml`, `items.yaml` |
| Minor 6 | ADR-0014's body states the three builds in one paragraph; `## Amended` is the history | ADR-0014 body and `## Amended` | none | Ch4 4.9 sentence; Ch6 constraint |
| Minor 8 | Slips in the decisions file corrected as listed | none | none | none |

### Major 1: the reference builds' Talent dice

- **Decision:** Review fix 1 with fix 3. ADR-0014's "Talent 1" (and the Veteran's 2, the Levi-grade soldier's 3) applies to the rolls a target measures a soldier's trade by: the Nape strike, the Body Part strike, Break Free, and Treat Injury, each with the dice Talent that names it (Clean Cut, Hamstringer, Grip Breaker, Field Medicine) at that level when the target measures that roll. **The reference builds carry no Talent dice on the dodge, Fly, Break Attention, Ride, or Read.** Every batch-2 dodge, Jam, and gas figure therefore stands as the baseline, and Chapter 4's section 4.4 strike table (Talent 1) and its section 4.3 and 4.9 dodge, Jam, and gas figures (no Talent) are now the same build. The binding Jam test and both sides of the Chapter 6 ladder name their full builds:
  - **Jam test build:** the Rookie, Agility 3, ODM Gear 2, no dodge Talent, Stress 1 when the fight begins.
  - **Ladder:** a supported Rookie (Agility 3, ODM Gear 2, no dodge Talent, Stress 1, one Help die) dodges Severity 3 29.2% of the time; a lone Veteran (Agility 3, ODM Gear 2, no dodge Talent, Stress 2) 26.1%; the two are "about as often". A lone Rookie dodges Severity 3 20.7% and Severity 2 49.7%; a lone Levi-grade soldier (Agility 4, ODM Gear 3, Stress 2) dodges Severity 3 38.6% and Severity 4 17.2%.
  - **Reported, not tuned:** the Flier template alone (Agility 4, Slip Away 1, ODM Gear 2, Stress 1: 38.0% at Severity 3, 66.6% at Severity 2), beside the Health 3 and template-Squad reports.
- **Why:** A Rookie holds one Talent, and the one the reference Rookie's attributes come from (the Slayer template) names the Nape strike. Giving the reference dodger Slip Away would tune every Severity against a Flier, the one Specialty built to dodge, and every other soldier at the table would then dodge one die under the baseline; tuning against the no-Talent dodge makes the Flier's Talent an edge, which is what a Talent is for (OQ-28). The strike, Break Free, and treatment targets keep Talent 1 because those targets are stated for a soldier of that trade (a striker, a Grabbed soldier who breaks free, a treater). The Jam and gas figures barely move between the readings (10.2% against 10.6% for one Titan; gas medians 8 against 7), so the choice is about Severity, and Severity is not yet set. Naming the full builds in the test and the ladder closes the ambiguity for good.
- **ADR change:** ADR-0014's body, rewritten under Minor 6 below, carries the sentence "Talent applies to the Nape strike, the Body Part strike, Break Free, and Treat Injury, with the dice Talent that names the roll; the dodge, Fly, Break Attention, Ride, and Read carry no Talent dice."
- **Glossary change:** none.
- **Chapter impact:** Chapter 2 section 2.10's design note and the stat block sentence: "Talent 1 in the Talent that names the Nape strike, the Body Part strike, Break Free, or Treat Injury; no Talent dice on the dodge, Fly, Break Attention, Ride, or Read"; `data/character/squadmates.yaml` `stat_block.matches_reference_build` and the `templates` comment say the same. Chapter 3 section 3.2 *Reference builds*: the same sentence; the Flier template joins the reported builds; section 3.7's Grab models (Grip Breaker 1 on Break Free, Talent 1 on the hand strike) stand. Chapter 4 section 4.3's gas note and section 4.9's OQ-72 and reference-builds notes say "no dodge Talent" where they name the Rookie. The decisions file's Chapter 5 constraint reads "Tunes Severity against a Rookie dodging with Agility 3, ODM Gear 2, no dodge Talent, and Stress 1 (ADR-0014)", the Jam test names that build, and the Chapter 6 constraint quotes the ladder above (text under Minor 8).
- **Revised by batch 3:** ADR-0014's sentence closes the list by exclusion: "No other roll a target measures carries Talent dice, including the dodge, Fly, Break Attention, Ride, and Read" (OQ-94 item 1).

### Major 2: horse ratings

- **Decision:** Review fix 1. `data/gear/standard-issue.yaml` `by_funding.horse_rating` becomes 1, 1, 2, 2, 2, 3 for Funding 1 to 6, the same ladder as ODM Gear. ADR-0014's Rookie has a horse rated 2, like its ODM Gear; the Veteran's horse is 2 and the Levi-grade soldier's 3. The saddle choice (a mounted soldier's dodge or Break Attention may take its Gear Dice from ODM Gear instead, one item per roll) stays, so the two dodges again differ only in currency: horse wear and a fall from a horse, against gas and a Jam.
- **Why:** OQ-25 was decided on the premise that a mounted dodge has the same pool as an ODM dodge and pays in a different coin, and ADR-0015's amendment, Sure Seat, and Loose the Horse were all sized on it. OQ-72 raised ODM Gear and left the horse at 1, so at Funding 3 the horse dodge ran one Gear Die under the ODM dodge (16.0% against 20.7% at Severity 3), lamed the horse three times as often as the harness Jammed (31.5% against 10.6%), and threw the rider when it did; no player would choose it, and a Rider's Talents bought nothing. Matching the ladders restores the premise with a data change and no new rule: a rating 2 horse goes lame within three rounds 10.6% and 22.6% of the time, the Jam figures, and lame still costs a fall from a horse. Canon's Survey Corps horses are bred for the field and are what a rider lives by; issuing them a step below the harness at every Funding was never the picture. The gas target is untouched, since a horse dodge makes no Gas Roll.
- **ADR change:** in ADR-0014's rewritten body (Minor 6): "ODM Gear and horse rated 2, every other item rated 1" for the Rookie.
- **Glossary change:** none.
- **Chapter impact:** `data/gear/standard-issue.yaml` `by_funding.horse_rating` 1, 1, 2, 2, 2, 3 and the file's comment. Chapter 4 section 4.9: the `by_funding` sentence and the reference-builds note ("The Funding 3 row issues ODM Gear and horses at rating 2, and Blade Sets at rating 1"; "a Funding 3 horse is rated 2, so a mounted dodge made with it follows the rating 2 rows: it goes lame within three rounds 10.6% of the time at Severity 3 against one Titan and 22.6% against two"); section 4.5 *What a horse rates* keeps the choice and may note the parity. The worked example: Jonas's and Ilse's rows read `Hr 2/2` (Jonas `Hr 2/2 @Distant A`, Ilse `Hr 2/2 M` then `Hr 2/2 @Distant A`), and any sentence that reads a horse's rating as 1. `data/gear/sheet-fields.yaml` `squad_sheet_row.example` reads `Hr 2/2 M`. Chapter 5's constraint on behaviors that reach mounted soldiers needs no special case: the mounted dodge has the baseline's pool.

### Minor 5: a full issue and worn items

- **Decision:** Review fix 1. A full Standard Issue replaces, at step 1, ODM Gear that the soldier lacks, that is Jammed, whose current rating is below its rating, or whose rating is below the row's; and, at step 4, a horse that the soldier lacks, that is lame, whose current rating is below its rating, or whose rating is below the row's. The replaced item leaves play. The decline (step 6) covers each of these exchanges: a soldier who declines keeps the item as it is, worn or at 0. The interim issue is unchanged: it replaces ODM Gear only when missing or rated below the row, and a horse when missing, lame, or rated below the row. "Standard Issue never restores the current rating of an item a soldier keeps" stays true.
- **Why:** At rating 2 a harness worn to 1 of 2 is the common state after a fight, and a rule that swaps a Jammed harness for a new one but keeps a worn one rewards leaving a Jam unrepaired before an Expedition. Replacing worn items too removes the incentive with the mechanism the step already uses, and keeps the Maintain Gear Downtime Action a role: items rated above the row (a Requisitioned harness, a Funding 6 horse) that the soldier declines to exchange. Restoring the current rating of kept items instead (the review's third fix) would make the issue repair gear, which the kept-items sentence and Field Repair's purpose both exclude. The interim issue stays narrow so that wear still carries between sessions in Phase 1 play, as OQ-59 intends.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Chapter 4 section 4.9 *Receiving it* steps 1, 4, and 6, and the OQ-59 design note; `data/gear/standard-issue.yaml` `receiving.steps[odm-gear]`, `[horse]`, `[decline]`, and `interim_issue.differences` (which now also states the horse step's narrower test); `data/gear/items.yaml` `odm-gear.restored_by` and `horse.restored_by` ("A full Standard Issue replaces Jammed or worn ODM Gear; the interim issue does not unless it is rated below the Funding row").
- **Revised by batch 3:** The interim issue's horse step now reads like the full issue's and replaces a worn horse, decline included (OQ-93); ODM Gear keeps the narrow rule because Field Repair restores it in the care window.

### Minor 6: ADR-0014's body

- **Decision:** Review fix 1, with fixes 2 and 3. ADR-0014's body paragraph on the reference builds is rewritten to state the three builds in full; `## Amended` keeps its history and gains one closing paragraph that says so. The body paragraph reads:

  > The simulator uses three reference builds. **Rookie:** Strength 4, Agility 3, Wits 2, and 3 elsewhere (the Slayer template's attributes; Health 4, Resolve 3), ODM Gear and horse rated 2 and every other item rated 1 (the Funding 3 Standard Issue), Talent 1, and Stress 1 when a fight begins. **Veteran:** Strength 5, Agility 3, Wits 2, and 3 elsewhere (19 points, a Top 10 Rookie; Health 4), two Scars (Resolve 5, minimum Stress 2), every item rated 2, Talent 2, and Stress 2 when a fight begins. **Levi-grade:** Strength 6, Agility 4, and 4 elsewhere (Health 5, Resolve 4), deliberately above any buildable total, no Scars, every item rated 3, Talent 3, and Stress 2 when a fight begins. Talent applies to the Nape strike, the Body Part strike, Break Free, and Treat Injury, with the dice Talent that names the roll; the dodge, Fly, Break Attention, Ride, and Read carry no Talent dice. The key attribute is Strength because the solo Nape-strike and Grab targets are Strength rolls, and Severity is tuned against the Rookie dodging with Agility 3 and ODM Gear 2. Unless a target says otherwise, the Squad is 4 PCs plus 2 Squadmates, all Rookies, in Wooded terrain, and results are medians. Beside every target, the simulator reports, without tuning: the Health-dependent targets (the Expedition PC Critical Injury and PC death targets, and a Grab on a victim already carrying untreated Critical Injuries) for the reference Squad with each soldier's Health set to 3 and nothing else changed, and for the Health 2, 5, and 6 builds Chapter 3 quotes; the Talent-dependent targets (the lone Grab, the rescue cells of OQ-50, the prepared-Squad kill) for a Squad built literally from the Squadmate templates; and the dodge for the Flier template alone.

  The closing `## Amended` paragraph reads:

  > After decision batch 2b (2026-09-14, the Chapters 1 to 4 conformance review, Majors 1 and 2, Minors 5 and 6): the body above now states the three builds in full, and the paragraphs of this section are the history of how they got there. Batch 2b settled that the builds carry no Talent dice on the dodge, Fly, Break Attention, Ride, or Read, and that the Rookie's horse is rated 2 like its ODM Gear, because Standard Issue now rates horses 1, 1, 2, 2, 2, 3 by Funding.
- **Why:** Five amendment paragraphs changed the build's attributes, Talent sense, report Squads, and ODM Gear, and a reader coding the simulator from the body line got Gear Dice 1. ADR-0003's checklist was moved into its body for the same reason. The "Flier or Rider" clause no longer has a case. The Veteran's ODM Gear equals the Rookie's, so Chapter 4's "higher ratings" sentence is true only of Blade Sets, horses, and kits, and the ladder must be measured on both builds the same way (Major 1).
- **ADR change:** ADR-0014, body paragraph replaced and the closing `## Amended` paragraph added, exactly as above. The two body sentences "The simulator uses three reference builds: Rookie (key attribute 4, Talent 1, Gear Dice 1), Veteran (5, 2, 2, two Scars), and Levi-grade (6, 3, 3). Unless a target says otherwise, the Squad is 4 PCs plus 2 Squadmates, all Rookies, in Wooded terrain, and results are medians." are what the new paragraph replaces; nothing else in the body changes.
- **Glossary change:** none.
- **Chapter impact:** Chapter 4 section 4.9's reference-builds note: "The Veteran's Blade Set and kit ratings of 2, and the Levi-grade soldier's ratings of 3, come from higher Funding or from Requisition. The Veteran's ODM Gear and horse ratings equal the Rookie's." The decisions file's Chapter 6 constraint quotes both sides of the ladder (Minor 8).

### Minor 8: corrections to `DECISIONS-2026-09-14.md`

Exact edits, applied:

1. **Preamble** (the paragraph beginning "Step 1 (2026-09-14, morning)"): replace "The register ends at OQ-57." with "The register ended at OQ-57 when step 2 was applied; OQ-58 and later entries are decided in the *Conformance follow-up*, *Batch 2*, and *Batch 2b* sections below."
2. ***Round-3 notes***, first paragraph: replace "The register ends at OQ-57; no note created a new entry." with "The register ended at OQ-57 at the time; no note created a new entry."
3. **Counts line:** replace "plus OQ-59 to OQ-73 under *Batch 2*. and marked Decided in OPEN-QUESTIONS.md." with "plus OQ-59 to OQ-73 under *Batch 2*, and the four batch 2b rulings; all 73 entries are marked Decided in OPEN-QUESTIONS.md." Replace "Four ADRs are amended (0003, 0005, 0014, 0015; ADR-0003 and ADR-0014 again in the conformance follow-up); no new ADR." with "Four ADRs are amended (0003, 0005, 0014, 0015), ADR-0003 and ADR-0014 again in the conformance follow-up, ADR-0014 and ADR-0015 again in batch 2, and ADR-0014's body in batch 2b; no new ADR." Replace "18 distinct glossary entries are edited (" with "19 distinct glossary entries are edited (Standard Issue in batch 2, and " keeping the rest of the list.
4. **OQ-72, *Why*:** replace "Rating 1 fails its own threshold before Chapter 5 adds anything: 31.7% of three-round fights against one Titan at Severity 3 and 47.1% against two," with "Rating 1 fails its own threshold against two Titans before Chapter 5 adds anything (47.1% of three-round fights at Severity 3) and sits just under it against one (31.7%),".
5. **OQ-72, *Decision*:** replace "Well-Kept Rig, Light Trigger, and the Blade Set and horse ratings are unchanged." with "Well-Kept Rig, Light Trigger, and the Blade Set ratings are unchanged." and add the line "- **Revised by batch 2b:** Standard Issue horse ratings follow the same ladder (1, 1, 2, 2, 2, 3), so the Rookie's horse is rated 2 (Major 2). The reference dodger carries no Talent dice (Major 1)."
6. **OQ-25:** add the line "- **Revised by batch 2b:** Parity between the horse dodge and the ODM dodge is restored by rating horses as ODM Gear (Major 2); the reference dodge carries no Talent dice (Major 1)."
7. **OQ-59:** add the line "- **Revised by batch 2b:** Horse ratings are 1, 1, 2, 2, 2, 3 by Funding (Major 2), and a full issue also replaces worn ODM Gear and worn horses, with the decline covering each exchange (Minor 5)."
8. **OQ-70:** add the line "- **Revised by batch 2b:** \"Talent 1 in the Talent that names each roll a target measures\" is narrowed to the Nape strike, the Body Part strike, Break Free, and Treat Injury; the dodge, Fly, Break Attention, Ride, and Read carry no Talent dice (Major 1)."
9. **OQ-58:** append to its `Revised by batch 2` line: "; batch 2b rates the Rookie's horse 2 and fixes the no-Talent dodge."
10. **Chapter 5 constraints:** replace "Tunes Severity against a Rookie dodging with Agility 3 and ODM Gear 2 (ADR-0014 as amended, OQ-72)" with "Tunes Severity against a Rookie dodging with Agility 3, ODM Gear 2, no dodge Talent, and Stress 1 (ADR-0014; a mounted Rookie's horse is rated 2 and dodges the same)". In the Jam test bullet, replace "the soldier who holds Attention and dodges for three rounds," with "the reference Rookie (Agility 3, ODM Gear 2, no dodge Talent, Stress 1 when the fight begins) who holds Attention and dodges for three rounds,".
11. **Chapter 6 constraint:** replace "re-measured at Agility 3 and ODM Gear 2 (OQ-72): a lone Rookie dodges Severity 3 20.6% of the time and Severity 2 49.7%." with "re-measured on the full builds (batch 2b): a supported Rookie (Agility 3, ODM Gear 2, no dodge Talent, Stress 1, one Help die) dodges Severity 3 29.2% of the time and a lone Veteran (Agility 3, ODM Gear 2, no dodge Talent, Stress 2) 26.1%; a lone Rookie dodges Severity 3 20.7% and Severity 2 49.7%; a lone Levi-grade soldier (Agility 4, ODM Gear 3, Stress 2) dodges Severity 3 38.6% and Severity 4 17.2%."
12. **Batch 2 intro** ("the Rookie dodge at Agility 3 and Stress 1, Pushing when short: 16.0%, 20.6%, and 25.6%"): insert "with no dodge Talent" after "Stress 1".
13. **Consistency check, *Reference builds* bullet:** append "Batch 2b fixes the no-Talent dodge, the rating 2 horse, and the ADR-0014 body text."

### Chapter impacts, batch 2b

**Chapter 1:** none.

**Chapter 2:** 2.10 design note and stat block sentence (Major 1); `data/character/squadmates.yaml` `stat_block.matches_reference_build` and `templates` comment (Major 1).

**Chapter 3:** 3.2 *Reference builds* (Major 1: the no-Talent sentence and the Flier report); nothing in 3.7.

**Chapter 4:** 4.3 gas note and 4.9 OQ-72 and reference-builds notes (Major 1, Minor 6); 4.5 and 4.9 horse rating sentences, the worked example rows, and `sheet-fields.yaml` example (Major 2); 4.9 *Receiving it* steps 1, 4, 6 and the OQ-59 note (Minor 5); `data/gear/standard-issue.yaml` `by_funding.horse_rating`, `receiving.steps`, `interim_issue.differences`; `data/gear/items.yaml` `restored_by` rows.

**Chapter 5 constraints:** the Severity baseline and the Jam test name the full Rookie build (Minor 8 items 10 and 11); no new constraint from Major 2, since the mounted dodge has the baseline's pool.

**Chapter 6 constraint:** the ladder on both builds (Minor 8 item 11).

## Batch 3: Chapter 5 and conformance leftovers (OQ-74 to OQ-99)

Decisions on OQ-74 to OQ-90 and OQ-93 to OQ-99: the PROVISIONAL choices and Unresolved Majors of Chapter 5 (`docs/rules/05-titan-engagement.md`, `data/engagement/`, three review rounds, last `docs/reviews/05-titan-engagement-review-3.md` and `-review-3-codex.md`), and the leftovers of the round 2 conformance review of Chapters 1 to 4 (`docs/reviews/01-04-decisions-conformance-review-2.md` and `-codex.md`). Decided and applied in one pass, since no review is running. The chapter files, YAML, probe scripts, review files, and `PROGRESS.md` are unchanged; the drafter applies the chapter impacts listed at the end of this section.

Odds without a source come from two scripts run outside the repository: `solo_b3.py` (100,000 trials per cell) reuses the committed dice core of `tools/probes/chapter-05/core.py` for the lone Nape strike under candidate levers and for Break Attention at needs 1 to 4; `decoy_b3.py` (12,000 fights per row, Medium, Wooded, 4 Rookie player characters at Stress 1 and 2 Squadmates) imports the committed `fight.py` unchanged and adds the round 3 review's beside-the-holder screen policy, the holder-only needs rule, and an escalating decoy cost. Both reproduce the chapter's and the reviews' figures within half a point (lone Rookie 13.2% at Stress 1, Levi-grade 47.4%; the beside-the-holder screen 0.423 Titan cards a round and 0.26 Critical Injuries per fight against the Opus review's 0.419 and 0.26; the 4 player character reference 62.1% by round 3, 0.70 Critical Injuries, 0.853 cards a round). Every number is a starting value for the ADR-0014 simulator.

Two entries change a rule (OQ-81 and OQ-97), one changes Chapter 4's interim issue (OQ-93), four amend ADR-0014 (OQ-79, OQ-94 item 1, OQ-95, OQ-98), and the rest keep the provisional choice with the Minor batches ruled item by item.

### Summary table

| OQ | Decision (one line) | ADR change | Glossary change | Chapter impact |
|---|---|---|---|---|
| OQ-74 | Keep (a): one step graph per Anchor Rating, Open's Blind Spot only while grounded, letting go | none | Blind Spot wording (OQ-99 item 9) | Ch5 5.2 note; `anchor-ratings.yaml` (OQ-99 item 9) |
| OQ-75 | Keep (a): a Position per Focus Titan with the close rule, records rewritten on a death, no effect reaches a horse | none | none | Ch5 5.2 note; `attention.yaml` horse wording (OQ-99 item 2) |
| OQ-76 | Keep (a): leaving and returning, soldiers who left as one Position, the Down crawl, falls land In Reach | none | none | Ch5 5.2, 5.11 notes |
| OQ-77 | Keep (a) with one change: Wings stand from the first wings step and change only after a loss or a new Focus Titan (OQ-97) | none | none | Ch5 5.3; `round.yaml` `wings`; Ch2 2.10 pointer |
| OQ-78 | Keep (a): every Size Class value is a simulator starting value; Large wording corrected (OQ-99 item 6) | none | none | Ch5 5.4, 5.13; `size-classes.yaml`, `tuning.yaml` |
| OQ-79 | Nape Depth 4 stays; ADR-0014's lone-Rookie bound becomes "about 10%", 8% to 14% at the Rookie's fight-start Stress 1, with 13.1% accepted and every lever measured and rejected | ADR-0014 body and `## Amended` | none | Ch5 intro, 5.13 (Simulator target block to design note); `tuning.yaml` `solo_nape.verdict` |
| OQ-80 | Keep (a): move up on an illegal roll, Positions checked at the card, tiers by result, five effect types | none | none | Ch5 5.5 note |
| OQ-81 | Break Attention needs 1 for the Attention holder only, 2 for anyone else, 2 against a holding Titan, plus 1 for each decoy that has already held that Titan's Attention this Titan Engagement; ties, flags, Down candidates, and the decoys stand | none (ADR-0010 holds) | Break Attention entry | Ch5 5.6, 5.13; `attention.yaml`, `round.yaml` tracker row; `action-catalog.yaml` `break-attention`; `tuning.yaml` `decoys`; probes |
| OQ-82 | Keep (a): Body Parts, Broken effects, grounding, one part per Regeneration clock | none | none | Ch5 5.7 note |
| OQ-83 | Keep (a): a soldier never spends an Opening they created; the glossary now says so | none | Opening entry | Ch5 5.7 note, 5.14; `bonus-dice-sources.yaml` unchanged |
| OQ-84 | Keep (a): Read needs 1 with 2 dice from Distant, closed fact list, Call It takes 2 successes for 2 dice to comrades | none | none | Ch5 5.8 note; `talents.yaml` Sharp Call pointer |
| OQ-85 | Keep (e), extended: the refund also covers a dodge whose successes the Grab's card compared (OQ-99 item 1) | none | none | Ch5 5.9; `grab.yaml` `countdown.failed_dodge`; Ch1 1.9 pointer |
| OQ-86 | Keep (a): every living soldier holding a Position, other than the victim, witnesses | none | none | Ch5 5.9 note |
| OQ-87 | Keep (a): clocks, entry, the retreat, the interim setup table; Lift Comrade leaves option 4 (OQ-99 item 4) | none | none | Ch5 5.10; `background-titans.yaml` |
| OQ-88 | Keep (a): two ending tests, the returner's one round, Down soldiers left behind die | none | none | Ch5 5.11 note |
| OQ-89 | Keep (a): four tactics, a Squad holds two, declarers and moments as drafted | none | none | Ch5 5.12 note; `squad-tactics.yaml` `rules.tuning` (OQ-99 item 5) |
| OQ-90 | Applied as listed; the three pending items are closed here (glossary Opening, Relentless and Sharp Call pointers, `sheet-fields.yaml` header) | none | Opening entry (with OQ-83) | Ch2 `talents.yaml`; Ch4 `sheet-fields.yaml`; Ch5 5.14 note |
| OQ-93 | (a): the interim issue's horse step reads like the full issue's and replaces a worn horse, decline included; ODM Gear keeps the narrow rule because the care window restores it | none | none | Ch4 4.1, 4.5, 4.9; `standard-issue.yaml`, `items.yaml` |
| OQ-94 | All four ruled: ADR-0014's no-Talent sentence closed ("No other roll a target measures carries Talent dice"); the four register summaries carry their batch 2b clause; the Counts line, Chapter 4's introduction and figures corrected; OQ-73's stale median revised | ADR-0014 body | none | Ch2 2.2, 2.7, 2.10; Ch3 3.2; Ch4 intro, 4.9; `squadmates.yaml` |
| OQ-95 | (c): ADR-0014 names "comrades close" as one comrade in reach with the reference build and starting state (OQ-50's six cells); the reference Squad's share is reported, not tuned | ADR-0014 body and `## Amended` | none | Ch5 5.9, 5.13 (Simulator target block to design note); `tuning.yaml` `grab` |
| OQ-96 | Keep (a): the Jam test is accepted on the worst legal support pattern against Behavior Table behaviors, with every card at kill Severity reported as an upper bound | none | none | Ch5 5.13 note; `tuning.yaml` `jam_test` |
| OQ-97 | Keep (a) with trims and bounds: the 12 to 20 minute band binds the one-Titan round, a two-Focus-Titan round is bounded at 30 minutes, Wings stand between losses, every soldier's Positions are read from the Squad sheet; the timed paper test has pass criteria and pre-decided fallbacks | none | none | Ch5 5.3; `round.yaml` `wings`, `gm_tracker`; `sheet-fields.yaml` |
| OQ-98 | (b) with (c): ADR-0014 states that each target is measured under a stated baseline policy, with sensitivity rows beside it, and lists what the Phase 1 simulator must model | ADR-0014 body and `## Amended` | none | Ch5 5.13 note; `tuning.yaml` `probes`, `simulator_cases` |
| OQ-99 | All nine ruled as listed under the entry | none | Opening and Blind Spot entries | Ch1 1.9; Ch4 `sheet-fields.yaml`; Ch5 5.3, 5.6, 5.9, 5.10, 5.12, 5.13; `grab.yaml`, `attention.yaml`, `background-titans.yaml`, `squad-tactics.yaml`, `size-classes.yaml`, `round.yaml`, `anchor-ratings.yaml`, `tuning.yaml` |

### OQ-74: Anchor Ratings, kinds of move, and Position steps

- **Decision:** Keep (a) as revised in review round 1. Each Anchor Rating has its own step rows in `anchor-ratings.yaml`: every rating joins Distant and In Reach and In Reach and On Body; every rating but Open joins On Body and Blind Spot; Sparse adds In Reach to Blind Spot with a Fly roll (failure ends at On Body); Wooded adds it with no roll; Urban adds it with no roll plus Distant to Blind Spot with a Fly roll (failure ends at In Reach); Giant Forest adds both with no roll. At Open, Distant to In Reach is made on foot or mounted only, and On Body to Blind Spot exists only while the Titan is grounded; a soldier holding Blind Spot there holds On Body once it stands. A mounted move makes only the Distant to In Reach step, and not at Urban. A grounded Titan lets moves on foot make its close steps. Letting go is a rule-named fall. The Fly roll needs are simulator starting values.
- **Why:** Both round 3 reviews judged the entry sound. The rating decides what ODM Gear allows, as the glossary says, one row per step with nothing to judge; Open is the plain where only a horse helps and Giant Forest is where the Survey Corps fights best. The prepared-Squad figures use the Wooded rows, which the interim setup table deals 2 times in 6.
- **ADR change:** none.
- **Glossary change:** the Blind Spot entry loses "behind or above" (OQ-99 item 9).
- **Chapter impact:** Section 5.2's `PROVISIONAL (OQ-74)` block becomes a design note; `anchor-ratings.yaml` `provisional` to `decided`, and its Blind Spot wording under OQ-99 item 9.

### OQ-75: Positions relative to two Focus Titans, placement, and recorded Positions

- **Decision:** Keep (a) as revised. A soldier holds a Position per Focus Titan, never On Body or Blind Spot relative to two at once (the close rule drops the other to In Reach). A Titan that enters is Distant from everyone. Records that name a dead Titan become Distant relative to the living Focus Titan with the earliest label. Everyone starts Distant, mounted or not as they were, unless the rule that begins the Titan Engagement names other starting Positions. Only a rider's move moves a horse; a riderless horse that succeeds as a decoy leaves; nothing moves left items; no effect type affects a horse. A comparison uses the Titan the roll or act names, otherwise the earliest living label. The riderless-horse decoy compares the horse's Position as `horses.yaml` does, relative to the Focus Titan recorded with it (OQ-99 item 2).
- **Why:** Both reviews judged it sound. A shared Position would make a second Titan change nothing, and no close rule would hook a soldier into two Titans. Starting Distant is placement by a rule, so no Drive fires on it (OQ-23).
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Section 5.2's two `PROVISIONAL (OQ-75)` blocks become design notes; `positions.yaml` `provisional` to `decided`; `attention.yaml` `decoys.riderless-horse.requirement` under OQ-99 item 2.

### OQ-76: Leaving, soldiers who left, a Down soldier's move, and where a fall lands

- **Decision:** Keep (a). A soldier leaves with a move while Distant relative to every Focus Titan and not Down, Grabbed, or carried; they still take turns, can return with a later move outside a retreat, and can take any Catalog entry that needs no Position relative to a Titan. Soldiers who left count as one Position for every rule that compares Positions and never as the same Position as, or one step from, a soldier still in the fight. A Down soldier's move can make only the In Reach to Distant step on foot. A fall from On Body or Blind Spot lands In Reach; a fall from In Reach or Distant keeps the Position.
- **Why:** Both reviews judged it sound. It extends Chapter 3's rule for soldiers who left to Chapter 4's acts, gives a Down soldier's move one use, and matches Chapter 4's height bands.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Sections 5.2 and 5.11 `PROVISIONAL (OQ-76)` blocks become design notes; `positions.yaml` `provisional` to `decided`.

### OQ-77: Initiative cards, swapping, Wings, and end steps

- **Decision:** Keep (a) as revised, with one change from OQ-97. Twenty numbered cards dealt face up: one to each player character and each Squadmate on no Wing, Tempo cards to each Focus Titan; a turn's move and action in either order, never split; the swap step before the first card, between two soldiers within one step who are neither Down nor Grabbed, once each per round, never with a Titan; end steps Gas Rolls, Regeneration, Background clocks, round ends. **Wings are assigned at the first wings step of the Titan Engagement and stand.** At a later wings step the players may change Wings only if, since the previous wings step, a soldier died, left, became Down, or became Grabbed, or a Focus Titan entered or died; a Squadmate whose player character died or left is assigned again at the next wings step whatever else happened. A Squadmate on no Wing still draws its own card.
- **Why:** Both reviews judged the entry sound. The one change is the round-time trim OQ-97 orders: assigning Wings every round is a deliberation the table pays each round for a choice that rarely changes, and the losses that made per-round assignment worth having are exactly the moments the rule keeps. Distinct numbers, the one-step swap, and the end-step order stand for the reasons drafted.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Section 5.3 *Wings* and the `PROVISIONAL (OQ-77)` block (a design note that states the cadence); `round.yaml` `wings.when` and `wings.assign` carry the cadence, `provisional` to `decided`; Chapter 2 section 2.10's Wings pointer to section 5.3 needs no change.

### OQ-78: Size Class starting values

- **Decision:** Keep (a). Small: Tempo 2, Nape Depth 3, Regeneration 2, Toughness 1 for every kind, Severity 1, 2, 2. Medium: Tempo 1, Nape Depth 4, Regeneration 3, Toughness 2, Severity 1, 2, 3. Large: Tempo 1, Nape Depth 4, Regeneration 4, Toughness eyes 2, arm 3, leg 2, Severity 2, 3, 4. Every value is a starting value for the ADR-0014 simulator, which must measure eyes and arm Toughness for every class and Large against the PC Critical Injury and PC death targets. The Large wording is corrected under OQ-99 item 6: a Large fight deals twice Medium's Critical Injuries and seven times its deaths.
- **Why:** The prepared-Squad target is met at Medium under every measured policy (median kill round 3, 62.6% by round 3, 0.71 Critical Injuries and 0.03 deaths per fight), and both reviews reproduced it (61.8% to 62.2%). Large at Nape Depth 4 finishes in a playable number of rounds (13.3% with no kill in 12 rounds against 36.6% at Nape Depth 5), and a canon Nape does not grow with the Titan. Large's death rate is the simulator's case, not a reason to move a value now: no Chapter 5 target measures Large, and the Expedition targets are where deaths are tuned.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Sections 5.4 and 5.13 `PROVISIONAL (OQ-78)` blocks become design notes; `size-classes.yaml` `provisional` to `decided`, its line 54 comment reads 36.6%; `tuning.yaml` `verdict` and section 5.13's *Large* bullet read as OQ-99 item 6 gives them.

### OQ-79: The lone Nape strike at Stress 1

- **Decision:** (a) with (d). Medium Nape Depth stays 4. ADR-0014's second target is amended to read: "A lone, average soldier who has used Break Attention succeeds on about 10% of Nape strikes against a Medium Titan, between 8% and 14% at the Rookie's fight-start Stress of 1; a Levi-grade soldier pushing hard succeeds about 50% of the time." The measured 13.1% (10.0% from Stress 0, 15.9% from Stress 2; the Veteran 32.3%; the Levi-grade soldier 47.4%) is accepted, and the Simulator target label comes off the block. The simulator re-measures the band with the full rules; a value outside it is a miss.
- **Why:** No lever meets the old bound without breaking another target, and each was measured before the bound moved. Nape Depth 5 gives the Rookie 3.6% but the Levi-grade soldier 28.2% and the prepared Squad a median kill of round 5 (35.1% by round 3). A 1-die penalty on the lone cut gives the Rookie 8.1% at Stress 1 and the Levi-grade soldier 41.9%, a 2-die penalty 4.3% and 35.6%, and forbidding the Push 2.1% and 19.6%; every one is a flat penalty for acting alone, which ADR-0010 rules out, and each pulls the Levi-grade target down more than it fixes the Rookie. The Rookie's Stress at a fight's start was set to 1 after the target was written (OQ-19, OQ-29, and the conformance follow-up), and in the Year Zero Engine Stress Dice add successes, so a bound written for a Stress 0 soldier reads three points higher at Stress 1: the miss is an artefact of the bound's date, not of the values. What the target protects still holds: the lone line succeeds on about one cut in eight, comes a median of 4 rounds after starting at Distant with 1.67 Titan cards against the soldier meanwhile, and under OQ-81 a second decoy on the same Titan needs 2 successes (49.8% per attempt for the Rookie) and a third 3 (20.8%), while a prepared Squad kills by round 3 in 62.6% of fights. Reading the Rookie at Stress 0 stays withdrawn.
- **Every target after the amendment:** prepared Squad, median kill round 3 (62.6% by round 3, 73.2% by round 4); lone Rookie 13.1% at Stress 1 (in the 8% to 14% band), Levi-grade 47.4%; a Grab kills 69.9% alone after a failed dodge and 73.1% with no dodge, 33.4% with one comrade in reach at Stress 2 and Grief 0 (cells 28.7% to 45.1%); gas medians 8 and 6 rounds; the Jam test's worst cell 32.7%; the Expedition targets await the Expedition rules.
- **ADR change:** ADR-0014, the second target in the body, and a `## Amended` paragraph. Applied.
- **Glossary change:** none.
- **Chapter impact:** Chapter 5 introduction ("Not every ADR-0014 target is met" becomes "every ADR-0014 target is met as amended in decision batch 3"); section 5.13's *A lone soldier after Break Attention* design note quotes the amended target, and its `Simulator target (OQ-79)` block becomes a design note; `tuning.yaml` `solo_nape.target` and `verdict`, `provisional` list; `size-classes.yaml` needs no change.
- **Revised by batch 3b:** The sentence "comes a median of 4 rounds after starting at Distant with 1.67 Titan cards against the soldier meanwhile, and under OQ-81 a second decoy on the same Titan needs 2 successes (49.8% per attempt for the Rookie) and a third 3 (20.8%)" was measured without OQ-81's escalation and is withdrawn. Under the rule as revised in batch 3b (decoys in a row, the Feint), on the full lone-fight model with the informed policy and the Rookie's decoy budget, a lone Rookie reaches a usable strike in 76.0% of fights within 12 rounds, most often in round 4, after about 2.9 Titan cards, and the cut succeeds 14.2% at the Stress those cards leave them at; one lone fight in nine kills. The 8% to 14% band is read on a fresh cut directly after Break Attention at fight-start Stress 1 (13.1%), and the in-fight cut is reported beside it. The Rookie's second and third decoy in a row succeed 49.6% and 20.6% of attempts on the committed core.

### OQ-80: The Behavior Table procedure

- **Decision:** Keep (a). A D6 table with results 1 and 2 terrorize, 3 and 4 control, 5 and 6 kill; an entry that repeats the previous behavior or needs Broken parts moves up to the next entry when rolled, wrapping from 6 to 1, else Thrash; at the card, missing parts give Thrash and an unmet Position requirement gives the fallback (Thrash if the fallback repeats or also fails); a holding Titan's card resolves nothing and keeps the Next Behavior; a decoy's card spends it; the tier rules and the closed list of five effect types stand. `behavior-procedure.yaml` `move_up_shares` stays as the warning to Chapter 6's authors, and the Chapter 6 constraints below make the shift a measured quantity.
- **Why:** Both reviews judged it sound. Moving up rolls the hidden die once (ADR-0003 item 8), a check at the card needs no guess, and tiers by result keep lethal harm to a third of rolls, which every kill and Jam figure measured.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Section 5.5's `PROVISIONAL (OQ-80)` block becomes a design note; `titan-format.yaml` and `behavior-procedure.yaml` `provisional` to `decided`.

### OQ-81: Attention Ladder ties, flags, Down soldiers, and Break Attention

- **Decision:** Keep (a) for ties, flags, Down and carried candidates, the struck-first narrowing, the end-step skip, the three decoys and their prices, and no decoy over a decoy. **Break Attention's needs change.** Against a Focus Titan: 1 success for the soldier who holds that Titan's Attention; 2 for anyone else, including while nothing or a decoy's aftermath holds it; 2 for anyone against a Titan holding a Grabbed soldier, which frees them; **plus 1 for each decoy that has already held that Titan's Attention in this Titan Engagement**, whoever placed it. The Focus Titan's tracker row records `decoys spent`, a count that starts at 0 when the Titan becomes a Focus Titan and never resets. Successes beyond the whole need create Openings as before. A comrade at the holder's Position no longer needs 1. The rejected decoy cap (no Break Attention on a Titan whose last card a decoy spent) stays rejected, and a decoy's card still resolves nothing (ADR-0010's "for its next card").
- **Why:** The round 2 rule did not do what it claimed. A Squadmate who rides or flies to the holder's Position first needs 1, so two Squadmates screening beside the holder left the Titan resolving 0.423 cards a round and 0.26 Critical Injuries per fight, against 0.833 and 0.65 with helper Squadmates: the screen took away half the Titan's cards and 60% of its harm while the kill got faster (73.3% by round 3 against 68.8%), a dominant play that no fiction supports. Measured on that policy, with the Squadmates sending and throwing whatever they need: needs 1 for the holder only gives 0.609 cards and 0.45 Critical Injuries; escalation alone (the round 2 rule plus 1 per decoy spent) 0.534 and 0.34; both together 0.660 cards, 0.47 Critical Injuries, 0.139 Grabs, 0.68 decoys per fight, and a median kill in round 3 at 67.5% by round 3. Under the two rules a screen is a trade rather than a dominant play: two Squadmates who spend their horses, cloaks, and every action cut the Titan's cards by a fifth and its harm by a quarter, and kill more slowly than two helpers. The holder-only rule restores ADR-0010's shape (Break Attention is the Attention holder's own escape, and a lone soldier always holds it, so OQ-79's figures do not move); Hook and Cut keeps its natural use, the holder breaking for a comrade at Blind Spot. Escalation is Position-proof and cheap to track, and it is what a Titan does: fooled once, it comes back fixated, and the second flare or bolting horse buys less. For a lone Rookie (Perception 3, ODM Gear 2, Pushing) a second decoy on the same Titan succeeds 49.8% of attempts and a third 20.8%, so the lone line keeps two or three cuts a fight; for a Levi-grade soldier 65.9% and 38.4%. The rejected cap would cost the lone soldier more (3.72 Titan cards before a usable strike against 1.67) and buys less than escalation on this policy (0.562 against 0.534 when added to the round 2 rule). Turning a decoyed card into a Thrash (Codex fix 1) would knock the lone striker off the Titan before their cut, and a per-round limit does nothing against a Tempo 1 Titan.
- **ADR change:** none. ADR-0010 is unchanged: Break Attention still shifts Attention onto a decoy for the Titan's next card, and the escalation is not a penalty for acting alone.
- **Glossary change:** Break Attention entry becomes: "An action that shifts a Focus Titan's Attention onto a decoy, such as a flare, a riderless horse, or a thrown cloak, for its next card. It is easiest for the soldier holding the Titan's Attention, and harder each time the same Titan has already been decoyed in the Titan Engagement." Applied.
- **Chapter impact:** Section 5.6 *Break Attention and decoys* (the needs list) and the `PROVISIONAL (OQ-81)` block (a design note with the figures above); `attention.yaml` `break_attention.needs` (`holder: 1`, `anyone_else: 2`, `titan_holds_a_grabbed_soldier: 2`, `per_decoy_already_spent: +1`) and `needs_rule`, `provisional` to `decided`; `round.yaml` `gm_tracker.focus_titan_row` adds "decoys spent" and its example; `data/character/action-catalog.yaml` `break-attention` `needs` line; section 5.13's *Decoys* bullet and `tuning.yaml` `decoys` and `titan_cards_resolved_per_round` re-run under the rule with the beside-the-holder policy (the figures above are the starting rows); `tools/probes/chapter-05/fight.py` `ba_need` and the rescue path carry the rule; Chapter 5 example unchanged.
- **Revised by batch 3b:** The escalation counts decoys in a row, reset by a card that resolves a behavior, and a repeatable Feint decoy is added, because the permanent count with finite decoys could close a lone soldier's route to the Nape (Codex Critical 1). "The lone line keeps two or three cuts a fight" and "The rejected cap would cost the lone soldier more (3.72 Titan cards before a usable strike against 1.67)" compared the cap with the rule before escalation and are withdrawn; the cap's rejection rests on the screen rows and on the lone model (3b-2). The figures this entry quotes from decoy_b3.py are superseded by the committed probes, which tuning.yaml governs: the screen beside the holder under the review round 2 rule 0.413 cards a round and 0.25 Critical Injuries per fight (not 0.423 and 0.26), needs 1 for the holder only 0.601 and 0.42 (not 0.609 and 0.45), the cap added to the round 2 rule 0.509 against escalation's 0.538 (the sentence "buys less than escalation" was inverted and is withdrawn), and the rule as revised 0.624 and 0.44 (batch 3's rule 0.663 and 0.49). The 4 player character and 2 helper Squadmate case sits on the boundary between a round 2 and a round 3 median (69.2% to 69.7% by round 3), so "kill more slowly than two helpers" reads "no faster than two helpers". A decoy holds for as many of the Titan's next cards as its Tempo (3b-8), which changes nothing at Tempo 1.
- **Revised by batch 3c:** A flag lasts until the Titan's next card that evaluates its Attention Ladder, not its next card, so that a hold of Tempo cards (batch 3b) cannot clear a hooked-by-strike flag unread; the Feint can be made on foot against a grounded Titan.
- **Revised by batch 3e:** A flag lasts until the end of the Titan's next card that resolves a behavior; the batch 3c and 3d wordings are withdrawn (3e-1). The nearest rung is met by the candidates at the closest Position, so when it is the highest rung met the tied set is those candidates and the holder step decides only ties at equal distance; the closed tests list gains current-holder for Abnormal ladders (3e-6).
- **Revised by batch 4:** The last tie-break no longer reads the Squad sheet: a tie the card step cannot break, at the start of a Titan Engagement or at an end step, leaves Attention held by nothing until the Titan's next card, which evaluates the ladder with that round's cards (4-3). "Keep (a) for ties" stands for the holder and card steps.

### OQ-82: Body Parts, what Broken does, a grounded Titan, and Regeneration

- **Decision:** Keep (a) as revised. Eyes are struck from On Body or Blind Spot, arms and legs from In Reach or On Body, every part from In Reach, On Body, or Blind Spot while grounded except a holding arm; counts return to 0 at each state change and successes beyond Broken become Openings; Broken eyes stop flare and cloak decoys, a Broken arm frees its victim, a Broken leg grounds the Titan (2 Nape strike dice, no working ODM Gear needed for strikes, close steps on foot); a full clock erases Openings, sets every count to 0, and moves the most damaged part one state toward Intact.
- **Why:** Both reviews judged it sound. One part per clock is what the glossary says, clearing counts makes Regeneration a real deadline (Medium 62% to 58% at a clock of 2), and grounding is the rule Chapter 4's strikes row waits for.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Section 5.7's `PROVISIONAL (OQ-82)` block becomes a design note; `titan-harm.yaml` `provisional` to `decided`.

### OQ-83: Whether a soldier can spend Openings they created

- **Decision:** Keep (a): only a soldier other than its creator can spend an Opening, whatever created it, and it waits on the Titan for a comrade even if its creator dies or leaves. The glossary is changed to match (with OQ-90 and OQ-99 item 7).
- **Why:** Both reviews judged it sound. Spendable own Openings would take the lone Rookie to 15.9% and let a lone soldier's short cut feed their own next cut, which ADR-0007 rejected when it stopped Nape cuts adding up. (a) reads "any ally" as the creator's comrades and keeps Openings a teamwork lever (ADR-0010).
- **ADR change:** none.
- **Glossary change:** Opening entry becomes: "A token on a Titan created by successes beyond Breaking a Body Part, extra successes on Break Attention, every success of a Nape strike that falls short, or a rule that names it, such as Relentless. Any comrade of the soldier who created it can spend it as a Bonus Die on a Nape strike until Regeneration erases it; its creator never can." Applied.
- **Chapter impact:** Section 5.7's `PROVISIONAL (OQ-83)` block becomes a design note and drops its pending-glossary sentence; section 5.14's OQ-90 note likewise; `titan-harm.yaml` `provisional` to `decided`; `data/core/bonus-dice-sources.yaml` `opening` row unchanged.

### OQ-84: Read and Call It

- **Decision:** Keep (a) as revised. A Read needs 1 success and gains 2 Bonus Dice from Distant; each success reveals one fact from the closed list (the Next Behavior against any Focus Titan; an Abnormal's named Body Part Toughness, Nape Depth, Regeneration clock length, or Attention Ladder); everything else is public. Call It takes 2 of that Read's successes (1 with Sharp Call) and gives 2 Bonus Dice to each dodge other than the reader's against the card that resolves the Called behavior. Read's needs, Call It's successes, and the two dice rows are simulator starting values, and the Tactician case (a soldier Reading from Distant every round and Calling It) is a simulator case reported against the Jam test and the PC Critical Injury target.
- **Why:** Both reviews judged it sound. It keeps the final design review's dice, closes the lists, spends no success on a public number, and keeps Call It teamwork.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Section 5.8's `PROVISIONAL (OQ-84)` block becomes a design note; `read.yaml` `provisional` to `decided`; `data/character/talents.yaml` Sharp Call's effect points to `data/engagement/read.yaml` (`call_it`) instead of "Chapter 5 states" (OQ-90).

### OQ-85: The Grab procedure and its rescue structure

- **Decision:** Keep (e), extended by OQ-99 item 1. Break Free and Pry Loose need 2, with a 2-die penalty once lifted; the holding arm is struck from In Reach, On Body, or Blind Spot before the lift and from On Body or Blind Spot after, with no strike penalty and no widening by grounding; a holding Titan's cards resolve nothing; Break Attention needing 2 frees the victim; a soldier freed before the lift holds In Reach and one freed after falls and lands In Reach; the Grab spends the action of the victim's first counted turn whether or not anything already spent it; a dodge against the Grab, or a dodge whose successes the Grab's card compared, that spent a turn later than the first counted turn has that turn given back as the Grab lands, with the first counted turn counting as spent instead. A Grabbed soldier who dies ends the Grab at once. The holding arm's count is 0 while it holds and after release.
- **Why:** Both reviews reproduced the figures (alone 69.9% after a failed dodge, 73.1% with none, 55.5% per Grab card for a victim who always dodges; with turn debt 70.1% and 73.0%; the six one-comrade cells 28.7% to 45.1%) and judged (e) sound. The Tempo 2 residual, where a failed dodge against a Small Titan's first card spent next round's turn and the second card's Grab then found both counted turns spent, is the same loss (e) removed, and the extension closes it with the same refund.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Section 5.9 *The countdown* and the `PROVISIONAL (OQ-85)` block (a design note); `grab.yaml` `countdown.failed_dodge` and `grab_lands.failed-dodge` cover a dodge whose successes the Grab's card compared, `provisional` to `decided`; Chapter 1 section 1.9's refund pointer names both dodges.

### OQ-86: Witnesses

- **Decision:** Keep (a): every living soldier who holds a Position in the Titan Engagement when the event is resolved, other than the victim, is a witness; soldiers who left are not.
- **Why:** Both reviews judged it sound. A Titan eating a soldier is seen across the field; spacing must not avoid Fear Rolls, and the OQ-50 cells give every rescuer the roll.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Section 5.9's `PROVISIONAL (OQ-86)` block becomes a design note; `engagement-flow.yaml` `provisional` to `decided`.

### OQ-87: Background Titans, the retreat, and the interim setup table

- **Decision:** Keep (a) as revised, with OQ-99 item 4. A clock fills 1 segment a round and 1 for each flare spent on Break Attention once that Break Attention and any Hook and Cut it allows are resolved; a full clock brings its Titan in Distant from everyone while fewer than two Focus Titans are alive, otherwise the Titan Engagement becomes a retreat with its forced moves (toward Distant, leave, toward a fallen comrade, or stay beside one after a rescue action for them this turn: Treat Injury, or for a Grabbed comrade Pry Loose, a strike on the holding arm, or Break Attention against the holding Titan; **Lift Comrade is not on the list**, because a lifted comrade is carried and the carrier heads out by option 1). The interim D6 setup table stands until Mission Briefs and Expeditions name these values. Clock lengths are simulator starting values, measured against a retreat rate per Titan Engagement, and OQ-97 names them as the fallback lever for two-Focus-Titan round time.
- **Why:** Both reviews judged it sound. A retreat that ends at once skips the escape that makes it dangerous, and no setup table is GM discretion (ADR-0003). Flares that fill clocks price the flare decoy in Titans drawn in, as signal flares do in canon.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Section 5.10 (option 4's list) and its `PROVISIONAL (OQ-87)` block (a design note); section 5.1's `PROVISIONAL (OQ-87)` block likewise; `background-titans.yaml` `retreat.moves` option 4 drops `lift-comrade` and adds "A soldier who lifts a comrade carries them out by option 1", `provisional` to `decided`; `engagement-setup.yaml` `provisional` to `decided`.
- **Revised by batch 5:** A retreat also starts when the Titan Engagement's retreat clock is full, 8 segments on the interim setup table, filled at the background-clocks end step after the Background clocks and never by a flare (5-10, OQ-126), and under a retreat the forced move comes before the action except a stay-with-a-comrade move (5-1, OQ-119). The retreat rate this entry left to the simulator is now a figure: 8.2% of the standard Medium Titan's reference fights and 13.8% of the Large's end in a retreat (`tools/probes/batch-5/retreat_b5_explore.out`).

### OQ-88: When a Titan Engagement ends, and soldiers left behind

- **Decision:** Keep (a) as revised: it ends when no Focus Titan is alive, or when no soldier holding a Position is alive and not Down; the second test ends it at once if no soldier holds a Position or no returner exists, otherwise at the round-ends step of the next round if the test still holds, or at once when the last returner is gone; in the second case with a Titan alive, every soldier still holding a Position dies with no Fear Rolls and counts for Grief.
- **Why:** Both reviews judged it sound. It makes carrying a comrade out the way to save them, gives a returner one round, and runs no rounds without choices.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Section 5.11's `PROVISIONAL (OQ-88)` block becomes a design note; `engagement-flow.yaml` `provisional` to `decided`.

### OQ-89: Squad Tactics for Phase 1

- **Decision:** Keep (a) as revised: Hook and Cut, Hamstring Line, Clear the Hand, and Fall Back, each with its declarer and moment; a Squad holds two, chosen before its first Titan Engagement; a use is spent once declared; disagreements go to the roll-off. Under OQ-81's Break Attention needs, Hook and Cut's Break Attention needs 1 only when the Attention holder makes it, and its needs rise with the decoys already spent on the Titan; the tactic's text is unchanged. The six Grab cells with each tactic held, and tactic policies beyond the probe's, are simulator cases.
- **Why:** Both reviews judged it sound, and every tactic alone and in pairs keeps the Medium median kill in round 3 for 4 player characters (61.8% to 66.2% by round 3, 0.63 to 0.72 Critical Injuries per fight). With Squadmates the median moves to round 2 whatever the tactics, which is the Squadmates' doing (OQ-98). Under the OQ-81 rule, 2 Squadmates screening beside the holder while the Squad holds Hook and Cut and Hamstring Line give a median kill in round 3 (70.2% by round 3, 0.46 Critical Injuries per fight, 0.621 Titan cards a round); 2 helper Squadmates with the same tactics give median 2, 72.4%, and 0.59; and 4 player characters alone with them give median 3, 66.3%, and 0.63, the round 2 figures unchanged.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Section 5.12's `PROVISIONAL (OQ-89)` block becomes a design note; `squad-tactics.yaml` `provisional` to `decided` and its `rules.tuning` row as OQ-99 item 5 gives it.
- **Revised by batch 3b:** Hook and Cut's Break Attention follows the needs as revised (decoys in a row, the Feint), and "with Squadmates the median moves to round 2" reads "with Squadmates the median sits on the boundary between rounds 2 and 3 (69.2% to 69.7% by round 3)".

### OQ-90: Rows and pointers Chapter 5 needs in Chapters 1 to 4

- **Decision:** Keep (a), applied. Items 1 to 16 stand as applied in the round 1 and round 2 fixes. The three pending items are closed: the glossary's Opening entry (OQ-83, applied here); `data/character/talents.yaml` Relentless and Sharp Call point to `data/engagement/titan-harm.yaml` (`nape_strikes`, `openings`) and `data/engagement/read.yaml` (`call_it`) instead of "Chapter 5 states"; `data/gear/sheet-fields.yaml`'s header carries OQ-90 beside its decided entries (OQ-99 item 3).
- **Why:** ADR-0012 keeps one source per table and ADR-0003 item 12 needs the two new acts in Chapter 2's files; the Chapter 5 reviews found the applied items consistent with every decided entry they checked. A pointer that says Chapter 5 will state a rule is stale once Chapter 5 does, and the same holds for the two Talent rows.
- **ADR change:** none.
- **Glossary change:** the Opening entry, under OQ-83.
- **Chapter impact:** Section 5.14's `PROVISIONAL (OQ-90)` block becomes a design note with no pending sentence; `data/character/talents.yaml` Relentless `effect` ("The strike creates 1 more Opening than data/engagement/titan-harm.yaml (nape_strikes) gives it for its successes") and Sharp Call `effect` ("Calling It needs one fewer success from your Read than data/engagement/read.yaml (call_it) states, to a minimum of 1"); `data/gear/sheet-fields.yaml` header `decided:` adds OQ-90.

### OQ-93: A worn horse at the interim issue

- **Decision:** (a), with (d)'s reason written into `why_narrow`. The interim issue's horse step reads like the full issue's: a soldier with no horse, a lame horse, a worn horse (current rating below its rating), or a horse rated below the row's horse_rating receives a horse with the row's rating at full, and the decline covers the exchange. ODM Gear keeps the narrow rule (replaced only when missing or rated below the row), and a kit at 0 is kept. `why_narrow` reads: "Wear carries between sessions only on items a Phase 1 rule other than Standard Issue can restore: ODM Gear and tool kits through Field Repair, medical kits through restocking. No Phase 1 rule restores a horse, so the interim issue replaces a worn one." Chapter 4's "No other Phase 1 rule restores a horse" becomes "The interim issue replaces a worn or lame horse (section 4.9); no other Phase 1 rule restores one."
- **Why:** Batch 2b rated the Funding 3 horse 2 so that the mounted dodge has the ODM dodge's pool, and it removed from the full issue the incentive to drive an item to 0 rather than keep it worn. The interim issue kept both problems for horses: a horse worn once (40.8% of horses after three mounted dodges at Severity 3) dodged at the rating 1 figures for the rest of Phase 1 play (16.0% against 20.7% at Severity 3, lame within three rounds 31.5% against 10.6%), a lame horse came back new while a worn one never did, and a Pushed Break Attention with the horse as gear item lamed it with no fall. The full issue's step is the mechanism already written; (b) widens Field Repair past what OQ-66 kept it to, and (c) would carry a worn horse into every Chapter 5 mounted figure and make Sure Seat and Loose the Horse pointless again. The Chapter 5 constraint "a mounted Rookie's horse is rated 2 and dodges the same" holds at every session's start.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Chapter 4 section 4.1 *Restoring* ("the interim issue replaces a lame or worn horse, replaces Jammed or worn ODM Gear only if it is rated below the Funding row, and never replaces a kit at 0"); section 4.5 *Lame* sentence; section 4.9 the interim sentence and the OQ-59 design note (wear carries between sessions on ODM Gear and kits, not horses); `data/gear/standard-issue.yaml` `interim_issue.differences` (the horse row becomes "At step horse, the full issue's test applies") and `why_narrow`; `data/gear/items.yaml` `horse.restored_by` ("Standard Issue, full or interim, replaces a lame or worn horse").

### OQ-94: Open Minor findings from the round 2 conformance review of Chapters 1 to 4

- **Decision:** each item as follows.
  1. **Unclassified rolls (ADR-0014):** review fix 1. ADR-0014's sentence becomes "Talent applies to the Nape strike, the Body Part strike, Break Free, and Treat Injury, with the dice Talent that names the roll. No other roll a target measures carries Talent dice, including the dodge, Fly, Break Attention, Ride, and Read." The Death Roll baseline is Strength alone (51.8% at Strength 4), Hard to Kill stays a simulator check. Chapters 2 and 3 and `squadmates.yaml` restate it.
  2. **Register summaries:** review fix 1. The `Decision` lines of OQ-25, OQ-59, OQ-70, and OQ-72 in OPEN-QUESTIONS.md gain their batch 2b clause: OQ-25 "Revised by batch 2b (OQ-92): parity restored by rating horses as ODM Gear"; OQ-59 "Revised by batch 2b (OQ-91, OQ-92): horses 1, 1, 2, 2, 2, 3; a full issue also replaces worn ODM Gear and horses" and now "(OQ-93): the interim issue replaces a worn horse"; OQ-70 "Revised by batch 2b (OQ-91): narrowed to the Nape strike, the Body Part strike, Break Free, and Treat Injury"; OQ-72 "Revised by batch 2b (OQ-92): horses on the same ladder". Applied.
  3. **Bookkeeping and figures:** review fix 1 and 2. The Counts line in this file's preamble is rewritten (applied). Chapter 4's introduction reads "Decision batch 2b revised two of them and ADR-0014's reference builds". Section 4.9 quotes 20.7% in the OQ-72 note and 10.6% for the lame figure everywhere, with the table row re-run exactly or labelled a sample.
  4. **OQ-73's stale median:** review fix 1. A `Revised by batch 3:` line on OQ-73 in this file records that at ODM Gear 2 the reference Rookie's roll needing 2 successes lasts a median of 7 rounds (mean 7.23, 10th to 90th percentile 3 to 12), as Chapter 4 section 4.3 states. Applied. The `PROGRESS.md` row is the orchestrator's.
- **Why:** Each is a wording or record fix; none changes a rule or a target. Closing the Talent list by exclusion is what "narrowed" meant in batch 2b and what Chapter 2's OQ-28 note already assumes.
- **ADR change:** ADR-0014 body (item 1). Applied.
- **Glossary change:** none.
- **Chapter impact:** Chapter 2 sections 2.2, 2.7, and 2.10 and `data/character/squadmates.yaml` `stat_block.matches_reference_build` and the `templates` comment (item 1); Chapter 3 section 3.2 *Reference builds* (item 1); Chapter 4 introduction and section 4.9 figures (item 3).

### OQ-95: What "comrades close" means for the Grab target in a Squad fight

- **Decision:** (c), naming the arrangement, with (a)'s report. ADR-0014's third target is amended to read: "A Grab kills about 1 time in 3 with comrades close, about 2 in 3 when alone. Comrades close means one comrade in reach with the reference build and starting state: a Rookie with Talent 1 on the Body Part strike at In Reach, over the six cells of witness Stress 1, 2, and 3 with Grief 0 and 1 (OQ-50), every cell under 50% and the Stress 2, Grief 0 cell near 1 in 3. The share of Grabs the reference Squad's victims die from, with every written rescue in play, is reported beside it and not tuned." The six cells stand as the band test (28.7% to 45.1%, 33.4% at Stress 2 and Grief 0). No Squad-model floor is set.
- **Why:** Both reviews judged (a) unsound as a final reading and recommended naming the arrangement. OQ-50's band was decided on one comrade in reach, and every lever that lifts the Squad-model rate toward 1 in 3 (normal Toughness after the lift, Break Attention needing 3, a rescue strike penalty) lifts a one-comrade cell past 50% or contradicts ADR-0015. A floor would bind a figure that depends on how many soldiers are in reach, which the Squad's play decides; the Expedition Critical Injury and death targets are where the fight's lethality is tuned, and a Grab's crush still costs a Critical Injury every time. The full-fight shares (9.1% of Grabs with 4 player characters, 2.1% with 2 helper Squadmates, 14.4% for the template Squad) are the report.
- **ADR change:** ADR-0014, the third target in the body, and a `## Amended` paragraph. Applied.
- **Glossary change:** none.
- **Chapter impact:** Section 5.9's OQ-85 note and section 5.13's `Simulator target (OQ-95)` block become a design note quoting the amended target; `tuning.yaml` `grab.target`, `provisional` list.

### OQ-96: The Jam test's acceptance reading

- **Decision:** Keep (a). The Jam test (OQ-72) is accepted on the worst legal support pattern, Help of 0 to 3 dice on every dodge and Covering on every Push or on none, against behaviors dealt by the Behavior Table procedure on the reference table, with every card at kill Severity reported as an upper bound. The worst cell is two Large Titans, Covered, no Help, at 32.7% (both reviews 32.4% to 32.9%); the upper bound is 35.4%. Any change to a Severity, Tempo, or the wear rule re-runs the test before it is accepted, and the Chapter 6 constraints below require the run for each standard Titan's table.
- **Why:** (c) rested on an arbitrary coin flip, and (b) measured a Titan no Behavior Table can deal. (a) is the worst case a legal fight reaches, and it passes by 0.6 points, which is why the re-run rule is written down.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Section 5.13's `PROVISIONAL (OQ-96)` block becomes a design note; `tuning.yaml` `jam_test` `provisional` to `decided`.

### OQ-97: Round time and the bookkeeping aids

- **Decision:** Keep (a) with trims and bounds, so that a typical round is runnable as written:
  1. **The band.** The final design review's 12 to 20 minutes binds the typical round: one Focus Titan, 4 player characters and 2 Squadmates, all fully tracked. A round with a Grab may run to the band's top plus its witnesses' Fear Rolls, rolled together. A round against two Focus Titans is bounded at 30 minutes. Both are design targets until the timed test below measures them.
  2. **Wings stand** (OQ-77): assigned at the first wings step and changed only after a loss or a Focus Titan entering or dying, so the wings step is usually a sentence.
  3. **One record of Positions:** every soldier who takes part in a Titan Engagement, player character or Squadmate, has a Squad sheet row whose positions column is the record the ladder reads; the character sheet's positions field mirrors it (OQ-99 item 3).
  4. **The aids stand:** the Titan-card checklist in procedure order, Gas Rolls and one event's Fear Rolls rolled together, a standard Titan's values public, and the tracker updated at the named moments including after each counted turn of a Grabbed soldier (OQ-99 item 8).
  5. **The timed paper test** is the first Phase 1 playtest item: one round with 4 player characters and 2 Squadmates against one Medium Titan, one Grab round, and one round against two Focus Titans, with players new to the rules, reporting median and upper-quartile times. Pass: one-Titan median at or under 20 minutes, two-Titan median at or under 30.
  6. **Fallbacks, pre-decided and in order.** If the one-Titan median misses: option (b), Wings fixed for the whole Titan Engagement and the swap step removed, which amends ADR-0010's list of soft levers. If the two-Titan median misses after that: the interim setup table's Background clocks lengthen by 2 (6, 8, and 6 with 10), a Chapter 5 starting value, so that two-Titan rounds are rarer in Phase 1 play; the retreat rule and the two-Titan cap are not touched. Option (c), collapsing Body Part states and counts or making gas one Squad check, is rejected: it changes ADR-0007 or Chapter 4's decided gas rule.
- **Why:** The round 3 estimates put the typical round inside the band (12 to 17 minutes), a Grab round at 16 to 22, and a two-Titan round at 22 to 30, which the second Titan's card, ladder, and tracker row make inevitable; a bound of 30 for that round is honest, and the setup table's clocks (4 to 8 rounds against fights of 3 to 4) are the lever that decides how often it happens. The trims cost no rule the ADRs rest on: Wings that stand save a deliberation each round, and one Positions record removes the double bookkeeping the round 3 review found. Naming the pass criteria and the fallbacks now means the test decides without another decision pass.
- **ADR change:** none now; ADR-0010 is amended only if fallback (b) is triggered.
- **Glossary change:** none.
- **Chapter impact:** Section 5.3 *Wings*, *What the GM tracks*, and the `PROVISIONAL (OQ-97)` block (a design note stating the band, the bounds, the test, and the fallbacks); `round.yaml` `wings`, `gm_tracker.per_round_order`, `titan_card_checklist` ("each soldier's Squad sheet row"), `provisional` to `decided`; `data/gear/sheet-fields.yaml` `squad_sheet_row.purpose` (every soldier in a Titan Engagement has a row).
- **Revised by batch 3b:** Fallback 2's clock list reads 8, 6, and 6 with 10; Fall Back is declared "before Wings are assigned or kept"; every soldier's Squad sheet row carries their name and, for a player character, a dash in the gear columns their character sheet holds.

### OQ-98: The policy each Chapter 5 tuning figure is measured under

- **Decision:** (b) with (c). ADR-0014's body gains: "Each target is measured under the baseline policy `data/engagement/tuning.yaml` states for it: the reference Squad's roles, striking and dodging choices, and rescues, with no Read, Call It, Wings, initiative swaps, Squad Tactics, or Background Titans unless the target names them. Sensitivity rows are reported beside each target, not tuned: every Squad Tactic alone and in pairs, decoy screens, a Tactician Reading and Calling It, Pry Loose, and helper Squadmates. Every value is a starting value until the Phase 1 simulator, which models every rule and every reference-build action under published policies, re-measures it." The tactic and escape rows stand as the sensitivity evidence, and the full simulator cases in `tuning.yaml` (`simulator_cases`) are the Phase 1 simulator's specification, extended by the list under the Chapter 6 constraints below.
- **Why:** ADR-0014 names reference builds, not a policy, so a probe that plays one policy could be read as either the target or an approximation; writing the baseline into the ADR makes the tuning rows the target's definition and the omitted abilities a bounded sensitivity, which is what both reviews asked for. (a), building the full simulator before accepting any value, is the Phase 1 simulator item in `PROGRESS.md`, not a chapter fix, and the starting values are needed now for Chapter 6.
- **ADR change:** ADR-0014 body and `## Amended`. Applied.
- **Glossary change:** none.
- **Chapter impact:** Section 5.13's `PROVISIONAL (OQ-98)` block becomes a design note; `tuning.yaml` `probes` states the baseline as the ADR does, `simulator_cases` gains the items listed under the Chapter 6 constraints, `provisional` to `decided`.

### OQ-99: Open Minor findings from Chapter 5 review round 3

- **Decision:** each item as follows.
  1. **Tempo 2 turn debt:** review fix 1, under OQ-85: `failed_dodge` also gives back the turn spent by a dodge whose successes the Grab's card compared, when that turn comes up after the first counted turn.
  2. **Riderless-horse wording:** review fix 1, under OQ-75: `attention.yaml` `decoys.riderless-horse.requirement` reads "the soldier is mounted on it, or it holds the Position the soldier holds, both compared relative to the Focus Titan recorded with the horse's Position (data/gear/horses.yaml, gear_dice)".
  3. **Positions record:** review fixes 1 and 2, under OQ-97: every soldier in a Titan Engagement has a Squad sheet row, whose positions column is the record the ladder reads and the character sheet's positions field mirrors; both use the column's format ("A In Reach B Distant"); `sheet-fields.yaml`'s header lists OQ-90 beside its decided entries.
  4. **Retreat option 4:** review fix 1, under OQ-87: `lift-comrade` leaves the list, and a sentence says a carrier heads out by option 1.
  5. **`squad-tactics.yaml` tuning row:** review fix 1, under OQ-89: "The reference rows are measured without Squad Tactics; every tactic alone and in pairs is reported beside them (data/engagement/tuning.yaml, prepared_squad_kill, squad_tactics)."
  6. **Large wording:** review fix 1, under OQ-78: "twice Medium's Critical Injuries and seven times its deaths (1.41 and 0.19 against 0.71 and 0.027)" in section 5.13, `tuning.yaml` `verdict`, and this file's OQ-78 entry; `size-classes.yaml` line 54 reads 36.6%.
  7. **Glossary Opening:** review fix 1, under OQ-83. Applied.
  8. **Tracker cadence:** review fix 1, under OQ-97: `round.yaml` `gm_tracker.per_round_order` and section 5.3 add "after each counted turn of a Grabbed soldier (the countdown and lifted)".
  9. **"Behind":** review fix 2: `anchor-ratings.yaml`'s Open row reads "Nothing holds a soldier out of a standing Titan's sight with its Nape in reach, so no step reaches blind-spot until the Titan is grounded"; the glossary's Blind Spot entry reads "The Position out of a Focus Titan's sight with its Nape within reach, anchored to terrain rather than hooked into the Titan, and the only Position a Nape strike can be made from. Making a Nape strike counts as hooking into the Titan." Applied.
- **Why:** Each item's rule is settled in the entry it belongs to; none changes an ADR-0014 figure. Item 1 is the residual of (e), item 3 removes a double record the round-time trims need gone, and item 9 removes the shorthand the glossary itself lists under Avoid.
- **ADR change:** none.
- **Glossary change:** Opening (item 7) and Blind Spot (item 9). Applied.
- **Chapter impact:** as listed under OQ-75, OQ-78, OQ-83, OQ-85, OQ-87, OQ-89, OQ-90, and OQ-97; Chapter 1 section 1.9's refund pointer (item 1); `data/gear/sheet-fields.yaml` (item 3); `anchor-ratings.yaml` (item 9).

### Chapter impacts of batch 3

**Chapter 1:** Section 1.9 *Which turn it spends*: the refund pointer covers a dodge against the Grab's card and a dodge whose successes that card compared (OQ-85, OQ-99 item 1). Nothing else; the Bonus Dice rows and the dodge are unchanged.

**Chapter 2:** Sections 2.2, 2.7, and 2.10: the no-Talent sentence becomes "No other roll a target measures carries Talent dice, including the dodge, Fly, Break Attention, Ride, and Read" (OQ-94 item 1); `data/character/squadmates.yaml` `stat_block.matches_reference_build` and the `templates` comment say the same. `data/character/action-catalog.yaml` `break-attention` `needs`: "1 for the soldier holding the Titan's Attention, otherwise 2, and 2 against a Titan holding a Grabbed soldier, plus 1 for each decoy that has already held that Titan's Attention this Titan Engagement; extra successes create Openings (data/engagement/attention.yaml)" (OQ-81). `data/character/talents.yaml` Relentless and Sharp Call effects point to `titan-harm.yaml` and `read.yaml` (OQ-90). Section 2.8's Break Attention line, if it quotes the needs, follows the Catalog row. Section 2.10's Wings pointer is unchanged.

**Chapter 3:** Section 3.2 *Reference builds*: the no-Talent sentence (OQ-94 item 1). Nothing else.

**Chapter 4:** Section 4.1 *Restoring*, section 4.5 *Lame*, section 4.9 the interim sentence and the OQ-59 design note, `data/gear/standard-issue.yaml` `interim_issue.differences` and `why_narrow`, `data/gear/items.yaml` `horse.restored_by` (OQ-93). Introduction "revised two of them and ADR-0014's reference builds"; section 4.9 quotes 20.7% and 10.6% consistently (OQ-94 item 3). `data/gear/sheet-fields.yaml`: the `positions` field records in the column's format and says the Squad sheet column is the record the ladder reads, `squad_sheet_row.purpose` says every soldier in a Titan Engagement has a row, and the header lists OQ-90 (OQ-97, OQ-99 item 3); section 4.12's sentence follows. `data/gear/horses.yaml` is unchanged (its wording is adopted by `attention.yaml`). Section 4.3's gas medians stand (OQ-94 item 4).

**Chapter 5:** Every `PROVISIONAL (OQ-nn)` block becomes a design note carrying its decision, and every `data/engagement/*.yaml` `provisional:` tag becomes `decided:` (OQ-74 to OQ-90, OQ-95 to OQ-98). Introduction: the Simulator target sentence becomes "every ADR-0014 target is met as amended in decision batch 3 (OQ-79, OQ-95, OQ-98)". Section 5.3: Wings stand between losses, the round-time band and bounds, the timed test and fallbacks, the positions record, the cadence line (OQ-77, OQ-97, OQ-99 items 3 and 8); `round.yaml` `wings`, `gm_tracker` (the `decoys spent` field and example, `per_round_order`, `titan_card_checklist`). Section 5.6: the Break Attention needs list and design note (OQ-81); `attention.yaml` `break_attention.needs`, `needs_rule`, and the riderless-horse requirement (OQ-99 item 2). Section 5.7: the OQ-83 note drops its pending sentence. Section 5.9: the countdown's refund sentence (OQ-99 item 1); `grab.yaml` `countdown.failed_dodge`, `grab_lands.failed-dodge`; the OQ-85 note quotes the amended "comrades close" (OQ-95). Section 5.10: option 4 (OQ-99 item 4); `background-titans.yaml`. Section 5.12: `squad-tactics.yaml` `rules.tuning` (OQ-99 item 5). Section 5.13: the OQ-79 and OQ-95 blocks become design notes quoting ADR-0014 as amended; the *Decoys* bullet and `tuning.yaml` `decoys` and `titan_cards_resolved_per_round` carry the OQ-81 rows (helpers 0.833 and 0.65; screen beside the holder under the old rule 0.423 and 0.26; under the new rule 0.660 and 0.47); the *Large* bullet, `tuning.yaml` `verdict`, and `size-classes.yaml` line 54 (OQ-99 item 6); `tuning.yaml` `probes` states the ADR-0014 baseline and `simulator_cases` gains the list below (OQ-98); `solo_nape.target` and `grab.target` quote the amended targets. Section 5.14: the OQ-90 note. `anchor-ratings.yaml` Open row (OQ-99 item 9). `tools/probes/chapter-05/fight.py` `ba_need` and the rescue path carry OQ-81's rule, and the affected rows are re-run from `tuning.yaml` (`probes`, `commands`).

## Batch 3b: Chapters 1 to 5 conformance leftovers

Rulings on the round 1 conformance review of Chapters 1 to 5 (`docs/reviews/01-05-decisions-conformance-review-1.md`, Opus; `-codex.md`; `-fable.md`, the narrow escalation on the lone line). The review disputed two batch 3 decisions: OQ-81's escalating Break Attention needs, which with the lone soldier's finite decoys could close the lone route to the Nape for good (Codex Critical 1, Opus Major 1, Fable Major 1), and OQ-79's and OQ-81's lone-soldier figures, which were measured without the escalation they adopted (all three). It also raised the OQ-97 clock list (Codex Minor 3), ADR-0014's gas wording (Opus Minor 5), the band's measurement point (Opus Minor 2, Fable Minor 3), the decision record's stale rows (Opus Minor 3), the decoys count's tracked value (Opus Minor 4), Fall Back's moment (Opus Minor 6), the Squad sheet row's wording (Opus Minor 7), and Chapter 3's stale Grab contract (Codex Critical 2). Chapter 6's round 1 review (`docs/reviews/06-standard-titans-review-1.md`) added two Majors that hang on the same rule: a lone soldier almost never gets a usable Nape strike against a Tempo 2 Titan (Major 3), and no Chapter 6 table has Squad Tactic or decoy-screen rows (Major 6); both are settled here (3b-8), and OQ-100 to OQ-105 are not decided. Decided in one pass; staged while Chapter 6's round 1 reviews run, then applied.

Odds without a source come from four scripts in `tools/probes/batch-3b/` (with the Fable review's `lone.py`, `cardorder.py`, and `core_local.py` beside them, and each script's `.out` file): `lone_b3b.py` (the Fable review's full lone-fight model, imported and subclassed: 100,000 trials per row, 12-round horizon unless stated, the informed policy with the Rookie's decoy budget), `screen_b3b.py` (the committed `tools/probes/chapter-05/fight.py` subclassed, 12,000 fights per row, Medium, Wooded, 4 Rookie player characters at Stress 1 and 2 Squadmates screening beside the Attention holder), `lone_t2_b3b.py` (the lone model with the Titan's Tempo, Nape Depth, and the decoy's hold as switches; its Tempo 1 rows reproduce `lone_b3b.py` within 0.2 points), and `screen6_b3b.py` (the drafter's `tools/probes/chapter-06/fight6.py` subclassed the same way, 6,000 fights per row for each Chapter 6 table). They reproduce the reviews and the committed figures: the batch 3 rule gives 67.0% of lone fights a usable strike with 27.9% exhausted (Fable: 67.1%, 28.0%) and 0.663 Titan cards a round with 0.49 Critical Injuries per fight for the screen (`tuning.yaml`: 0.661, 0.47); the 4 player character and helper rows match `data/titans/tuning.yaml` within sampling.

### Summary table

| Item | Decision (one line) | ADR change | Glossary change | Chapter impact |
|---|---|---|---|---|
| 3b-1 (OQ-81) | Break Attention keeps needs 1 for the holder and 2 for anyone else; the escalation counts only decoys in a row, resetting when a card of the Titan resolves a behavior; a fourth decoy, the Feint, is repeatable and spends nothing but needs 1 more and exposes the soldier at In Reach or On Body | none (ADR-0010 holds) | Break Attention entry | Ch2 `action-catalog.yaml`; Ch5 5.6, 5.13, 5.14; `attention.yaml`, `round.yaml`, `tuning.yaml`; probes; Ch6 lone note |
| 3b-2 (OQ-79) | The lone-line sentences are replaced by figures measured under the rule; the band is read on a fresh cut directly after Break Attention at fight-start Stress 1, and the in-fight cut is reported beside it | ADR-0014 body wording and `## Amended` | none | Ch5 5.13; `tuning.yaml` `solo_nape`; a lone-fight probe |
| 3b-3 (OQ-97) | The fallback clock list reads 8, 6, and 6 with 10 | none | none | none (Chapter 5 and `round.yaml` already correct) |
| 3b-4 (gas) | ADR-0014's gas target reads "about 9 rounds of ODM use (median 8, mean 9.25), about 6 when pushing every round (median 6, mean 6.33)" | ADR-0014 body | none | none |
| 3b-5 (Fall Back) | Its moment reads "at the wings step, before Wings are assigned or kept" | none | none | Ch5 5.12; `squad-tactics.yaml` |
| 3b-6 (Squad sheet row) | The name column is "the soldier's name"; a player character's row may carry a dash in gear columns their character sheet holds | none | none | Ch4 4.12; `sheet-fields.yaml` |
| 3b-7 (Chapter 3 section 3.7) | Section 3.7's standing models and rescue contract are replaced by the decided figures and a pointer to Chapter 5 section 5.13; section 3.12's pointer follows | none | none | Ch3 3.7, 3.12 |
| 3b-8 (Chapter 6 Majors 3 and 6) | A decoy holds a Titan's Attention for as many of its next cards as its Tempo, each resolving nothing; Chapter 6 renders the lone-fight rows at each Tempo and the screen, tactic, and helper rows for every table | ADR-0010 `## Amended` | Break Attention entry (with 3b-1) | Ch5 5.6, 5.13; `attention.yaml`, `behavior-procedure.yaml`, `round.yaml`; probes; Ch6 6.6, `data/titans/tuning.yaml`, `fight6.py`, `lone6.py` |

### 3b-1: OQ-81, the lone route and the screen

- **Decision:** Break Attention against a Focus Titan needs, as batch 3 ruled, 1 success for the soldier holding that Titan's Attention, 2 for anyone else, and 2 for anyone against a Titan holding a Grabbed soldier. Two changes:
  1. **The escalation counts decoys in a row.** Add 1 for each decoy that has held the Titan's Attention since the last card of that Titan that resolved a behavior. The tracker's `decoys spent` becomes **`decoys in a row`**: it rises by 1 when a decoy takes the Titan's Attention and returns to 0 when one of the Titan's cards resolves a behavior; a card that resolves nothing because the Titan holds a Grabbed soldier, or because no one holds its Attention, leaves it unchanged. It starts at 0 when the Titan becomes a Focus Titan.
  2. **A fourth decoy, the Feint.** The soldier's own pass across the Titan's face. *Needs:* the soldier at In Reach or On Body relative to the Titan, with working ODM Gear or mounted on a horse that is not lame; the roll's gear item is that ODM Gear or that horse, and a roll made with ODM Gear is ODM use (Chapter 4). It works against Broken eyes. *Spends:* nothing when declared, and nothing on success. *Successes needed:* 1 more than the need above (2 for the holder, 3 for anyone else, 3 against a holding Titan), plus the decoys in a row. *On success:* as any decoy. A Feint can be named any number of times in a Titan Engagement.
  The flare, riderless horse, and thrown cloak are unchanged. Squadmates take Break Attention with a Feint like any soldier and never Push (Chapter 2). The rejected decoy cap stays rejected, and every card a decoy holds resolves nothing (how many it holds is 3b-8).
- **Why:** The Codex review showed that batch 3's permanent count with the Rookie's finite decoys (one horse, two flares at Funding 3, one cloak) could leave a lone soldier holding Attention with no legal Break Attention and so no route to the Nape, which contradicts ADR-0010, and every review showed that OQ-79 and OQ-81 quoted the lone line under the rule batch 3 replaced. Measured on one model and horizon (the full lone-fight model, informed policy, decoy budget, 12 rounds), the lone Rookie reaches a usable strike in 67.0% of fights under batch 3's rule with 27.9% running out of decoys first; with no escalation 79.1% and 17.3%; with the count resetting on a resolved card but no Feint 69.9% and 24.9%; with the reset and the Feint **76.0%**, the median strike in round 4 (mean 4.33) after 2.88 Titan cards against the soldier, 0.18 Critical Injuries per fight, 3.1% devoured, 3.3% Down, the cut succeeding 14.2% at a mean Stress of 2.8, and one lone fight in nine (10.8%) ending in a kill; the route now closes only by a Jam or running dry (8.2%), which also closes the Nape strike itself, and 9.3% are still fighting at round 12. The Feint is priced by exposure: it is made from In Reach or On Body, so Critical Injuries per lone fight rise from 0.10 to 0.18 and deaths from 1.9% to 3.1%, and it costs gas or horse wear, not a spent item. The Squad screen keeps its trade: two Squadmates screening beside the holder leave the Titan resolving 0.624 cards a round and 0.44 Critical Injuries per fight under the new rule (helpers 0.836 and 0.65; batch 3's rule 0.663 and 0.49; no escalation 0.603 and 0.43; the review round 2 rule 0.413 and 0.25), with the kill no faster than helpers' (67.9% by round 3 against 68.9%); Squadmate Feints succeed 0.03 times a fight, since a non-holder needs 3 without a Push. The reset is what stops the Feint becoming a perpetual screen: a soldier who holds Attention and feints every round blanks about 38% of the Titan's cards under the reset (needs 2, then 3 while the blanks continue) against about half with no escalation, and the finite decoys were never a better cap than that in a fight of three or four rounds. A Titan fooled while it has not yet acted is the one that comes back fixated; once it has acted, it can be fooled again, which reads better than a count that never resets. The 4 player character reference rows do not move (61.9% by round 3, 0.71 Critical Injuries; with Hook and Cut and Hamstring Line 66.1% and 0.63), the Grab cells, the Jam test, and gas do not read the rule, and the lone per-strike band is measured before any decoy is spent (3b-2). ADR-0010 holds: the Feint is the lone soldier's Break Attention that never runs out, and nothing penalizes acting alone.
- **ADR change:** none.
- **Glossary change:** Break Attention entry becomes: "An action that shifts a Focus Titan's Attention onto a decoy, such as a flare, a riderless horse, a thrown cloak, or the soldier's own Feint, for as many of its next cards as its Tempo. It is easiest for the soldier holding the Titan's Attention, and harder for each decoy the Titan has fallen for since it last acted." Staged (the Tempo clause is 3b-8).
- **Chapter impact:** Chapter 5 section 5.6 (the needs list: the decoys-in-a-row sentence; the Feint row under *The decoys*; the OQ-81 design note with the figures above); section 5.3 *What the GM tracks* (`decoys in a row`); section 5.13's *Decoys* bullet (the rows above) and the lone-soldier note (3b-2); section 5.14's Break Attention row. `data/engagement/attention.yaml` `break_attention.needs` (`per_decoy_in_a_row: 1`, `feint_extra: 1`), `needs_rule`, `on_success` ("decoys in a row rises by 1"), and a `feint` row under `decoys` with the requirement, gear, spends none, on_success none, works_against_broken_eyes true; `data/engagement/round.yaml` `gm_tracker.focus_titan_row` ("decoys in a row, from 0, reset by a card that resolves a behavior") and its example; `data/engagement/behavior-procedure.yaml` `resolving_a_card` (the `next` step sets decoys in a row to 0); `data/character/action-catalog.yaml` `break-attention.needs` ("1 for the soldier holding the Titan's Attention, otherwise 2, and 2 against a Titan holding a Grabbed soldier; 1 more for a Feint; plus 1 for each decoy the Titan has fallen for since its last card that resolved a behavior") and, for ADR-0003 item 12 (Opus Minor 4), the tracked value `attention-shift` reworded to "shift a Focus Titan's Attention onto a decoy and raise its decoys in a row" (no new value); `data/gear/items.yaml` `other_objects` needs no change (a Feint is no object). `tuning.yaml` `decoys` rows re-run under the rule with the beside-the-holder screen (the figures above are the starting rows) and `break_attention_by_need` unchanged; `tools/probes/chapter-05/fight.py` `ba_rule` gains the reset and the Feint, and `titan_card` resets the count when a behavior resolves. Chapter 2 section 2.8, if it quotes Break Attention's needs, follows the Catalog row. **Chapter 6:** section 6.6's lone-soldier note ("waits on the card order and on Break Attention's rising needs") reads "on the card order and on the decoys in a row"; `tools/probes/chapter-06/fight6.py` inherits the rule from `fight.py` and its decoy-screen rows in `data/titans/tuning.yaml`, if any are quoted, are re-run; `data/titans/roster.yaml`'s note that a decoy overrides an Abnormal's ladder is unchanged. Chapter 6's stat blocks and tables do not change: the rule lives in Chapter 5's files.
- **Revised by batch 3c:** "The route now closes only by a Jam or running dry (8.2%), which also closes the Nape strike itself" was measured on the Wooded lone fight with a probe that counted a dry soldier holding a spare canister and a Jam that Field Repair clears; corrected, no decoy is usable before a canister change or a repair in 0.2% of lone fights (76.9% reach a usable strike), and the Feint can also be made on foot against a grounded Titan, so a Feint is available in every state in which a Nape strike is legal (3c-2, 3c-3). Where the figures here differ from the committed lone.py and tuning.yaml rows by sampling, the committed rows govern.

### 3b-2: OQ-79, the lone-line figures and the band's measurement point

- **Decision:** The lone-line sentences in OQ-79 and OQ-81 are withdrawn and replaced (the `Revised by batch 3b:` lines in Part 2). The record now says: under the rule as decided in 3b-1, on the full lone-fight model with the informed policy (Break Attention only on a round in which the Titan's card has already come, from In Reach, then a step to Blind Spot and the cut) and the Rookie's decoy budget, a lone Rookie reaches a usable Nape strike in 76.0% of fights within 12 rounds, most often in round 4, after about 2.9 Titan cards resolved against them; the cut succeeds 14.2% at the Stress those cards have lifted them to (about 2.8); about one lone fight in nine kills. "After starting at Distant" is dropped. **The band's measurement point is pinned:** ADR-0014's 8% to 14% is read on a cut made directly after Break Attention from the Rookie's fight-start Stress of 1, with no other card resolved against the soldier (the `solo_nape` probe: 13.1%); the in-fight cut, made after the Roars a lone soldier takes while waiting, is reported beside it and not tuned (14.2% to 14.4% at a mean Stress of 2.6 to 2.8; 12.4% from fight-start Stress 0). A simulator value outside the band on the fresh cut is a miss; the in-fight figure is a report. The rejected cap's rejection now rests on the screen rows (the committed probes: 0.509 cards a round with the cap against 0.538 with escalation, both added to the review round 2 rule) and on the lone model, where the cap reaches a strike in 73.0% of fights but costs 4.28 Titan cards, 0.20 Critical Injuries, and 3.8% devoured per fight (the Fable review), and it is moot under 3b-1.
- **Why:** Three reviews reproduced the same fact: "median of 4 rounds, 1.67 cards", "two or three cuts a fight", and "the cap costs the lone soldier more" were the card-order model with no escalation, and the rejected cap was compared with that model instead of with the rule. The chapter's own card-order row (median 6, 60.8% by round 12) measured a policy that wastes decoys on rounds where the Titan's card is still to come, which face-up cards let a player avoid. The full lone model on the informed policy is the honest measure, and 3b-1's rule is chosen on it. The band question is a wording ambiguity: "at the Rookie's fight-start Stress of 1" can mean the fight or the cut; pinning it to the fresh cut keeps the target as measured and stops a simulator re-litigating Nape Depth 4 over the half point that Roars add.
- **ADR change:** ADR-0014 body, the second target: "..., between 8% and 14% on a cut made directly after Break Attention from the Rookie's fight-start Stress of 1, with the cut a lone soldier makes after the cards they took while waiting reported beside it; ..." and a `## Amended` paragraph (Part 3). Staged.
- **Glossary change:** none.
- **Chapter impact:** Chapter 5 section 5.13, *A lone soldier after Break Attention*: the card-order paragraph is replaced by the full lone-fight rows (the rule, no escalation, batch 3's rule, and the cap, with the columns of the table in 3b-1's *Why*), one sentence that a lone soldier breaks Attention after the Titan's card has come and from In Reach (or from Blind Spot with a flare or the cloak, or from Distant only at Urban and Giant Forest), and the band's measurement point; the OQ-79 design note quotes ADR-0014 as amended. `tuning.yaml` `solo_nape.model` and `verdict` (the measurement point), `card_order_wait` replaced by `lone_fight` rows from a committed lone-fight probe (`tools/probes/chapter-05/lone.py`, the Fable review's model, which the drafter commits with the informed policy, the decoy budget, the Feint, and the reset as switches; the naive card-order row may stay as the upper bound on waste), and `simulator_cases` gains the in-fight lone cut with its Stress. `data/titans/tuning.yaml` `targets.lone_strike` quotes the measurement point.

### 3b-3: OQ-97's fallback clock list

- **Decision:** The parenthetical reads "8, 6, and 6 with 10" (the setup table's 6, 4, and 4 with 8, each lengthened by 2). `round.yaml` and Chapter 5 already say so.
- **Why:** An arithmetic slip in the record (Codex Minor 3).
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none.

### 3b-4: ADR-0014's gas wording

- **Decision:** Review fix 1: the body's fourth target reads "A full gas canister lasts about 9 rounds of ODM use (median 8, mean 9.25), about 6 when pushing every round (median 6, mean 6.33)."
- **Why:** The body is the current statement of every target since batch 2b, "results are medians" sits beside it, and the exact median is 8; the batch 2 amendment already accepts 8. Writing both numbers stops a simulator reading a miss (Opus Minor 5).
- **ADR change:** ADR-0014 body (Part 3). Staged.
- **Glossary change:** none.
- **Chapter impact:** none; Chapter 4 section 4.3 and Chapter 5 section 5.13 already quote medians 8 and 6.

### 3b-5: Fall Back's moment

- **Decision:** `squad-tactics.yaml` `fall-back.when` and section 5.12 read "At the wings step, before Wings are assigned or kept."
- **Why:** Under OQ-97 most wings steps keep Wings rather than assign them (Opus Minor 6).
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Chapter 5 section 5.12 (the Fall Back row); `data/engagement/squad-tactics.yaml` `fall-back.when`.

### 3b-6: the Squad sheet row for every soldier

- **Decision:** `sheet-fields.yaml` `squad_sheet_row.columns[name].format` reads "the soldier's name", and `purpose` says that every soldier in a Titan Engagement has a row (OQ-97), that a player character's row may carry a dash in every gear column their character sheet already holds, and that the positions column is always filled.
- **Why:** The row is now the record the ladder reads for every soldier (Opus Minor 7).
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Chapter 4 section 4.12 *The Squad sheet row*; `data/gear/sheet-fields.yaml`.

### 3b-7: Chapter 3's stale Grab contract

- **Decision:** Review fix 2 with fix 1's figures. Chapter 3 section 3.7 keeps its bullets on what the crush, Down, and the Fear Rolls do, and replaces its standing models and rescue-contract paragraphs ("Break Free as needing 3 successes", the about-60% lone figure, "Chapter 5 may use either of two rescue structures", the two-comrade cells, and "a single result near one third does not meet the test") with one paragraph: the decided figures (Break Free needing 2, a lone victim 69.9% after a failed dodge and 73.1% with no dodge, the six one-comrade cells 28.7% to 45.1% with 33.4% at Stress 2 and Grief 0) and a pointer to Chapter 5 section 5.13 and `data/engagement/tuning.yaml` (`grab`) as the measured source, with "comrades close" as ADR-0014 defines it (OQ-95). Section 3.12's pointer to "the permitted rescue structures" points to section 5.9 instead.
- **Why:** Chapter 3 was written before Chapter 5 chose a rescue structure and before OQ-95 fixed the arrangement in ADR-0014; a rulebook with two acceptance tests for one target is the contradiction Codex Critical 2 names. OQ-50's band and its six cells are unchanged, and Chapter 3's other Grab text (the crush, Down in the hand, Break Free's penalty) stands.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Chapter 3 sections 3.7 and 3.12.

### 3b-8: the decoy's hold on a Tempo 2 Titan, and Chapter 6's support rows (Chapter 6 Majors 3 and 6)

- **Decision:** A decoy holds a Focus Titan's Attention for its next cards, **as many as its Tempo**: one round of the Titan's cards, however the deal falls. Each of those cards resolves nothing, spends the Next Behavior, and re-evaluates the ladder; the last of them ends the hold. Against a Tempo 1 Titan this is the rule as written (the next card). The tracker's Focus Titan row records how many cards the hold has left. A second decoy still cannot be laid over one that holds. Chapter 6 renders, for every table, the lone-fight rows at that Titan's Tempo and Nape Depth (3b-2's columns, on the waiting line and on the hurried line) beside the per-strike table, and reports, beside its 4 player character row: 2 helper Squadmates; 2 Squadmates screening beside the holder under the rule as revised; Hook and Cut with Hamstring Line and the escapes; and the screen with that pair. The standard Medium Titan, as the target's table, also reports every Squad Tactic alone and in pairs as Chapter 5 section 5.13 does. A table's "not trivial" and "not unwinnable" readings compare each row with the standard Medium Titan's row of the same support.
- **Why:** ADR-0010's "for the Titan's next card" was written for one card a round. Against a Tempo 2 Titan one card is half a round, so a decoy laid after the Titan's cards is spent by its first card of the next round two times in three, and the lone soldier can only wait for the one deal in three that puts their card first. Measured on the full lone-fight model at Tempo 2 (Medium table, informed policy, 12 rounds): under the rule as revised in 3b-1 with a one-card hold, 49.5% of lone fights reach a usable strike (batch 3's rule 41.1%, no escalation 48.1%), the median strike in round 5 after 8.3 Titan cards, 13.0 cards against the soldier per fight, 0.52 Critical Injuries, 9.0% devoured, 10.7% Down, and 27.7% still waiting at round 12; the route is legal (3.1% run dry) but the fast Titans with the shallow Nape are the ones a lone soldier can least reach, which the chapter's per-strike table (33.1% for the Small Titan) hides. With the hold at Tempo cards, the lone line is Tempo-neutral: 77.1% reach a usable strike (Tempo 1: 75.9%), most often in round 4 after 6.7 cards, 8.8 cards per fight, 0.26 Critical Injuries, 4.7% devoured, 5.5% Down, the cut succeeding 15.2% at Nape Depth 4 (11.7% of fights kill) and 34.6% at Nape Depth 3 (26.7% kill, the Small Titan's and the Abnormal's depth). The Tempo 2 fight stays the deadlier one, since 1.5 cards a round come against a waiting soldier. A hurried line that breaks Attention after the Titan's first card of a round strikes sooner (67.4% usable, median round 3, 3.75 cards before the strike) and pays for it (10.8% devoured, 14.1% Down): a player's choice the chapter reports. Batch 3's rule with the Tempo hold gives 74.3% and runs dry in 11.6%, so the hold does not replace 3b-1. The squad rows keep their shape: two Squadmates screening beside the holder leave the Small Titan resolving 1.10 cards a round with 0.51 Critical Injuries per fight (helpers 1.48 and 0.78; one-card hold 1.27 and 0.62), with the kill median round 2 as before and no faster than helpers' by round 3 (87.9% against 87.0%); the Sprinting Abnormal 1.11 and 1.10 with 0.049 deaths (helpers 1.48, 1.60, 0.075; a one-card hold 1.28, 1.37, 0.064), kill median round 2, 80.2% by round 3 against helpers' 79.8%; the Medium and Large are Tempo 1 and do not move (Medium 0.624 and 0.43; Large 0.64 and 0.83, helpers 0.85 and 1.25, deaths 0.009 against 0.020, so Heavy Tread does not make the screen a trap). The screen's share of a Tempo 2 Titan's cards (1.10 of 1.48) is the Medium's share (0.62 of 0.84), which is the proportion a decoy should cost whatever the Tempo. With the screen and the tactic pair the Large kills at median round 2 (72.2% by round 3, 0.70 Critical Injuries, 0.010 deaths) and the Abnormal at 84.3% by round 3 with 1.04 Critical Injuries and 0.028 deaths, both still above the standard Medium's same row (70.3%, 0.41, 0.005): no table becomes trivial under the strongest support, and the Abnormal's own bar (OQ-103, not decided here) is read row against row. ADR-0014's "beside each target" sentence names the rows; Chapter 6 measured only helpers.
- **ADR change:** ADR-0010, `## Amended` paragraph (Part 3): "for the Titan's next card" reads "for the Titan's next cards, as many as its Tempo". Staged.
- **Glossary change:** the Break Attention entry (with 3b-1, Part 4): "for its next card" reads "for as many of its next cards as its Tempo".
- **Chapter impact:** Chapter 5 section 5.6 (the decoy's hold: "until the Titan's next card" reads "for as many of its next cards as its Tempo, each resolving nothing"; the design note's "a decoy's card resolves nothing, as ADR-0010's 'for its next card' says" quotes the amendment); section 5.3 *What the GM tracks* (the hold's cards left); section 5.13 *Decoys* (a sentence that the Small Titan's screen rows are Chapter 6's); `data/engagement/attention.yaml` `changes` (`effect: The decoy holds its Attention for its next cards, as many as its Tempo (break_attention)`) and `break_attention.on_success`; `data/engagement/behavior-procedure.yaml` `resolving_a_card` (a card under a decoy's hold resolves nothing and counts the hold down; the last ends it); `data/engagement/round.yaml` `gm_tracker.focus_titan_row` (cards the hold has left); `tools/probes/chapter-05/fight.py` `decoy_success` and `titan_card` (a hold counter of `t.tempo`), no change to any Chapter 5 figure. **Chapter 6:** section 6.6 *A lone soldier after Break Attention* renders the lone-fight rows per table at its Tempo and Nape Depth (the figures above are the starting rows; `tools/probes/chapter-06/lone6.py` gains the fight model with Tempo, or imports Chapter 5's committed `lone.py`), and its design note says that the Small Titan and the Abnormal are the deadlier lone fights though the strike comes as often; section 6.6 *How the fights compare* and each table's tuning block report the helper, screen, tactic-pair, and screen-with-pair rows (the figures above are the starting rows), the Medium the full tactic set; `data/titans/tuning.yaml` `simulator_cases` first item is done rather than deferred, `verdicts` per table quote the support rows, and `abnormals.rule` reads its bar row against row; `tools/probes/chapter-06/fight6.py` inherits the hold and the rule from `fight.py` and `cases6.json` gains the rows; `data/titans/roster.yaml`'s "a decoy overrides the ladder" is unchanged. OQ-102's riders argument (a riderless horse is one decoy per horse) now buys one round of the Abnormal's cards per horse rather than one card, which the OQ-102 decision reads before it is taken; nothing here decides it.
- **Revised by batch 3c:** "Each of those cards resolves nothing, spends the Next Behavior, and re-evaluates the ladder" reads "each of those cards resolves nothing and spends the Next Behavior; only the last ends the hold and evaluates the ladder", as Chapter 5 sections 5.5 and 5.6 say (3c-4). A flag lasts until the Titan's next card that evaluates its ladder, so a hold's earlier cards do not clear it (3c-1). "The lone line is the same at Tempo 1 and 2" was measured on the reference table; the Sprinting Abnormal's lower lone rate is a table effect (3c-7). Where the figures here differ from the committed tuning.yaml rows by sampling, the committed rows govern.

### Chapter impacts of batch 3b

**Chapter 1:** none.

**Chapter 2:** `data/character/action-catalog.yaml` `break-attention.needs` and the `attention-shift` tracked value's name (3b-1); section 2.8 if it quotes the needs.

**Chapter 3:** sections 3.7 and 3.12 (3b-7).

**Chapter 4:** section 4.12 and `data/gear/sheet-fields.yaml` (3b-6).

**Chapter 5:** sections 5.3, 5.6, 5.12, 5.13, 5.14; `attention.yaml`, `behavior-procedure.yaml`, `round.yaml`, `squad-tactics.yaml`, `tuning.yaml`; `tools/probes/chapter-05/fight.py`, `simple.py` (`solo_wait` may stay as the waste bound), and a committed `lone.py` with Tempo, Nape Depth, the hold, and the policy as switches (3b-1, 3b-2, 3b-5, 3b-8).

**Chapter 6:** section 6.6 *A lone soldier after Break Attention* (the lone-fight rows per table at its Tempo and Nape Depth, the waiting and the hurried line, and the design note's last sentence); section 6.6 *How the fights compare* and each table's tuning block (helper, screen-beside-the-holder, Hook and Cut with Hamstring Line, and screen-with-pair rows for every table, the full tactic set for the Medium); `data/titans/tuning.yaml` (`targets.lone_strike` with the measurement point, `simulator_cases` first item done, `verdicts` quoting the support rows, `abnormals.rule` read row against row); `tools/probes/chapter-06/fight6.py` inherits the rule and the hold from `fight.py`, `lone6.py` gains or imports the fight model, `cases6.json` gains the rows (3b-1, 3b-2, 3b-8). No stat block or Behavior Table changes. OQ-100 to OQ-105 are not decided here; OQ-102 reads 3b-8 before it is decided.

## Batch 3c: Chapters 1 to 5 conformance round 2

Rulings on the round 2 conformance review of Chapters 1 to 5 against batch 3b (`docs/reviews/01-05-decisions-conformance-review-2.md`, Opus; `-codex.md`; `-fable.md`, the narrow escalation on the grounded-Titan case), and on Chapter 6's round 2 Minor 5 (`docs/reviews/06-standard-titans-review-2.md`), which reads ADR-0010's batch 3b amendment. Two Majors: under a hold of Tempo cards the flags clear on cards that evaluate nothing, so a Nape striker who falls short against a Tempo 2 Titan can escape ADR-0010's struck-first rule (Opus Major 1); and batch 3b's lone-route guarantee overstates itself against a grounded Titan, where the Nape strike needs no working ODM Gear but every Feint did (Opus Major 2, the Codex Critical, ruled Minor by the Fable review because Field Repair keeps the Jammed case open, with a residual at Open when dry with no spare). The Minors: the lone probe's route check (3), the record's wording on ladder evaluation (4), the Feint's YAML requirement (5), `tuning.yaml`'s target wording (6), the glossary (7), a Chapter 3 pointer (8), and bookkeeping (9). OQ-100 onward are not decided here.

Odds without a source come from three scripts in `tools/probes/batch-3c/`, each importing the committed probes unchanged and writing its `.out` file beside it: `lone_b3c.py` (`tools/probes/chapter-05/lone.py` with the route check corrected and Field Repair added; 100,000 lone fights per row), `flags_b3c.py` (`tools/probes/chapter-06/fight6.py` with the flags kept through a hold as a switch; 6,000 fights per row), and `onfoot_b3c.py` (Break Attention rates by need and gear on `core.py`, 100,000 rolls per cell; the Medium and Large screen rows on `tools/probes/chapter-05/fight.py` with the on-foot Feint as a switch, 12,000 fights per row). Their as-written rows reproduce the committed figures (lone fight 75.9% and 8.3% route closed; Medium screen 0.627 cards a round and 0.46 Critical Injuries; Small screen 87.7% by round 3). Where a staged figure and a committed `tuning.yaml` row differ by sampling, the committed row governs.

### Summary table

| Item | Decision (one line) | ADR change | Glossary change | Chapter impact |
|---|---|---|---|---|
| 3c-1 (Opus Major 1) | A flag lasts until the Titan's next card that evaluates its Attention Ladder; cards under a hold that leave cards left neither evaluate nor clear flags | ADR-0003 item 2, ADR-0010 body, `## Amended` paragraphs | none | Ch5 5.5, 5.6; `attention.yaml`, `behavior-procedure.yaml`; `fight.py`; Ch6 rows |
| 3c-2 (Opus Major 2, Codex Critical, Fable) | The Feint can also be made on foot against a grounded Titan, from In Reach or On Body, with no gear item; a Jam is repaired in the fight by Field Repair; the route sentence is re-scoped | ADR-0010 `## Amended` (the promise) | Feint entry | Ch5 5.6, 5.13; `attention.yaml`; Ch2 Catalog; Ch6 6.6 |
| 3c-3 (Opus Minor 3) | The lone probe counts a spare canister and Field Repair; the route column is re-measured and renamed | none | none | `lone.py`, `tuning.yaml` `lone_fight`; Ch5 5.13 |
| 3c-4 (Opus Minor 4) | Only the hold's last card evaluates the ladder; the record's sentence is corrected | none | none | `fight.py` comment |
| 3c-5 (Opus Minor 5) | The Feint's YAML requirement names working ODM Gear (Chapter 4's test), the soldier's own horse, and the grounded case; `feint_extra` has one source | none | none | `attention.yaml`; Ch5 5.6 |
| 3c-6 (Opus Minor 6) | `solo_nape.target` quotes ADR-0014's body word for word | none | none | `tuning.yaml` |
| 3c-7 (Opus Minor 7, Chapter 6 Minor 5) | Glossary: Break Attention's reset wording; a Feint entry; the Shifter line avoids the word; ADR-0010's and ADR-0014's batch 3b sentences say "on the reference table" and promise a route, not a rate | ADR-0010, ADR-0014 `## Amended` | Break Attention, Feint, Shifter Intent Table | none |
| 3c-8 (Opus Minor 8) | Chapter 3 section 3.2 points to Chapter 5's lone Grab model | none | none | Ch3 3.2 |
| 3c-9 (Opus Minor 9) | The batch 3b revision lists name OQ-50, OQ-89, and OQ-97; the governing source is stated; like-for-like helper figures | none | none | Ch5 introduction, the OQ-81 note |

### 3c-1: flags under a hold of Tempo cards

- **Decision:** A flag (hooked-by-strike, just-hurt, loudest) lasts **until the Titan's next card that evaluates its Attention Ladder**, and clears once that evaluation is finished. A card that resolves nothing because a decoy's hold has cards left neither evaluates the ladder nor clears the flags; the hold's last card does both. A card that resolves nothing because the Titan holds a Grabbed soldier still clears them (the ladder is not evaluated, and the Grab holds Attention, as batch 3 ruled). Draw Attention's loudest flag lasts the same way (ADR-0003 item 2, amended). At Tempo 1 nothing changes.
- **Why:** The struck-first rule (ADR-0010: a striker who falls short draws the Titan's turn) works through the hooked-by-strike flag, which only the ladder reads. Batch 3b made a decoy hold for Tempo cards, so against a Tempo 2 Titan the hold's first card cleared the flags without reading them, and a Nape strike made under the hold, which is exactly the Hook and Cut line, went unread: on the committed probes 0.13 flags a fight in the Small Titan's screen row, 0.17 with Hook and Cut and Hamstring Line, and 0.22 to 0.25 against the Sprinting Abnormal (the Opus review counted 0.175). Keeping flags until the evaluating card restores the rule and moves no figure: the Small screen row with the tactic pair reads 89.3% killed by round 3 and 0.49 Critical Injuries against 88.8% and 0.52 as written, the Abnormal 89.1% and 0.65 against 88.7% and 0.67, and the Medium rows are identical, all within sampling. The alternative of tying only flags set during a hold to its end is the same in play and a second rule; accepting the lapse would make the struck-first rule Tempo-dependent for no reason.
- **ADR change:** ADR-0003 item 2, "lasts until the Titan's next card", reads "lasts until the Titan's next card that evaluates its Attention Ladder" (an `## Amended` paragraph); ADR-0010 body, "just hurt it (until its next card)", reads the same way (in the batch 3c `## Amended` paragraph). Staged.
- **Glossary change:** none (Attention Ladder and Draw Attention entries do not name the moment).
- **Chapter impact:** Chapter 5 section 5.5 *Resolving a card* step 2 (the flags clear only when the card evaluates the ladder; under a hold with cards left they stay) and section 5.6 *Flags* ("each clears once the Titan's next card that evaluates its ladder has been evaluated") and *Draw Attention* ("until that Titan's next card that evaluates its ladder"); `data/engagement/behavior-procedure.yaml` `resolving_a_card.decoy` (clear the flags only when the hold ends) and `grab` unchanged; `data/engagement/attention.yaml` `flags` comment, `changes.card`, `draw_attention.effect`; `data/character/action-catalog.yaml` `draw-attention` if it quotes the moment; `tools/probes/chapter-05/fight.py` `resolve_card` (no `clear_flags` on a non-last hold card; `flags_b3c.py` shows the change). **Chapter 6:** the Small and Abnormal screen and tactic rows in section 6.6 and `data/titans/tuning.yaml` are re-run under the rule (the figures above are the starting rows; the Medium and Large rows do not move); `tools/probes/chapter-06/fight6.py` `resolve_card` follows `fight.py`.
- **Revised by batch 3d:** A card that comes up while the Titan holds a Grabbed soldier also clears the flags (OQ-111, ADR-0003 item 2 as amended in batch 3d). The Small and Abnormal figures here were measured on the pre-round-2 Chapter 6 model; the rows that stand are `data/titans/tuning.yaml`'s re-run under this rule (3d-3).
- **Revised by batch 3e:** "Until the Titan's next card that evaluates its Attention Ladder" was the wrong moment: the card that ends a hold evaluates and resolves nothing, so the striker's flag was read once and cleared before the card that acts, and the Grab-card clause (batch 3d) was written for one flag of three. A flag now lasts until the end of the Titan's next card that resolves a behavior, and a card that resolves nothing leaves every flag standing (3e-1). The figures here stand within sampling.

### 3c-2: the lone route against a grounded Titan

- **Decision:** The Feint gains a third way to be made: **on foot against a grounded Titan**, from In Reach or On Body, with no gear item (Perception alone, no Gas Roll, no wear), at the same need. Its requirement reads: the soldier holds In Reach or On Body relative to the Titan, and has working ODM Gear (Chapter 4: not Jammed, Gas Rating above 0), or is mounted on their own horse that is not lame, or the Titan is grounded. So **a Feint can be named in every state in which a Nape strike is legal**: a Nape strike needs working ODM Gear unless the Titan is grounded, and the Feint follows the same line. A Jammed harness is repaired in the fight by Field Repair (Chapter 4 section 4.8, an action, Wits alone without a tool kit, needing 1, retried each turn), which the Fable review shows is the path at Open, and an empty canister is changed for a spare; the route sentence in section 5.13 and 3b-1 is re-scoped to the Wooded lone fight and corrected (3c-3). The Regeneration clock's window (a Medium's Broken leg heals within 1 to 3 rounds) is stated beside the grounded Open text.
- **Why:** The Fable review is right that the Codex state is not a dead end: Field Repair ends a Jam (about two in three per attempt with a Push for the Rookie), and a Feint from On Body with the repaired harness precedes the cut, reaching a legal strike in 69.5% of runs within 12 rounds against 77.9% with working gear. It also names the residual: at Open, grounded, with the Gas Rating at 0 and no spare, the Nape strike is legal on foot and no Feint could precede it. Rather than record that as an accepted close, the smallest rule that removes it is the on-foot Feint against a grounded Titan, because it makes the guarantee exact and stated (the Feint's line and the Nape strike's line are the same) and it changes nothing measured: in the Medium and Large screen rows Squadmates make an on-foot Feint 0.001 and 0.003 times a fight (0.628 cards a round and 0.45 Critical Injuries against 0.627 and 0.46; Large 0.641 and 0.87 against 0.635 and 0.85), and the lone-fight probe never grounds the Titan, so its rows do not read the rule. The price stays exposure: on foot the soldier stands within the Titan's hands with no line to fly out on, and without Gear Dice the Rookie's Feint at need 2 succeeds 37.7% of attempts at Stress 1 (49.6% with ODM Gear or a horse), 43.9% at Stress 3. A crawling Titan turning after a soldier who runs across its face is canon. The Fable review's other alternatives are not taken: a grounded-Open In Reach to Blind Spot step changes every grounded Open strike and escape, and a mounted Feint that places the soldier On Body needs a new success effect. The residual that remains is the one the Nape strike shares: a standing Titan against a soldier who can neither fly nor ride, where no strike is legal either.
- **ADR change:** ADR-0010 `## Amended` (with 3c-7): the batch 3b sentence "with a repeatable Feint decoy so that it never runs out" reads as a promise of a legal route, not a rate: "Break Attention is available in every state in which a Nape strike is legal: the Feint can be made with working ODM Gear, from a sound horse, or on foot against a grounded Titan, and a Jam is repaired in the fight." Staged.
- **Glossary change:** the new Feint entry (Part 4) names the three ways.
- **Chapter impact:** Chapter 5 section 5.6 *The decoys*, the Feint row (the grounded case; "their own horse"; the roll's gear item: none on foot) and its design note (a Jam delays the Feint, Field Repair clears it; the price on foot); section 5.13 *The route* bullet (3c-3's wording); section 5.2 *A grounded Titan* (one sentence: at Open the window is short, the Regeneration clock stands the Titan within 3 rounds); `data/engagement/attention.yaml` `decoys.feint.requirement` and `gear` (3c-5); `data/character/action-catalog.yaml` `break-attention` needs no change (the gear rule is the decoy's). **Chapter 6:** section 6.6's lone design note may cite the guarantee; no figure moves.

### 3c-3: the lone probe's route check

- **Decision:** `lone.py` counts a soldier whose canister is empty but who carries a spare as still able to Feint (Change Canister comes on their turn), and gives a Jammed soldier Field Repair (Wits 2, no tool kit, needing 1, Pushed when short, each success restoring 1 point of the current rating). The `route_closed_first` column is re-measured and renamed **`no_decoy_usable_first`**: dry with no spare and no sound horse against a standing Titan, the state in which no Nape strike is legal either.
- **Why:** The committed 8.2% was mostly a probe artefact: 5.4 points were a dry soldier with a spare in hand, and the rest Jams that Field Repair clears. Re-measured (100,000 lone fights): Tempo 1 as committed 75.9% usable strike and 8.3% closed; with the spare counted 76.5% and 3.2%; with Field Repair as well **76.9%**, most often in round 4, the cut succeeding 14.4% at a mean Stress of 2.9, 11.1% of lone fights killing, 4.0% devoured, 4.0% Down, and **0.2%** with no decoy usable (0.024 repairs a fight; 3.3% of fights Jam); the Tempo 2 waiting line 77.4% and 0.0%. Over 24 rounds 81.5% reach a strike. Every batch 3b figure the targets read stays within sampling of its committed row (76.0% and 77.0%).
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** `tools/probes/chapter-05/lone.py` (`feint_usable`, `any_decoy_left`, a Field Repair line in `soldier_turn`; `lone_b3c.py` is the reference change); `data/engagement/tuning.yaml` `lone_fight` (`model`, the column rename, the rows re-run); Chapter 5 section 5.13 *The route* bullet: "in the lone fight (Wooded) no decoy is usable before the soldier changes a canister or repairs the harness in 0.2% of fights, the state in which no Nape strike is legal either; a Jam is repaired in the fight by Field Repair (Chapter 4 section 4.8) and an empty canister changed for a spare; at Open a grounded Titan's Nape lies two steps from In Reach, so a Feint from On Body precedes the cut, on foot or with the repaired harness, inside the Regeneration clock's window"; the OQ-81 design note's lone bullet in section 5.6 follows.
- **Revised by batch 3d:** On the committed seed the row reads 77.0% usable strike, 0.2% with no decoy usable (`tuning.yaml` `lone_fight`), against the 76.9% measured here; the committed row governs (3d-3).

### 3c-4: which card of a hold evaluates the ladder

- **Decision:** Only the hold's last card ends the hold and evaluates the ladder; the cards before it resolve nothing and spend the Next Behavior. 3b-8's sentence "Each of those cards resolves nothing, spends the Next Behavior, and re-evaluates the ladder" is corrected by a `Revised by batch 3c:` line (Part 2). The chapter and YAML as applied are right.
- **Why:** A mid-hold evaluation would name a soldier holder while the decoy holds, which contradicts "the decoy keeps Attention" and would bar that soldier's Nape strike under the hold. The drafter read it correctly; the record must say so.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** `tools/probes/chapter-05/fight.py` `resolve_card`: a comment that the evaluation on a non-last hold card is overwritten by `titan_card` and has no effect (`flags_b3c.py` keeps the same structure).

### 3c-5: the Feint's YAML requirement

- **Decision:** `attention.yaml` `decoys.feint.requirement` reads: "The soldier holds in-reach or on-body relative to the Titan, and has working ODM Gear (data/gear/odm-gear.yaml, strikes: not Jammed, Gas Rating above 0), or is mounted on their own horse that is not lame, or the Titan is grounded (data/engagement/titan-harm.yaml, grounded). Broken eyes do not stop this decoy." Its `gear` row adds "on foot against a grounded Titan, no gear item". `decoys.feint.needs_extra` is removed in favour of a pointer to `break_attention.needs.feint_extra`.
- **Why:** Chapter 4's test for working ODM Gear includes gas; the row is the importer's source (Opus Minor 5); one value, one source (ADR-0012).
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** `data/engagement/attention.yaml`; Chapter 5 section 5.6 Feint row ("their own horse").

### 3c-6: `solo_nape.target`

- **Decision:** `data/engagement/tuning.yaml` `solo_nape.target` quotes ADR-0014's second target word for word as amended in batch 3b.
- **Why:** The field a harness keys on carried the wording 3b-2 removed (Opus Minor 6).
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** `data/engagement/tuning.yaml` `solo_nape.target`.

### 3c-7: glossary, and the batch 3b amendments' promise

- **Decision:** CONTEXT.md: the Break Attention entry reads "harder for each decoy the Titan has fallen for since one of its cards last resolved a behavior"; a **Feint** entry is added after it: "A decoy for Break Attention: the soldier's own pass across a Focus Titan's face from In Reach or On Body, made with working ODM Gear, from a sound horse, or on foot against a grounded Titan. It spends nothing and needs 1 more success." with `_Avoid_: bait, taunt`; the Shifter Intent Table entry's "deliberate tactics such as feints and guarding the Nape" reads "deliberate tactics such as false attacks and guarding the Nape". ADR-0010's and ADR-0014's batch 3b `## Amended` sentences on "the lone line is the same at Tempo 1 and 2" gain "on the reference table" (a new paragraph in each, not an edit of the old), and ADR-0010's promise is stated as a legal route (3c-2). Chapter 6's OQ-102 records the Sprinting Abnormal's 51.7% as the runner's known cost (not decided here; the chapter already reports it).
- **Why:** "Since it last acted" leaves open whether holding a Grabbed soldier or a decoy's card is acting (Opus Minor 7); Feint is a term the Catalog keys on; the Chapter 6 review shows the Abnormal's lower lone rate is a table effect (Trample reaching Distant, the start's Fear Roll), and an ADR sentence measured on the reference table must say so.
- **ADR change:** ADR-0010 and ADR-0014 `## Amended` paragraphs (Part 3). Staged.
- **Glossary change:** Break Attention, Feint (new), Shifter Intent Table (Part 4). Staged.
- **Chapter impact:** none.

### 3c-8: Chapter 3 section 3.2

- **Decision:** Section 3.2's design note reads "It is the victim in the lone Grab model of Chapter 5 (section 5.13, `data/engagement/tuning.yaml`, `grab`), whose figures section 3.7 quotes."
- **Why:** 3b-7 withdrew the section 3.7 model the sentence pointed to (Opus Minor 8).
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Chapter 3 section 3.2.

### 3c-9: bookkeeping

- **Decision:** The DECISIONS Counts line and Chapter 5's introduction name OQ-50, OQ-79, OQ-81, OQ-89, and OQ-97 as revised under batch 3b; 3b-1 and 3b-8 carry a sentence that the committed `lone.py` and `tuning.yaml` rows govern where they differ from the staged scripts by sampling (the provenance paragraph above says the same for batch 3c); the OQ-81 design note in section 5.6 compares the screen's kill by round 3 with the helpers' figure from the same run.
- **Why:** Opus Minor 9.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Chapter 5 introduction (the revised-entries list) and section 5.6's OQ-81 design note (68.9% from `screen_b3b.py` beside 67.9%, or both from `tuning.yaml`).

### Chapter impacts of batch 3c

**Chapter 1:** none.

**Chapter 2:** `data/character/action-catalog.yaml` `draw-attention` if it quotes the flag's end (3c-1); `break-attention` unchanged.

**Chapter 3:** section 3.2 (3c-8).

**Chapter 4:** none (Field Repair is cited, not changed).

**Chapter 5:** sections 5.2, 5.5, 5.6, 5.13, and the introduction; `attention.yaml`, `behavior-procedure.yaml`, `tuning.yaml` (`solo_nape.target`, `lone_fight`); `tools/probes/chapter-05/fight.py`, `lone.py` (3c-1 to 3c-6, 3c-9).

**Chapter 6:** section 6.6 and `data/titans/tuning.yaml`: the Small and Abnormal screen and tactic rows re-run with flags kept through a hold (3c-1; starting rows in `flags_b3c.out`); `tools/probes/chapter-06/fight6.py` `resolve_card` follows `fight.py`; the lone design note may cite the guarantee (3c-2); OQ-102's record of the Abnormal's lone rate is the Chapter 6 decider's (3c-7). No stat block or Behavior Table changes. OQ-100 onward are not decided here.

## Batch 3d: batch 3c apply follow-ups

Rulings on what the drafter found while applying batch 3c: OQ-111 (a card that comes up while the Titan holds a Grabbed soldier clears the flags, which ADR-0003 item 2 as amended in batch 3c did not say), the glossary's Draw Attention and Attention Ladder entries (still "until its next card"), and two figures in the batch 3c record measured on a seed and a Chapter 6 model that the committed rows have since replaced. No chapter or YAML changes: the drafter applied 3c-1's text, and only the ADR and the glossary lagged it.

### Summary table

| Item | Decision (one line) | ADR change | Glossary change | Chapter impact |
|---|---|---|---|---|
| 3d-1 (OQ-111) | (c): ADR-0003 item 2 names the Grab exception; 3c-1 stands | ADR-0003 `## Amended` | none | none |
| 3d-2 (glossary) | Draw Attention and Attention Ladder entries say "until the Titan's next card that evaluates its Attention Ladder" | none | Draw Attention, Attention Ladder | none |
| 3d-3 (figures) | The batch 3c record cites the committed rows: lone fight 77.0% (`tuning.yaml` `lone_fight`), Chapter 6's flag re-run rows from `data/titans/tuning.yaml` | none | none | none |

### 3d-1: OQ-111, flags on a card that comes up while the Titan holds a Grabbed soldier

- **Decision:** Option (c). A flag lasts until the Titan's next card that evaluates its Attention Ladder **or that comes up while it holds a Grabbed soldier**; either card clears it. 3c-1 stands as applied in Chapter 5 sections 5.5 and 5.6, `attention.yaml` (`flag_duration`), `behavior-procedure.yaml`, `round.yaml`, and both fight probes. OQ-111 is Decided.
- **Why:** The Grab holds Attention (batch 3, OQ-81), so a flag set while the Titan holds a soldier is never read, and the first card after the release evaluates the ladder from a clean slate, which is what the Grab rescues and every Chapter 5 and 6 row with a Grab were measured under. Option (b) would turn a freed Titan on whoever cut its Nape during the Grab, a rule no target reads and one that re-runs every Grab row; the gap was in the ADR's words, not the rule.
- **ADR change:** ADR-0003 item 2, a batch 3d `## Amended` paragraph naming the exception. Applied.
- **Glossary change:** none beyond 3d-2.
- **Chapter impact:** none.
- **Revised by batch 3e:** Withdrawn. OQ-111 is decided as its option (b) after all: a card that comes up while the Titan holds a Grabbed soldier leaves the flags standing, like every card that resolves nothing, and the first acting card after the release reads them. Measured, the Grab rows do not move (a holding card finds a flag standing 0.03 times a fight), so the reason given here for (a) did not hold (3e-1).

### 3d-2: the glossary's one-card flag wording

- **Decision:** CONTEXT.md's Draw Attention entry reads "until the Titan's next card that evaluates its Attention Ladder, or that comes up while it holds a Grabbed soldier"; the Attention Ladder entry's "just hurt it (until its next card)" reads "just hurt it (until its next card that evaluates the ladder)". No other one-card flag wording remains in CONTEXT.md or `docs/adr/` (Telegraph's "what the Titan's next card will do" is a behavior, not a flag; ADR-0010's body sentence is amended by its batch 3c paragraph).
- **Why:** 3c-1 changed the flag's moment and edited no glossary entry.
- **ADR change:** none.
- **Glossary change:** Draw Attention, Attention Ladder. Applied.
- **Chapter impact:** none.
- **Revised by batch 3e:** The two entries now read "until the Titan's next card that resolves a behavior" (3e-1); the Grab clause is gone.

### 3d-3: the batch 3c record's figures

- **Decision:** Where 3c-1 and 3c-3 quote figures, the committed rows govern and are cited: the lone fight under the rule with a spare canister and Field Repair is **77.0%** usable strike on the committed seed (`data/engagement/tuning.yaml` `lone_fight`: median round 4, 2.94 cards before the strike, 0.22 Critical Injuries, 3.9% devoured, 3.9% Down, 0.2% with no decoy usable, the cut 14.2% at Stress 2.85, 10.9% of lone fights kill), against 76.9% on the decider's seed; and 3c-1's Small and Abnormal rows were measured on the pre-round-2 Chapter 6 model, so the rows that stand are `data/titans/tuning.yaml`'s re-run under 3c-1 (Small: screen 87.4% by round 3 and 0.53 Critical Injuries, the screen with Hook and Cut and Hamstring Line 88.8% and 0.50; Sprinting Abnormal: screen 81.3%, 0.52, 0.010 deaths, the screen with that pair 84.5%, 0.44, 0.009), each moved within sampling by the flag rule.
- **Why:** The drafter's report; the record should not carry a second set of figures once the committed rows exist.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none.

### Chapter impacts of batch 3d

None. Chapters 1 to 6, their YAML, and the probes already carry 3c-1 as decided here.

## Batch 3e: Chapters 1 to 5 conformance round 3

Rulings on the round 3 conformance review of Chapters 1 to 5 (`docs/reviews/01-05-decisions-conformance-review-3.md`, Opus: Critical 1, Major 2, Minors 3 to 7; `-codex.md`: one Minor, the pre-batch-3d summaries of the Grab flag exception). Both Attention-flag findings come from the same cause: batches 3c and 3d tied a flag's life to the card that *evaluates the ladder*, which is not the card that *acts*. A decoy's hold ends on a card that evaluates and resolves nothing, so a short striker took Attention for one inert card, lost the flag, and was never the target of a behavior (Major 2); and the Grab exception batch 3d wrote for Draw Attention's flag was never written for the other two, so ADR-0010, ADR-0003, and the glossary named three targets after a Grab (Critical 1). Batch 3e replaces the two-clause rule with one clause for every flag. OQ-100 onward are not decided here; OQ-111 is revised.

Odds without a source come from `tools/probes/batch-3e/flags_b3e.py` (`tools/probes/chapter-05/fight.py` subclassed with the flag's life as a switch; 12,000 fights per row; its as-committed rows reproduce `tuning.yaml`: the reference row 61.9% by round 3 and 0.71 Critical Injuries, the screen 0.627 cards a round and 0.46). Where a figure here differs from a committed row by sampling, the committed row governs.

### Summary table

| Item | Decision (one line) | ADR change | Glossary change | Chapter impact |
|---|---|---|---|---|
| 3e-1 (Critical 1, Major 2, OQ-111 revised) | One rule for every flag: a flag lasts until the end of the Titan's next card that resolves a behavior; a card that resolves nothing leaves every flag standing | ADR-0003 item 2 (the list and `## Amended`), ADR-0010 `## Amended` | Attention Ladder, Draw Attention | Ch2 Catalog; Ch5 5.5, 5.6, 5.7; `attention.yaml`, `behavior-procedure.yaml`; both fight probes; Ch6 rows |
| 3e-2 (Minor 3) | ADR-0010's legal-route promise is scoped "outside a retreat"; a retreat closes the lone cut by design | ADR-0010 `## Amended` | none | Ch5 5.6 note, 5.10 note |
| 3e-3 (Minor 4) | The Feint's grounded way is on foot in the YAML requirement too: "or is not mounted and the Titan is grounded" | none | none | `attention.yaml` |
| 3e-4 (Minor 5) | ADR-0003's list item 2 is edited to the batch 3e wording, as item 9 was; the paragraphs stay as history | ADR-0003 list | none | none |
| 3e-5 (Minors 6, 7; Codex Minor; Chapter 6 Minor 4) | The Catalog note, Chapter 5's summaries and introduction, Chapter 6 section 6.6, the register, and ADR-0014's lone figure carry the rule and 77.0% | ADR-0014 `## Amended` | none | Ch2 Catalog; Ch5 introduction, 5.6; Ch6 6.6 |
| 3e-6 (Chapter 6 Critical 1) | The nearest rung is met by the candidates at the closest Position, so when it is the highest rung met the tied set is those candidates; the holder step then decides ties at equal distance; a `current-holder` test joins the closed list for Abnormal ladders | ADR-0010 `## Amended` (the ladder's last rung) | Attention Ladder | Ch5 5.6; `attention.yaml` `tests`, `evaluation`; both fight probes; Ch6 6.5, 6.6, `roster.yaml`, OQ-102, OQ-103 |

### 3e-1: one lifetime for every flag

- **Decision:** **A flag lasts until the end of the Titan's next card that resolves a behavior.** The three flags (hooked-by-strike, just-hurt, loudest) are set as before and are read only when the ladder is evaluated. A card that resolves nothing, whether under a decoy's hold, while the Titan holds a Grabbed soldier, or because no one holds its Attention, leaves every flag standing. The card that resolves a behavior evaluates the ladder with the flags, acts, and clears them at its *Next* step. So a striker who falls short draws the Titan's next behavior, whatever cards come between: under a hold, the hold's last card gives them Attention (they cannot cut again until the Titan has acted, which is ADR-0010's restriction doing its work) and the next acting card lands on them; during a Grab, the first acting card after the release lands on them. ADR-0003 item 2 becomes the one flag rule, and OQ-111 is revised to its option (b): the batch 3d exception for holding cards is withdrawn.
- **Why:** ADR-0010's struck-first sentence means the Titan's turn, not a moment of Attention on an inert card. Measured on the committed `fight.py` (12,000 fights a row), the Titan's next resolved behavior after a hold that ended on a flagged striker lands on that striker 0.0% to 0.5% of the time as committed and **98.9% to 99.8%** under the rule (the rest die, go Down, or are Grabbed first), in the rows where holds and strikes meet: 0.15 such holds a fight with Hook and Cut and Hamstring Line, 0.26 to 0.29 with the screen beside the holder, 0.10 in the Small Titan's. Every figure a target reads stays within sampling: the reference row 62.0% by round 3 and 0.71 Critical Injuries (committed 61.9%, 0.71), Grabs 0.215 and devours 0.020 (0.21, 0.020); the tactic pair 65.3% and 0.62; helpers 68.7% and 0.66; the screen 0.630 cards a round and 0.43 (0.627, 0.46); the screen with the pair 70.2% by round 3 and 0.39 (70.7%, 0.41; the median sits on its round 2 to 3 boundary either way); the Small screen with the pair 87.9% and 0.51 (89.2%, 0.51); the Large reference row 61.2%, 1.40, 0.193 deaths (60.8%, 1.40, 0.183). The Grab exception buys nothing: a holding card finds a flag standing 0.03 times a fight, and the rows with it (`acting_grab`) and without it differ within sampling, so the one-clause rule wins on simplicity and on fidelity (the Titan that was cut while it held a soldier turns on the one hooked in its nape, as ADR-0010's ladder says). The alternatives fail: an exception-laden rule is what produced three texts with three targets; having the hold's last card evaluate nothing leaves every Break Attention at need 2 in the gap and re-runs the screen rows; accepting the lapse would make Hook and Cut's striker the one soldier the struck-first rule never reaches.
- **ADR change:** ADR-0003 item 2, in the list and by a paragraph; ADR-0010 `## Amended` (Part 3). Staged.
- **Glossary change:** Attention Ladder and Draw Attention entries (Part 4). Staged.
- **Chapter impact:** Part 6, items 1 to 9.

### 3e-2: the legal-route promise in a retreat

- **Decision:** ADR-0010's batch 3c promise reads "in every state in which a Nape strike is legal, outside a retreat". A retreat closes the lone cut by design: every move is forced toward Distant (OQ-87), so a soldier at Blind Spot whose decoy holds the Titan must still step away, and no rule is added to let them stay. Section 5.6's Feint note carries the same scope and section 5.10's design note says so in one sentence.
- **Why:** The promise is about the Attention restriction, which Break Attention lifts; in a retreat it is the forced move, not Attention, that closes the cut, for a Squad as much as for a lone soldier, and OQ-87 chose that. A fifth retreat option ("stay put at Blind Spot while your decoy holds") would let a lone soldier keep fighting a Titan the clocks say to leave, against the retreat's purpose.
- **ADR change:** ADR-0010 `## Amended` (Part 3). Staged.
- **Glossary change:** none.
- **Chapter impact:** Part 6, items 10 and 11.

### 3e-3: the Feint's grounded way in the YAML

- **Decision:** `attention.yaml` `decoys.feint.requirement` reads "... or is mounted on their own horse that is not lame, or is not mounted and the Titan is grounded (data/engagement/titan-harm.yaml, grounded)". A mounted soldier against a grounded Titan Feints with the horse.
- **Why:** The prose, the glossary, and the row's own `gear` text say on foot; the requirement did not (Opus Minor 4).
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Part 6, item 12.

### 3e-4: ADR-0003's list

- **Decision:** ADR-0003's *Drafting requirements* item 2 is edited in the list itself to the batch 3e wording, as item 9 was edited after the first conformance review; the batch 3c, 3d, and 3e paragraphs stay as history.
- **Why:** The ADR's own precedent: the checklist is applied as amended, from the list (Opus Minor 5).
- **ADR change:** ADR-0003 list item 2 (Part 3). Staged.
- **Glossary change:** none.
- **Chapter impact:** none.

### 3e-5: summaries, pointers, and figures

- **Decision:** The Catalog's `draw-attention` note, Chapter 5's Draw Attention paragraph, its *Who holds Attention* list, `flag_duration`, `draw_attention.effect`, and `changes.card` state the rule as 3e-1 words it and cite batch 3e; the stale sentence in section 5.6 *Flags* ("ADR-0003's amended words name no such card, and OQ-111 records the gap") is removed; Chapter 5's introduction lists the batch 3b, 3c, 3d, and 3e revisions; ADR-0014 gains a paragraph that the committed seed's 77.0% governs (3d-3); the OQ-81 register line quotes 77.0%; the register preamble names OQ-50, OQ-89, OQ-97 (batch 3b), batch 3d (OQ-111), and batch 3e.
- **Why:** Opus Minors 6 and 7, the Codex Minor.
- **ADR change:** ADR-0014 `## Amended` (Part 3). Staged.
- **Glossary change:** none.
- **Chapter impact:** Part 6, items 13 to 16.

### 3e-6: the nearest rung when it is the highest rung met

- **Decision:** The **nearest** test is met by the candidates at the closest Position any candidate holds, in the order On Body, In Reach, Blind Spot, Distant. So when nearest is the highest rung a ladder meets, the tied set is the candidates at that closest Position, not every candidate; the holder step keeps the current holder only if they stand there, and a tie at equal distance goes to the holder, then the lowest card, then the Squad sheet, as before. Down and carried soldiers meet nearest by their Position like anyone else, so a Titan turns to a Down soldier only when no one is closer, as section 5.6 promises. The closed `tests` list gains **`current-holder`**: "The soldier holds the Titan's Attention" (`down_can_meet: true`), for Abnormal ladders only; the standard ladder does not use it. A ladder that wants a Titan to keep the soldier it last turned on names that rung.
- **Why:** Two readings of one YAML row produced two Titans (Chapter 6 round 3, Critical 1). Chapter 5's prose, its Down-soldier promise, Chapter 6's GM text, `roster.yaml`, and OQ-102 all describe a Titan that narrows to the nearest; only the `evaluation` procedure's wording and the probes let every candidate tie on nearest and the holder keep it from Distant. Measured on the committed `fight.py` with the batch 3e flag rule (12,000 fights a row), the standard ladder reaches nearest as its highest rung about 1.2 times a fight but keeps a holder who is not closest 0.000 to 0.002 times a fight, so every standard row is unchanged within sampling (reference 61.7% by round 3, 0.70 Critical Injuries, 0.024 deaths; helpers 68.6%, 0.65; the screen 0.629 cards a round and 0.44; the screen with the pair 69.9% and 0.39; Large 61.8%, 1.41, 0.192; the Small screen with the pair 88.6% and 0.48). The fixating reading is a real design for an Abnormal, so it becomes a rung a Read can reveal rather than a quirk of the procedure. **Chapter 6 consequence (a constraint, not a decision on OQ-102 or OQ-103):** every Sprinting Abnormal figure, its bar, and OQ-102's canon argument were measured on the fixating Titan. Under this rule its ladder `[loudest-or-brightest, hooked-into-its-body, nearest]` narrows to the nearest and its helper, screen, and screen-with-pair rows fail the bar's ceiling against the Large Titan by 8 to 10 standard errors (the review's rows). Chapter 6 either names `current-holder` on that ladder (`[loudest-or-brightest, hooked-into-its-body, current-holder, nearest]`), which reproduces the measured Titan and keeps its figures, and rewrites OQ-102's canon text and section 6.5's GM bullets for a runner that keeps whoever it last turned on until noise, a Nape strike, or a soldier On Body turns it; or re-chooses the ladder and values under the rule and re-runs every Abnormal row against the bar. The bar is not relaxed.
- **ADR change:** ADR-0010 `## Amended` (the ladder's last rung reads "nearest, the closest Position"; Part 3). Staged.
- **Glossary change:** the Attention Ladder entry's "nearest" reads "nearest (the closest Position)" (Part 4). Staged.
- **Chapter impact:** Part 6, items 17 to 20.
- **Revised by batch 4:** "Then the lowest card, then the Squad sheet, as before" reads "then the lowest card; a tie the cards cannot break leaves Attention held by nothing until the Titan's next card" (4-3). current-holder reads "The soldier holds the Titan's Attention and a Position other than Distant", so a quarry who gets away to Distant is dropped (4-3); the Sprinting Abnormal's figures this entry quotes are re-measured under 4-3 and 4-4.

### Chapter impacts of batch 3e

**Chapter 1:** none.

**Chapter 2:** `data/character/action-catalog.yaml` `draw-attention.notes` (Part 6, item 13).

**Chapters 3 and 4:** none.

**Chapter 5:** the introduction; sections 5.5 *Resolving a card*, 5.6 *Who holds Attention*, *The Attention Ladder* (rung 5 and the evaluation steps), *Flags*, *Draw Attention*, *Down and carried soldiers*, the Feint note and the OQ-81 note, 5.7 *Nape strikes*, 5.10 *The retreat* note; `attention.yaml` (`flag_duration`, `changes.card`, `draw_attention.effect`, `decoys.feint.requirement`, `tests` (`nearest`, the new `current-holder`), `evaluation` (`top`, `narrow`), `abnormal_ladder_format`); `behavior-procedure.yaml` (`resolving_a_card` steps `holding`, `decoy`, `attention`, `next`); `tools/probes/chapter-05/fight.py` (`flag_rule` default, `resolve_card`, `evaluate`); `data/engagement/tuning.yaml` rows re-run under the rules, which move within sampling (Part 6).

**Chapter 6:** `tools/probes/chapter-06/fight6.py` `resolve_card` and `evaluate` follow `fight.py`, with the `current-holder` test implemented for Abnormal ladders; section 6.6 and `data/titans/tuning.yaml` standard rows re-run under the rules (within sampling), with the provenance sentence "re-run with flags that wait for a hold's last card (decision batch 3c, 3c-1)" reading "re-run with flags that last until the Titan's next card that resolves a behavior and the nearest rung narrowing (decision batch 3e)"; section 6.6's flag statement and the introduction quote the batch 3e rule in full and drop the pre-round-2 flag comparison figures (Chapter 6 round 3, Minor 4); **the Sprinting Abnormal** (section 6.5, its GM bullets and design note, `roster.yaml` `ladders` and `reads_as`, OQ-102, OQ-103, and every Abnormal row and its bar) is re-decided under 3e-6's constraint: name `current-holder` on its ladder and describe the fixating runner, or re-choose and re-run against the bar. No standard stat block or Behavior Table changes.

## Batch 4: Chapter 6 (OQ-100 onward)

Decisions on Chapter 6's open questions, OQ-100 to OQ-110 (OQ-111 was decided in batch 3d and revised in batch 3e), after the chapter's three review rounds (`docs/reviews/06-standard-titans-review-1*.md` to `-review-3*.md`), the batch 3b, 3c, and 3e passes that changed the rules the chapter's figures read, and the two Chapters 5 and 6 conformance reviews after batch 3e: `docs/reviews/05-06-decisions-conformance-review-1.md` (Opus: one Critical and one Major on the Sprinting Abnormal, five Minors) and `05-06-decisions-conformance-review-1-codex.md` (two Minors on the batch 3b probes). Nine provisional choices are kept. Two change: OQ-102, because the Abnormal's quarry for a whole fight was chosen by the Squad sheet's order, which no rule sets, and a quarry could be parked at Distant (the Critical and the Major); and OQ-103, because under a rule-set tie-break the Abnormal as committed fails its bar's ceiling in every supported row, and its two kill entries move to Severity 2. The Attention Ladder's last tie-break is a Chapter 5 rule, so batch 4 changes Chapter 5 there, as batch 3e did for the nearest rung. The Abnormal's figures move; the standard Titans' rows move within sampling only.

Odds without a source come from `tools/probes/batch-4/` (relative imports of the committed `fight6.py` and `fight.py`, subclassed only in the Squad sheet order, the roles, and the two switches under decision): `quarry_b4.py` (the tie-break and the current-holder test, 24,000 fights a row in `quarry_b4_explore.out`; the bar as decided at 120,000 fights a row in both sheet orders in `quarry_b4_bar.out`; the Grab alone at Severity 2 in `quarry_b4_grab2_bar.out`), `sweep_b4.py` (the value changes, 24,000 fights a row), `margin_b4.py` (the kill entries at 120,000), and `runner_b4.py` (OQ-102 option (f) under the committed tie-break, 12,000). Where a figure here differs from a committed row by sampling, the committed row governs; every Sprinting Abnormal row is re-run by the drafter under the rule.

### Summary table

| Item | Entry | Decision (one line) | Kept or changed | ADR change | Glossary change | Chapter impact |
|---|---|---|---|---|---|---|
| 4-1 | OQ-100 | (b): an entry is marked as a Grab by its grab effect alone; the Closing Hand Scar reads that | kept | none | none | Ch6 6.1 (drop `PROVISIONAL:`) |
| 4-2 | OQ-101 | (a): the three standard tables as revised, "any state" read with every count of Broken parts; Thrash's share is an accepted report | kept | none | none | Ch6 6.1 to 6.4 |
| 4-3 | OQ-102 | (b) with two rule changes: a tie the card step cannot break leaves Attention held by nothing until the Titan's next card (the Squad sheet chooses nothing), and current-holder is met only by a holder who is not at Distant | changed | ADR-0003, ADR-0010 (`## Amended`) | none | Ch5 5.6; `attention.yaml`; Ch6 6.5; `index.yaml`; both fight probes |
| 4-4 | OQ-103 | (a) with the Grab and Headlong Lunge at Severity 2; the bar as stated, read under the rule in both sheet orders, holds every row | changed | ADR-0014 (`## Amended`) | none | Ch6 6.5, 6.6; `sprinting-abnormal.yaml`; every Abnormal figure re-run |
| 4-5 | OQ-104 | (b): the setup table's Medium roll sends the Sprinting Abnormal 1 time in 6 (1 Titan Engagement in 12) | kept | none | none | Ch5 5.1, Ch6 6.1 (drop `PROVISIONAL:`); the setup mix re-run |
| 4-6 | OQ-105 | The applied pointers stand; items 14 and 16 are OQ-106 and OQ-107, decided here; item 10 stays the coordinator's | kept | none | none | none new |
| 4-7 | OQ-106 | (a): Nape Depth and Regeneration are "set by Size Class, or by an Abnormal's own stat block" | kept | none | Nape Depth, Regeneration | Ch6 6.5 (drop the citation) |
| 4-8 | OQ-107 | (a): a target who dies receives none of the card's later effects; every other target still does (a Chapter 5 rule) | kept | none | none | Ch5 5.5; `behavior-procedure.yaml` |
| 4-9 | OQ-108 | (a): an Abnormal's hidden values and ladder print only in a GM section | kept | none | none | Ch6 6.5, 6.6 (drop `PROVISIONAL:`) |
| 4-10 | OQ-109 | (a): every Chapter 6 entry that uses a leg lists both legs; no new Chapter 5 rule | kept | none | none | `titan-format.yaml` comment; Ch6 6.1 (drop `PROVISIONAL:`) |
| 4-11 | OQ-110 | (a): `data/titans/index.yaml`, applied in the batch 3e pass | kept | none | none | none |
| 4-12 | Codex Minors 1 and 2 | The batch 3b `.out` files are historical snapshots; the two screen scripts drop their reproduction claim | changed (probe text only) | none | none | `tools/probes/batch-3b/` docstrings |
| 4-13 | Opus Minors 3 to 7 | The Down-soldier promise is scoped to the standard ladder; the `nearest_rung` rows are renamed and their note corrected; the glossary's Attention Ladder reads "until the end of"; OQ-111 and OQ-81 catch up; a quarry Grabbed by another Focus Titan is named | changed (wording) | none | Attention Ladder | Ch5 5.6; `tuning.yaml`; Ch6 6.5; `index.yaml`; `attention.yaml` |

### 4-1: OQ-100, how an entry is marked as a Grab

- **Decision:** Keep (b). An entry is marked as a Grab by having a grab effect in `effects`; each rendered table shows the mark in its Grab column; `data/mind/scars.yaml` (`the-closing-hand`) triggers on "a behavior whose Behavior Table entry has a grab effect"; a critical-injury effect carries its own Injury Location and lethality, and a grab effect's harm is the Grab's crush in `data/harm/health.yaml`. No entry field is added.
- **Why:** The batch 3 constraint's word "marked" asks for a fact a table can read, not a second field: (a) restated `effects` and let a dodge pool depend on the copy (round 1, Opus finding 11), against ADR-0012's single source; (c) splits an entry's data. The Grab column cannot disagree with the effects it is rendered from.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Chapter 6 section 6.1 drops the `PROVISIONAL:` line and cites this decision; `data/titans/index.yaml` (`grab_mark`) cites it. The Chapter 3 and 5 pointers applied under OQ-105 stand.

### 4-2: OQ-101, the standard Behavior Tables and the kill-share reading

- **Decision:** Keep (a): the Small, Medium, and Large tables as revised through round 3, with "any state" in the kill-share constraint read as every previous behavior combined with every count of Broken eyes, arms, and legs, so a table whose kill share exceeds one half in any such state is redrawn. Thrash's share of resolved cards (30% to 42% by table) is accepted and stated in section 6.1 as a consequence of the fallback rule, not tuned away.
- **Why:** The strict reading is the one OQ-80 made the move-up a measured quantity for; under it the reference table fails and every standard table peaks at exactly one half, which is the constraint's number. The entries follow 845 to 850 (Titans go for people, grin, snap, swat, shake off, bite and grab; a Small Titan crouches and clutches at legs; a Large Titan's Bite needs a soldier on its body), every text names only the Body Parts its row lists (`titans.py` fails the rest), and the figures at the reference start hold every band (Medium median kill round 3, 62.8% by round 3, 0.68 Critical Injuries, 0.031 deaths, 0.200 Grabs; Small median 2, 0.81; Large median 3, 12.8% with no kill within 12 rounds, 1.38, 0.160; Jam worst cells 8.4% and 22.5%, 9.3% and 24.4%, 12.4% and 32.9%), and under batch 4's tie-break they move within sampling only (4-3). Thrash's share comes from a holder at a Position the rolled entry excludes, most often a Nape striker who fell short at Blind Spot; pointing fallbacks at each table's own knock-loose entry re-opens the kill share, the Jam test, and every reference row, and buys a Titan that punishes the striker twice. The Large two-Titan Jam cell is 0.4 points under a third, so any change to the Large table re-runs it (a standing constraint).
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Chapter 6 sections 6.1 to 6.4 drop the `PROVISIONAL:` lines and cite this decision; `data/titans/tuning.yaml` (`targets`, `verdicts`) cites it; `data/engagement/behavior-procedure.yaml` (`move_up_shares`) already states the reading (OQ-105 item 8).

### 4-3: OQ-102, the Sprinting Abnormal's ladder, the first quarry, and the parked quarry

- **Decision:** Keep the ladder `[loudest-or-brightest, hooked-into-its-body, current-holder, nearest]` and the round 2 table (OQ-102 (b)), with two rule changes, both in Chapter 5's data.
  1. **The last tie-break (every Titan).** The `evaluation` step `sheet` ("Otherwise the tied soldier listed first on the Squad sheet holds it") is replaced by `none`: "Otherwise nothing holds the Titan's Attention until its next card. Only the start of a Titan Engagement and an end step reach this step, since during a round every soldier's card is distinct or comes right after their player character's; the Titan's next card evaluates the ladder with that round's cards dealt." The Squad sheet's order chooses nothing. At the start of a Titan Engagement every soldier is at Distant, so a Squad of two or more starts with nothing holding the Titan's Attention (Break Attention needs 2, as `needs_rule` already says for that state), and the Titan's first card turns to whoever has come closest, or to the lowest card when no one has moved.
  2. **`current-holder` (Abnormal ladders).** The test reads "The soldier holds the Titan's Attention and a Position other than Distant. A holder who is at Distant, mounted or on foot, does not meet it" (`down_can_meet: true` stands). The Sprinting Abnormal runs its quarry down while they are in its reach, at its Nape, or on it; a rider who gets away to Distant is no longer its quarry, and it goes for the nearest.
  Option (f), a most-soldiers test, stays rejected (`runner_b4.py`, under the committed tie-break: it fails the ceiling with helpers by 3.0 standard errors at 12,000 fights, 4.0 with the test below the hooked rung, 2.6 with current-holder beneath it), as do (a), (b1), (c), (d), and (e) for the entry's reasons.
- **Why:** The Opus review's Critical 1 and Major 2 (`05-06-decisions-conformance-review-1.md`), both reproduced on `quarry_b4.py` (24,000 fights a row unless stated).
  - **The first quarry was the Squad sheet's.** Every Titan Engagement starts with every soldier at Distant and no cards dealt, so the first evaluation always reached the `sheet` step, and with current-holder that soldier was the Abnormal's quarry until noise, a Nape strike, or a soldier On Body turned it. No rule orders the Squad sheet (Chapter 4, `sheet-fields.yaml` `squad_sheet_row`), so whoever wrote it chose the Abnormal's quarry for the fight, a choice outside every rule (ADR-0003; Chapter 5's "the GM never decides who holds Attention"). The committed probe listed the cutters first, and every Abnormal figure measured a Titan fixed on a cutter at In Reach: with the strikers listed first, the reference start gives 0.130 deaths against 0.069 and the helpers row 0.039 against 0.022, and a random order per fight 0.103 and 0.028 (the review: +15.8 and +5.3 standard errors past the Large twin at 120,000).
  - **Why "nothing holds" and not a stated order or a roll.** A stated order (the review's option 3) would keep the quarry a fact of the sheet and would have to be held at the order worst for the Squad, which fails by 9 to 16 standard errors as the values stood. A roll adds a step for the one moment it is needed. Leaving Attention held by nothing is already what `changes.holder-gone` does when a holder dies, and it needs no new procedure: the Titan's next card evaluates the ladder as every card does, and the `card` step breaks every tie during a round, because each player character holds a distinct card and a Wing Squadmate (at most one per Wing, `squadmates.yaml`) comes right after its player character. So the `sheet` step is never reached during a round, and removing it takes no choice from anyone. The standard Titans do not notice: they re-evaluate at their first card anyway, and their reference rows under the rule differ from the committed rows within sampling (Small 0.044 deaths against 0.040, Medium 0.033 against 0.033, Large 0.155 against 0.164, Chapter 5's reference Titan 0.029 against 0.032, at 24,000 fights; the twins at 120,000 in 4-4 sit within 1 standard error of `bar.json`).
  - **The parked quarry.** With current-holder met "wherever they stand", a quarry who stayed mounted at Distant drew only Run Past, Veer, Trample, and Thrash's knock-loose, none of which harm a mounted soldier at Distant, and kept the Abnormal off everyone else: a rider listed first halved its Critical Injuries (0.62 against 1.64 with the same rider listed last) to below the standard Medium Titan's 0.96 against the same Squad. Narrowing the test to a holder not at Distant closes it in the direction canon supports: a rider who rides clear has led it off, and it goes for the nearest. Under the rule the parked rider is a wasted soldier, not a shield: 0.25 deaths and 1.83 Critical Injuries (rider first) against 0.24 and 1.81 (rider last) as the values stood, and with the values decided in 4-4 the Abnormal still deals 0.176 deaths and 1.37 Critical Injuries against the standard Medium Titan's 0.082 and 0.95 to the same Squad (120,000 fights). Dropping the quarry at Blind Spot as well (a "path" test, In Reach or On Body only) was measured and rejected: it makes the Abnormal turn back to the cutters at In Reach, where its Grab and Lunge apply, and it fails the ceiling by 5.9 and 6.1 standard errors with helpers and the screen as the values stood, against 3.8 and 3.4 for the test decided.
  - **Under the rule, the sheet order does nothing.** The reference start gives 0.126 deaths with the cutters listed first and 0.126 with the strikers first; the helpers row 0.0315 and 0.0305. That is the measurement the Critical asked for, and it shows the values as committed fail the ceiling under any rule-set tie-break (helpers 0.029 to 0.034 against the Large twin's 0.022, 3.8 to 5.9 standard errors at 24,000), because about half of all fights now start with a striker as the quarry, who then cannot strike from Blind Spot, and the cutters at In Reach take the Grab and the Lunge. So OQ-103's values move (4-4).
  - **Canon.** The runner picks where it goes by what it sees, not by whose name is written first; it keeps to its quarry through the riders cutting at its legs; and a rider who outruns it has got away.
- **ADR change:** ADR-0003 `## Amended` (the ladder no longer reads the Squad sheet's order, which no rule sets) and ADR-0010 `## Amended` (a tie the cards cannot break leaves Attention held by nothing; current-holder's Distant exception). Part 3. Applied.
- **Glossary change:** none (the Attention Ladder entry is edited under 4-13).
- **Chapter impact:** Chapter 5 section 5.6 evaluation step 6 and `data/engagement/attention.yaml` `evaluation` (`sheet` becomes `none`), `tests.current-holder` `meaning`; Chapter 6 section 6.5 GM bullets (*Then the one it is already running down*, *Only then whoever is nearest*, *Riders*, *Down soldiers*) and its design note; `data/titans/index.yaml` `ladders` `reads_as`; `tools/probes/chapter-05/fight.py` and `tools/probes/chapter-06/fight6.py` `evaluate` (the last branch sets no holder; `current-holder` tests the Position); every Sprinting Abnormal row re-run (4-4). Part 6.
- **Revised by batch 4b:** The ladder's top two rungs swap, to `[hooked-into-its-body, loudest-or-brightest, current-holder, nearest]`, because every ladder's first rung is hooked-into-its-body (a rule of the ladder format; ADR-0010's promise on every ladder), and a rider shouting from Distant no longer draws the Abnormal off a striker who fell short (4b-1). The tie-break and the current-holder test stand.

### 4-4: OQ-103, the Sprinting Abnormal's values and its bar under the rule

- **Decision:** Keep (a)'s bar unchanged (row against row against the standard Medium and Large Titans' twins with the same support, every limit held within 2 standard errors of the difference at 120,000 fights a row; not trivial, winnable, ceiling, report), read under batch 4's tie-break (4-3), which the twins are run under too. Keep Medium Size Class, Tempo 2, Nape Depth 3, Regeneration 3, and Toughness 2 for every Body Part. **The Grab and Headlong Lunge move from Severity 3 to Severity 2**, so the Abnormal's Severities read 1 (Run Past, Veer, Pitch Headlong), 2 (Trample, Grab, Headlong Lunge, Thrash): every harmful entry one below the medium row's tier Severity, as Pitch Headlong already was. The bar is not relaxed.
- **Why:**
  - **The values as committed fail under the rule.** With the tie-break decided in 4-3, the Abnormal as committed deals 0.029 to 0.034 deaths with helpers against the Large twin's 0.022 (3.8 to 5.9 standard errors at 24,000 fights) and 0.0145 with the screen against 0.0104 (3.4), in either sheet order. The committed bar held only because the probe's sheet gave it a cutter to run down.
  - **Which lever** (`sweep_b4.py`, 24,000 fights a row, helpers and screen rows, against Large twins under the rule). Headlong Lunge cannot be lethal: +2.9 and +3.8 standard errors. Headlong Lunge Severity 2 alone: +5.4 and +4.4. Regeneration 4: +3.3 and +3.2. Leg Toughness 1: −1.9 and +0.9, but it moves every Toughness off the medium row and the Jam test with it. Nape Depth 2: −3.0 and −0.1, but 89% by round 3 makes it the softest kill in the chapter. Grab Severity 2: −0.1 and +0.1. Grab and Headlong Lunge Severity 2: −0.8 and −0.5. The Grab is the lever because under the rule its cards fall on soldiers at In Reach, where Grab and Lunge apply, and a Grab at Severity 3 against a Rookie lands 4 times in 5.
  - **Why both kill entries and not the Grab alone** (`quarry_b4_grab2_bar.out`, `margin_b4.out`, 120,000 fights a row). With the Grab alone at Severity 2 the ceiling holds on one seed (helpers +1.2, the screen +0.6, the screen with the pair −0.5 standard errors) and fails on the next (+0.8, +0.8, and +2.1), so its true rate sits at the twin's and a fresh seed fails a row one time in five. With both at Severity 2: helpers 0.0200 against 0.0211 (−1.5), the screen 0.0104 against 0.0105 (−0.1), the screen with the pair 0.0081 against 0.0084 (−0.8), on the safe side in every row, and the floor stands: the reference start median kill round 2, 69.6% by round 3, 7.4% with no kill within 12 rounds, 0.85 Critical Injuries (the Medium twin 0.70), 0.077 deaths (the Medium reference 0.033, the Large twin 0.160), 0.32 Grabs. Headlong Lunge cannot be lethal with the Grab at 2 holds by more (−1.2, −3.2, −1.9) but leaves the Abnormal no way to kill except its Grab, which no kill entry of a runner should lack.
  - **The bar, as decided, in both sheet orders** (`quarry_b4_bar.out`, 120,000 fights a row, the cutters first and the strikers first; deaths against the Large twin run under the same rule and order). Reference start: median kill round 2, 69.7% by round 3, 7.6% with no kill within 12 rounds (the Large twin 13.2%), 0.85 Critical Injuries (the Medium twin 0.70), 0.079 and 0.077 deaths (the Medium reference 0.033, the Large twin 0.162 and 0.159), 0.32 Grabs. Helpers: 0.0205 against 0.0205 and 0.0197 against 0.0216 (+0.0 and −2.2 standard errors), 0.79 Critical Injuries against the Medium twin's 0.64. The screen: 0.0104 against 0.0104 and 0.0102 against 0.0105 (+0.0 and −0.6), 0.52 against 0.42. The screen with Hook and Cut and Hamstring Line: 0.0078 against 0.0086 and 0.0081 against 0.0082 (−1.9 and −0.2), 0.45 against 0.39. Every row holds every part; the two orders differ by sampling alone, as the rule says they must. The parked rider (rider, cutter, striker, striker, the rider listed first and never leaving the saddle at Distant): 0.176 deaths and 1.37 Critical Injuries against the standard Medium Titan's 0.082 and 0.95 with the same Squad, so parking a rider costs the Squad a soldier and buys nothing (4-3).
  - **Canon for Severity 2.** The runner is committed to its line: its snatch and its lunge are made at full stride, and a soldier leaps clear of a Titan that cannot stop more easily than of one that reaches for them. Its harm is its speed, its two cards a round, and its reach at Distant (Run Past and Trample), which no standard Titan has. Severity 2 is the Small class's kill Severity and inside the Abnormal range (1 to 4).
  - **Figures that move.** Every Sprinting Abnormal row: the reference start (from 74.6% by round 3, 0.83, 0.071 to about 69.6%, 0.85, 0.077), the bar rows, the template Squad, the Draw Attention row, the rider rows, the earlier-ladder and standard-ladder rows, the Grab cells (now the Small Titan's Severity 2 cells, 29.0% to 45.3%, every cell under 50%), the lone rows if the lone model reads the Grab's Severity, and the setup mix (OQ-104). The Nape Depth 3 argument and the GM note *What a Read teaches* stand; Nape Depth 4 was measured failing every row read and is not re-measured.
- **ADR change:** ADR-0014 `## Amended` (the bar is read under the rule-set tie-break in both sheet orders; the Abnormal's kill Severities are chosen against it). Part 3. Applied.
- **Glossary change:** none.
- **Chapter impact:** `data/titans/sprinting-abnormal.yaml` (`grab` and `headlong-lunge` `severity: 2`, the header comment on values that differ from the medium row); Chapter 6 sections 6.5 (the rendered table, the design note) and 6.6 (every Abnormal figure, the bar design note, *How the fights compare*, the Grab cells); `data/titans/tuning.yaml` (`abnormals`, `verdicts.sprinting_abnormal`); `data/titans/probe-figures.yaml` and `results/` re-run with `run6.py`; OQ-104's setup mix. Part 6.
- **Revised by batch 4b:** "Every harmful entry one below the medium row's tier Severity" reads "both kill entries one below the medium kill tier's Severity 3, Pitch Headlong one below the medium control tier's Severity 2, and Trample at that control Severity" (4b-7). The Grab alone at Severity 2 sits above its twin, not at it (pooled +3.5 standard errors with helpers, +2.6 with the screen), and the decided helpers ceiling sits at the Large twin's rate; a row past 2 standard errors on one seed is re-run on a second seed and fails only on the pooled figure (4b-4). The bar was re-run under the swapped ladder in both orders and holds (4b-1).
- **Revised by batch 5:** The bar's winnable limit "no kill within 12 rounds is at most the standard Large Titan's twin" reads "no kill", the share of fights that end with the Focus Titan alive, since the 12-round horizon was the simulator's reading and not a rule; every Titan Engagement now carries a retreat clock (5-10), and the bar re-measured under it holds every limit in every row and both orders (`tools/probes/batch-5/retreat_b5_bar.out`).

### 4-5: OQ-104, when the Abnormal enters Phase 1 play

- **Decision:** Keep (b): when the interim setup table's Focus Titan roll gives Medium, a D6 on `medium_abnormal` makes the Focus Titan the Sprinting Abnormal on a 6, so 1 Titan Engagement in 12 the table sets up meets it; Background Titans are always standard.
- **Why:** Without a roll the Abnormal, its Fear Roll, and its Read facts never reach the written Phase 1 game; the roll is one deterministic step in the one setup procedure (ADR-0003, ADR-0012), and its cost is measured (0.84 Critical Injuries and 0.054 deaths per Titan Engagement without it, 0.85 and 0.057 with it, re-run under 4-4). Standard Background Titans keep Chapter 5's Background figures and one hidden-value tracker per fight.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Chapter 5 section 5.1 and Chapter 6 section 6.1 drop the `PROVISIONAL:` lines and cite this decision; `data/engagement/engagement-setup.yaml` (`medium_abnormal`) cites it; the setup mix re-run.

### 4-6: OQ-105, rows and pointers in Chapters 1 to 5

- **Decision:** The applied items 1 to 9, 11 to 13, and 17 stand as pointers, comments, and field lists; item 14 is decided as OQ-106 (4-7) and item 16 as OQ-107 (4-8); item 10 (`docs/rules/PROGRESS.md`) stays the coordinator's; item 15 (Chapter 5's `fight.py` makes no start-of-fight Fear Roll) stays a listed simulator case, since Chapter 5's targets are measured at Stress 1 after that roll by construction (ADR-0014).
- **Why:** Each item points at or lists what Chapter 6's files state; none changes a rule except the two now decided.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none new.

### 4-7: OQ-106, "set by Size Class" in the glossary

- **Decision:** Keep (a): the Nape Depth entry reads "set by Size Class, or by an Abnormal's own stat block"; the Regeneration entry reads "at a pace set by Size Class, or by an Abnormal's own stat block".
- **Why:** The batch 3 constraint lets an Abnormal list every value in full within the Size Class rows' range, the Abnormal entry gives it its own table, and the Sprinting Abnormal's Nape Depth of 3 is not the Medium row's 4; a glossary term must not contradict a stat block, and narrowing the constraint would remove the build OQ-103 is measured with.
- **ADR change:** none.
- **Glossary change:** Nape Depth and Regeneration (Part 4). Applied.
- **Chapter impact:** Chapter 6 section 6.5 drops the citation of this entry as open.

### 4-8: OQ-107, a card's later effects on a target who has died

- **Decision:** Keep (a), as a Chapter 5 rule: a target who dies while a card's effects are applied receives none of that card's later effects; every other target still receives theirs. No Chapter 6 entry gives a target any effect after one that harms them, so no current table reaches the case; `fight6.py` models it.
- **Why:** It is the reading a table reaches without a ruling (a dead soldier cannot dodge, take Stress, or be knocked loose, and the Critical Injury that killed them is recorded); (b) invites a second Critical Injury on a corpse to count for Grief; (c) constrains later Titans the procedure could serve.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** `data/engagement/behavior-procedure.yaml` `resolving_a_card` step `effects` gains "A target who dies receives none of the card's later effects; every other target still does (decision batch 4, OQ-107)"; Chapter 5 section 5.5 *Resolving a card* step 7 gains the same sentence; Chapter 6 section 6.1 drops the `PROVISIONAL:` line.

### 4-9: OQ-108, where an Abnormal's hidden values print

- **Decision:** Keep (a): an Abnormal's Toughness, Nape Depth, Regeneration clock length, and Attention Ladder, with what they mean at the table, print only in a GM section of section 6.5 that players do not read, and section 6.6's Abnormal lone rows are the GM's; its Tempo, Behavior Table, Severities, move-up shares, Jam test, Grab cells, and support rows stay public.
- **Why:** A Read must be worth its successes, Chapter 5's hidden list is exactly these values, and `data/titans/` stays the single source with `hidden_until_read` for tools. (b) makes Reads worthless for a group that has read the chapter; (c) splits a chapter across books the rulebook does not have.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Chapter 6 sections 6.5 and 6.6 drop the `PROVISIONAL:` line for OQ-108 and cite this decision; `data/titans/index.yaml` (`hidden_until_read`) cites it.

### 4-10: OQ-109, a grounded Titan's leg entries

- **Decision:** Keep (a): every Chapter 6 entry that uses a leg lists both legs (`[leg, leg]`), so one Broken leg makes it illegal and its result moves up; `titans.py` fails an entry on a two-legged Titan that lists one leg. No Chapter 5 rule is added.
- **Why:** The format already says it (a kind listed twice needs two), the grounded picture and the rows agree, every table stays legal (the highest kill share in any state stays one half; the fewest legal entries besides Thrash stay 3 on the Large Titan and 1 on the Sprinting Abnormal), and the Large Titan's rows do not move beyond sampling. (c) would state once what the rows already state and re-run every table for the same result; (b) keeps a Titan on the ground sprinting.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** `data/engagement/titan-format.yaml` (`entry_fields`, `body_parts_used`) gains a comment: "an entry a grounded Titan must not resolve lists leg twice (decision batch 4, OQ-109)"; Chapter 6 section 6.1 drops the `PROVISIONAL:` line and cites this decision.

### 4-11: OQ-110, the file name

- **Decision:** Keep (a), applied in the batch 3e pass: `data/titans/index.yaml`, with every pointer moved. The glossary's _Avoid_ line for Squad Pool keeps "roster".
- **Why:** One source of truth and no file named by a word the glossary avoids.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none.

### 4-12: the batch 3b screen probes (Codex Minors 1 and 2)

- **Decision:** `tools/probes/batch-3b/screen_b3b.out` and `screen6_b3b.out` are historical snapshots of the decision-era model and are labelled so; the two scripts' docstrings drop "the model is the decider's, unchanged" and the reproduction claim, and say that they import the live probes (whose flag, nearest, tie-break, table, ladder, start, and harm rules have changed since batch 3b), that their `BASE_PIN` pins only the Break Attention switches, and that the rows that govern are `data/engagement/tuning.yaml` (`decoys`) and `data/titans/tuning.yaml` (support rows). No snapshot of the old model is committed.
- **Why:** The decision record already says the committed rows govern where the staged scripts differ (3b-1, 3b-8, 3d-3); a byte-for-byte reproduction of a superseded model would need a second copy of Chapter 5's and Chapter 6's data, against ADR-0012.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** `tools/probes/batch-3b/screen_b3b.py` and `screen6_b3b.py` docstrings (Part 6); `lone_b3b.py` and `lone_t2_b3b.py` reproduce and need no change.

### 4-13: the Opus Minors 3 to 7

- **Decision:**
  - **Minor 3, the Down-soldier promise.** Chapter 5 section 5.6 reads "On the standard ladder, a Titan turns to a Down soldier only when no one is closer, hooked in, hurting it, or louder"; the OQ-81 design note's *Ties* and *Down soldiers* lines add "; an Abnormal ladder naming current-holder keeps a Down holder who is not at Distant". 3e-6's clause stays as history.
  - **Minor 4, the `nearest_rung` rows.** `data/engagement/tuning.yaml` `prepared_squad_kill.nearest_rung`: the second column is renamed `evaluations_where_the_earlier_reading_kept_a_farther_holder_per_fight`, the `as_written` rows read "not counted", and the note reads "Under the earlier reading a holder farther off than the closest candidate was kept 0.002 times a fight or less; the rule never keeps one." Section 6.6's *Support rows* note and the OQ-81 note read the same. `tools/probes/batch-3e/nearest_b3e.py` is not re-run (its counter is right; its labels were wrong). No figure moves.
  - **Minor 5, the glossary.** The Attention Ladder entry reads "just hurt it (until the end of its next card that resolves a behavior)". Part 4. Applied.
  - **Minor 6, the register.** OQ-111's *Provisional choice* and *Earlier-chapter change needed* gain "(history; revised by batch 3e: both probes keep the flags)"; OQ-81's Decision line puts the Feint under batch 3c and the flag lifetime under batch 3e. Part 5. Applied.
  - **Minor 7, a quarry Grabbed by another Focus Titan.** Chapter 6 section 6.5's *Only then whoever is nearest* bullet and `index.yaml` `reads_as` add "or is Grabbed by another Focus Titan" to the list of when nothing holds its Attention; `attention.yaml` `changes.holder-gone` `when` adds "is Grabbed by another Focus Titan" (`candidates.never` already excludes them).
- **Why:** Each is a wording gap the review located exactly; none changes a rule or a figure.
- **ADR change:** none.
- **Glossary change:** Attention Ladder (Part 4).
- **Chapter impact:** Part 6.

### Chapter impacts of batch 4

**Chapter 1:** none.

**Chapter 2:** none.

**Chapter 3:** none (`data/mind/scars.yaml` stands as applied under OQ-105).

**Chapter 4:** none. `sheet-fields.yaml` `squad_sheet_row` stays unordered; nothing reads its order any more (4-3).

**Chapter 5:** section 5.1 (drop the `PROVISIONAL:` line for OQ-104, cite batch 4); section 5.5 *Resolving a card* step 7 (OQ-107); section 5.6 evaluation step 6 ("Otherwise nothing holds its Attention until its next card, which evaluates the ladder again with that round's cards; only the start of a Titan Engagement and an end step reach this step"), *Down and carried soldiers* ("On the standard ladder, ..."), the OQ-81 design note (*Ties*, *Down soldiers*, the `nearest_rung` sentence), and *Abnormal ladders* if it quotes current-holder's meaning; `data/engagement/attention.yaml` `evaluation` (`sheet` becomes `none`), `tests.current-holder` `meaning`, `changes.holder-gone` `when`; `data/engagement/behavior-procedure.yaml` `resolving_a_card.effects` (OQ-107); `data/engagement/engagement-setup.yaml` `medium_abnormal` (cite); `data/engagement/titan-format.yaml` `entry_fields.body_parts_used` comment (OQ-109); `data/engagement/tuning.yaml` `prepared_squad_kill.nearest_rung` (4-13); `tools/probes/chapter-05/fight.py` `evaluate` (the last branch: `t.holder = None`), then `run_simple.py`, `lone.py`, and every Chapter 5 row re-run for the record (they move within sampling; the committed rows govern); `tools/probes/batch-3b/screen_b3b.py` and `screen6_b3b.py` docstrings (4-12).

**Chapter 6:** every `PROVISIONAL:` line in sections 6.1, 6.5, and 6.6 is removed and the rule cites "decision batch 4, OQ-1xx"; the introduction's sentence on open entries reads that OQ-100 to OQ-111 are decided and that batch 4 changed the last tie-break, current-holder, and the Abnormal's kill Severities; section 6.5's GM bullets and design note (4-3, 4-13), its rendered table (Grab and Headlong Lunge Severity 2); section 6.6's Abnormal figures, bar note, *How the fights compare*, Grab cells, and *Support rows* note (4-4, 4-13); `data/titans/sprinting-abnormal.yaml` (severities, header comment, `provisional` to `decided`); `data/titans/index.yaml` (`reads_as`; `provisional` to `decided`); `data/titans/tuning.yaml` (`abnormals`, `verdicts`, `probes`); `data/titans/probe-figures.yaml`; `tools/probes/chapter-06/fight6.py` `evaluate` (the last branch and the current-holder test), then `run6.py` in full.

## Batch 4b: Chapters 5 and 6 conformance round 2

Rulings on the round 2 conformance reviews of Chapters 5 and 6 after batch 4 (`docs/reviews/05-06-decisions-conformance-review-2.md`, Opus: one Critical, one Major, four Minors; `05-06-decisions-conformance-review-2-codex.md`, Codex: one Major, the same stance, and one Minor), and on the drafter's notes after batch 4. The Critical is closed by the smallest rule that makes ADR-0010's promise structural: hooked-into-its-body is the first rung of every ladder, so the Sprinting Abnormal's ladder swaps its top two rungs. The Major on cutting legs is measured on every table and logged as an unresolved Major with its reason: the two nearest levers either leave it standing or break the target rows, and ADR-0014's kill target is defined under the baseline policy; the four-striker row becomes a reported row beside the target. Odds without a source come from `tools/probes/batch-4b/` (`loud_b4b.py`: the loud rider and the bar under the swapped ladder, `loud_b4b_explore.out` at 60,000 fights a row and `loud_b4b_bar.out` at 120,000 in both Squad sheet orders; `strikers_b4b.py`: four strikers against the baseline on Chapter 5's reference Titan and every Chapter 6 table, with two candidate levers, `strikers_b4b.out` at 60,000). Both import the committed `fight6.py` and `fight.py`, subclassed only in the Squad's roles and in the change under measurement. Where a figure here differs from a committed row by sampling, the committed row governs; the drafter re-runs every Sprinting Abnormal row under 4b-1.

### Summary table

| Item | Finding | Decision (one line) | ADR change | Glossary change | Chapter impact |
|---|---|---|---|---|---|
| 4b-1 | Opus Critical 1; Codex Major 1 | Every ladder's first rung is hooked-into-its-body (a rule of the ladder format); the Sprinting Abnormal's ladder is `[hooked-into-its-body, loudest-or-brightest, current-holder, nearest]`; the bar holds in both orders and the loud rider stops paying | ADR-0010 (`## Amended`) | none | Ch5 5.6; `attention.yaml`; Ch6 6.5, 6.6; `index.yaml`; every Abnormal row re-run |
| 4b-2 | Opus Major 2 | Unresolved Major, logged with its reason and measurements: four strikers beat the baseline on every table; the two levers measured fail or break the target rows; the kill target is read under the baseline, and the four-striker row is reported beside it | ADR-0014 (`## Amended`) | none | Ch5 5.13; Ch6 6.6; `tuning.yaml` (both); OQ-112 (staged) |
| 4b-3 | Opus Minor 3 | A Titan that enters mid-round after a flare evaluates its ladder with that round's cards; only an end-step entry and the start reach `none` | none | none | Ch5 5.6; `attention.yaml` `evaluation.card`, `evaluation.none`; Ch6 6.5 |
| 4b-4 | Opus Minor 4; the drafter's notes | The bar's tolerance reads: a row past 2 standard errors on one seed is re-run on a second, and fails only on the pooled figure; the notes say the helpers ceiling sits at the twin's rate and the Grab alone above it | ADR-0014 (`## Amended`) | none | Ch6 6.6; `tuning.yaml` `abnormals.sampling`, `verdicts` |
| 4b-5 | Opus Minor 5 | OQ-102's and OQ-103's pre-batch-4 paragraphs get "(History: ...)" markers | none | none | OQ-102, OQ-103 (staged) |
| 4b-6 | Opus Minor 6 | "Nothing holds Attention at the start" is conditional on no rung picking out one soldier; the glossary's Attention entry names a decoy and nothing | ADR-0010 (`## Amended`) | Attention | Ch5 5.1; Ch6 6.6 |
| 4b-7 | Codex Minor 1 | 4-4's Severity sentence reads: both kill entries one below the medium kill tier, Pitch Headlong one below the medium control tier, Trample at the medium control tier's Severity | none | none | Ch6 6.5 if it repeats the sentence; OQ-103 (staged) |

### 4b-1: the Abnormal's top rung, and ADR-0010's promise on every ladder

- **Decision:** `abnormal_ladder_format` gains the rule "The first rung is always hooked-into-its-body, so a Nape striker who falls short draws the Titan's next behavior on every ladder (ADR-0010); the last rung is always nearest." The Sprinting Abnormal's ladder becomes `[hooked-into-its-body, loudest-or-brightest, current-holder, nearest]`. Draw Attention is unchanged (unrolled, from any Position). No new test joins the closed list, and the bar is unchanged.
- **Why:**
  - **The contradiction.** Batch 4 wrote into ADR-0010 that a striker who falls short draws the Titan's next behavior on every ladder, while the Sprinting Abnormal's ladder put the loudest flag above the hooked-by-strike flag. Measured (`loud_b4b_explore.out`, 60,000 fights a row): a rider who stays in the saddle at Distant and takes Draw Attention every turn draws 1.94 of the Abnormal's cards a fight, on 0.55 of which a comrade holding the hooked-by-strike flag was passed over, and that comrade struck again from Blind Spot. The Squad that gives up a cutter to shout does better than the baseline on every measure (71.1% killed by round 3 against 69.5%, 3.2% with no kill against 7.6%, 0.78 Critical Injuries against 0.85, 0.052 deaths against 0.078; with two helpers 0.013 deaths against 0.021), because the rider draws only Run Past, Veer, Trample, and Thrash's knock-loose, none of which harm a mounted soldier at Distant, and every striker keeps ADM-0010's restriction off their back.
  - **The smallest rule.** Making hooked-into-its-body the first rung of every ladder is the promise itself written as a format rule, so it holds for the ladders a later chapter writes, not only for this one. It needs no new test (Codex's loud-not-at-Distant test would leave a loud soldier at In Reach above a striker who fell short, and still need the promise scoped), no Position or roll on Draw Attention (which the standard ladder never needed, since loudest is its fourth rung), and no change to the bar.
  - **The stance closes.** Under the swapped ladder the loud rider draws 1.67 cards a fight and never one over a hooked comrade, and the Squad that fields him does worse than the baseline on every measure: 65.1% by round 3, 7.4% with no kill, 0.90 Critical Injuries, 0.080 deaths; with two helpers 0.0224 deaths against the baseline helpers row's 0.021. Against the standard Medium Titan the same Squad gives 49.6%, 0.92, and 0.077, as before.
  - **The bar holds in both orders** (`loud_b4b_bar.out`, 120,000 fights a row, deaths against the Large twin run under the same rule and order): the cutters first and the strikers first. Reference start: median kill round 2, 69.6% and 69.3% by round 3, 7.6% with no kill within 12 rounds (the Large twin 13.1% and 13.3%), 0.85 Critical Injuries (the Medium twin 0.70), 0.077 and 0.076 deaths (the Medium reference 0.033, the Large twin 0.161 and 0.166). Helpers: 0.0206 against 0.0207 and 0.0194 against 0.0215 (−0.1 and −2.4 standard errors), 0.79 Critical Injuries against the Medium twin's 0.64. The screen: 0.0101 against 0.0108 and 0.0096 against 0.0101 (−1.4 and −1.0), 0.52 against 0.42. The screen with Hook and Cut and Hamstring Line: 0.0078 against 0.0088 and 0.0080 against 0.0092 (−2.4 and −2.4), 0.46 against 0.39. Every part holds in every row and both orders; the floor and the winnable limit hold by 22 standard errors or more.
  - **Canon.** The runner turns on a blade at its Nape before it turns toward noise: it is the standard Titan's first turn too (ADR-0010), and what made the Sprinting Abnormal a runner is what it lacks below that rung, reach and pain.
  - **Figures that move.** The Abnormal's Draw Attention row (cutters take Draw Attention while a striker holds Attention) reads 68.8% by round 3, 5.2% with no kill, 1.03 Critical Injuries, 0.090 deaths, against 72.0%, 3.4%, 0.96, 0.073 under the committed ladder; the loud-rider row is reported beside it. The reference start and the bar rows move within sampling (69.6% by round 3, 0.85, 0.077).
- **ADR change:** ADR-0010 `## Amended`. Applied.
- **Glossary change:** none.
- **Chapter impact:** Chapter 5 section 5.6 *Abnormal ladders* ("always begin with hooked into its body and end with nearest") and `data/engagement/attention.yaml` `abnormal_ladder_format` (`rungs`, `rules`); Chapter 6 section 6.5 (the rendered ladder, the GM bullets *Noise turns it first* and *Then what digs into it* swap and read "A blade at its Nape or a soldier On Body turns it first; then noise"), its design note; section 6.6 (the Draw Attention row, a loud-rider row beside it, every Abnormal figure re-run with `run6.py`); `data/titans/index.yaml` `ladders` (`rungs`, `reads_as`); `titans.py` checks the first rung as it checks the last; `cases6.json` gains the loud-rider row.

### 4b-2: cutting legs against four strikers (an unresolved Major)

- **Decision:** Logged as an unresolved Major, with its reason. No rule or value changes in this batch. ADR-0014's prepared-Squad kill target is read under the baseline policy (two cutters, two strikers), as batch 3 amended it, and the four-striker Squad is a reported row beside it in Chapter 5 section 5.13 and Chapter 6 section 6.6, in `tuning.yaml` `prepared_squad_kill.squads` and `simulator_cases`. OQ-112 (staged) records the question, the measurements, and the levers left to a decision that can redraw the Behavior Tables and re-run every target: the Phase 1 simulator's report is its input.
- **Why:**
  - **Measured** (`strikers_b4b.out`, 60,000 fights a row; four eager strikers against the baseline): Chapter 5's reference Titan 78.4% killed by round 3 against 61.9%, 0.43 Critical Injuries against 0.71, 0.008 deaths against 0.030, a median kill in round 2 against 3; the standard Small 90.4% against 80.6%, 0.65 against 0.84, 0.019 against 0.043; the standard Medium 78.1% against 61.6%, 0.42 against 0.70, 0.011 against 0.034; the standard Large 78.8% against 61.4%, 0.79 against 1.42, 0.084 against 0.165; the Sprinting Abnormal 91.4% against 69.4%, 0.62 against 0.86, 0.019 against 0.079. The strikers make 4.6 Nape strikes a fight against the baseline's 3.3 and 0.3 Body Part strikes against 5.8.
  - **Why it happens.** Two more Nape attempts a round and the Openings a short strike leaves are worth more than the grounded dice the cutters buy, and a striker who falls short holds Attention at Blind Spot, where most entries fall back to Thrash's knock-loose (4-2), while the cutters stand at In Reach, where every Grab, Bite, Trample, and Lunge applies.
  - **The two nearest levers fail.** Giving the Titan its turn against a Blind Spot holder (a holder at Blind Spot counts as In Reach for an entry's Position requirement) doubles the baseline's harm on the target's own table (the reference Titan 1.14 Critical Injuries and 0.061 deaths against 0.71 and 0.030; the standard Medium 1.09 and 0.073) and leaves four strikers ahead on every measure (0.84 and 0.029; 76.4% by round 3). Raising the grounded-titan Bonus Dice from 2 to 3 moves the baseline to 65.8% by round 3, 0.66, and 0.025, and leaves four strikers at 78.6%, 0.42, and 0.008. Each of the levers the review names (a Thrash that reaches Blind Spot from On Body's height, a fallback that harms a Blind Spot holder, a standing Nape that resists more than a grounded one) redraws a table or re-reads Nape Depth, so it re-runs the kill-share constraint, the Jam test, the move-up shares, the lone band, and the Levi-grade figure; none can be measured to hold inside this batch.
  - **Why not Critical.** The target is met under its stated policy, no rule is broken, and no ruling is needed; a Squad that fields four strikers plays a legal, faster, safer fight, which is a balance and fidelity cost the chapters must state rather than hide.
  - **What a decision needs.** The Phase 1 simulator reports the four-striker row beside every target under ADR-0014 (this batch adds it to `simulator_cases`); the decision then chooses between a rule that limits what Blind Spot holds (canon's pair at the Nape), a table shape that reaches a Blind Spot holder, and accepting the stance with the cutters' role restated as grounding a Titan that must be stopped, not killed faster.
- **ADR change:** ADR-0014 `## Amended` (the kill target is read under the baseline policy; the four-striker row is reported beside every target; the unresolved Major is named). Applied.
- **Glossary change:** none.
- **Chapter impact:** Chapter 5 section 5.13 gains the four-striker row (78.4%, 0.43, 0.008, median round 2) beside the target, with a sentence that the target is read under the baseline policy and that the stance is an open question (OQ-112); `data/engagement/tuning.yaml` `prepared_squad_kill.squads` gains `four_strikers` and `simulator_cases` the row for every table; Chapter 6 section 6.6 *How the fights compare* gains the five rows above; `data/titans/tuning.yaml` `simulator_cases` likewise; `tools/probes/chapter-05/cases2.json` and `chapter-06/cases6.json` gain the row.

### 4b-3: a Titan that enters mid-round after a flare

- **Decision:** `evaluation.card` reads "Skip this step if no cards have been dealt this round, or if the evaluation is made at an end step, as when a Background Titan enters at the background-clocks end step (`full_clock`). A Titan that enters mid-round, when a flare fills its clock, is evaluated with that round's cards." `evaluation.none` reads "Only the start of a Titan Engagement, an end step, and a tie among Wing Squadmates of one player character (none in Phase 1, since a Wing holds one) reach this step." Chapter 5 section 5.6 steps 5 and 6 and Chapter 6's GM bullet read the same.
- **Why:** The `card` step's words already give the lowest card; the example read as a rule for every entry. Naming the moment keeps one reading and no new procedure.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Chapter 5 section 5.6 evaluation steps 5 and 6; `attention.yaml` `evaluation.card` and `evaluation.none`; Chapter 6 section 6.5 *Only then whoever is nearest*.

### 4b-4: the bar's tolerance on a row with no margin

- **Decision:** `abnormals.sampling` reads: "A limit holds within sampling when the Abnormal's figure is past its twin's by no more than 2 standard errors of the difference at 120,000 fights a row. A row past that on one seed is re-run on a second seed in the same order, and it fails only if the figure pooled over the two runs is past 2 standard errors." Section 6.6's bar note and `verdicts.sprinting_abnormal` state that the decided helpers ceiling sits at the Large twin's rate (pooled over the committed and review runs 0.0207 against 0.0208), so a single run past 2 standard errors there is sampling until the second seed says otherwise, and that the Grab alone at Severity 2 sits above its twin (pooled +3.5 standard errors with helpers, +2.6 with the screen), not at it. 4-4's "its true rate sits at the twin's" is revised below.
- **Why:** The bar's limits are unchanged; the second seed removes the one-in-22 false failure the review computed without loosening what a row must show, since a row truly past its twin fails the pooled figure sooner than a single seed. The drafter's "Grab alone" failures (+2.2 and +2.8 on the committed seeds) are a real miss of a rejected variant, and the text says so.
- **ADR change:** ADR-0014 `## Amended` (the pooled reading). Applied.
- **Glossary change:** none.
- **Chapter impact:** Chapter 6 section 6.6 (the bar design note); `data/titans/tuning.yaml` `abnormals.sampling`, `verdicts.sprinting_abnormal`; `run6.py bar` re-runs a failing row on a second seed and prints the pooled figure.

### 4b-5: the register's OQ-102 and OQ-103 bodies

- **Decision:** OQ-102's *Canon for (b)*, *How often it runs its quarry down*, *Figures*, *Riders*, *Riders after decision batch 3b*, *Draw Attention*, and *The lone fight*, and OQ-103's option (a) Severities, *Figures under (a)*, and *The setup mix*, gain "(History: before decision batch 4; see the Decision line and Chapter 6, section 6.6)". Staged in `batch-4b-staging.md`, since the register is being edited by another drafter.
- **Why:** Batch 4 gave OQ-111 the same markers for the same lag.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none.

### 4b-6: "nothing holds" at the start, and the glossary's Attention entry

- **Decision:** ADR-0010's batch 4 sentence reads, through the batch 4b paragraph, "a Titan Engagement starts with nothing holding the Titan's Attention unless a rung picks out one soldier, as none of the Phase 1 ladders' rungs does at the start"; Chapter 5 section 5.1 step 5 and Chapter 6 section 6.6 *Support rows* copy `attention.yaml`'s condition. The glossary's Attention entry reads: "The one soldier or decoy a Focus Titan is fixed on at any moment, which its Behavior Table acts against; nothing holds it when no rung, its holder, or the cards pick one out, as at the start of a Titan Engagement. A soldier holding Attention cannot strike the Nape."
- **Why:** The closed `tests` list holds mounted, most-harmed, and down, which a later ladder may name and which can pick out one soldier at Distant before any card is dealt; `attention.yaml` states the condition and the ADR and two chapter sentences dropped it.
- **ADR change:** ADR-0010 `## Amended` (with 4b-1). Applied.
- **Glossary change:** Attention. Applied.
- **Chapter impact:** Chapter 5 section 5.1 step 5; Chapter 6 section 6.6 *Support rows*.

### 4b-7: the Severity sentence

- **Decision:** 4-4's "every harmful entry one below the medium row's tier Severity, as Pitch Headlong already was" reads "both kill entries one below the medium kill tier's Severity 3, Pitch Headlong one below the medium control tier's Severity 2, and Trample at that control Severity" (a `Revised by batch 4b:` line on 4-4); OQ-103's Decision line reads the same (staged); Chapter 6 keeps its table and YAML, which were right.
- **Why:** Trample is a harming control entry at Severity 2, equal to the medium control tier's.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Chapter 6 section 6.5's design note if it repeats the sentence.

### Chapter impacts of batch 4b

**Chapters 1 to 4:** none.

**Chapter 5:** section 5.1 step 5 (4b-6); section 5.6 evaluation steps 5 and 6 (4b-3) and *Abnormal ladders* (4b-1); section 5.13 (the four-striker row and its sentence, 4b-2); `data/engagement/attention.yaml` `abnormal_ladder_format` (4b-1), `evaluation.card` and `evaluation.none` (4b-3); `data/engagement/tuning.yaml` `prepared_squad_kill.squads` and `simulator_cases` (4b-2); `tools/probes/chapter-05/cases2.json` (4b-2).

**Chapter 6:** section 6.5 (the rendered ladder, GM bullets, design note; 4b-1, 4b-3, 4b-7); section 6.6 (every Abnormal figure re-run under the swapped ladder; the Draw Attention row and a loud-rider row; the bar note on the pooled reading and the helpers row; *How the fights compare* with the four-striker rows; *Support rows*; 4b-1, 4b-2, 4b-4, 4b-6); `data/titans/index.yaml` `ladders` (4b-1); `data/titans/tuning.yaml` `abnormals.sampling`, `verdicts`, `simulator_cases` (4b-2, 4b-4); `tools/probes/chapter-06/titans.py` (the first-rung check), `run6.py bar` (the second seed), `cases6.json` (the loud-rider and four-striker rows).

## Batch 5: final full review

Rulings on the owner's final full review of Chapters 1 to 6 before the playtest packet (`docs/reviews/01-06-full-review-1-fable.md`: two Majors and three Minors; `docs/reviews/01-06-full-review-1-astra.md`: two Criticals, four Majors, two Minors), with the two rules questions the simulator review round 2 raised (`docs/reviews/simulator-review-2.md`, Critical 1 and Major 3; `docs/reviews/simulator-review-2-codex.md`, Major 2) folded in as 5-10 and 5-11, and its Minor 9 confirmed in 5-12. Astra C1 (tables rendered into the chapters), Astra m2 (YAML quoting), and Fable Minor 1 (section 5.13's "not yet built") are the drafter's and are not ruled here. Every other finding is decided below, with OQ-112 and OQ-113 reconsidered in the light of both reviews. 5-15 to 5-18, added after the round 2 full reviews (`docs/reviews/01-06-full-review-2-fable.md`: one Critical, one Major, four Minors; `docs/reviews/01-06-full-review-2-astra.md`: two Majors), rule on their findings.

Measurement: 5-1 to 5-9 move no figure, and why is stated in each entry (the retreat's ordering and days between sessions are not modeled; no reference build holds Horsemanship; the probes already resolve a Grab's hold before its crush; two-Titan falls and Positions after the last kill do not reach a target; no bar row takes Draw Attention from Distant). 5-10 adds a rule that ends every long fight and is measured on the committed simulator with that rule on top of it (`tools/probes/batch-5/retreat_b5.py`, `retreat_b5_explore.out` at 30,000 fights a row, `retreat_b5_bar.out` at 120,000 fights a row in both sheet orders): the prepared-Squad target, Chapter 6's Medium, Small, and Large bands, and the Abnormal's bar all hold under it, with the Medium deaths band at its edge, as 5-10 records.

### Summary table

| Item | Finding | Decision (one line) | ADR change | Glossary change | Chapter impact |
|---|---|---|---|---|---|
| 5-1 | Astra C2 | Option 2: under a retreat the forced move comes before the action on every turn, except a stay-with-a-comrade move (retreat option 4), whose action comes first; the lone cut stays closed | ADR-0010 (`## Amended`) | none | Ch5 5.3, 5.6 note, 5.10; `round.yaml`; `background-titans.yaml` |
| 5-2 | Fable Major 1 | An interim day: one day passes at the start of each session, before the interim issue, with `each_day` as written and no Stress or Grief change; OQ-116's cadence for play | none | none | Ch3 intro, 3.1, 3.6; Ch4 4.9; Ch5 intro; `healing.yaml`; `standard-issue.yaml` |
| 5-3 | Fable Major 2; Astra M4 | Ride is dormant until the Chase rules; Horsemanship also names the dodge a mounted soldier makes with the horse's Gear Dice, so it is live; the Rider template and the Lifepath rows stand | none | none | Ch2 2.7, 2.8, 2.10, the Mira example; Ch4 4.5; `action-catalog.yaml`; `talents.yaml`; `horses.yaml` |
| 5-4 | Astra M1 | The Positions held when the last Focus Titan died are the ones the engagement-end steps read; Chapter 4 clears the records after the last of them | none | none | Ch3 3.5; Ch5 5.7, 5.11; `positions.yaml`; `treat-injury.yaml`; `engagement-end.yaml` |
| 5-5 | Astra M2 | A fall is read relative to the Focus Titan the soldier holds the closest Position to; on a tie, the Titan whose card or effect caused it, else the earliest label | none | none | Ch4 4.6; Ch5 5.2; `falls.yaml`; `positions.yaml` |
| 5-6 | Astra M3 | A Grab's hold step comes before its crush: the target is Grabbed, then crushed, and a target the crush makes Down is Down in the Titan's hand and does not fall | none | none | Ch5 5.9; `grab.yaml`; `falls.yaml` |
| 5-7 | Fable Minors 2 and 3; Astra m1 | "Intent" leaves the standard Titan's telegraph; Distant reads "out of a standing Titan's reach"; the Small Titan note reads "two successes break an Intact part" | none | none | Ch5 5.2, 5.4; Ch6 6.1, 6.2, 6.5; `positions.yaml` |
| 5-8 | OQ-113 | Decided (b): Draw Attention needs a Position other than Distant; the loud-rider rows leave the bar and the chapter | ADR-0010 (with 5-1) | none | Ch5 5.6; Ch6 6.5, 6.6; `attention.yaml`; `action-catalog.yaml`; `tuning.yaml` |
| 5-9 | OQ-112 | Kept open; the final review saw it and added nothing | none | none | OQ-112 |
| 5-10 | Simulator review 2, Critical 1 | Every Titan Engagement carries a retreat clock, 8 segments on the interim setup, filled at the end of each round; when it fills the Engagement becomes a retreat, and the retreat's own rules end it; "no kill within 12 rounds" becomes "no kill"; the Medium deaths band holds at its edge (0.0499 and 0.0482), the Large winnable band holds (14.4% and 14.6%), and the Abnormal's bar holds in every row and both orders | ADR-0014 (`## Amended`) | new **Retreat clock** | Ch5 5.1, 5.3, 5.10, 5.11, 5.13; Ch6 6.6; `engagement-setup.yaml`; `background-titans.yaml`; `round.yaml`; `engagement-flow.yaml`; both tuning files; the probes and the simulator |
| 5-11 | Simulator review 2, Major 3; Codex Major 2 | Every "about" on a proportion reads five points either side; a median reads exactly; a stated range or limit is its own band; a figure past an edge by at most 2 standard errors is judged on a pooled second seed; the Levi-grade cut, the lone Grab, and the Stress 2, Grief 0 cell are Met | ADR-0014 (`## Amended`) | none | Ch5 5.13; Ch6 6.6; `data/engagement/tuning.yaml`; `data/titans/tuning.yaml`; the report |
| 5-12 | Simulator review 2, Minor 9 | Pry Loose's own row in `grab.yaml` is complete (needs 2, lifted penalty 2, who, roll, on success); the engine reads it, no rule changes | none | none | none (`tools/sim/rules.py`, `engine.py`) |
| 5-13 | Batch 5 apply, the drafter's PROVISIONAL in section 5.10 | Decided: under a retreat a Lift Comrade action comes before the move, the second exception to move-first, so a lifted comrade is carried out the same turn; the marker goes | ADR-0010 (the batch 5 paragraph) | none | Ch5 5.10; `background-titans.yaml` `order`; `tuning.yaml` `retreat` |
| 5-14 | Batch 5 re-run, the first-Titan-Engagement row at 0.063 deaths | Not bound by the Medium band: the band reads the reference start, which makes no start-of-fight Fear Roll; the row is a sensitivity row, reported beside the target and not tuned | ADR-0014 (the batch 5 paragraph) | none | none |
| 5-15 | Full review round 2, Fable Critical 1 | No Nape strike is made during a retreat, on a turn or through Hook and Cut, so the promise holds on every Anchor Rating whatever chain a forced move takes | ADR-0010 (`## Amended`, batch 5b) | none | Ch5 5.6, 5.10, 5.12; `background-titans.yaml`; `attention.yaml`; `squad-tactics.yaml` |
| 5-16 | Full review round 2, Fable Major 1; Astra M1 | The interim day's care window covers every soldier in the Squad, and Field Repair is allowed in it, as on an Expedition day | none | none | Ch3 3.5, 3.6; Ch4 4.8, 4.9; `treat-injury.yaml`; `healing.yaml`; `field-repair.yaml` |
| 5-17 | Full review round 2, Astra M2 | No decision: the per-Background-Titan Size Class roll exists in `engagement-setup.yaml`; Chapter 5 step 3 renders it | none | none | Ch5 5.1 |
| 5-18 | Full review round 2, Fable Minors 2 to 4 (Minor 1 queued) | The Oskar example's next day; a left-behind soldier's items leave play; Ride joins the Dormant rolls list; 5-13's marker removal stands | none | none | Ch2 2.8; Ch3 3.17; Ch4 4.11; Ch5 5.10, 5.11; `carrying.yaml` |
| 5-19 | Simulator rerun with batches 5 and 5b | The Medium deaths band reads deaths through the end of the Titan Engagement (end steps, aftermath, end Death Rolls); on it the band is Missed (0.0573 at the reference start, 0.0546 and 0.0552 in the bar's orders) and is logged, not retuned | ADR-0014 (`## Amended`, batch 5c) | none | Ch5 5.13; Ch6 6.6; both tuning files (the reading named) |

### 5-1: the retreat's forced move and the action (Astra C2)

- **Decision:** Option 2. Under a retreat, on every turn of a soldier the retreat's `moves` bind, the forced move is made before the action; the one exception is retreat option 4, stay with a fallen comrade, whose move is legal only after the action taken for that comrade in the same turn, so there the action comes first. Section 5.3's "in either order" gains "except under a retreat (section 5.10)". A soldier at Blind Spot when a retreat starts therefore steps to In Reach before acting and cannot cut the Nape; the lone cut is closed, as ADR-0010's batch 3e paragraph and section 5.10 say.
- **Why:** The batch 3e amendment and the Feint note rest on the retreat closing the lone cut; section 5.3's free order let a soldier whose card came before the Titan's cut first and step away after, so the ADR and the turn procedure disagreed (a Critical under ADR-0003). Option 1 would keep a last cut the design rejected in OQ-87 and re-open the Feint's exposure argument. The ordering costs nothing else: a treat, a Pry Loose, a Body Part strike on the holding arm, and Break Attention for a fallen comrade all belong to option 4, which keeps action first, and carrying a comrade out (option 1 with Lift Comrade) already lifts before the move. No figure moves: the retreat's ordering is not what 5-10 measures (its retreat policy moves first on every turn).
- **ADR change:** ADR-0010 `## Amended` (batch 5). Applied.
- **Glossary change:** none.
- **Chapter impact:** Chapter 5 section 5.3 (*Order of play*: "in either order, except under a retreat, where the forced move comes first (section 5.10)"), section 5.6's Feint note (cite the ordering), section 5.10 *The retreat* (the effects list gains "Order: the forced move comes before the action, except a stay-with-a-comrade move, which follows the action taken for that comrade"; *Actions are unaffected* reads "Actions are not limited by the retreat, only ordered after the forced move"); `data/engagement/round.yaml` `turn_order.order` ("except under a retreat, data/engagement/background-titans.yaml, retreat, order"); `data/engagement/background-titans.yaml` `retreat.effects` gains `- id: order` with that text and `actions` reads accordingly.
- **Revised by batch 5b:** The claim that the ordering closes the lone cut because a soldier at Blind Spot "steps to In Reach before acting" holds at Open, Sparse, and Wooded only; at Giant Forest and Urban a shortest chain from On Body may pass through Blind Spot, and a step toward a Down comrade at Blind Spot or a Hook and Cut before the striker's card gives the same cut on every rating. 5-15 closes all three: no Nape strike is made during a retreat. The ordering stands.

### 5-2: a day between sessions (Fable Major 1)

- **Decision:** An interim day, beside Chapter 4's interim issue: until the Expedition and Downtime rules are written, one day passes at the start of each session, before the interim issue, and if a session begins partway through a procedure, once that procedure has ended, as the interim issue does. The `each_day` steps run as written (a day care window, day-limit Death Rolls, every living soldier gets back all Health lost to damage, every held Critical Injury's healing time drops by 1 day and one at 0 heals). Stress and Grief do not change: no Phase 1 rule lowers them outside a Titan Engagement, and the Downtime rules will. OQ-116's provisional cadence becomes the written one: a Phase 1 session is a chain of Titan Engagements with their care windows, opened by the interim day and issue; the simulator's sequence re-runs under it.
- **Why:** Without a day nothing heals, Down from damage never ends without a revive, and a `day` Death Roll never comes, so the second session of a playtest asks the GM to invent a day (ADR-0003). One day per session is the smallest rule that runs every day-keyed step, keeps the Health boxes decision's routes (a day erases damage marks and keeps crossed-off boxes), and mirrors the interim issue's timing, so the two stopgaps are one line in the packet. Fable's option 2 (1 to 3 days at the players' choice) is a choice with no rule behind it; option 3 leaves the gap. Figures: none move; the sequence rows are reports (OQ-116), and no ADR-0014 target reads them.
- **ADR change:** none. ADR-0009's night camps stand for Expeditions; the interim day is Chapter 3's stopgap and says so.
- **Glossary change:** none.
- **Chapter impact:** `data/harm/healing.yaml` `day_passes` gains `interim: >- Until the Expedition and Downtime rules are written, one day passes at the start of each session, before the interim issue (data/gear/standard-issue.yaml, interim_issue); each_day runs as written, and Stress and Grief do not change. The Expedition and Downtime rules replace this row.`; `data/gear/standard-issue.yaml` `interim_issue.when` adds "after the interim day (data/harm/healing.yaml, day_passes, interim)"; Chapter 3 introduction (the unwritten-rules list), section 3.1 *Getting Health back* and section 3.6 (the interim day, cited as decision batch 5, OQ-120); Chapter 4 section 4.9 (the interim issue follows the interim day); Chapter 5 introduction or section 5.1 (a Phase 1 session is a chain of Titan Engagements with their care windows; when one begins is scene framing, not a rule); `tools/sim/cases.py` `SEQUENCE` and `families.py` (one day between sessions), OQ-116.
- **Revised by batch 5b:** "`each_day` runs as written" left the `day` care window's scope and Field Repair undefined on the interim day, which is neither an Expedition day nor a Downtime day; 5-16 gives it the Expedition day's reading: every soldier in the Squad, and Field Repair allowed.

### 5-3: Ride and Horsemanship (Fable Major 2; Astra M4)

- **Decision:** `ride` is marked dormant, called by the Chase rules (not yet written); the two claims that a Chapter 4 or Chapter 5 rule calls it (the Catalog row and Chapter 2 section 2.8) are corrected. Horsemanship names `ride` and the dodge made while mounted with the horse's Gear Dice (`names: [ride, dodge]`, with the condition in its description), so it is a live Talent; the Rider template, Minor Noble House, *Stable duty*, and *The signal relay* stand as they are, and the Mira example stands. Sure Seat is unchanged.
- **Why:** The dodge from the saddle is the horsemanship 845 to 850 shows (riders swerving from a Titan's reach), it is the roll a mounted soldier makes most, and it needs no new procedure, so it is the smallest live call. Adding a Ride roll to a mounted step (Fable's option 2) would change the mounted screen rows of Chapters 5 and 6 and every mounted start, and the Rider still rides nowhere in Phase 1 but a Titan Engagement. Marking Horsemanship dormant (option 3) leaves the Rider template dead and repairs three Lifepath rows for nothing. Figures: none move; no reference build holds Horsemanship, ADR-0014 gives no Talent dice on the dodge or Ride to a measured build, and the Flier template's dodge Talent still applies to its mounted dodges.
- **ADR change:** none. ADR-0014's "no Talent dice on the dodge, Fly, Break Attention, Ride, and Read" stands for the reference builds.
- **Glossary change:** none.
- **Chapter impact:** `data/character/action-catalog.yaml` `ride` (`dormant: true`; `requirements: Called by the Chase rules (not yet written)`; its `rules` list points at the Chase rules, not Chapters 4 and 5); `data/character/talents.yaml` `horsemanship` (`names: [ride, dodge]`, description "adds its dice to Ride and to the dodge a mounted soldier makes with the horse's Gear Dice"); `data/gear/horses.yaml` `gear_dice.dodge` (cite Horsemanship); Chapter 2 sections 2.7 (Horsemanship's line), 2.8 (the roll entries list: "Fly (ODM Gear): an Agility roll a Chapter 4 or Chapter 5 rule calls for; Ride (horse): dormant until the Chase rules"), 2.10 (the Rider template's Talent is live), the dormant count (one more), and the Mira example's sentence; Chapter 4 section 4.5 (the mounted dodge names Horsemanship); Chapter 5 section 5.5 *Dodging a Titan* where the dodge's Talent is named.

### 5-4: Positions after the last Focus Titan dies (Astra M1)

- **Decision:** When a Focus Titan dies, every soldier's Position relative to it at that moment is recorded as their last Position relative to it, and if no Focus Titan is left, those last Positions are the ones the engagement-end steps read ("held when the Titan Engagement ended": the aftermath rolls' who rolls, and soldiers who left). Chapter 4 clears the Position records after the last engagement-end step, not at the Titan's death. The dead Titan acts no more; nothing else in `a_focus_titan_dies` changes.
- **Why:** The aftermath roll's distance test is decided (OQ-57) and needs a record the death step erased first; keeping the last Positions until the end steps have run is the smallest fix and states one order. No figure moves: the simulator's engagement-end steps read the Positions at the kill already.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** `data/engagement/positions.yaml` `a_focus_titan_dies` ("stops holding a Position relative to it; the Position held at that moment is recorded as their last Position relative to it, and when no Focus Titan is left the engagement-end steps read those last Positions; Chapter 4 clears the records after the last engagement-end step"); `data/harm/treat-injury.yaml` `aftermath_rolls.who_rolls` ("held, at the moment the Titan Engagement ended, the patient's last Position or one step from it, relative to the Focus Titan alive last"); `data/harm/engagement-end.yaml` (a note that Positions are read as last held); Chapter 5 sections 5.7 *A Titan's death* and 5.11 *Ending*; Chapter 3 section 3.5.

### 5-5: a fall's reference Titan (Astra M2)

- **Decision:** Every fall in a Titan Engagement is read relative to one Focus Titan: the one the soldier holds the closest Position to, in the order On Body, Blind Spot, In Reach, Distant; on a tie at the same Position, the Titan whose card, Grab, or effect caused the fall, and otherwise the living Focus Titan with the earliest label. Its band, its Large-class raise, and its landing (`falls_land`) all use that Titan; Positions relative to any other Titan do not change. A fall from a horse stays low whatever the Titans.
- **Why:** A soldier's height is where they are hanging: a soldier On Body relative to Large A is on that Titan whatever they hold relative to B, so the closest Position gives the band, and the Titan that struck them breaks a tie. The close rule already forbids On Body or Blind Spot relative to both, so the tie can only be at In Reach or Distant, where the band is low either way and only the landing needs the choice. No figure moves: two-Titan fights are not modeled (OQ-115).
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** `data/gear/falls.yaml` `height.steps` (a first step naming the reference Titan) and `data/engagement/positions.yaml` `falls_land` (the same Titan; "other Titans" stands); Chapter 4 section 4.6 *Height* and *After the fall*; Chapter 5 section 5.2 *Two Focus Titans* and *Where a fall lands*.

### 5-6: the Grab's hold before its crush (Astra M3)

- **Decision:** `grab_lands.steps` run failed-dodge, hold, crush, attention, witnesses. At the hold step the target becomes Grabbed: they are no longer airborne, a mounted target is dismounted without a fall (`horses.yaml`, forced dismount, grabbed), and a comrade they carry falls (`falls.yaml`, triggers, carried). The crush then lands on a soldier already in the Titan's hand, so a target it makes Down is Down in the hand and does not fall; the crush stays the Grab's one Titan attack.
- **Why:** The text already said the target is Down "in the Titan's hand"; the step order said otherwise, and read literally it added a high fall to one landed Grab in six from On Body (Astra's 16.7%). The probes and the simulator resolve the hold first and never fall from the crush, so the decided order is the measured one and the Grab targets do not move (alone 69.9%, one comrade 33.2%).
- **ADR change:** none. ADR-0015's "the Grab's harm is its crushing Critical Injury" stands.
- **Glossary change:** none.
- **Chapter impact:** `data/engagement/grab.yaml` `grab_lands.steps` (reordered; the hold's text names the airborne, mounted, and carrying consequences; the crush's text "on a soldier already Grabbed, so becoming Down here causes no fall"); `data/gear/falls.yaml` `triggers` (`down-airborne` and `down-mounted` note that a Grab's hold has already ended those states); Chapter 5 section 5.9 *When a Grab lands*; Chapter 4 sections 4.2 and 4.6 where they cite the order.

### 5-7: three wording findings (Fable Minors 2 and 3; Astra m1)

- **Decision:**
  - **Intent.** Chapter 5 section 5.4's `telegraph` bullet reads "because what the Titan will do next shows either way", and Chapter 6 section 6.1's *Terrorize* bullet "What it will do next shows in its body". Intent stays the Shifter term.
  - **Distant.** `positions.yaml` `distant.meaning` and Chapter 5 section 5.2 read "Out of a standing Titan's reach. A Behavior Table entry may still name Distant in its Position requirement, as a running Abnormal's does (Chapter 6)". The glossary's Position entry lists the four Positions without meanings and is unchanged.
  - **The Small Titan note.** Chapter 6 section 6.2's design note reads "each success advances a part one state, so two successes break an Intact part (Toughness 1)"; the value is unchanged.
- **Why:** Each is a wording gap the reviews located exactly; no rule or figure changes.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Chapter 5 sections 5.2 and 5.4; Chapter 6 sections 6.1 and 6.2 (and 6.5 *It runs through people*, which may now cite section 5.2's sentence); `data/engagement/positions.yaml`.

### 5-8: OQ-113, Draw Attention from Distant

- **Decision:** Option (b): Draw Attention requires a Position other than Distant relative to the named Focus Titan (`attention.yaml` `draw_attention.requirements`; the Catalog's `draw-attention` row points there). The closed `tests` list, the ladders, and the bar's limits are unchanged; the loud-rider and loud-Squadmate rows are no longer legal policies and leave section 6.6 and the bar; the loud cutter row stays. OQ-114's items that waited on this entry are moot.
- **Why:** Both final reviews name OQ-113 as the one remaining balance problem with the Abnormal and add nothing to it. Under (b) the flag can never be set from Distant, so its figures are the review's option (a) figures (`fixloud_r3.py`, 60,000 fights): the loud-Squadmate row becomes the silent riders row (70.1% by round 3, 7.6% with no kill, 0.86 Critical Injuries, 0.065 deaths, against 0.53 and 0.0195 with the stance), the loud cutter row does not move (69.1%, 1.03, 0.088), and the standard Medium Titan's rows do not move (loudest is its fourth rung). (b) changes one action's requirement instead of the loudest test on every ladder (a), needs no new bar reading for a loud rider (a's cost), and does not accept a failed floor (c). Canon: a shout from beyond a Titan's reach is not what turns it; a flare from there is Break Attention, which stays. No bar row or ADR-0014 target holds Draw Attention from Distant, so no target moves; the drafter re-runs section 6.6's Draw Attention rows for the record.
- **ADR change:** ADR-0010 `## Amended` (with 5-1). Applied.
- **Glossary change:** none.
- **Chapter impact:** `data/engagement/attention.yaml` `draw_attention.requirements` (adds "The soldier holds a Position other than Distant relative to that Titan (decision batch 5, OQ-113)"); `data/character/action-catalog.yaml` `draw-attention` (`requirements` pointer stands; its notes may say "not from Distant"); Chapter 5 section 5.6 *Draw Attention*; Chapter 6 section 6.5 (*Riders* bullet: riders at Distant draw it only as the nearest, since Draw Attention needs a closer Position; the design note) and section 6.6 (drop the loud-rider and loud-Squadmate rows and the *A loud rider* bullet, keep the loud cutter row, restore the *Riders* sentence); `data/titans/tuning.yaml` `abnormals.rule` and `simulator_cases` (drop the Distant Draw Attention case); `data/titans/index.yaml` `reads_as` if it mentions noise from Distant; `tools/sim/policy.py` (the loud-rider policy).

### 5-9: OQ-112, four strikers

- **Decision:** Kept open. Both final reviews saw it and added nothing (Fable: the rules never break and the target is met under its stated policy; Astra excludes it as logged). No fix fits without a change that cannot be measured to hold: option (b), at most two soldiers at Blind Spot, changes every screen and decoy that flies there; option (e) redraws every table. The entry gains a sentence saying the final review saw it.
- **Why:** As 4b-2.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** OQ-112 only.

### 5-10: how a Titan Engagement that goes long ends (simulator review 2, Critical 1)

- **Decision:** Every Titan Engagement carries a **retreat clock**. Its length is named by the rule that begins the Titan Engagement, or by the interim setup table, which gives 8 segments to every Titan Engagement it sets up (`engagement-setup.yaml`, a fixed row, no roll). The clock is recorded on the tracker's Engagement line ("Retreat 3/8"). It fills 1 segment at the background-clocks end step of each round, after the Background Titans' clocks and resolved after them; flares do not fill it (they fill the Background clocks, which already carry a flare's cost); no clock fills during a retreat. When it is full the Titan Engagement becomes a retreat (`background-titans.yaml`, `retreat.starts` gains "or when the retreat clock is full"), under the retreat's own rules as written and as ordered in 5-1: every standing soldier's move is forced toward Distant and out, or toward a fallen comrade; a soldier who lifts a Down comrade carries them out; Grabbed comrades are pried, struck free, or lost; no soldier returns; and when no standing soldier holds a Position the ending's no-returner test ends the Titan Engagement at once, and every soldier still holding a Position dies, left to the Titans (`engagement-flow.yaml`, `left_behind`, unchanged). A Titan Engagement therefore always ends: by a kill, by no soldier standing, or by the retreat the clock forces. The simulator's 12-round horizon is not a rule and goes: fights run to their end under the rules, a far safety cap is a model check, and the column "no kill within 12 rounds" becomes "no kill", the share of fights that end with the Focus Titan alive (by retreat or by no soldier standing). Chapter 6's Large band reads "no kill in at most 15% of fights" and the Abnormal's winnable limit "no kill at most the standard Large Titan's twin"; the Medium, Small, and Abnormal bands are otherwise unchanged in wording. The Squad may still leave earlier by choice (section 5.11); the clock is the rule that ends a fight nobody ends.
- **Why:** The review is right that no rule ended a Titan Engagement that neither killed the Titan nor lost every soldier, so the simulator's horizon was a model choice and its two readings gave different verdicts (deaths 0.039 or at least 0.101 against the Medium band's 0.05). The retreat already exists with full mechanics (OQ-87, OQ-99) and was reachable only when a Background Titan's clock filled with two Focus Titans alive; a clock on the Engagement itself is the smallest rule that reaches it in every fight, and it is the canon of 845 to 850: Titans converge on a fight that lasts, and Scouts who linger are lost. Eight segments because a full canister lasts a median of 8 rounds of ODM use (ADR-0014), so the retreat begins as the gas runs low; because every interim Background clock (4, 6, and 4 with 8) has filled by then, so a Background Titan enters before the retreat or with it and the retreat's two-Focus-Titan trigger keeps its meaning for Mission Briefs with longer clocks; and because it is the length that leaves the fewest dead. Measured (`retreat_b5_explore.out`, the standard Medium Titan at its reference start, 30,000 fights a row, the committed simulator with the retreat clock on top of it): under the horizon reading 0.0333 deaths and 5.1% with no kill in 12 rounds; under retreat clocks of 6, 8, 9, 10, and 12: 0.0518, 0.0493, 0.0542, 0.0548, and 0.0680 deaths, with 12.4%, 8.2%, 6.6%, 6.0%, and 4.8% of fights ending in a retreat. A later clock kills more, not fewer, because the Titan piles up Down soldiers in the rounds before the Squad must carry them, and 8 is the minimum. The retreat policy measured lifts and carries every Down comrade it can reach and pries or strikes for a Grabbed one, without Treat Injury during the retreat, so the deaths are an upper reading. Every target holds under the rule (`retreat_b5_bar.out`, 120,000 fights a row, the cutters first and the strikers first): the standard Medium Titan's reference row gives a median kill round of 3, 61.7% and 61.8% by round 3, 0.698 and 0.694 Critical Injuries, 0.217 and 0.218 Grabs, and 0.0499 and 0.0482 deaths, inside the band's 0.05 by less than one standard error (0.0009), which is the band's edge and is recorded as such: the committed simulator run judges it under 5-11's second-seed rule, and a miss there is a decision on a lever, not on the clock. The standard Large Titan's reference row gives a median of 3 and 14.4% and 14.6% with no kill (the band's 15%; 13.5% under the horizon reading, which counted the fights alive at round 12 as no kill anyway); the standard Small Titan a median of 2 and 0.85 Critical Injuries. The Sprinting Abnormal's bar holds every limit in every row and both orders, by wider margins than before (the helpers ceiling 0.0341 against the Large twin's 0.0468 and 0.0326 against 0.0470, −10.5 and −11.8 standard errors; the reference row 0.105 deaths against the Medium reference's 0.050 and the Large twin's 0.178; 8.5% with no kill against the Large twin's 14.4%), because the retreat leaves the Large Titan's Down soldiers behind more often than the Abnormal's. The prepared-Squad kill (median round 3) and every kill-by-round-3 figure move within sampling. The gas, lone, and Grab targets do not read the clock.
- **ADR change:** ADR-0014 `## Amended` (batch 5): the horizon is replaced by the retreat clock, "no kill within 12 rounds" reads "no kill", the Medium deaths band's edge is recorded. Applied. ADR-0003 is unchanged (the clock is a data row); ADR-0010 is unchanged (the retreat's promise stands, 3e-2 and 5-1).
- **Glossary change:** new entry **Retreat clock** in `CONTEXT.md`, after Background Titan. Applied.
- **Chapter impact:** `data/engagement/engagement-setup.yaml` (a `retreat_clock: 8` row, "every Titan Engagement this table sets up", and the `steps` naming it); `data/engagement/engagement-flow.yaml` `starting.setup` (the rule that begins the Titan Engagement names the retreat clock's length, or the setup gives it) and `ending` (a sentence that the retreat clock's retreat ends every fight that is not ended by a kill or by no soldier standing); `data/engagement/background-titans.yaml` (`retreat.starts` gains the clock; `ticks` gains the retreat clock at the end of round and not by flares; `stopped` covers it); `data/engagement/round.yaml` `end_steps.background-clocks` (fill the retreat clock after the Background clocks) and `gm_tracker.engagement_line` (the retreat clock's filled segments); Chapter 5 section 5.1 (the setup table's retreat clock), 5.3 *End steps* and *What the GM tracks*, 5.10 *Clocks* and *The retreat* (the clock as a second way a retreat starts), 5.11 *Ending* (a Titan Engagement always ends; the three ways), 5.13 (the tables' "no kill within 12 rounds" column reads "no kill", and the rows are re-run under the clock); Chapter 6 section 6.6 (the same column; the Large band's wording; the bar's winnable limit); `data/engagement/tuning.yaml` `prepared_squad_kill.columns` and `model` (the retreat clock replaces "no Background Titans" as the fight's end; `no_kill` replaces `no_kill_in_12_rounds`) and `data/titans/tuning.yaml` `targets.large`, `abnormals.winnable`, and the columns; `tools/probes/chapter-05/fight.py`, `tools/probes/chapter-06/fight6.py`, and `tools/sim/` (the retreat clock and the retreat, in the simulator's own round; the horizon becomes a safety cap that no fight may reach); the committed rows in both tuning files and `probe-figures.yaml` are re-run under the clock and re-rendered, and until then stand as measured under the horizon reading with this entry's figures beside them. OQ-103, OQ-115 (the retreat is now measured on one Focus Titan), and OQ-87 (a retreat rate per Titan Engagement is now a figure: 8.2% at Medium, 13.8% at Large) carry `Revised by batch 5` lines.
- **Revised by batch 5 (5-19):** "the Medium deaths band holds at its edge" was the during-the-fight reading; the band reads deaths through the end of the Titan Engagement, on which the committed rerun gives 0.0573 at the reference start and 0.0546 and 0.0552 in the bar's orders, a miss logged as OQ-132 and not retuned now. The clock's length stands: it is the length that leaves the fewest dead.

### 5-11: tolerances for the "about" targets (simulator review 2, Major 3; Codex Major 2)

- **Decision:** ADR-0014 gains one reading for every target, so that the report can judge each Met or Missed. A target stated as "about" a proportion reads five percentage points either side of it: the Levi-grade soldier's "about 50%" is 45% to 55%; a Grab's "about 2 in 3" alone is 61.7% to 71.7%; the Stress 2, Grief 0 cell's "near 1 in 3" is 28.3% to 38.3%, beside OQ-50's "every cell under 50%", which is exact. A target stated as a range or a limit ("between 8% and 14%", "at most 0.05", "55% to 70%", "at most 15%") is its own band, exact. A target stated as "about" a count of rounds or a count per fight reads as the median equal to the stated whole number ("about 3 rounds": the median kill round is 3; the gas target's medians 8 and 6, as batch 3b wrote them), and a target stated as a rate ("a PC dies every 3 to 4 missions") reads on the mean within the stated range (0.25 to 0.33 PC deaths a mission), since a median of deaths per mission is 0. A figure is judged on the committed seed; one past a band's edge by at most 2 standard errors is re-run on a second seed in the same way and judged on the figure pooled over both, as the Abnormal's bar is (4b-4); past that it is Missed. The verdicts today: the Levi-grade cut 47.2% and 47.4%, Met; the lone Grab 69.9%, Met; the Stress 2, Grief 0 cell 33.2%, Met, with every cell under 50%; the prepared-Squad median 3, Met; the gas medians 8 and 6, Met. The tuning files carry each band as data beside its target (`tolerance`), and the report renders Met or Missed against it, never "Reported" for a target.
- **Why:** Round 1's Minor 8 was right that the simulator must not invent a band, and round 2 is right that a target with no band cannot be missed, so the band is a decision. Five points is the width the lone-Rookie band's upper side already uses (about 10%, up to 14%), it is wider than the sampling error at the committed fight counts (a standard error under half a point at 30,000 fights), so a seed cannot decide a verdict, and it is narrower than what any tuning lever moves (Nape Depth, Toughness, Severity, Tempo, and a die are whole steps that move the Levi-grade cut and the lone Grab by more than five points, as batch 3's sweep showed), so a target inside it cannot be tuned closer with the levers the ADR names. A median target is exact because a median is a whole number and "about 3" has no other reading (batch 3b). The second-seed rule is the bar's rule (4b-4) applied to every target, so one reading judges every figure.
- **ADR change:** ADR-0014 `## Amended` (batch 5). Applied.
- **Glossary change:** none.
- **Chapter impact:** `data/engagement/tuning.yaml` (`solo_nape` gains `tolerance: {levi_grade: "45% to 55%"}`, `grab` gains `tolerance: {alone: "61.7% to 71.7%", stress_2_grief_0: "28.3% to 38.3%", every_cell: "under 50%"}`, `prepared_squad_kill` and `gas` state their medians as exact, and each `verdict` cites the band); `data/titans/tuning.yaml` `adr_0014_targets_quoted` (the bands beside the quotes); Chapter 5 section 5.13 (the bands in the target paragraphs); Chapter 6 section 6.6 (the bands where the quotes appear); `tools/sim/report.py` and `rules.py` (read the bands; render Met or Missed; the second-seed rule for targets, in the simulator's own round).

### 5-12: Pry Loose's own row (simulator review 2, Minor 9)

- **Decision:** Confirmed complete. `data/engagement/grab.yaml` `escapes` `pry-loose` carries its own `who` (a comrade with Pry Loose at On Body relative to the holding Titan, not Grabbed), `roll` (break-free on the Grabbed soldier's behalf with the comrade's own pool), `needs: 2`, `lifted_penalty: 2`, and `on_success` (release). Help on it follows Chapter 1, section 1.8, as on any roll; Break Free's row states that only because its helpers compare Positions relative to the holding Titan, which Pry Loose's `who` already fixes. No rule changes; the engine reads Pry Loose's own row (the review's fix option 1, the simulator's round).
- **Why:** The values are equal today, and the row is the source of truth under ADR-0012; the finding is a code path, not a rule gap.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** none in the chapters; `tools/sim/rules.py` and `engine.py` read `pry-loose`'s `needs` and `lifted_penalty`.

### 5-13: a Lift Comrade action under the retreat's order (the batch 5 apply)

- **Decision:** Decided as the drafter wrote it, and the `PROVISIONAL` marker goes. On a turn the retreat's forced moves bind, the move comes before the action with two exceptions: a stay-with-a-comrade move (option 4) comes after the action taken for that comrade, and a move on a turn whose action is Lift Comrade comes after the lift, so a soldier who shares a Down comrade's Position lifts them and carries them out by option 1 or 2 in the same turn. `round.yaml` `turn_order` still says "except under a retreat"; the retreat's `order` row names both exceptions.
- **Why:** 5-1's reasoning already said that carrying a comrade out lifts before the move; without the exception a soldier at a Down comrade's Position would have to step away before lifting, and one at Distant would have to leave them, which is the abandonment OQ-87's design note says a retreat never forces. The exception cannot reopen the lone cut: Lift Comrade is not a strike, and a soldier carrying a Rookie is Overloaded, so an ODM move also spends the action. No figure moves: the retreat policy 5-10 measured lifts and moves in the same turn (`retreat_b5.py`, `retreat_turn`), as the simulator's re-run does (`tuning.yaml`, `retreat`).
- **ADR change:** ADR-0010, a sentence added to the batch 5 paragraph. Applied.
- **Glossary change:** none.
- **Chapter impact:** Chapter 5 section 5.10 *The retreat*, the *Order* bullet: drop `PROVISIONAL:` and cite "decision batch 5, 5-13"; `data/engagement/background-titans.yaml` `retreat.effects.order` (the comment reads decided, 5-13); `data/engagement/tuning.yaml` `prepared_squad_kill.model.retreat` ("the PROVISIONAL order" reads "the order of 5-1 and 5-13"). OQ-119 carries the ruling.

### 5-14: the first-Titan-Engagement row against the Medium deaths band (the batch 5 re-run)

- **Decision:** The row is not bound by the band. Chapter 6's Medium band (`data/titans/tuning.yaml`, `targets.medium.at_the_reference_start`) reads the reference start, which is the baseline of `prepared_squad_kill`: four Rookies at Stress 1 who hold a Position with no start-of-fight Fear Roll, the fight the probes measure and the bar's twin. The first-Titan-Engagement row adds the `first-titan-engagement` Fear Roll (`data/mind/fear-rolls.yaml`), a trigger each soldier meets once in a career, and is one of the sensitivity rows ADR-0014 reports beside each target and does not tune (as the mounted start, the template Squad, and the helpers are). Its figures stand in the record as a report: median kill round 3, 57.0% by round 3, 0.75 Critical Injuries, 0.063 deaths, 0.230 Grabs under the retreat clock (the simulator's earlier run without the clock: 0.041 in the fight, 0.051 through the end steps). No fix, and no Unresolved Major.
- **Why:** The band is a promise about the standard fight, and a Squad's first fight is not the standard fight by the rules' own design: the Fear Roll exists to make the first Titan Engagement worse (Trost, 845), and 1 first fight in 16 killing a Rookie is the canon rate, not a tuning miss. Binding the row would tune the Fear Roll's cost out of the one fight it is written for. The place a career's deaths are tuned is the Expedition target (a PC dies every 3 to 4 missions), which a first fight feeds once; the first-fight row is reported beside it so that the Expedition rules can read it.
- **ADR change:** ADR-0014, a sentence added to the batch 5 paragraph. Applied.
- **Glossary change:** none.
- **Chapter impact:** none; `data/titans/tuning.yaml`'s verdict sentence ("its deaths pass the Medium band's limit, and it is reported, not tuned") stands and may cite 5-14.

### 5-15: no Nape strike during a retreat (full review round 2, Fable Critical 1)

- **Decision:** Fix option 2. During a retreat no soldier makes a Nape strike: not on their own turn, and not through Hook and Cut, whose cut is a Nape strike (the Break Attention that would have allowed it still resolves, and the Squad Tactic is not spent unless its cut is made). `background-titans.yaml` `retreat.effects.actions` reads "Actions are not limited by the retreat, only ordered after the forced move, except that no Nape strike is made during a retreat". The forced move's option 1 stays as written: at Giant Forest and Urban a shortest chain from On Body may pass through Blind Spot, and it no longer matters, since nothing can be cut from there. Every other action stands: Body Part strikes (an arm that holds a comrade, a leg that grounds a pursuing Titan), Break Attention, Pry Loose, Treat Injury, Lift Comrade.
- **Why:** The ADR's promise was stated as a property of the step rows ("steps to In Reach before acting"), and the step rows do not give it on two of the five ratings, which the interim setup deals one fight in three; a Down comrade at Blind Spot beside a grounded Titan gives option 3 the same path on every rating, and a decoy's Hook and Cut on a card before the striker's gives a third. Option 1 closes only the first path and adds a geometry clause to a move rule players already find the longest in the chapter; option 3 leaves the exploit on the ratings the simulator does not run. One sentence on the action closes all three paths on every rating, and it is what the design decided in OQ-87 and 3e-2: a retreat is the fight the Squad has stopped trying to win. The cost the review names, a cut beside a Grabbed comrade, does not exist under the move-first order: a Grabbed comrade is in the hand at On Body, no forced move toward them ends at Blind Spot, and a soldier already at Blind Spot must move before acting; the `titan-dies` escape stays open outside a retreat and by an arm strike or Pry Loose in one. No figure moves: the simulator's retreat policy (`tuning.yaml`, `prepared_squad_kill.model.retreat`) makes no Nape strike in a retreat, so every batch 5 row already measures the rule; the batch 5 probe's policy allowed one only for a striker at Blind Spot with two free Openings while a Grab was held at the retreat's start, an event under one fight in a hundred, and the probe could not be re-run for this entry because the simulator engine it imports is mid-rerun (`R.horizon_reading`); the drafter's re-run is the measurement.
- **ADR change:** ADR-0010 `## Amended` (batch 5b): the batch 5 sentence "a soldier at Blind Spot when the retreat starts steps to In Reach before acting, and no card order gives a last cut" is superseded by "no Nape strike is made during a retreat, so the promise holds on every Anchor Rating whatever chain a forced move takes". Applied.
- **Glossary change:** none.
- **Chapter impact:** Chapter 5 section 5.10 *The retreat* (*Actions are not limited* gains the sentence; the OQ-87 design note's "no option lets them stay" reads "and no Nape strike is made in a retreat"); section 5.6's Feint design note ("A retreat's forced moves close the lone cut by design" reads "A retreat closes the lone cut by design: no Nape strike is made in one"); section 5.12 Hook and Cut (not in a retreat); `data/engagement/background-titans.yaml` `retreat.effects.actions`; `data/engagement/attention.yaml` `break_attention` Feint row ("every move in it is forced toward Distant" reads "no Nape strike is made in it"); `data/engagement/squad-tactics.yaml` `hook-and-cut.condition` ("and no retreat is under way"). OQ-119 and OQ-87 carry `Revised by batch 5b` lines; new entry OQ-129.

### 5-16: the interim day's care window and Field Repair (Fable Major 1; Astra M1)

- **Decision:** Fix option 1. The interim day's care window (`each_day`, the `day` window) has the scope "every soldier in the Squad", written as a third branch of `treat-injury.yaml` `care_windows.day.scope` and Chapter 3 section 3.5 beside the Expedition day and the Downtime day. Field Repair is allowed in it: `field-repair.yaml` `outside_titan_engagement.when` and Chapter 4 section 4.8 read "or on the interim day (Chapter 3, section 3.6)" in the allowed list, with the Downtime prohibition unchanged. The interim day's row in `healing.yaml` cites both.
- **Why:** The interim day stands in for the night camps of ADR-0009, which are Expedition days, so it takes the Expedition day's reading on both counts: every soldier in the Squad is at the camp, and a soldier repairs their harness there. Forbidding Field Repair (option 2) would carry a Jammed harness rated at the Funding row into the next session's first fight, since the interim issue replaces only gear rated below the row, and would make the interim day the one day on which nobody touches their gear. No figure moves: the sequence rows are reports (OQ-116), and the simulator's interim day runs the care window over the whole Squad already.
- **ADR change:** none. ADR-0009 stands; the interim day is Chapter 3's stopgap.
- **Glossary change:** none.
- **Chapter impact:** `data/harm/treat-injury.yaml` `care_windows.day.scope` (a third branch: "For the interim day (data/harm/healing.yaml, day_passes, interim), every soldier in the Squad"); Chapter 3 section 3.5 *Care windows* (the same sentence) and section 3.6 (the interim day names its scope and its Field Repair); `data/harm/healing.yaml` `day_passes.interim` (cites the scope and Field Repair rows); `data/gear/field-repair.yaml` `outside_titan_engagement.when` and Chapter 4 section 4.8 ("or on the interim day"); Chapter 4 section 4.9 (the interim issue follows the interim day and its repairs). OQ-120 carries a `Revised by batch 5b` line; new entry OQ-130.

### 5-17: the Background Titans' Size Class rolls (Astra M2)

- **Decision:** No rule decision. The rule exists and is complete: `data/engagement/engagement-setup.yaml` `steps`, `background-titans` ("For each Background Titan it gives, roll D6 on size_class for its Size Class, in the order the row lists the clocks. Each is the standard Titan of its Size Class; medium_abnormal is never rolled for it"). Chapter 5 section 5.1's numbered step 3 renders the count and clock roll and drops the per-Titan Size Class roll, so it is a render omission for the drafter: step 3 states the Size Class roll for each Background Titan in clock order and that the Abnormal roll is never made for one, and the Size Class table is retitled to serve both the Focus Titan and the Background Titans.
- **Why:** ADR-0012 makes the YAML the source; the chapter must carry the procedure a reader at the table needs (Astra's review, "that procedure must reach the packet reader"). No figure moves: the setup mix and the retreat rows already roll Background sizes from the YAML.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Chapter 5 section 5.1 *The interim setup table*, step 3 and the Size Class table's title and last column ("Standard Titan"); section 5.10 *Background Titans* may point at step 3. No YAML change.

### 5-18: Minors of the round 2 reviews (Fable Minors 2 to 4; Fable Minor 1 queued)

- **Decision:**
  - **Minor 2, the Oskar example.** Chapter 3 section 3.17's "Later" bullet reads "When the next day passes (at a night camp once the Expedition rules exist, and until then at the start of the next session, section 3.6) there is a care window before his next Death Roll."
  - **Minor 3, a left-behind soldier's items.** Fix option 1: the left items of a soldier who dies as left behind (`engagement-flow.yaml`, `left_behind`) leave play with the field; they are not shared out. `carrying.yaml` `leaving_play.death.shared_out` gains the sentence, Chapter 4 section 4.11 and Chapter 5 section 5.11 state it. Items a soldier dropped or passed before the ending are unchanged.
  - **Minor 4, the Dormant rolls list.** Chapter 2 section 2.8 lists `ride` under *Dormant rolls* with "(decision batch 5, OQ-121)" and drops it from the live list; section 2.3.3's "Eight" stands.
  - **Minor 1.** 5-13's chapter impact stands and is the drafter's: Chapter 5 section 5.10's *Order* bullet, `background-titans.yaml` `order`, and `tuning.yaml` `retreat` drop the `PROVISIONAL` marker and cite 5-13.
- **Why:** Each is a wording or fiction gap the reviews located exactly. Minor 3's rule follows the fiction the retreat is built on, a field abandoned to the Titans, and removes the one way leaving a comrade behind pays. No figure moves: the probes and the simulator do not share out items.
- **ADR change:** none.
- **Glossary change:** none.
- **Chapter impact:** Chapter 2 section 2.8; Chapter 3 section 3.17; Chapter 4 section 4.11; Chapter 5 sections 5.10 and 5.11; `data/gear/carrying.yaml` `leaving_play.death.shared_out`. New entry OQ-131.

### 5-19: which reading binds the Medium deaths band (the simulator rerun with batches 5 and 5b)

- **Decision:** The band "deaths per fight at most 0.05" (Chapter 6's Medium band, `data/titans/tuning.yaml` `targets.medium.at_the_reference_start`) reads deaths through the end of the Titan Engagement: every death the Titan Engagement causes, the fight's own and those of its end steps (`data/harm/engagement-end.yaml`: turn limits, aftermath rolls, end Death Rolls). Deaths during the fight are reported beside it, never judged. The same reading holds for every deaths figure a band or a bar limit names, the Abnormal's ceiling and floor included, which hold on it in both orders. On this reading the Medium band is Missed under 5-11: the reference start gives 0.0573 (standard error 0.0030, 2.4 past the limit, so the second-seed rule does not reach it), and the bar's two runs of the same row 0.0546 and 0.0552 (standard error 0.0009, past by more than 5); during the fight the same rows give 0.050, 0.0485, and 0.0493, the reading the chapter probes quoted (0.0487 and 0.0501, pooled 0.0494), which is the band's edge, not a pass. Nothing is retuned now: the miss is logged as OQ-132, a Simulator target entry with the figures and the levers, for the decision that follows the round 3 simulator review. The first-Titan-Engagement row stays reported, not bound (5-14): 0.066 during the fight, 0.073 through the end.
- **Why:** A soldier who dies of the fight's wounds at its end died of the fight; the end steps are the Titan Engagement's own procedure, not a later scene, and the Expedition target counts the same deaths, so a band that stopped at the last card would promise less than it says. The band was set on the Chapter 5 probes' column, which had no end steps, and 5-14 read it that way; but a reading chosen because the figure passes it is what 5-11 was written against, and the probes' column was the measurement available, not the target's meaning. What moved the figure is the retreat clock (5-10), which ends the fights that used to run past round 12 and leaves their Down soldiers to the Titans: 0.037 through the end before it, 0.057 after it, with 0.020 of that the left-behind deaths and about 0.007 the end steps; the clock was chosen at the length that leaves the fewest dead (6, 9, 10, and 12 all leave more), so the miss is the cost of a rule the design needs, and the lever that closes it must be found on the retreat's rescues or on the band, not on the clock. ADR-0014's batch 5 paragraph said the committed run would judge the edge; it has, and the answer is recorded.
- **ADR change:** ADR-0014 `## Amended` (batch 5c): the deaths reading, the miss, and OQ-132; the batch 5 paragraph's "holds at its edge" is superseded. Applied.
- **Glossary change:** none.
- **Chapter impact:** `data/titans/tuning.yaml` `targets.medium.at_the_reference_start.deaths_per_fight` ("at most 0.05, deaths through the end of the Titan Engagement; deaths during the fight reported beside it") and the same words in `abnormals.not_trivial` and `abnormals.ceiling`; `data/engagement/tuning.yaml` `prepared_squad_kill.columns` (a `deaths_per_fight` note naming the reading; the probes' rows are during-the-fight figures until the probes run the end steps, and say so); Chapter 5 section 5.13 (the deaths column's reading; the Medium band's verdict reads Missed, OQ-132, with both figures); Chapter 6 section 6.6 (the same; the bar's deaths rows name the reading). The Constraints section's Chapter 6 bullet and 5-10 carry `Revised by batch 5 (5-19)` lines.

### Chapter impacts of batch 5

**Chapter 1:** none.

**Chapter 2:** sections 2.7, 2.8, and 2.10 and the Mira example (5-3); `data/character/action-catalog.yaml` `ride`, `draw-attention`; `data/character/talents.yaml` `horsemanship`.

**Chapter 3:** the introduction, sections 3.1 and 3.6 (5-2); section 3.5 (5-4); `data/harm/healing.yaml` `day_passes.interim`; `data/harm/treat-injury.yaml` `aftermath_rolls.who_rolls`; `data/harm/engagement-end.yaml` (a note).

**Chapter 4:** section 4.5 (5-3); section 4.6 (5-5, 5-6); section 4.9 (5-2); `data/gear/horses.yaml` `gear_dice.dodge`; `data/gear/falls.yaml` `height.steps`, `triggers`; `data/gear/standard-issue.yaml` `interim_issue.when`.

**Chapter 5:** the introduction or section 5.1 (5-2, 5-10); section 5.2 (5-5, 5-7); section 5.3 (5-1, 5-10); section 5.4 (5-7); section 5.5 (5-3); section 5.6 (the Feint note, 5-1; *Draw Attention*, 5-8); sections 5.7 and 5.11 (5-4, 5-10); section 5.9 (5-6); section 5.10 (5-1, 5-10); section 5.13 (5-10, 5-11); `data/engagement/round.yaml` `turn_order`, `end_steps`, `gm_tracker`; `data/engagement/background-titans.yaml` `retreat`, `ticks`; `data/engagement/engagement-setup.yaml` `retreat_clock`; `data/engagement/engagement-flow.yaml` `starting`, `ending`; `data/engagement/positions.yaml` `distant`, `a_focus_titan_dies`, `falls_land`; `data/engagement/grab.yaml` `grab_lands`; `data/engagement/attention.yaml` `draw_attention`; `data/engagement/tuning.yaml` (5-10, 5-11).

**Chapter 6:** sections 6.1 and 6.2 (5-7); section 6.5 (*Riders*, the design note, *It runs through people*; 5-7, 5-8); section 6.6 (the Draw Attention rows, 5-8; the "no kill" column, the Large band, and the bar's winnable limit, 5-10; the bands, 5-11); `data/titans/tuning.yaml` `abnormals.rule`, `abnormals.winnable`, `targets.large`, `adr_0014_targets_quoted`, `simulator_cases`; `data/titans/index.yaml` `reads_as`; `data/titans/probe-figures.yaml` (re-run under the retreat clock).

**Probes and simulator (`tools/probes/chapter-05/`, `tools/probes/chapter-06/`, `tools/sim/`, their own round):** the retreat clock and the retreat in place of the horizon, the "no kill" column, and the re-run of every committed row (5-10); the sequence with one day between sessions (5-2); the Draw Attention policy from Distant removed (5-8); the bands read from the tuning files and rendered Met or Missed, with the second-seed rule for targets (5-11); Pry Loose's own row (5-12).

**Batch 5b (5-15 to 5-18), by chapter:** Chapter 2 section 2.8 (5-18); Chapter 3 sections 3.5, 3.6 (5-16), 3.17 (5-18); Chapter 4 sections 4.8, 4.9 (5-16), 4.11 (5-18); Chapter 5 sections 5.1 (5-17), 5.6, 5.10, 5.12 (5-15), 5.10 (5-13's marker), 5.11 (5-18); `data/engagement/background-titans.yaml` `retreat.effects.actions` and `order`; `data/engagement/attention.yaml` (the Feint row); `data/engagement/squad-tactics.yaml` `hook-and-cut`; `data/engagement/tuning.yaml` `retreat`; `data/harm/treat-injury.yaml` `care_windows.day.scope`; `data/harm/healing.yaml` `day_passes.interim`; `data/gear/field-repair.yaml` `outside_titan_engagement.when`; `data/gear/carrying.yaml` `shared_out`. No Chapter 6 change. The simulator's retreat policy already makes no Nape strike in a retreat and runs the interim day's window over the Squad, so no re-run is needed for batch 5b.

## Batch 6: the retreat and the Regeneration clock

Ruling on the playtest packet round 3 review (`docs/reviews/playtest-packet-review-3.md`, Source note 2): the sources said "no clock fills during a retreat" without saying whether a Focus Titan's Regeneration clock is one of the clocks.

| Item | Finding | Decision (one line) | ADR change | Glossary change | Chapter impact |
|---|---|---|---|---|---|
| 6-1 | Packet review 3, Source note 2 | Narrow: a retreat stops the Background Titans' clocks and the retreat clock only; every living Focus Titan's Regeneration clock still fills | none | none | Ch5 5.3 end step 3, 5.7 *Regeneration*, 5.10; `background-titans.yaml` `ticks.stopped`, `retreat.effects.no-entries`; `titan-harm.yaml` `regeneration.tick` (applied by the decider) |

### 6-1: which clocks a retreat stops

- **Decision:** The narrow reading. During a retreat no Background Titan's clock fills and the retreat clock does not fill; a living Focus Titan's Regeneration clock still fills at the regeneration end step of every round, retreat or not, and resolves as `titan-harm.yaml` `regeneration.when_full` says (a Broken leg heals to Wounded, the Titan stands, and a soldier at Blind Spot at Open moves to On Body as `grounded_titan` says). `background-titans.yaml` `ticks.stopped` and `retreat.effects.no-entries` now name the two clocks that stop and say the Regeneration clock does not; `titan-harm.yaml` `regeneration.tick` says a retreat does not stop it; Chapter 5 end step 3, section 5.7 *Regeneration*, and section 5.10 read the same. Applied by the decider in this batch, with the renders re-run.
- **Why:** The sentence lives in the file about Background Titans and in the retreat's "no entries" effect, and its purpose is that no more Titans arrive once the Squad is running; a Titan's healing is its body, not the field's traffic, and in 845 to 850 a Titan heals whatever the soldiers do. The wide reading would also hand a fleeing Squad a grounded Titan for the whole retreat, which is a reward for retreating, and it is not what any figure measured: the simulator fills the Regeneration clock at every end step, retreat or not (`tools/sim/engine.py`, the end steps), so every batch 5 row, the Medium deaths band (OQ-132), and the Abnormal's bar were measured under the narrow reading. Simulator impact: none; no case changes. `round.yaml`'s end-step example is the drafter's to fix after this batch.
- **ADR change:** none. ADR-0010's retreat promise (no Nape strike in a retreat, 5-15) is unchanged.
- **Glossary change:** none; the Regeneration entry already says the clock ticks at the end of each round.
- **Chapter impact:** applied: Chapter 5 section 5.3 *End steps* (step 3), section 5.7 *Regeneration* (a sentence), section 5.10 *The retreat* (the first bullet); `data/engagement/background-titans.yaml` `ticks.stopped` and `retreat.effects.no-entries`; `data/engagement/titan-harm.yaml` `regeneration.tick`. The drafter: `data/engagement/round.yaml`'s end-step example, and the packet's three lines (`docs/playtest/`).

## Constraints on the undrafted Phase 1 chapters

Chapters 4 and 5 are drafted; their lists stay as the record the conformance reviews check (Chapter 5's as amended by batch 3, which also rewrote Chapter 6's list and added what the Phase 1 simulator must model).

**Chapter 4, Gear:**
- Adds `item-give`, `pass-item`, and the mount and dismount move to `data/character/action-catalog.yaml`, and cannot be Done without them (OQ-35).
- Defines mounted and dismounted, the horse's Gear Dice and wear (lame at 0), and horse wear from a Pushed dodge (OQ-25, ADR-0015).
- Defines airborne so that a carried soldier is not airborne on their own ODM Gear (OQ-23).
- Tunes Gear Dice ratings against OQ-01's wear rate at Stress 1, and the gas target with Pushes on dodges and Break Attention rather than strikes (OQ-12, OQ-25).
- Sizes fall and other damage against current Health, 1 to 6, since crossed-off boxes are not available to damage (OQ-19, OQ-39, Health boxes; range corrected under OQ-71 item 7). Met by section 4.6.
- Provides a one-line Squad sheet row for Squadmate gear (OQ-29).
- States any medical Squad Supply use as a `bonus-dice-sources.yaml` row (OQ-44).

**Chapter 5, Titan Engagement:**
- The Grabbed state row carries `forbids: [help, cover, reaction]`; a Grabbed soldier can Push (OQ-18).
- The lift and devour are Grab procedure steps, never Behavior Table entries. Keep ADR-0015's victim-turn countdown and Toughness 1 hand. Either rescue structure is allowed; reach and strike penalties must be explicit, and all six OQ-50 cells must meet the band. Keep Hesitate as drafted (OQ-39, OQ-42, OQ-50).
- The crushing Critical Injury crosses off a Health box like any other; a victim whose last box it crosses off is Down in the Titan's hand (Health boxes).
- Defines witnesses for `comrade-grabbed` and `comrade-dies`, when a Titan Engagement ends, how a soldier leaves and what they can do after (OQ-49, OQ-56), and which Position changes a Down soldier's move can make (OQ-45).
- Starting placement does not count as the soldier's own move for Drives (OQ-23).
- Tunes Severity against a Rookie dodging with Agility 3, ODM Gear 2, no dodge Talent, and Stress 1 (ADR-0014; a mounted Rookie's horse is rated 2 and dodges the same, and the interim issue returns it to 2 of 2 at each session's start, OQ-93) and models turn debt for the Attention holder (OQ-17).
- Passes the Jam test (OQ-72): at the Severity and Tempo Chapter 5 sets, the reference Rookie (Agility 3, ODM Gear 2, no dodge Talent, Stress 1 when the fight begins) who holds Attention and dodges for three rounds, receiving cards from every Titan Chapter 5 lets act on them in a round, Pushing when short with Stress rising, with Stress Responses, Help, Covering, and turn debt applied, Jams in no more than a third of those fights. The simplified two-Titan figure at rating 2 is 22.6% at Severity 3; Chapter 5 shows the full model under a third before any Severity or Tempo value is accepted.
- States how a soldier's Positions relative to two Focus Titans relate, and what a horse's or a dead soldier's recorded Position becomes when the Focus Titan it names dies (OQ-61). States whether soldiers who have left a Titan Engagement count as holding the same Position for Field Repair, passing, and taking (OQ-56, Chapter 4's list).
- Decides whether a striker can spend Openings from their own strike (OQ-28's Relentless case).

**Chapter 6, Standard Titans** (rewritten in batch 3):
- **Format and values.** Each standard Titan is a stat block in `data/engagement/titan-format.yaml`'s format that takes Tempo, Nape Depth, Regeneration clock, each Body Part's Toughness, and each tier's Severity from its Size Class row in `data/engagement/size-classes.yaml`, with the five standard Body Parts in order and the standard ladder. Chapter 6 changes no Size Class value: those are Chapter 5's simulator starting values (OQ-78), and a change goes through `tuning.yaml` and the simulator, not a Titan's block. An Abnormal lists every value in full and names its ladder from the closed `tests` list (OQ-81).
- **Behavior Table shape.** Results 1 and 2 terrorize, 3 and 4 control, 5 and 6 kill, one Thrash entry, and the tier rules as `titan-format.yaml` gives them (OQ-80). No entry names death; each harming entry lists its Injury Location and whether its Critical Injury cannot be lethal; entries with a grab effect are marked, since the Closing Hand Scar depends on it (OQ-39, OQ-42). At most one result of each standard table gives a grab effect and at most one a Critical Injury that can be lethal: the targets were measured on the reference table (Grab on 5, Bite on 6), and a second Grab result doubles Grabs per fight. Every entry lists a Position requirement and a fallback, and a holder at In Reach must meet the requirement of at least four results in six, as on the reference table, because the Jam test and the kill were measured with that share of resolved behaviors. No effect type affects a horse (OQ-75); an entry that should needs a new type on the closed list and a decision.
- **ADR-0014 targets, measured per table.** Before a standard Titan is accepted, its table replaces the reference table in the Chapter 5 probes (`tuning.yaml`, `probes`, `commands`) at the reference start (4 Rookie player characters at Stress 1, Wooded, eager strikers dodging every harming behavior) and must hold: **Medium** median kill round 3, 55% to 70% killed by round 3, 0.5 to 0.9 Critical Injuries and at most 0.05 deaths per fight, 0.15 to 0.30 Grabs per fight; **Small** median kill round 2 and at most 1.0 Critical Injuries per fight; **Large** median kill round 3 and no kill within 12 rounds in at most 15% of fights. The Jam test (OQ-72, on OQ-96's reading) is re-run with each table, and its worst cell stays under a third for one and for two Titans of that class. The lone Nape strike, the Grab cells, and gas do not depend on the table and are not re-run. `behavior-procedure.yaml`'s move-up shares are reported for each table by previous behavior and by Broken parts (OQ-80); a table whose kill share by previous behavior exceeds one half at any state is redrawn.
- **Abnormals** are reported under the same probes and not tuned. Their values stay within the Size Class rows' range (Tempo 1 to 2, Nape Depth 3 to 5, Regeneration 2 to 4, Toughness 1 to 3, Severity 1 to 4) unless a decision widens it, and each Abnormal is a simulator case against the PC Critical Injury and death targets.
- **Public and hidden values.** A standard Titan's numbers are public and only an Abnormal's Toughness, Nape Depth, clock length, and ladder are Read facts (OQ-84).
- **Severity ladder** (batch 2b, re-measured on the full builds): a supported Rookie (Agility 3, ODM Gear 2, no dodge Talent, Stress 1, one Help die) dodges Severity 3 29.2% of the time and a lone Veteran (Agility 3, ODM Gear 2, no dodge Talent, Stress 2) 26.1%; a lone Rookie dodges Severity 3 20.7% and Severity 2 49.7%; a lone Levi-grade soldier (Agility 4, ODM Gear 3, Stress 2) dodges Severity 3 38.6% and Severity 4 17.2%. Severity 4 belongs to Large's kill tier, and no standard Small or Medium entry exceeds its class's kill Severity.

**What the Phase 1 simulator must model** (ADR-0014 as amended in batch 3; `tuning.yaml` `simulator_cases` is its specification):
- Every Chapter 1 to 5 rule under published policies for each reference-build action: Read and Call It (a Tactician Reading from Distant every round and Calling It, reported against the Jam test and the PC Critical Injury target), Wings under the standing cadence, initiative swaps, every Squad Tactic alone and in pairs with the six Grab cells, Pry Loose, Help on Break Free, Break Attention rescues, decoy screens from Distant and beside the Attention holder under OQ-81's needs as revised in batch 3b (decoys in a row, the Feint, a hold of Tempo cards), for every table, Background Titans and the retreat with clock lengths measured against a retreat rate per Titan Engagement, treatment in the care windows between fights, Death Rolls, and the interim issue between sessions (a horse returns to 2 of 2; ODM Gear worn at or above the row carries).
- The targets as amended: the lone Rookie's 8% to 14% band on the fresh cut, with the in-fight lone cut beside it at each table's Tempo and Nape Depth, and the Levi-grade "about 50%" (OQ-79, batch 3b); comrades close as one comrade in reach, with the reference Squad's Grab death share reported (OQ-95); each target under its stated baseline policy with sensitivity rows beside it (OQ-98).
- Eyes and arm Toughness for every class, Large against the PC Critical Injury and death targets, and Medium at Tempo 2 and the other rejected alternatives as sensitivity rows (OQ-78).
- The Jam test inside the full-fight model, with helpers' cards, Positions, and actions deciding who can Help and Cover (OQ-96).
- The reports ADR-0014 already names: the Health 3 Squad, the Health 2, 5, and 6 builds, the template Squad, and the Flier.
- Round-time counters (tracker writes, ladder evaluations, pools, dodges, Fear Rolls, and Gas Rolls per round) for one and for two Focus Titans, beside the timed paper test OQ-97 orders.
- The Expedition targets once the Expedition rules exist.
- **Revised by batch 5:** In the Chapter 6 bands, "no kill within 12 rounds" reads "no kill", the share of fights that end with the Focus Titan alive under the retreat clock (the Large Titan: no kill in at most 15% of fights), and the Medium deaths band is measured under the clock, where it holds at its edge, 0.0499 and 0.0482 against at most 0.05 (5-10); every "about" target carries the band 5-11 gives, and the simulator judges each Met or Missed against it.
- **Revised by batch 5 (5-19):** The Medium deaths band reads deaths through the end of the Titan Engagement, on which it is Missed (0.0573 at the reference start; 0.0546 and 0.0552 in the bar's orders) and logged as OQ-132; "holds at its edge" above was the during-the-fight reading.
