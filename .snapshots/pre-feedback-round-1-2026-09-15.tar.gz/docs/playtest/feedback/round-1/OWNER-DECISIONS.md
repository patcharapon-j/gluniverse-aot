# Playtest packet feedback, round 1: owner decisions

Given 2026-09-15, in answer to the five research files in this folder. Nothing is applied yet. When fixing starts, a Fable decider turns these into a decision batch (DECISIONS, ADRs, CONTEXT, OQ entries) before any chapter or YAML changes.

| # | Topic | Owner decision | Research file |
|---|---|---|---|
| 1 | Manual character creation | Add both the Template Build and a freer choose-what-you-get build, alongside the lifepath roll. The GM allows either per campaign. | `character-creation-and-talents.md` |
| 2 | Talent list size | Grow past the ~60 recommendation: ship the full Talent list as part of the playtest. | `character-creation-and-talents.md` |
| 2b | Non-canon Talents | Accepted, with guardrails as recommended. | `character-creation-and-talents.md` |
| 3 | Critical Injuries | Cause variety, confirmed. No mental Critical Injuries, because Scars, Fear Rolls, Stress Responses, and Grief already cover lasting mental harm. Left and right locations and Injury Type as recommended. | `critical-injuries.md` |
| 4 | Lost limbs | Graded, not a hard ban. Losing one limb makes things harder; losing both is severe. The decider sets exact effects for one arm, both arms, one leg, and both legs. | `critical-injuries.md` |
| 5 | Fear and Stress results | May touch gear (dropped blades, burned gas) and may force actions or moves (flee, cling, berserk). | `stress-and-fear.md` |
| 6 | Canon and era | No Marley for now. Otherwise as recommended: era lock 845 to 850, later inventions as Canon Clock Discoveries, invented items only through Requisition or Discovery, Nape-only kills, Funding and Scarcity with no prices, Titans before gear in Phase 2, nothing new in gear or Titans before the playtest, the charter recorded as an ADR. | `gear-and-canon-expansion.md` |
| 7 | Where deaths come from | Owner leans "fights". Explanation given; awaiting confirmation (see below). | `squadmates-and-lethality.md` |
| 8 | Death Roll odds | Take the recommendation: keep the Death Roll as written for the playtest and revisit on playtest data. | `squadmates-and-lethality.md` |
| - | Squadmates | As recommended: keep 4 PCs plus 2 Squadmates as the default; allow fewer with the stated cost. | `squadmates-and-lethality.md` |

## Open

- Item 7 needs the owner's confirmation before the decider settles OQ-132.
- Item 7 follow-up: owner wants each fight lethal on its own, to suit AoT, and chose both A (playtest with 4 PCs and no Squadmates) and B (retune Titans harder so a PC dies about every 8 typical fights even with Squadmates). Timing (both before the playtest, or A now and B after) is being confirmed.

## Minimal rules for Talent hooks (owner, 2026-09-15)

The owner chose minimal rules to work with (not tags) for Expeditions, Requisition, and human-versus-human combat. Proposal: `minimal-rules-expeditions-requisition-combat.md`. Owner questions in its section 5, all answered as recommended:

1. Human conflict is in scope. First foes: Military Police, bandits, Garrison sentries. No Marley.
2. Guns are as lethal as Titan fights (a landed musket hit puts a Rookie Down).
3. No Requisition before the first Expedition. The first playtest uses the reference kit; Requisition starts at the first Downtime.
4. Pistol, musket, and the shot kind are accepted as the one exception to "nothing new in gear".
5. Straggler victims are picked at random, not by the players.
6. Add a Fear Roll trigger for a soldier's first human kill.
7. Downtime is a fixed 7 days for the playtest.
8. Hazard table heat follows item 7: as written under A alone, hotter if B applies before the playtest. The decider settles it once item 7's timing is confirmed.
9. Keep "bare hands never kill": Crush puts a foe out cold; only Cut or Pierce kills.

The proposal's section 6 goes to the Fable decider.
- Two proposals both claim ADR-0016 (Injury Type, canon charter), and the Talent guardrails want an ADR too. The decider numbers them.

## Prerequisite

`tools/sim/rules.py` line 624 still parses "the retreat clock included". Decision batch 6 (OQ-134) reworded `data/engagement/background-titans.yaml` `ticks.stopped`, so `tools/sim/run.py` fails on the live YAML. Fix this before any rerun.

## Process for the fixes

- Implementation: Opus.
- Research: Opus or Fable, chosen per task.
- Decisions: a Fable decider, as needed.
- Final review: Fable, as in the Phase 1 full reviews. Then fix every issue, concern, and inconsistency it raises.
