# Titans act from Behavior Tables, not ordinary turns

A Titan is modeled as a natural disaster rather than a combatant: it has no normal turn and acts from a Behavior Table. How a Titan dies is set by ADR-0007, and how the Squad works together against it by ADR-0010. We chose this over tactical turn-by-turn titan combat and over abstract single-roll resolution because it keeps the Titan World feel: read it, work around it, set it up, then kill.

## Considered Options

- Tactical combat where the Titan is a combatant with turns: rejected, it turns titans into big humans and loses the disaster feel.
- One team roll per Titan Engagement: rejected, too thin for the game's headline pillar.

## Amended

After the final design review (2026-09-14), removed wording that required breaking Body Parts before any kill and that gave each Squad member a fixed job. Both contradicted ADR-0010.
