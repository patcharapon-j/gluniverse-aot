# Titan attacks bypass Health

Humans track a small Health pool plus Critical Injuries rolled by Injury Location, and Titan attacks skip Health entirely and inflict Critical Injuries directly. This keeps Titan World's body-part injuries with only one tracked number, and stops a soldier from shrugging off a Titan's swat because they happen to have Health left.

## Considered Options

- Titan World's per-location wound states with no pool: rejected, too much bookkeeping per hit.
- Alien's Health pool with a generic critical injury table: rejected, loses the body-part identity the injuries need.

## Amended

After the owner decision on Health boxes (2026-09-14): Health is half of Strength plus Agility, rounded up, kept as a row of boxes. Each untreated Critical Injury crosses off one box and treating it gives the box back; Titan attacks still inflict Critical Injuries directly and cause no Health loss of their own. Damage marks the boxes left. A soldier whose current Health is 0, from crossed-off boxes, damage, or both, is Down, which replaces the earlier rule that three untreated Critical Injuries put a soldier Down; a row that says Down still does. Damage that brings current Health to 0 still inflicts one immediate Critical Injury; a Critical Injury that crosses off the last box does not. A day passing restores Health lost to damage, not crossed-off boxes.
