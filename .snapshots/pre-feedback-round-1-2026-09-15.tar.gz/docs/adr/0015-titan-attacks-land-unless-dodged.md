# Titan attacks land unless dodged, and countdowns run on soldier turns

Titan behaviors do not roll attack dice. Each has a Severity, and it lands unless the target's Reaction (Agility plus ODM Gear Dice) scores that many successes. One Reaction covers every card from that Titan in the round, and Titans cannot be blocked. A Grab counts down in the victim's turns, not the Titan's cards: lifted after their next turn, devoured after the one after. While holding someone the grabbing hand has Toughness 1, and the Grab's crushing Critical Injury cannot be lethal.

The final design review showed that rolled Titan attacks roughly doubled lethality, that one Reaction per card starved the soldier holding Attention of turns, and that counting the Grab in cards let a high-Tempo Titan eat a soldier before any comrade acted. Soldier turns give every Titan the same rescue window.

## Amended

After the open-question decisions (2026-09-14, OQ-25): the Reaction's Gear Dice come from ODM Gear, or from the horse while the soldier is mounted, one item per roll (ADR-0006). When a dodge made with the horse is Pushed, its Gear Dice showing 1 wear the horse, not ODM Gear (ADR-0004), and the Push does not by itself raise the Gas Roll. Chapter 4 defines mounted. (The wear sentence was tightened after the conformance review round 2, OQ-71, which found it read as wear on every Push.)
