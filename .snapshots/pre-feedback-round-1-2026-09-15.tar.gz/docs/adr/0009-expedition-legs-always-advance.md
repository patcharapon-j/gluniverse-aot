# Expedition Legs always advance

An Expedition is a pointcrawl of Legs between Waypoints, and every Leg reaches the next Waypoint even on a failed roll. Failure instead costs double Squad Supply and worsens the hazard, which grows harsher with distance from the Walls and with days outside (+1 per night camp). Adapted from Coriolis: The Great Dark's delve procedure, this models a formation that cannot stop mid-ride and avoids hexcrawl bookkeeping.

The guarantee covers navigation, not survival: a Squad that retreats from a Chase or Titan Engagement falls back to the previous Waypoint. Legs are never ridden at night, and night camps use calmer hazard results, except against Abnormals.

## Amended

After the final design review (2026-09-14): failed Legs no longer cost gas (horses carry the Squad; gas drains only in Titan Engagements and Chases), and retreat and night rules were added.
