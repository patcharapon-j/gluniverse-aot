# Wings of Freedom

A private tabletop RPG for running Attack on Titan campaigns on the Year Zero Engine, set on Paradis during the walls era (845 to 850).

## Language

### Military

**Survey Corps**:
The military branch that ventures beyond the Walls, and the branch the Squad serves in.
_Avoid_: Scout Regiment, Recon Corps, Scouts

**Garrison**:
The military branch that defends and maintains the Walls.
_Avoid_: Stationary Guard

**Military Police**:
The elite interior branch, open only to top graduates.
_Avoid_: MP Brigade, Interior Police

**Training Corps**:
The three-year program every soldier completes before joining a branch.
_Avoid_: Cadet Corps, academy

**Cadet**:
A member of the Training Corps who has not yet graduated.
_Avoid_: trainee, recruit

**Rank**:
A soldier's place in the chain of command: Private, Squad Leader, or Section Commander.
_Avoid_: level, grade

**Commendations**:
The track of a soldier's standing with command, raised by objectives, following orders, and bringing soldiers home, lowered by disobedience, and used to trigger promotion.
_Avoid_: reputation, renown

**Funding**:
The Survey Corps' political and financial backing, rated 1 to 6, which sets what Requisitions and resupply can deliver.
_Avoid_: budget, wealth

**Faction**:
One of the powers inside the Walls the Squad deals with: Survey Corps Command, Garrison, Military Police, Church of the Walls, Nobility, or Underground.

**Faction Standing**:
The Squad's relationship with one Faction, from -3 to +3, added to the dice for dealings with that Faction.
_Avoid_: reputation

**HQ Upgrade**:
An improvement to the Squad's headquarters, such as stables, a workshop, an infirmary, a training yard, or a research lab, that improves a Downtime Action.
_Avoid_: base upgrade, stronghold

**Squad**:
The Survey Corps unit made up of the player characters and their Squadmates.
_Avoid_: party, team, group

**Squadmate**:
A named NPC soldier who rides into the field with the player characters, can be directed by any player, can be targeted by Titans like anyone else, never Pushes or Covers, and can be promoted to a player character.
_Avoid_: hireling, retainer, backup character

**Squad Pool**:
The Squadmates currently serving in the Squad.
_Avoid_: roster, reserve

**Wing**:
A Squadmate's attachment to one player character during a Titan Engagement. The Squadmate acts right after that character.
_Avoid_: follower, buddy

**Squad Tactic**:
A team move owned by the Squad rather than any one soldier, usable once per Titan Engagement when its condition is met.
_Avoid_: maneuver, team move

### Character

**Lifepath**:
The character creation procedure that walks a Cadet through their origin and three years of Training Corps events.
_Avoid_: background, backstory generator

**Graduation Exam**:
The optional played prologue of three Trials whose Merit replaces the third Training Year's performance roll and so helps decide each Cadet's Class Rank.

**Trial**:
One of the three tests of the Graduation Exam: the ODM balance test, the Titan dummy course, and the squad field exercise.

**Class Rank**:
A graduate's final standing in their class. The Top 10 are offered a place in the Military Police.
_Avoid_: grade, score

**Specialty**:
A character's trained specialization, gained through the Lifepath, which grants bonuses but never exclusive permission to attempt anything: Slayer, Flier, Hunter, Tactician, Leader, Medic, Engineer, Rider, or Brawler.
_Avoid_: class, career, profession, role

**Talent**:
A narrow trained ability that adds dice or bends a rule, but only for the actions it names from the Action Catalog.
_Avoid_: skill, feat, perk

**Action Catalog**:
The complete list of named actions a soldier can take, which Talents reference by name.
_Avoid_: move list

**Wits**:
The attribute for planning, mechanics, and medicine.
_Avoid_: Logic, Intelligence

**Instinct**:
The attribute for gut calls, survival, reading people, and Reading Titans.
_Avoid_: Insight, Intuition

**Haven**:
What a soldier has to return to, which lets them recover Stress and Grief during downtime.
_Avoid_: Anchor (reserved for ODM Gear)

**Origin**:
Where a Cadet was born and raised, the first stage of the Lifepath.
_Avoid_: background, homeland

**Training Year**:
One of the three Lifepath stages spent in the Training Corps, each with a training event and a performance roll. The Graduation Exam, if played, replaces the third year's performance roll.

**Merit**:
What a Cadet earns from Training Year performance, which decides their Class Rank.
_Avoid_: XP, score

**Retirement**:
A soldier leaving play at five Scars to become an NPC instructor or Squad contact.
_Avoid_: discharge

**Drive**:
What keeps a soldier fighting, written as a "When I ..." trigger, which lets them shrug off one Fear Roll result per session while that trigger is met by their own act, a Position they moved into, or their own ODM flight. Position triggers require a Titan Engagement; turn triggers work outside one only when a rule extends them, while Freedom's flight trigger can work anywhere.
_Avoid_: motivation, goal

### Rolls and harm

**Push**:
Re-rolling base and Stress Dice that did not show a 6, at the cost of 1 Stress, allowed only if no Stress Die showed a 1. 1s on Gear Dice stay and wear that gear.
_Avoid_: reroll

**Stress**:
A soldier's mounting fear and adrenaline, which makes them both more capable and more likely to break.
_Avoid_: panic, strain, sanity

**Stress Dice**:
Dice added to attribute rolls equal to current Stress, unless the roll explicitly excludes them, which can succeed like any die but can also set off a Stress Response.

**Stress Response**:
The harmful reaction set off when a Stress Die shows a 1.
_Avoid_: panic, freak-out

**Resolve**:
A soldier's steadiness, half of Instinct plus Empathy, rounded up, plus 1 per Scar and minus 1 per point of Grief, which counts against Stress Response and Fear Roll results.
_Avoid_: willpower, sanity

**Gear Dice**:
Dice contributed by equipment. When a Pushed roll is final, each Gear Die showing 1 wears that equipment down by 1.

**Help**:
Adding 1 die to a comrade's roll, up to 3 helpers. In a Titan Engagement it spends the helper's action and needs the same Position or one step away; outside one, the rule that calls for the roll states who can Help and what it spends.
_Avoid_: assist

**Bonus Dice**:
Dice from Help, Openings, and situational advantages, which together can add at most 4 to a roll.
_Avoid_: advantage, modifier

**Rally**:
An Empathy action that clears a comrade's Stress Response, but not their Stress.
_Avoid_: inspire

**Covering**:
Taking on a comrade's Stress from their Push, so that the Push adds no new Stress Die.
_Avoid_: sharing stress

**Reaction**:
A dodge or block made when an enemy acts against the soldier, outside the soldier's own turn. It spends the soldier's earliest turn, starting with this round's, whose move and action are both unspent. Against a Titan, one dodge covers all of that Titan's cards for the round, and blocking is impossible.
_Avoid_: interrupt, free defense

**Fear Roll**:
A roll forced by a horrifying event, such as a Titan seizing a comrade, rather than by the dice.
_Avoid_: Panic Roll

**Scar**:
A lasting named trauma with a mechanical effect, which also raises the soldier's minimum Stress and Resolve by 1.
_Avoid_: mental trauma, madness

**Grief**:
The weight a soldier carries after a comrade dies, gained by the fight's participants when it ends, or by the Squad after other deaths and any Fear Rolls they cause. Each point lowers Resolve by 1, up to 3 held, until dealt with during Downtime.

**Health**:
How much punishment a character can absorb before they can no longer act: half of Strength plus Agility, rounded up, kept as a row of boxes. Each untreated Critical Injury crosses off one box, up to Health; damage marks the boxes left; at 0 the soldier is Down.
_Avoid_: HP, hit points

**Critical Injury**:
A lasting wound tied to an Injury Location, labeled with whether it puts the soldier Down, whether it is lethal and how fast, its effect, and its healing time. Titan attacks inflict these directly, without reducing Health first; each one crosses off a Health box until it is treated, and a later injury to the same location is rolled with a worsening bonus.
_Avoid_: wound, crit

**Down**:
The state of a human at 0 current Health, whether from damage, from untreated Critical Injuries crossing off every Health box, or both, or holding an untreated Critical Injury whose row says so, who can do little more than crawl. Reaching 0 current Health through damage also inflicts an immediate Critical Injury.
_Avoid_: Broken (reserved for Body Parts), knocked out

**Death Roll**:
The Strength roll, which cannot be Pushed, made each time a lethal Critical Injury's time limit runs out, to see whether the soldier dies.
_Avoid_: death save

**Injury Location**:
Where a human's Critical Injury lands: arm, leg, torso, or head.
_Avoid_: hit location, Body Part

### Titans

**Titan**:
A mindless, regenerating giant that dies only when its Nape is destroyed.
_Avoid_: Pure Titan, Mindless Titan, giant, monster

**Shifter**:
A human who holds one of the Nine Titans and can transform at will. Always GM-controlled: either a threat, or an allied asset inside an Operation Frame.
_Avoid_: Titan Shifter, Intelligent Titan

**Loses Control Table**:
The table that can turn an allied Shifter into a hazard during an Operation Frame.

**Intent Table**:
The table a Shifter acts from in place of an Attention Ladder, describing deliberate tactics such as false attacks and guarding the Nape.
_Avoid_: tactics table

**Hardening**:
A Shifter's ability to armor a Body Part or its Nape, raising Toughness or blocking Nape strikes until the hardening breaks.
_Avoid_: armor, crystal

**Extraction**:
What reaching a Shifter's Nape Depth starts instead of a kill: a clock that ends in the human being captured or escaping.
_Avoid_: kill, capture roll

**Shifter Stamina**:
The reserve a Shifter spends each time it regenerates. At 0, the human must emerge.
_Avoid_: energy, consciousness

**Abnormal**:
A Titan whose behavior breaks the standard pattern and that uses its own Behavior Table.
_Avoid_: Deviant, Aberrant

**Size Class**:
A Titan's height category: Small (3 to 5 m), Medium (6 to 10 m), or Large (11 to 15 m).

**Nape**:
The only location where a strike can kill a Titan.
_Avoid_: weak point, weak spot

**Nape Depth**:
The successes a single Nape strike needs to kill a Titan, set by Size Class, or by an Abnormal's own stat block. A strike that falls short turns its successes into Openings.

**Body Part**:
A breakable location on a Focus Titan other than the Nape, such as the eyes, an arm, or an ankle.
_Avoid_: limb, hit location, Injury Location

**Body Part State**:
Intact, Wounded, or Broken. A Broken Body Part disables the behaviors that use it until it regenerates.
_Avoid_: severed, crippled, disabled

**Toughness**:
The successes, accumulated across strikes, needed to move a Body Part one state toward Broken.
_Avoid_: armor, defense

**Regeneration**:
A Titan's single healing clock, which ticks at the end of each round at a pace set by Size Class, or by an Abnormal's own stat block. When it fills, the most damaged Body Part recovers one state and all Openings are erased.
_Avoid_: healing, recovery

**Behavior Table**:
The table that decides what a Titan does. Titans act from it instead of taking ordinary turns.
_Avoid_: attack table, AI

**Thrash**:
The default behavior every Behavior Table falls back to when no other entry can legally happen.

**Next Behavior**:
A Focus Titan's upcoming Behavior Table result, rolled in advance and hidden until it happens or is Read.
_Avoid_: queued attack

**Telegraph**:
A behavior that announces what the Titan's next card will do.
_Avoid_: tell, wind-up

**Grabbed**:
Held in a Titan's hand, unable to Help, Cover, or make a Reaction. The Titan lifts the soldier after their next turn and devours them after the turn after that, unless they get free.
_Avoid_: seized, caught

**Attention**:
The one soldier or decoy a Focus Titan is fixed on at any moment, which its Behavior Table acts against; nothing holds it when no rung, its holder, or the cards pick one out, as at the start of a Titan Engagement. A soldier holding Attention cannot strike the Nape.
_Avoid_: aggro, threat, focus

**Attention Ladder**:
The ranked stimuli a Focus Titan turns its Attention toward each time it acts. The standard order is: hooked into its body, nearest person in reach, just hurt it (until the end of its next card that resolves a behavior), loudest or brightest, nearest (the closest Position). Abnormals have their own ladder.
_Avoid_: priority list, aggro table

**Draw Attention**:
An action that makes the soldier the loudest or brightest stimulus on the Attention Ladder until the end of the Titan's next card that resolves a behavior.
_Avoid_: taunt, bait roll

**Break Attention**:
An action that shifts a Focus Titan's Attention onto a decoy, such as a flare, a riderless horse, a thrown cloak, or the soldier's own Feint, for as many of its next cards as its Tempo. It is easiest for the soldier holding the Titan's Attention, and harder for each decoy the Titan has fallen for since one of its cards last resolved a behavior.
_Avoid_: taunt, distract

**Feint**:
A decoy for Break Attention: the soldier's own pass across a Focus Titan's face from In Reach or On Body, made with working ODM Gear, mounted on their own horse that is not lame, or on foot against a grounded Titan. It spends nothing and needs 1 more success.
_Avoid_: bait, taunt

**Severity**:
The successes a Reaction needs to avoid a Titan's behavior.
_Avoid_: attack dice, difficulty

**Position**:
Where a soldier is relative to a Focus Titan: Distant, In Reach, On Body, or Blind Spot.
_Avoid_: range, zone

**Blind Spot**:
The Position out of a Focus Titan's sight with its Nape within reach, anchored to terrain rather than hooked into the Titan, and the only Position a Nape strike can be made from. Making a Nape strike counts as hooking into the Titan.
_Avoid_: rear, behind

**Opening**:
A token on a Titan created by successes beyond Breaking a Body Part, extra successes on Break Attention, every success of a Nape strike that falls short, or a rule that names it, such as Relentless. Any comrade of the soldier who created it can spend it as a Bonus Die on a Nape strike until Regeneration erases it; its creator never can.
_Avoid_: advantage, setup bonus

**Tempo**:
How many initiative cards a Titan draws each round.
_Avoid_: speed, ferocity

**Chase**:
A pursuit between riders and a Titan, resolved across Chase Bands.
_Avoid_: retreat roll

**Chase Band**:
The gap in a Chase: Grabbing Distance, Close, Far, or Escaped.
_Avoid_: range, Position

**Titan Engagement**:
A scene in which the Squad confronts one or more Titans.
_Avoid_: encounter, combat, battle

**Focus Titan**:
The Titan in a Titan Engagement that is tracked in full, with Body Parts, Attention, and a Behavior Table.

**Background Titan**:
A Titan in a Titan Engagement that is run as a closing clock and enters as a second Focus Titan when the clock fills.

**Retreat clock**:
The clock every Titan Engagement carries, filled one segment at the end of each round after the Background Titans' clocks and never by a flare; when it fills, the Titan Engagement becomes a retreat. The rule that begins the Titan Engagement names its length, or the interim setup gives 8.

**Read**:
Observing a Titan during a Titan Engagement to learn facts about it, such as its Next Behavior, for the whole Squad.
_Avoid_: scan, analyze, study

**Call It**:
Spending a Read to warn whoever the Next Behavior targets, giving them bonus dice on their Reaction.
_Avoid_: warning

**Titan Research**:
The campaign-level record of what humanity has learned about Titans, which unlocks options for the whole Squad.
_Avoid_: lore, intel

**Research Points**:
What the Survey Corps earns from Reads, captures, surviving Abnormals, and research work, spent on Discoveries. Separate from Squad Points.
_Avoid_: science points

**Discovery**:
A permanent piece of Titan Research with a cost, possible prerequisites, and a lasting effect. Some stay locked until the Canon Clock reaches them.
_Avoid_: unlock, tech

### Field

**ODM Gear**:
The gas-powered grappling harness soldiers use to fly between anchor points and reach a Titan's Nape.
_Avoid_: 3DMG, 3D Maneuver Gear, maneuver gear

**Anchor Rating**:
How well a battlefield holds ODM Gear anchors: Open, Sparse, Wooded, Urban, or Giant Forest. It decides which Position changes ODM Gear allows.
_Avoid_: terrain type

**Jam**:
ODM Gear worn down to 0, which stops working and drops an airborne soldier.
_Avoid_: breakdown, malfunction

**Blade Set**:
One pair of ODM blades, the unit in which blades are carried, counted, and lost.
_Avoid_: blade pair, blades

**Gas Rating**:
The gas left in a soldier's current canister, which drops as Gas Rolls turn up 1s.
_Avoid_: fuel, canister count

**Gas Roll**:
Two dice rolled each round a soldier uses ODM Gear, three after a Pushed roll that used ODM Gear. Each 1 lowers the Gas Rating by 1.
_Avoid_: supply roll

**Standard Issue**:
The gear every soldier receives when they join the Squad and whenever a rule issues it, such as before each Expedition, scaled by Funding: ODM Gear, gas canisters, Blade Sets, a horse, and a Specialty's kit.
_Avoid_: starting kit

**Requisition**:
Requesting gear beyond Standard Issue from command during Downtime, rolled against the item's Scarcity.
_Avoid_: purchase, shopping

**Scarcity**:
How hard an item is to Requisition: Standard, Limited, or Rare.
_Avoid_: rarity, cost

**Overloaded**:
Carrying more than Strength + 4 items, which makes every ODM move cost the soldier's action as well.
_Avoid_: encumbered

**Squad Supply**:
The shared pool of rations, flares, and medical supplies the Squad draws on in the field.
_Avoid_: provisions, party supplies

**Formation Post**:
The place the whole Squad rides in an Expedition formation, assigned by command: Vanguard, Flank Scout, Signal Relay, Center, Supply Wagon, or Rear Guard. It changes only at a Waypoint.
_Avoid_: role, Position (reserved for Titan Engagements)

**Expedition**:
A Survey Corps operation beyond the Walls, travelled as a chain of Legs between Waypoints.
_Avoid_: sortie, delve, journey

**Leg**:
One stretch of an Expedition between two Waypoints. The Squad always reaches the next Waypoint, but failure makes the arrival costly.
_Avoid_: stage, shift, hex

**Pace**:
The speed Command sets for a Leg: Steady, or a Hard Ride that arrives faster at a higher cost.
_Avoid_: speed

**Distance Band**:
How far an Expedition has pushed from the Walls: Near, Far, or Deep. Deeper bands make Leg hazards worse.
_Avoid_: depth, zone

**Waypoint**:
A named stopping point on an Expedition route, such as a forest, an abandoned town, or a supply depot.
_Avoid_: node, location

### Campaign

**Downtime**:
The time the Squad spends inside the Walls between Expeditions.
_Avoid_: shore leave, rest

**Downtime Action**:
One of the two things each player character does during Downtime: Recover, Visit Haven, Train, Requisition, Maintain Gear, Investigate, or Contribute to Research.

**Squad Action**:
The one shared Downtime Action the Squad takes together, such as recruiting Squadmates, lobbying for Funding, upgrading HQ, or Honoring the Fallen to ease everyone's Grief.

**XP**:
A soldier's personal advancement points, earned from end-of-session questions and spent on Talents.
_Avoid_: experience

**Squad Points**:
Advancement points earned by the Squad as a whole and spent on Squad Tactics and HQ upgrades.
_Avoid_: crew points

**Canon Clock**:
The dated canon events that happen on schedule unless the player characters interfere.
_Avoid_: timeline, metaplot

**Campaign Year**:
The year the campaign has reached, from 845 to 850, recorded before the Lifepath and advanced only by the Canon Clock rules. Origin conditions are tested against it.
_Avoid_: start year, current date

**Divergence Hook**:
A condition on a Canon Clock event describing how that event changes if the Squad has done something.

**Plan Roll**:
The Wits roll made before an Expedition that earns Intel Questions and Preparation Points.
_Avoid_: planning check

**Intel Question**:
A question about an upcoming mission that the GM must answer truthfully.

**Preparation Points**:
Points spent during a mission to reveal, by flashback, something the Squad prepared beforehand.
_Avoid_: flashback points

**Operation Frame**:
A reusable template for a set piece, made of an objective clock, a threat clock, special actions, and outcomes, such as Wall Defense or a Capture Operation.
_Avoid_: scenario type, mini-game

**Mission Brief**:
The GM's record of an assigned mission: objective, route, Distance Band, expected Titans, one complication, and rewards.
_Avoid_: adventure, scenario

**Canon Proximity**:
The campaign setting for how close the Squad serves to the canon cast: Close or Distant.

**Canon Tie**:
A character's optional personal link to one canon character, drawn from their Lifepath.
_Avoid_: canon connection
